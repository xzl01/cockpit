cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Managing software updates": [
  null,
  "პროგრამული უზრუნველყოფის განახლების მართვა"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "პროგრამების განახლებები"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kpatch"
 ],
 "package": [
  null,
  "პაკეტი"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "უსაფრთხოება"
 ],
 "updates": [
  null,
  "განახლებები"
 ],
 "yum": [
  null,
  "yum"
 ]
});
