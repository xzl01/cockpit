cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Managing software updates": [
  null,
  "Software-updates beheren"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Software updates"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "package": [
  null,
  "pakket"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "veiligheid"
 ],
 "yum": [
  null,
  "yum"
 ]
});
