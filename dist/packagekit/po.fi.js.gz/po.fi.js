cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 exited with code $1": [
  null,
  "$0 poistui koodilla $1"
 ],
 "$0 failed": [
  null,
  "$0 epäonnistui"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 tapettu signaalilla $1"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 package": [
  null,
  "$0 paketti",
  "$0 pakettia"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 paketti vaatii järjestelmän uudelleenkäynnistyksen",
  "$0 pakettia vaatii järjestelmän uudelleenkäynnistyksen"
 ],
 "$0 security fix available": [
  null,
  "$0 turvallisuuspäivitys saatavilla",
  "$0 turvallisuuspäivitystä saatavilla"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 palvelu on käynnistettävä uudelleen",
  "$0 palvelua on käynnistettävä uudelleen"
 ],
 "$0 update available": [
  null,
  "$0 päivitys saatavilla",
  "$0 päivitystä saatavilla"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 ", including $1 security fix": [
  null,
  ", mukaan lukien $1 turvallisuuspäivitys",
  ", mukaan lukien $1 turvallisuuspäivitystä"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "1 minute": [
  null,
  "1 minuutti"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "20 minutes": [
  null,
  "20 minuuttia"
 ],
 "40 minutes": [
  null,
  "40 minuuttia"
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "60 minutes": [
  null,
  "60 minuuttia"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Paketti vaatii uudelleenkäynnistyksen, jotta päivitykset tulevat voimaan:",
  "Jotkut paketit vaativat uudelleenkäynnistyksen, jotta päivitykset tulevat voimaan:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Palvelu on käynnistettävä uudelleen, jotta päivitykset tulevat voimaan:",
  "Joitakin palveluja on käynnistettävä uudelleen, jotta päivitykset tulevat voimaan:"
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Hallinta Cockpit-verkkokonsolilla"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "All updates": [
  null,
  "Kaikki päivitykset"
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-roolien dokumentaatio"
 ],
 "Apply kernel live patches": [
  null,
  "Asenna ytimen live-paikkaukset"
 ],
 "Applying updates": [
  null,
  "Asennetaan päivityksiä"
 ],
 "Applying updates failed": [
  null,
  "Päivitysten asentaminen epäonnistui"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Todennus vaaditaan etuoikeutettujen tehtävien suorittamiseen Cockpit Web Console:ssa"
 ],
 "Automatic updates": [
  null,
  "Automaattiset päivitykset"
 ],
 "Automatically using NTP": [
  null,
  "Käytetään automaattisesti NTP:tä"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Käytetään automaattisesti lisättyjä NTP-palvelimia"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Käytetään automaattisesti tiettyjä NTP-palvelimia"
 ],
 "Automation script": [
  null,
  "Automaatio-komentosarja"
 ],
 "Available updates": [
  null,
  "Saatavilla olevat päivitykset"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Bug fix updates available": [
  null,
  "Virheenkorjauspäivityksiä saatavilla"
 ],
 "Bugs": [
  null,
  "Viat"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Cannot forward login credentials": [
  null,
  "Kirjautumistietoja ei voi välittää eteenpäin"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tapahtumaa ei voi aikatauluttaa menneisyyteen"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Change system time": [
  null,
  "Vaihda järjestelmän aika"
 ],
 "Check for updates": [
  null,
  "Etsi päivityksiä"
 ],
 "Checking for package updates...": [
  null,
  "Tarkistetaan pakettipäivityksiä ..."
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "Checking software status": [
  null,
  "Tarkistetaan ohjelmiston tila"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManagerin ja Firewalld:n Cockit-asetukset"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ei saanut yhteyttä koneeseen."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit on palvelinhallintatyökalu, joka tekee ylläpidon helpoksi selaimen kautta. Liikkuminen päätteen ja verkkokäyttöliittymän välillä ei ole ongelma. Cockpitissä aloitettu palvelu voidaan lopettaa päätteessä. Samaten päätteessä näkyvä virheilmoitus voidaan nähdä myös Cockpitin journal-näkymässä."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ei ole yhteensopiva järjestelmän ohjelmiston kanssa."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ei ole asennettu järjestelmässä."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit on täydellinen uusille ylläpitäjille. Sen avulla voi tehdä helposti toimenpiteitä kuten tallennustilan hallintaa, lokien tarkistamista sekä palveluiden käynnistämistä ja lopettamista. Voit monitoroida ja hallita useita palvelimia samanaikaisesti. Lisää ne yhdellä napsautuksella ja koneesi katsovat kavereidensa perään."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kerää ja paketoi diagnostiikkaa ja tukitietoja"
 ],
 "Collect kernel crash dumps": [
  null,
  "Kerää ytimen kaatumisvedoksia"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Connection has timed out.": [
  null,
  "Yhteys aikakatkaistiin."
 ],
 "Continue": [
  null,
  "Jatka"
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Create new task file with this content.": [
  null,
  "Luo uusi tehtävätiedosto tällä sisällöllä."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Danger alert:": [
  null,
  "Vaaran hälytys:"
 ],
 "Delay": [
  null,
  "Viive"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Disabled": [
  null,
  "Ei käytössä"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "Downloaded": [
  null,
  "Ladattu"
 ],
 "Downloading": [
  null,
  "Ladataan"
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "Edit": [
  null,
  "Muokkaa"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Enable": [
  null,
  "Ota käyttöön"
 ],
 "Enabled": [
  null,
  "Käytössä"
 ],
 "Enhancement updates available": [
  null,
  "Parannuspäivitykset saatavilla"
 ],
 "Errata": [
  null,
  "Virheet"
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Dnf-automatic.timer- tai dnf-automatic-install.timer-tiedostojen jäsentäminen epäonnistui. Poista mukautetut ohitukset määrittääksesi automaattiset päivitykset."
 ],
 "Failed to restart service": [
  null,
  "Ei voitu käynnistää uudelleen palvelua"
 ],
 "Fridays": [
  null,
  "Perjantai"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "History package count": [
  null,
  "Historian pakettien määrä"
 ],
 "Host key is incorrect": [
  null,
  "Koneen avain on väärin"
 ],
 "Ignore": [
  null,
  "Ohita"
 ],
 "Info": [
  null,
  "Tiedot"
 ],
 "Initializing...": [
  null,
  "Alustetaan ..."
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Install all updates": [
  null,
  "Asenna kaikki päivitykset"
 ],
 "Install kpatch updates": [
  null,
  "Asenna kpatch-päivitykset"
 ],
 "Install security updates": [
  null,
  "Asenna tietoturvapäivitykset"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "Installed": [
  null,
  "Asennettu"
 ],
 "Installing": [
  null,
  "Asennetaan"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Internal error": [
  null,
  "Sisäinen virhe"
 ],
 "Invalid date format": [
  null,
  "Virheellinen päivämuoto"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Virheellinen päivämuoto ja aikamuoto"
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Invalid time format": [
  null,
  "Virheellinen aikamuoto"
 ],
 "Invalid timezone": [
  null,
  "Virheellinen aikavyöhyke"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Ytimen live-korjaus $0 on aktiivinen"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Ytimen live-korjaus $0 on asennettu"
 ],
 "Kernel live patch settings": [
  null,
  "Ytimen live-korjausten asetukset"
 ],
 "Kernel live patching": [
  null,
  "Ytimen live-korjauksia asennetaan"
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Last checked: $0": [
  null,
  "Viimeksi tarkistettu: $0 sitten"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "Loading available updates failed": [
  null,
  "Saatavilla olevien päivitysten lataus epäonnistui"
 ],
 "Loading available updates, please wait...": [
  null,
  "Ladataan saatavilla olevat päivitykset, odota hetki..."
 ],
 "Loading system modifications...": [
  null,
  "Ladataan järjestelmän muutoksia ..."
 ],
 "Log messages": [
  null,
  "Kirjaa viestit"
 ],
 "Login failed": [
  null,
  "Kirjautuminen epäonnistui"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Manage storage": [
  null,
  "Tallennustilan hallinta"
 ],
 "Manually": [
  null,
  "Manuaalisesti"
 ],
 "Message to logged in users": [
  null,
  "Viesti sisäänkirjautuneille käyttäjille"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Mondays": [
  null,
  "Maanantai"
 ],
 "More info...": [
  null,
  "Lisätietoja..."
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "NTP server": [
  null,
  "NTP-palvelin"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Need at least one NTP server": [
  null,
  "Tarvitaan vähintään yksi NTP-palvelin"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "No delay": [
  null,
  "Ei viivettä"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "No system modifications": [
  null,
  "Ei järjestelmän muutoksia"
 ],
 "No updates": [
  null,
  "Ei päivityksiä"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Not available": [
  null,
  "Ei saatavilla"
 ],
 "Not installed": [
  null,
  "Ei asennettu"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ei oikeutta suorittaa tätä toimintoa."
 ],
 "Not registered": [
  null,
  "Ei rekisteröity"
 ],
 "Not set up": [
  null,
  "Ei asetettu"
 ],
 "Not synchronized": [
  null,
  "Ei synkronisoitu"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Occurrences": [
  null,
  "Tapahtumat"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Kun Cockpit on asennettu, ota se käyttöön 'systemctl enable --now cockpit.socket'."
 ],
 "Other": [
  null,
  "Muu"
 ],
 "Package information": [
  null,
  "Pakettitiedot"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit ei ole asennettu"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit raportoi virhekoodin $0"
 ],
 "Packages": [
  null,
  "Paketit"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Paste": [
  null,
  "Siirrä"
 ],
 "Paste error": [
  null,
  "Liittämisvirhe"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "Ratkaise ongelma ja lataa sivu uudelleen."
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Reboot after completion": [
  null,
  "Käynnistä uudelleen päivitysten asentamisen jälkeen"
 ],
 "Reboot recommended": [
  null,
  "Uudelleenkäynnistystä suositellaan"
 ],
 "Reboot system...": [
  null,
  "Käynnistä järjestelmä uudelleen..."
 ],
 "Refreshing package information": [
  null,
  "Päivitetään pakettitietoja"
 ],
 "Register…": [
  null,
  "Rekisteröi…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Ladataan jäljellä olevien palvelujen tila"
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "Restart services": [
  null,
  "Käynnistä palvelut uudelleen"
 ],
 "Restart services...": [
  null,
  "Käynnistä palvelut uudelleen..."
 ],
 "Restarting": [
  null,
  "Käynnistetään uudelleen"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "Lauantai"
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "Save changes": [
  null,
  "Tallenna muutokset"
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linuxin asetukset ja ongelmanratkaisu"
 ],
 "Security updates available": [
  null,
  "Tietoturvapäivityksiä saatavilla"
 ],
 "Security updates only": [
  null,
  "Vain tietoturvapäivityksiä"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Turvallisuuspäivitykset asennetaan $0 klo $1"
 ],
 "Server has closed the connection.": [
  null,
  "Palvelin on sulkenut yhteyden."
 ],
 "Set time": [
  null,
  "Aseta aika"
 ],
 "Set up": [
  null,
  "Asetukset tehty"
 ],
 "Setting up": [
  null,
  "Tehdään asetuksia"
 ],
 "Settings": [
  null,
  "Asetukset"
 ],
 "Severity": [
  null,
  "Vakavuus"
 ],
 "Shell script": [
  null,
  "Komentotulkin komentosarja"
 ],
 "Shift+Insert": [
  null,
  "Vaihto + Syöttö"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Software updates": [
  null,
  "Ohjelmistopäivitykset"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Joku muu ohjelma käyttää tällä hetkellä paketinhallintaa, odota ..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Jotkin ohjelmistot on käynnistettävä uudelleen manuaalisesti"
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Specific time": [
  null,
  "Tietty aika"
 ],
 "Status": [
  null,
  "Tila"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Sundays": [
  null,
  "Sunnuntai"
 ],
 "Synchronized": [
  null,
  "Synkronoitu"
 ],
 "Synchronized with $0": [
  null,
  "Synkronoi palvelimen $0 kanssa"
 ],
 "Synchronizing": [
  null,
  "Synkronoidaan"
 ],
 "System is up to date": [
  null,
  "Järjestelmä on ajan tasalla"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "The following service will be restarted:": [
  null,
  "Seuraava palvelu käynnistetään uudelleen:",
  "Seuraavat palvelut käynnistetään uudelleen:"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Sisäänkirjautunut käyttäjä ei saa tarkastella järjestelmän muutoksia"
 ],
 "The passwords do not match.": [
  null,
  "Salasanat eivät täsmää."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Palvelin kieltäytyi tunnistautumista käyttäen mitään tuetuista tavoista."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Tämä kone käynnistyy uudelleen, kun päivitykset on asennettu."
 ],
 "This system is not registered": [
  null,
  "Tätä järjestelmää ei ole rekisteröity"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tämä työkalu asettaa SELinux-käytännön ja auttaa käytäntörikkeiden ymmärtämisessä ja ratkaisemisessa."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Tämä työkalu asettaa järjestelmän kirjoittamaan ytimen kaatumisvedokset levylle."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tämä työkalu luo arkiston konfiguraatio- ja diagnostiikkatiedoista käynnissä olevasta järjestelmästä. Arkisto voidaan tallentaa paikallisesti tai keskitetysti tallennus- tai seurantatarkoituksiin tai se voidaan lähettää teknisen tuen edustajille, kehittäjille tai järjestelmänvalvojille auttamaan teknisten vikojen etsinnässä ja virheenkorjauksessa."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tämä työkalu hallinnoi paikallista tallennustilaa, kuten tiedostojärjestelmiä, LVM2-taltioryhmiä ja NFS-liitoksia."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tämä työkalu hallitsee verkkoyhteyksiä, kuten sidoksia, siltoja, ryhmiä, VLAN-verkkoja ja palomuureja NetworkManagerin ja Firewalld:n avulla. NetworkManager ei ole yhteensopiva Ubuntun oletusarvoisten systemd-networkd- ja Debianin ifupdown-komentosarjojen kanssa."
 ],
 "Thursdays": [
  null,
  "Torstai"
 ],
 "Time": [
  null,
  "Aika"
 ],
 "Time zone": [
  null,
  "Aikavyöhyke"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Ohjelmistopäivitysten saamiseksi tämä järjestelmä on rekisteröitävä Red Hatille joko käyttämällä Red Hat -asiakasportaalia tai paikallista tilauspalvelinta."
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Too much data": [
  null,
  "Liian paljon dataa"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Trying to synchronize with $0": [
  null,
  "Yritetään synkronoida palvelimen $0 kanssa"
 ],
 "Tuesdays": [
  null,
  "Tiistai"
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "Unavailable packages": [
  null,
  "Ei käytettävissä olevia paketteja"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Untrusted host": [
  null,
  "Epäluotettava kone"
 ],
 "Update Success Table": [
  null,
  "Päivityksen onnistumisen taulukko"
 ],
 "Update history": [
  null,
  "Päivityshistoria"
 ],
 "Update was successful": [
  null,
  "Päivitys onnistui"
 ],
 "Updated": [
  null,
  "Päivitetty"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Päivitetyt paketit saattavat vaatia uudelleenkäynnistyksen, jotta muutokset tulevat voimaan."
 ],
 "Updates available": [
  null,
  "Päivityksiä saatavilla"
 ],
 "Updates history": [
  null,
  "Päivitysten historia"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Päivitykset asennetaan $0 klo $1"
 ],
 "Updating": [
  null,
  "Päivitetään"
 ],
 "Verified": [
  null,
  "Vahvistettu"
 ],
 "Verifying": [
  null,
  "Varmistetaan"
 ],
 "Version": [
  null,
  "Versio"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "View automation script": [
  null,
  "Näytä automaatio-komentosarja"
 ],
 "View update log": [
  null,
  "Katso päivityslokit"
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Web Console for Linux servers": [
  null,
  "Verkkokonsoli Linux-palvelimille"
 ],
 "Web Console will restart": [
  null,
  "Verkkokonsoli käynnistyy uudelleen"
 ],
 "Wednesdays": [
  null,
  "Keskiviikko"
 ],
 "When": [
  null,
  "Kun"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Kun verkkokonsoli käynnistetään uudelleen, et enää näe edistymistä koskevia tietoja. Päivitysprosessi jatkuu kuitenkin taustalla. Muodosta yhteys uudelleen jatkaaksesi päivitysprosessin seurantaa."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Selaimesi ei salli liittämistä pikavalikosta. Voit käyttää Vaihto+Insert."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Palvelimesi sulkee yhteyden pian. Voit muodostaa yhteyden uudelleen, kun palvelin on käynnistynyt uudelleen."
 ],
 "Your session has been terminated.": [
  null,
  "Istuntosi on päätetty."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Istuntosi on vahventunut. Ole hyvä ja kirjaudu uudelleen sisään."
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "at": [
  null,
  "kello"
 ],
 "bug fix": [
  null,
  "viankorjaus"
 ],
 "enhancement": [
  null,
  "parannus"
 ],
 "every Friday": [
  null,
  "perjantaisin"
 ],
 "every Monday": [
  null,
  "maanantaisin"
 ],
 "every Saturday": [
  null,
  "lauantaisin"
 ],
 "every Sunday": [
  null,
  "sunnuntaisin"
 ],
 "every Thursday": [
  null,
  "torstaisin"
 ],
 "every Tuesday": [
  null,
  "tiistaisin"
 ],
 "every Wednesday": [
  null,
  "keskiviikkoisin"
 ],
 "every day": [
  null,
  "päivittäin"
 ],
 "for current and future kernels": [
  null,
  "nykyisille ja tuleville ytimille"
 ],
 "for current kernel only": [
  null,
  "vain nykyiselle kernelille"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "patches": [
  null,
  "paikkauksia"
 ],
 "security": [
  null,
  "turvallisuus"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ]
});
