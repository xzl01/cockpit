cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 exited with code $1": [
  null,
  "$0 がコード $1 で終了しました"
 ],
 "$0 failed": [
  null,
  "$0 が失敗しました"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 がシグナル $1 で終了しました"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 package": [
  null,
  "$0 パッケージ"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 パッケージにはシステムの再起動が必要です"
 ],
 "$0 security fix available": [
  null,
  "$0 セキュリティー修正が利用可能"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 サービスを再起動する必要があります"
 ],
 "$0 update available": [
  null,
  "$0 更新を利用できます"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 ", including $1 security fix": [
  null,
  "セキュリティー修正を $1 個含む"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "パッケージの更新を有効にするには、システムを再起動する必要があります:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "更新を有効にするには、サービスを再起動する必要があります:"
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Acceptable password": [
  null,
  "受け入れられるパスワード"
 ],
 "Add $0": [
  null,
  "$0 の追加"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの管理"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "All updates": [
  null,
  "すべてのアップデート"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible ロールのドキュメント"
 ],
 "Apply kernel live patches": [
  null,
  "カーネルライブパッチの適用"
 ],
 "Applying updates": [
  null,
  "アップデートの適用中"
 ],
 "Applying updates failed": [
  null,
  "アップデートの適用に失敗しました"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの特権タスクの実行には、認証が必要です"
 ],
 "Automatic updates": [
  null,
  "自動アップデート"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using additional NTP servers": [
  null,
  "追加の NTP サーバーを自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "Automation script": [
  null,
  "オートメーションスクリプト"
 ],
 "Available updates": [
  null,
  "利用可能なアップデート"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Bug fix updates available": [
  null,
  "バグ修正の更新が利用可能"
 ],
 "Bugs": [
  null,
  "バグ"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Cannot forward login credentials": [
  null,
  "ログインのクレデンシャルをフォワードできません"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Check for updates": [
  null,
  "更新の確認"
 ],
 "Checking for package updates...": [
  null,
  "パッケージの更新を確認しています..."
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Checking software status": [
  null,
  "ソフトウェアステータスの確認"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit の NetworkManager と Firewalld の設定"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit は該当するホストに接続できませんでした。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit は、Web ブラウザーで Linux サーバーを簡単に管理できるサーバーマネージャーです。端末と Web ツールを区別せずに使用できます。Cockpit で起動されたサービスは端末で停止できます。同様に、端末でエラーが発生した場合は、そのエラーを Cockpit ジャーナルインターフェースで確認できます。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit にはシステム上のそのソフトウェアとの互換性がありません。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit はシステムにインストールされていません。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit は経験が少ないシステム管理者に最適です。これらのシステム管理者はストレージの管理、ジャーナルの検査、サービスの起動および停止などの単純なタスクを簡単に実行できるようになります。また、複数のサーバーを同時に監視および管理できます。これらのサーバーはクリックするだけで追加できます。追加後に、ご使用のマシンは他のマシンを管理するようになります。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "診断およびサポートデータの収集とパッケージ化"
 ],
 "Collect kernel crash dumps": [
  null,
  "カーネルクラッシュダンプの収集"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Connection has timed out.": [
  null,
  "接続がタイムアウトしました。"
 ],
 "Continue": [
  null,
  "続行"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Create new task file with this content.": [
  null,
  "このコンテンツで新しいタスクファイルを作成します。"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Danger alert:": [
  null,
  "Danger アラート:"
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "Details": [
  null,
  "詳細"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Disabled": [
  null,
  "無効"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "Downloaded": [
  null,
  "ダウンロードされました"
 ],
 "Downloading": [
  null,
  "ダウンロード中"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "Edit": [
  null,
  "編集"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Enable": [
  null,
  "有効化"
 ],
 "Enabled": [
  null,
  "有効"
 ],
 "Enhancement updates available": [
  null,
  "機能拡張の更新を利用できます"
 ],
 "Errata": [
  null,
  "エラータ"
 ],
 "Excellent password": [
  null,
  "優れたパスワード"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld での $0 の有効化に失敗しました"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "dnf-automatic.timer または dnf-automatic-install.timer のユニットファイルの分析に失敗しました。カスタムオーバーライドを削除して、自動更新を設定してください。"
 ],
 "Failed to restart service": [
  null,
  "サービスの再起動に失敗しました"
 ],
 "Fridays": [
  null,
  "毎週金曜日"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "Hide confirmation password": [
  null,
  "確認パスワードの非表示"
 ],
 "Hide password": [
  null,
  "パスワードの非表示"
 ],
 "History package count": [
  null,
  "履歴パッケージ数"
 ],
 "Host key is incorrect": [
  null,
  "ホスト鍵が正しくありません"
 ],
 "Ignore": [
  null,
  "無視"
 ],
 "Info": [
  null,
  "情報"
 ],
 "Initializing...": [
  null,
  "初期化中..."
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install all updates": [
  null,
  "すべてのアップデートをインストールする"
 ],
 "Install kpatch updates": [
  null,
  "kpatch の更新をインストールする"
 ],
 "Install security updates": [
  null,
  "セキュリティーアップデートをインストールする"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installed": [
  null,
  "インストール済み"
 ],
 "Installing": [
  null,
  "インストール中"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Internal error": [
  null,
  "内部エラー"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid file permissions": [
  null,
  "無効なファイルパーミッション"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Kernel live patch $0 is active": [
  null,
  "カーネルライブパッチ $0 はアクティブです"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "カーネルライブパッチ $0 がインストールされています"
 ],
 "Kernel live patch settings": [
  null,
  "カーネルライブパッチの設定"
 ],
 "Kernel live patching": [
  null,
  "カーネルライブパッチ"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Last checked: $0": [
  null,
  "最終確認: $0"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Loading available updates failed": [
  null,
  "利用可能なアップデートのロードに失敗しました"
 ],
 "Loading available updates, please wait...": [
  null,
  "利用可能なアップデートをロード中です。しばらくお待ちください..."
 ],
 "Loading system modifications...": [
  null,
  "システム変更をロード中..."
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "Login failed": [
  null,
  "ログインが失敗しました"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Lunch box": [
  null,
  "ランチボックス"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Manage storage": [
  null,
  "ストレージの管理"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Mondays": [
  null,
  "毎週月曜日"
 ],
 "More info...": [
  null,
  "詳細..."
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "No system modifications": [
  null,
  "システム変更がありません"
 ],
 "No updates": [
  null,
  "更新なし"
 ],
 "Not a valid private key": [
  null,
  "有効な秘密鍵ではありません"
 ],
 "Not available": [
  null,
  "利用できません"
 ],
 "Not installed": [
  null,
  "インストールされていません"
 ],
 "Not permitted to perform this action.": [
  null,
  "この動作を実行する権限がありません。"
 ],
 "Not registered": [
  null,
  "登録されていません"
 ],
 "Not set up": [
  null,
  "設定されていません"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Occurrences": [
  null,
  "発生"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit がインストールされたら、\"systemctl enable --now cockpit.socket\" コマンドで有効にします。"
 ],
 "Other": [
  null,
  "その他"
 ],
 "Package information": [
  null,
  "パッケージ情報"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit はインストールされていません"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit が、エラーコード $0 を報告しました"
 ],
 "Packages": [
  null,
  "パッケージ"
 ],
 "Password is not acceptable": [
  null,
  "パスワードは受け入れられません"
 ],
 "Password is too weak": [
  null,
  "パスワードが弱すぎます"
 ],
 "Password not accepted": [
  null,
  "パスワードは受け入れられません"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Paste error": [
  null,
  "貼り付けエラー"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "問題を解決し、このページを再ロードしてください。"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add によるプロンプトがタイムアウトしました"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen によるプロンプトがタイムアウトしました"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Reboot after completion": [
  null,
  "完了後に再起動する"
 ],
 "Reboot recommended": [
  null,
  "再起動を推奨します"
 ],
 "Reboot system...": [
  null,
  "システムの再起動..."
 ],
 "Refreshing package information": [
  null,
  "パッケージ情報の更新中"
 ],
 "Register…": [
  null,
  "登録中…"
 ],
 "Reloading the state of remaining services": [
  null,
  "残りのサービス状態の再読み込み"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Restart services": [
  null,
  "サービスの再起動"
 ],
 "Restart services...": [
  null,
  "サービスの再起動..."
 ],
 "Restarting": [
  null,
  "再起動中"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "毎週土曜日"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save changes": [
  null,
  "変更の保存"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux の設定とトラブルシューティング"
 ],
 "Security updates available": [
  null,
  "セキュリティーの更新を利用できます"
 ],
 "Security updates only": [
  null,
  "セキュリティー更新のみ"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "$0 $1 にセキュリティーアップデートが適用されます"
 ],
 "Server has closed the connection.": [
  null,
  "サーバーの接続が終了しました。"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Set up": [
  null,
  "設定済み"
 ],
 "Setting up": [
  null,
  "設定中"
 ],
 "Settings": [
  null,
  "設定"
 ],
 "Severity": [
  null,
  "重大度"
 ],
 "Shell script": [
  null,
  "シェルスクリプト"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "確認パスワードの表示"
 ],
 "Show password": [
  null,
  "パスワードを表示する"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Software updates": [
  null,
  "ソフトウェア更新"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "別のプログラムがパッケージマネージャーを使用中です。しばらくお待ちください..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "一部のソフトウェアを手動で再起動する必要があります"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Status": [
  null,
  "ステータス"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Strong password": [
  null,
  "強固なパスワード"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Sundays": [
  null,
  "毎週日曜日"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "System is up to date": [
  null,
  "システムは最新の状態です"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "The following service will be restarted:": [
  null,
  "以下のサービスが再起動します:"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ログインしているユーザーには、システム変更を表示する権限がありません"
 ],
 "The passwords do not match.": [
  null,
  "パスワードが一致しません。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "サーバーはサポートされた方法を使用した認証を拒否しました。"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "このホストは、更新後に再起動します。"
 ],
 "This system is not registered": [
  null,
  "このシステムは登録されていません"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "このツールは、SELinux ポリシーを設定します。また、ポリシー違反の把握と解決に役立ちます。"
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "このツールは、カーネルクラッシュダンプをディスクに書き込むようにシステムを設定します。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "このツールは、実行中のシステムから設定および診断情報のアーカイブを生成します。アーカイブは、記録や追跡の目的でローカルまたは一元的に保存することも、技術的な障害の発見やデバッグを支援するためにテクニカルサポート担当者、開発者、システム管理者に送信することもできます。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "このツールは、ファイルシステム、LVM2 ボリュームグループ、NFS マウントなどのローカルストレージを管理します。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "このツールは、NetworkManager と Firewalld を使用して、ボンディング、ブリッジ、チーム、VLAN、ファイアウォールなどのネットワーク設定を管理します。NetworkManager は、Ubuntu のデフォルトの systemd-networkd および Debian の ifupdown スクリプトと互換性がありません。"
 ],
 "Thursdays": [
  null,
  "毎週木曜日"
 ],
 "Time": [
  null,
  "時間"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "ソフトウェアアップデートを取得するには、このシステムを Red Hat に登録する必要があります。登録には、Red Hat カスタマーポータルまたはローカルのサブスクリプションサーバーを使用します。"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Too much data": [
  null,
  "データが多すぎます"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "Tuesdays": [
  null,
  "毎週火曜日"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Unavailable packages": [
  null,
  "利用できないパッケージ"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Untrusted host": [
  null,
  "信用できないホスト"
 ],
 "Update Success Table": [
  null,
  "更新成功テーブル"
 ],
 "Update history": [
  null,
  "更新履歴"
 ],
 "Update was successful": [
  null,
  "更新が正常に実行されました"
 ],
 "Updated": [
  null,
  "更新済み"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "パッケージの更新を反映するには、再起動が必要になる場合があります。"
 ],
 "Updates available": [
  null,
  "更新を利用できます"
 ],
 "Updates history": [
  null,
  "更新履歴"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "$0 $1 に更新が適用されます"
 ],
 "Updating": [
  null,
  "更新中"
 ],
 "Verified": [
  null,
  "検証済み"
 ],
 "Verifying": [
  null,
  "検証中"
 ],
 "Version": [
  null,
  "バージョン"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "View automation script": [
  null,
  "オートメーションスクリプトの表示"
 ],
 "View update log": [
  null,
  "更新ログの表示"
 ],
 "Visit firewall": [
  null,
  "ファイアウォールへのアクセス"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Weak password": [
  null,
  "脆弱なパスワード"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux サーバー用 Web コンソール"
 ],
 "Web Console will restart": [
  null,
  "Web コンソールが再起動します"
 ],
 "Wednesdays": [
  null,
  "毎週水曜日"
 ],
 "When": [
  null,
  "条件"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Web コンソールを再起動すると、進捗情報が表示されなくなります。ただし、更新プロセスはバックグラウンドで続行されます。更新プロセスの監視を継続するには、再接続します。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "お使いのブラウザーでは、コンテキストメニューからの貼り付けが許可されていません。Shift+Insert を使用できます。"
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "サーバーがまもなく接続を閉じます。再起動したら再接続できます。"
 ],
 "Your session has been terminated.": [
  null,
  "セッションが終了しました。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "セッションの有効期限が切れました。再度ログインしてください。"
 ],
 "Zone": [
  null,
  "ゾーン"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "at": [
  null,
  "時間"
 ],
 "bug fix": [
  null,
  "バグ修正"
 ],
 "enhancement": [
  null,
  "機能強化"
 ],
 "every Friday": [
  null,
  "毎週金曜日"
 ],
 "every Monday": [
  null,
  "毎週月曜日"
 ],
 "every Saturday": [
  null,
  "毎週土曜日"
 ],
 "every Sunday": [
  null,
  "毎週日曜日"
 ],
 "every Thursday": [
  null,
  "毎週木曜日"
 ],
 "every Tuesday": [
  null,
  "毎週火曜日"
 ],
 "every Wednesday": [
  null,
  "毎週水曜日"
 ],
 "every day": [
  null,
  "毎日"
 ],
 "for current and future kernels": [
  null,
  "現在および将来のカーネルを対象とする"
 ],
 "for current kernel only": [
  null,
  "現在のカーネルのみを対象とする"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "パスワードの強度"
 ],
 "patches": [
  null,
  "パッチ"
 ],
 "security": [
  null,
  "セキュリティー"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ]
});
