cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Managing software updates": [
  null,
  "소프트웨어 최신화 관리"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "소프트웨어 최신화"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "k패치"
 ],
 "package": [
  null,
  "꾸러미"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "보안"
 ],
 "updates": [
  null,
  "최신화"
 ],
 "yum": [
  null,
  "yum"
 ]
});
