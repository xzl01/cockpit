cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Managing software updates": [
  null,
  "管理软件更新"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "软件更新"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "package": [
  null,
  "软件包"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "安全"
 ],
 "yum": [
  null,
  "yum"
 ]
});
