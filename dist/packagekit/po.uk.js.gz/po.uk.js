cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "$0 key changed": [
  null,
  "Змінено ключ $0"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 package": [
  null,
  "$0 пакунок",
  "$0 пакунки",
  "$0 пакунків"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 пакунок потребує перезавантаження системи",
  "$0 пакунки потребують перезавантаження системи",
  "$0 пакунків потребують перезавантаження системи"
 ],
 "$0 security fix available": [
  null,
  "Доступне $0 оновлення захисту",
  "Доступні $0 оновлення захисту",
  "Доступні $0 оновлень захисту"
 ],
 "$0 service needs to be restarted": [
  null,
  "Слід перезапустити $0 службу",
  "Слід перезапустити $0 служби",
  "Слід перезапустити $0 служб"
 ],
 "$0 update available": [
  null,
  "Доступне $0 оновлення",
  "Доступні $0 оновлення",
  "Доступні $0 оновлень"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 ", including $1 security fix": [
  null,
  ", включно із $1 виправленням захисту",
  ", включно із $1 виправленнями захисту",
  ", включно із $1 виправленнями захисту"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "На $0 не встановлено сумісної версії Cockpit."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Буде створено новий ключ SSH у $0 для $1 на $2 і його буде додано до файла $3 $4 на $5."
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Для набуття оновленнями пакунків чинності слід перезапустити систему:",
  "Для набуття оновленнями пакунків чинності слід перезапустити систему:",
  "Для набуття оновленнями пакунків чинності слід перезапустити систему:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Для набуття оновленнями чинності слід перезапустити деякі служби:",
  "Для набуття оновленнями чинності слід перезапустити деякі служби:",
  "Для набуття оновленнями чинності слід перезапустити деякі служби:"
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Acceptable password": [
  null,
  "Прийнятний пароль"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Адміністрування за допомогою вебконсолі Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "All updates": [
  null,
  "Усі оновлення"
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документація з ролей Ansible"
 ],
 "Apply kernel live patches": [
  null,
  "Застосувати інтерактивні латки до ядра"
 ],
 "Applying updates": [
  null,
  "Застосовуємо оновлення"
 ],
 "Applying updates failed": [
  null,
  "Не вдалося застосувати оновлення"
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Щоб отримати доступ до виконання привілейованих завдань за допомогою вебконсолі Cockpit, слід пройти розпізнавання"
 ],
 "Authorize SSH key": [
  null,
  "Уповноважити ключ SSH"
 ],
 "Automatic updates": [
  null,
  "Автоматичні оновлення"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматично за допомогою додаткових серверів NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Automation script": [
  null,
  "Скрипт автоматизації"
 ],
 "Available updates": [
  null,
  "Доступні оновлення"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Bug fix updates available": [
  null,
  "Доступні оновлення із виправленнями вад"
 ],
 "Bugs": [
  null,
  "Вади"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Зміна ключів часто є результатом перевстановлення операційної системи. Втім, неочікувана зміна може вказувати на сторонню спробу перехопити дані вашого з'єднання."
 ],
 "Check for updates": [
  null,
  "Перевірити наявність оновлень"
 ],
 "Checking for package updates...": [
  null,
  "Шукаємо оновлення пакунків…"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "Checking software status": [
  null,
  "Перевіряємо стан програмного забезпечення"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Налаштування Cockpit для NetworkManager і Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit — програма для керування сервером, яка полегшує адміністрування ваших серверів під керуванням Linux за допомогою програми для перегляду сторінок інтернету. Ви зможете одночасно використовувати термінал і вебінструмент. Службу, яку було запущено за допомогою Cockpit, можна зупинити за допомогою термінала. І навпаки, якщо трапиться помилка у терміналі, ви побачите її у інтерфейсі журналу Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не встановлено"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit — чудовий інструмент для системних адміністраторів-початківців. За його допомогою вони без проблем впораються із простими завданнями, зокрема адмініструванням сховищ даних, інспектуванням журналів та запуском і зупиненням служб. Ви зможете одночасно стежити за роботою декількох серверів і адмініструвати ці сервери. Просто додайте їх одним клацанням кнопкою миші і ваш комп’ютер сам нагляне за своїми приятелями."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Збирати і пакувати діагностичні дані і дані щодо підтримки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Збирати дампи аварій ядра"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Confirm key password": [
  null,
  "Підтвердження пароля до ключа"
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Continue": [
  null,
  "Продовжити"
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Copied": [
  null,
  "Скопійовано"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Create $0": [
  null,
  "Створити $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Створити ключ SSH і уповноважити його"
 ],
 "Create new task file with this content.": [
  null,
  "Створити файл завдання із цим вмістом."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Danger alert:": [
  null,
  "Попередження про небезпеку:"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Disabled": [
  null,
  "Вимкнено"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "Downloaded": [
  null,
  "Отримано"
 ],
 "Downloading": [
  null,
  "Отримуємо"
 ],
 "Downloading $0": [
  null,
  "Отримуємо $0"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Enable": [
  null,
  "Увімкнути"
 ],
 "Enabled": [
  null,
  "Увімкнено"
 ],
 "Enhancement updates available": [
  null,
  "Доступні оновлення із поліпшеннями"
 ],
 "Errata": [
  null,
  "Відомі помилки"
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Не вдалося обробити файли модулів для dnf-automatic.timer або dnf-automatic-install.timer. Будь ласка, вилучіть нетипові перевизначення, щоб налаштувати автоматичні оновлення."
 ],
 "Failed to restart service": [
  null,
  "Не вдалося перезапустити службу"
 ],
 "Fridays": [
  null,
  "П'ятниці"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "Hide confirmation password": [
  null,
  "Приховати підтвердження пароля"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "History package count": [
  null,
  "Кількість пакунків у журналі"
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Якщо відбиток є відповідним, натисніть «Довіряти і додати вузол». Якщо ж це не так, не встановлюйте з'єднання і повідомте про подію адміністратору."
 ],
 "Ignore": [
  null,
  "Ігнорувати"
 ],
 "Info": [
  null,
  "Інформація"
 ],
 "Initializing...": [
  null,
  "Ініціалізація…"
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Install all updates": [
  null,
  "Встановити усі оновлення"
 ],
 "Install kpatch updates": [
  null,
  "Встановити оновлення kpatch"
 ],
 "Install security updates": [
  null,
  "Встановити оновлення захисту"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "Installed": [
  null,
  "Встановлено"
 ],
 "Installing": [
  null,
  "Встановлення"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Активною є інтерактивна латка до ядра $0"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Встановлено інтерактивну латку до ядра $0"
 ],
 "Kernel live patch settings": [
  null,
  "Параметри інтерактивних латок до ядра"
 ],
 "Kernel live patching": [
  null,
  "Інтерактивне латання ядра"
 ],
 "Key password": [
  null,
  "Пароль до ключа"
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Last checked: $0": [
  null,
  "Востаннє перевірено: $0"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Loading available updates failed": [
  null,
  "Не вдалося завантажити список доступних оновлень"
 ],
 "Loading available updates, please wait...": [
  null,
  "Завантажуємо доступні оновлення, зачекайте…"
 ],
 "Loading system modifications...": [
  null,
  "Завантажуємо модифікації системи…"
 ],
 "Log in": [
  null,
  "Увійти"
 ],
 "Log in to $0": [
  null,
  "Увійти до $0"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Manage storage": [
  null,
  "Керування сховищем"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Mondays": [
  null,
  "Понеділки"
 ],
 "More info...": [
  null,
  "Докладніше…"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "No results found": [
  null,
  "Нічого не знайдено"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "No system modifications": [
  null,
  "Немає модифікацій системи"
 ],
 "No updates": [
  null,
  "Немає оновлень"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Not available": [
  null,
  "Недоступний"
 ],
 "Not installed": [
  null,
  "Не встановлено"
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Not registered": [
  null,
  "Не зареєстровано"
 ],
 "Not set up": [
  null,
  "Не налаштовано"
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "Випадки"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Після встановлення Cockpit його можна увімкнути за допомогою команди «systemctl enable --now cockpit.socket»."
 ],
 "Other": [
  null,
  "Інше"
 ],
 "Package information": [
  null,
  "Дані щодо пакунка"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit не встановлено"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit повідомлено про помилку із кодом $0"
 ],
 "Packages": [
  null,
  "Пакунки"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Paste error": [
  null,
  "Помилка вставлення"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "Будь ласка, усуньте проблему і перезавантажте цю сторінку."
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Reboot after completion": [
  null,
  "Перезавантажити після завершення"
 ],
 "Reboot recommended": [
  null,
  "Рекомендовано перезавантажити"
 ],
 "Reboot system...": [
  null,
  "Перезавантажити систему…"
 ],
 "Refreshing package information": [
  null,
  "Оновлюємо дані щодо пакунків"
 ],
 "Register…": [
  null,
  "Зареєструвати…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Перезавантажуємо стан решти служб"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Restart services": [
  null,
  "Перезапустити служби"
 ],
 "Restart services...": [
  null,
  "Перезапустити служби…"
 ],
 "Restarting": [
  null,
  "Перезапускаємо"
 ],
 "Row expansion": [
  null,
  "Розгортання рядка"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустити цю команду довіреною мережею або фізично на віддаленому комп'ютері:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Ключ SSH"
 ],
 "SSH key login": [
  null,
  "Вхід за ключем SSH"
 ],
 "Saturdays": [
  null,
  "Суботи"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Save changes": [
  null,
  "Зберегти зміни"
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Налаштування Security Enhanced Linux та усування вад"
 ],
 "Security updates available": [
  null,
  "Доступні оновлення захисту"
 ],
 "Security updates only": [
  null,
  "Лише оновлення захисту"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Оновлення безпеки буде застосовано $0 о $1"
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Set up": [
  null,
  "Налаштувати"
 ],
 "Setting up": [
  null,
  "Налаштовуємо"
 ],
 "Settings": [
  null,
  "Параметри"
 ],
 "Severity": [
  null,
  "Важливість"
 ],
 "Shell script": [
  null,
  "Скрипт оболонки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Показати підтвердження пароля"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Software updates": [
  null,
  "Оновлення програм"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Програмою для керування пакунків користується якась інша програма, будь ласка, зачекайте…"
 ],
 "Some software needs to be restarted manually": [
  null,
  "Частину програмного забезпечення доведеться перезавантажити вручну"
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Status": [
  null,
  "Стан"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Strong password": [
  null,
  "Складний пароль"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Sundays": [
  null,
  "Неділі"
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "System is up to date": [
  null,
  "Система не потребує оновлення"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Ключ SSH $0 $1 на $2 буде додано до файла $3 $4 на $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Ключ SSH $0 буде доступним протягом решти сеансу і також буде доступним для входу на інші вузли."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено паролем, а на вузлі заборонено вхід без пароля. Буль ласка, вкажіть пароль до ключа у $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено. Ви можете увійти або за допомогою пароль до вашого облікового запису або вказавши пароль до ключа у $1."
 ],
 "The fingerprint should match:": [
  null,
  "Відбиток має збігатися:"
 ],
 "The following service will be restarted:": [
  null,
  "Буде перезавантажено такі служби:",
  "Буде перезавантажено такі служби:",
  "Буде перезавантажено такі служби:"
 ],
 "The key password can not be empty": [
  null,
  "Пароль до ключа не може бути порожнім"
 ],
 "The key passwords do not match": [
  null,
  "Паролі до ключа не збігаються"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Користувач, який увійшов до системи, не має права переглядати модифікації системи"
 ],
 "The password can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Відбиток-результат можна поширювати у спосіб із загальним доступом, зокрема електронною поштою."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Відбиток-результат можна поширювати відкритими способами, включно із електронною поштою. Якщо ви просите когось виконати перевірку для вас, вони можуть надсилати результати за допомогою будь-якого способу."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Цей вузол буде перезавантажено після встановлення оновлень."
 ],
 "This system is not registered": [
  null,
  "Цю систему не зареєстровано"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Цей інструмент налаштовує правила SELinux і може допомогти зрозуміти та усунути порушення правил."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Цей інструмент налаштовує систему на запис дампів аварій ядра. Передбачено підтримку призначень дампу «local» (диск), «ssh» та «nfs»."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Цей інструмент створюдє архів даних щодо налаштувань та діагностики для запущеної системи. Архів може бути збережено локально або централізовано з метою журналювання або стеження або надіслано до представників технічної підтримки, розробників або адміністраторів системи, щоб допомогти з пошуком технічних проблем та діагностикою."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Цей інструмент керує локальним сховищем даних, зокрема файловими системами, групами томів LVM2 та монтуваннями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Цей інструмент керує можливостями роботи у мережі, зокрема зв'язками, містками, командами, віртуальними LAN та брандмауерами, за допомогою NetworkManager і Firewalld. NetworkManager є несумісним із типовим для Ubuntu systemd-networkd та скриптами ifupdown Debian."
 ],
 "Thursdays": [
  null,
  "Четверги"
 ],
 "Time": [
  null,
  "Час"
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Щоб переконатися, що дані вашого з'єднання не буде перехоплено зловмисниками, будь ласка, підтвердьте відбиток ключа вузла:"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Щоб отримувати оновлення програмного забезпечення, цю систему слід зареєструвати у Red Hat або за допомогою порталу клієнтів Red Hat, або за допомогою локального сервера передплати."
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Щоб перевірити відбиток, віддайте вказану нижче команду для $0 під час безпосередньої роботи на комп'ютері або з використанням надійної мережі:"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Trust and add host": [
  null,
  "Довіряти і додати вузол"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "Tuesdays": [
  null,
  "Вівторки"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не вдалося увійти до $0 за допомогою розпізнавання за ключем SSH. Будь ласка, вкажіть пароль."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не вдалося увійти до $0. Вузол не приймає входу за паролем або будь-яким з ваших ключів SSH."
 ],
 "Unavailable packages": [
  null,
  "Недоступні пакунки"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Unknown host: $0": [
  null,
  "Невідомий вузол: $0"
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Update Success Table": [
  null,
  "Таблиця успіху оновлення"
 ],
 "Update history": [
  null,
  "Історія оновлень"
 ],
 "Update was successful": [
  null,
  "Успішне оновлення"
 ],
 "Updated": [
  null,
  "Оновлено"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Використання оновлених пакунків може потребувати перезапуску."
 ],
 "Updates available": [
  null,
  "Доступні оновлення"
 ],
 "Updates history": [
  null,
  "Журнал оновлень"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Оновлення буде застосовано $0 о $1"
 ],
 "Updating": [
  null,
  "Оновлення"
 ],
 "Verified": [
  null,
  "Перевірено"
 ],
 "Verify fingerprint": [
  null,
  "Перевірити відбиток"
 ],
 "Verifying": [
  null,
  "Перевіряємо"
 ],
 "Version": [
  null,
  "Версія"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "View automation script": [
  null,
  "Переглянути скрипт автоматизації"
 ],
 "View update log": [
  null,
  "Переглянути журнал оновлення"
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Weak password": [
  null,
  "Простий пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Вебконсоль для серверів під керуванням Linux"
 ],
 "Web Console will restart": [
  null,
  "Вебконсоль буде перезапущено"
 ],
 "Wednesdays": [
  null,
  "Середи"
 ],
 "When": [
  null,
  "Якщо"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Після перезапуску вебконсолі ви не зможете більше бачити даних щодо поступу. Втім, процес оновлення триватиме у фоновому режимі. Встановіть з'єднання повторно, щоб продовжити спостереження за процесом оновлення."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Ви вперше встановлюєте з'єднання із $0."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "У вашій програмі для перегляду не передбачено можливості вставлення з контекстного меню. Ви можете скористатися для вставлення комбінацією Shift+Insert."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Невдовзі ваш сервер розірве з’єднання. Ви можете відновити це з’єднання, щойно сервер буде перезапущено."
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "at": [
  null,
  "на"
 ],
 "bug fix": [
  null,
  "виправлення вад"
 ],
 "enhancement": [
  null,
  "поліпшення"
 ],
 "every Friday": [
  null,
  "кожної п'ятниці"
 ],
 "every Monday": [
  null,
  "кожного понеділка"
 ],
 "every Saturday": [
  null,
  "кожної суботи"
 ],
 "every Sunday": [
  null,
  "кожної неділі"
 ],
 "every Thursday": [
  null,
  "кожного четверга"
 ],
 "every Tuesday": [
  null,
  "кожного вівторка"
 ],
 "every Wednesday": [
  null,
  "кожної середи"
 ],
 "every day": [
  null,
  "кожного дня"
 ],
 "for current and future kernels": [
  null,
  "для поточного і майбутніх ядер"
 ],
 "for current kernel only": [
  null,
  "лише для поточного ядра"
 ],
 "in less than a minute": [
  null,
  "за менше, ніж хвилину"
 ],
 "less than a minute ago": [
  null,
  "менш, ніж хвилину тому"
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "patches": [
  null,
  "латки"
 ],
 "security": [
  null,
  "безпека"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ]
});
