cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 package": [
  null,
  "$0 balíček",
  "$0 balíčky",
  "$0 balíčků"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 balíček vyžaduje restart systému",
  "$0 balíčky vyžadují restart systému",
  "$0 balíčků vyžaduje restart systému"
 ],
 "$0 security fix available": [
  null,
  "Je k dispozici $0 oprava zabezpečení",
  "Jsou k dispozici $0 opravy zabezpečení",
  "Je k dispozici $0 oprav zabezpečení"
 ],
 "$0 service needs to be restarted": [
  null,
  "Je třeba zrestartovat $0 službu",
  "Je třeba zrestartovat $0 služby",
  "Je třeba zrestartovat $0 služeb"
 ],
 "$0 update available": [
  null,
  "$0 aktualizace k dispozici",
  "$0 aktualizace k dispozici",
  "$0 aktualizací k dispozici"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainstalováno."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 ", including $1 security fix": [
  null,
  ", včetně $1 opravy zabezpečení",
  ", včetně $1 oprav zabezpečení",
  ", včetně $1 oprav zabezpečení"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Aby se uplatnil, aktualizovaný balíček potřebuje restart systému:",
  "Aby se uplatnily, aktualizované balíčky potřebují restart systému:",
  "Aby se uplatnily, aktualizované balíčky potřebují restart systému:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Aby se aktualizace uplatnily, je třeba restartovat službu:",
  "Aby se aktualizace uplatnily, je třeba restartovat některé služby:",
  "Aby se aktualizace uplatnily, je třeba restartovat některé služby:"
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All updates": [
  null,
  "Všechny aktualizace"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Apply kernel live patches": [
  null,
  "Aplikovat záplaty pro jádro systému za chodu"
 ],
 "Applying updates": [
  null,
  "Aplikují se aktualizace"
 ],
 "Applying updates failed": [
  null,
  "Aplikace aktualizací se nezdařila"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ],
 "Automatic updates": [
  null,
  "Automatické aktualizace"
 ],
 "Automatically using NTP": [
  null,
  "Automatické použití NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické použití dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatické použití uvedených NTP serverů"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "Available updates": [
  null,
  "Dostupné aktualizace"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Bug fix updates available": [
  null,
  "Jsou k dispozici aktualizace opravující zabezpečení"
 ],
 "Bugs": [
  null,
  "Chyby"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Check for updates": [
  null,
  "Zkontrolovat aktualizace"
 ],
 "Checking for package updates...": [
  null,
  "Zjišťování aktualizací balíčků…"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Checking software status": [
  null,
  "Kontroluje se stav software"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správce serveru, který usnadňuje správu Linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce serverů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Můžete současně sledovat a spravovat několik serverů najednou. Stačí je přidat jedním kliknutím a vaše stroje se budou starat o své kamarády."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Continue": [
  null,
  "Pokračovat"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořit nový soubor s úlohou s tímto obsahem."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Danger alert:": [
  null,
  "Výstraha na nebezpečí:"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Disabled": [
  null,
  "Vypnuto"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "Downloaded": [
  null,
  "Staženo"
 ],
 "Downloading": [
  null,
  "Stahuje se"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Enable": [
  null,
  "Povolit"
 ],
 "Enabled": [
  null,
  "Povoleno"
 ],
 "Enhancement updates available": [
  null,
  "Jsou k dispozici vylepšující aktualizace"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Nepodařilo se zpracovat jednotkové soubory pro dnf-automatic.timer nebo dnf-automatic-install.timer. Pokud chcete nastavit automatické aktualizace, odeberte uživatelsky určená přepsání."
 ],
 "Failed to restart service": [
  null,
  "Službu se nepodařilo restartovat"
 ],
 "Fridays": [
  null,
  "Pátky"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "History package count": [
  null,
  "Počet historie balíčku"
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "Ignore": [
  null,
  "Ignorovat"
 ],
 "Info": [
  null,
  "Informace"
 ],
 "Initializing...": [
  null,
  "Inicializace…"
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install all updates": [
  null,
  "Nainstalovat všechny aktualizace"
 ],
 "Install kpatch updates": [
  null,
  "Nainstalovat kpatch aktualizace"
 ],
 "Install security updates": [
  null,
  "Nainstalovat aktualizace zabezpečení"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installed": [
  null,
  "Nainstalováno"
 ],
 "Installing": [
  null,
  "Instaluje se"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná souborová práva"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Záplata za chodu pro jádro systému $0 je aktivní"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Záplata za chodu pro jádro systému $0 je nainstalovaná"
 ],
 "Kernel live patch settings": [
  null,
  "Nastavení záplatování jádra systému za chodu"
 ],
 "Kernel live patching": [
  null,
  "Záplatování jádra systému za chodu"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Last checked: $0": [
  null,
  "Naposledy zkontrolováno: $0"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "Loading available updates failed": [
  null,
  "Načtení dostupných aktualizací se nezdařilo"
 ],
 "Loading available updates, please wait...": [
  null,
  "Načítání dostupných aktualizací, čekejte…"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Mondays": [
  null,
  "Pondělky"
 ],
 "More info...": [
  null,
  "Více informací…"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "No updates": [
  null,
  "Žádné aktualizace"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Not available": [
  null,
  "Není k dispozici"
 ],
 "Not installed": [
  null,
  "Nenainstalováno"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Not registered": [
  null,
  "Nezaregistrováno"
 ],
 "Not set up": [
  null,
  "Nenastaveno"
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Package information": [
  null,
  "Informace o balíčku"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit není nainstalovaný"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásilo chybový kód $0"
 ],
 "Packages": [
  null,
  "Balíčky"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nebylo přijato"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Path to file": [
  null,
  "Popis umístění serveru"
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "Vyřešte problém a načtěte tuto stránku znovu."
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Reboot after completion": [
  null,
  "Po dokončení restartovat"
 ],
 "Reboot recommended": [
  null,
  "Doporučen restart"
 ],
 "Reboot system...": [
  null,
  "Restartovat systém…"
 ],
 "Refreshing package information": [
  null,
  "Obnovují se informace o balíčcích"
 ],
 "Register…": [
  null,
  "Zaregistrovat…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Znovunačítání stavu zbývajících služeb"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Restart services": [
  null,
  "Restartovat služby"
 ],
 "Restart services...": [
  null,
  "Restartovat služby…"
 ],
 "Restarting": [
  null,
  "Restartuje se"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "Soboty"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Save changes": [
  null,
  "Uložit změny"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "Security updates available": [
  null,
  "Jsou k dispozici aktualizace zabezpečení"
 ],
 "Security updates only": [
  null,
  "Pouze aktualizace zabezpečení"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Aktualizace zabezpečení budou aplikovány $0 v $1"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Set up": [
  null,
  "Nastavit"
 ],
 "Setting up": [
  null,
  "Nastavování"
 ],
 "Settings": [
  null,
  "Nastavení"
 ],
 "Severity": [
  null,
  "Závažnost"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Software updates": [
  null,
  "Aktualizace software"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Správa balíčků je v tuto chvíli používána nějakým jiným programem, vyčkejte…"
 ],
 "Some software needs to be restarted manually": [
  null,
  "Některý software je třeba restartovat ručně"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Sundays": [
  null,
  "Neděle"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "System is up to date": [
  null,
  "Systém je aktuální"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "The following service will be restarted:": [
  null,
  "Je třeba restartovat následující službu:",
  "Je třeba restartovat následující služby:",
  "Je třeba restartovat následující služby:"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "The passwords do not match.": [
  null,
  "Zadání hesla se neshodují."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Tento hostitel se po instalaci aktualizací restartuje."
 ],
 "This system is not registered": [
  null,
  "Tento systém není zaregistrován"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje pravidla pro SELinux a může pomoci s porozuměním a řešením porušení pravidel."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Tento nástroj nastavuje systém pro zapisování výpisů pádů jádra na disk."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení, mosty, spojení, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s Ubuntu ve výchozím stavu používaným systemd-networkd a skripty ifupdown v distribuci Debian."
 ],
 "Thursdays": [
  null,
  "Čtvrtky"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Pro získávání aktualizací software je třeba systém zaregistrovat u Red Hat, buď pomocí Red Hat portálu pro zákazníky nebo místního serveru předplatného."
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Tuesdays": [
  null,
  "Úterky"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unavailable packages": [
  null,
  "Nedostupné balíčky"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "Update Success Table": [
  null,
  "Tabulka úspěchů aktualizací"
 ],
 "Update history": [
  null,
  "Historie aktualizací"
 ],
 "Update was successful": [
  null,
  "Aktualizace byla úspěšná"
 ],
 "Updated": [
  null,
  "Aktualizováno"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Aby se uplatnily, aktualizovaný balíček může vyžadovat restart."
 ],
 "Updates available": [
  null,
  "Jsou k dispozici aktualizace"
 ],
 "Updates history": [
  null,
  "Historie aktualizací"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Aktualizace bude aplikovány $0 v $1"
 ],
 "Updating": [
  null,
  "Aktualizuje se"
 ],
 "Verified": [
  null,
  "Ověřeno"
 ],
 "Verifying": [
  null,
  "Ověřuje se"
 ],
 "Version": [
  null,
  "Verze"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "View update log": [
  null,
  "Zobrazit záznamy událostí při aktualizacích"
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "Web Console will restart": [
  null,
  "Webová konzole se restartuje"
 ],
 "Wednesdays": [
  null,
  "Středy"
 ],
 "When": [
  null,
  "Když"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Když je webová konzole restartována, už neuvidíte informaci o průběhu. Nicméně aktualizační proces bude pokračovat na pozadí. Pokud chcete sledovat proces aktualizace, znovu se připojte."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Server brzy zavře spojení. Po dokončení jeho restartu se budete moci opět připojit."
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "at": [
  null,
  "v"
 ],
 "bug fix": [
  null,
  "oprava chyby"
 ],
 "enhancement": [
  null,
  "vylepšení"
 ],
 "every Friday": [
  null,
  "každý pátek"
 ],
 "every Monday": [
  null,
  "každé pondělí"
 ],
 "every Saturday": [
  null,
  "každou sobotu"
 ],
 "every Sunday": [
  null,
  "každou neděli"
 ],
 "every Thursday": [
  null,
  "každý čtvrtek"
 ],
 "every Tuesday": [
  null,
  "každé úterý"
 ],
 "every Wednesday": [
  null,
  "každou středu"
 ],
 "every day": [
  null,
  "každý den"
 ],
 "for current and future kernels": [
  null,
  "pro stávající a budoucí jádra systému"
 ],
 "for current kernel only": [
  null,
  "pouze pro stávající jádro systému"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "patches": [
  null,
  "záplaty"
 ],
 "security": [
  null,
  "zabezpečení"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ]
});
