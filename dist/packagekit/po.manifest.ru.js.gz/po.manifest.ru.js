cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Managing software updates": [
  null,
  "Управление обновлениями программного обеспечения"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Обновления программного обеспечения"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "package": [
  null,
  "пакет"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "безопасность"
 ],
 "yum": [
  null,
  "yum"
 ]
});
