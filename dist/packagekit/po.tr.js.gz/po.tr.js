cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 exited with code $1": [
  null,
  "$0, $1 koduyla çıkış yaptı"
 ],
 "$0 failed": [
  null,
  "$0 başarısız oldu"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "$0 key changed": [
  null,
  "$0 anahtarı değişti"
 ],
 "$0 killed with signal $1": [
  null,
  "$0, $1 sinyali ile sonlandırıldı"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 package": [
  null,
  "$0 paket",
  "$0 paket"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 paketin, sistemin yeniden başlatılmasına ihtiyacı var",
  "$0 paketin, sistemin yeniden başlatılmasına ihtiyacı var"
 ],
 "$0 security fix available": [
  null,
  "$0 güvenlik düzeltmesi mevcut",
  "$0 güvenlik düzeltmesi mevcut"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 hizmetin yeniden başlatılması gerekiyor",
  "$0 hizmetin yeniden başlatılması gerekiyor"
 ],
 "$0 update available": [
  null,
  "$0 güncelleme mevcut",
  "$0 güncelleme mevcut"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 will be installed.": [
  null,
  "$0 kurulacak."
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 ", including $1 security fix": [
  null,
  ", $1 güvenlik düzeltmesi dahil",
  ", $1 güvenlik düzeltmesi dahil"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0 üzerinde uyumlu bir Cockpit sürümü kurulu değil."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerinde $1 için $0 konumunda yeni bir SSH anahtarı oluşturulacak ve $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Güncellemelerin etkili olması için bir paket, sistemin yeniden başlatılmasını gerektiriyor:",
  "Güncellemelerin etkili olması için bazı paketler, sistemin yeniden başlatılmasını gerektiriyor:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Güncellemelerin etkili olması için bir hizmetin yeniden başlatılması gerekiyor:",
  "Güncellemelerin etkili olması için bazı hizmetlerin yeniden başlatılması gerekiyor:"
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Acceptable password": [
  null,
  "Kabul edilebilir parola"
 ],
 "Add $0": [
  null,
  "$0 ekle"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile Yönetim"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "All updates": [
  null,
  "Tüm güncellemeler"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rolleri belgeleri"
 ],
 "Apply kernel live patches": [
  null,
  "Çekirdek canlı yamalarını uygula"
 ],
 "Applying updates": [
  null,
  "Güncellemeler uygulanıyor"
 ],
 "Applying updates failed": [
  null,
  "Güncellemeleri uygulama başarısız oldu"
 ],
 "Authentication": [
  null,
  "Kimlik doğrulama"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile yetkili görevleri gerçekleştirmek için kimlik doğrulaması gerekir"
 ],
 "Authorize SSH key": [
  null,
  "SSH anahtarını yetkilendir"
 ],
 "Automatic updates": [
  null,
  "Otomatik güncellemeler"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Otomatik olarak ek NTP sunucularını kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "Automation script": [
  null,
  "Otomatikleştirme betiği"
 ],
 "Available updates": [
  null,
  "Mevcut güncellemeler"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Bug fix updates available": [
  null,
  "Hata düzeltme güncellemeleri mevcut"
 ],
 "Bugs": [
  null,
  "Hatalar"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Cannot forward login credentials": [
  null,
  "Oturum açma kimlik bilgileri yönlendirilemiyor"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Değiştirilen anahtarlar genellikle bir işletim sisteminin yeniden kurulması sonucudur. Ancak, beklenmeyen bir değişiklik, üçüncü tarafın bağlantınıza müdahale etme girişimini gösterebilir."
 ],
 "Check for updates": [
  null,
  "Güncellemeleri denetle"
 ],
 "Checking for package updates...": [
  null,
  "Paket güncellemeleri denetleniyor..."
 ],
 "Checking installed software": [
  null,
  "Kurulu yazılımlar denetleniyor"
 ],
 "Checking software status": [
  null,
  "Yazılım durumu denetleniyor"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager ve Firewalld'un Cockpit yapılandırması"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit, verilen anamakineyle iletişim kuramadı."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit, Linux sunucularınızı bir web tarayıcısı aracılığıyla yönetmenizi kolaylaştıran bir sunucu yöneticisidir. Terminal ve web aracı arasında geçiş yapmak sorun değildir. Cockpit aracılığıyla başlatılan bir hizmet terminal aracılığıyla durdurulabilir. Aynı şekilde, terminalde bir hata meydana gelirse, Cockpit günlüğü arayüzünde görülebilir."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit, sistemdeki yazılımla uyumlu değil."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit kurulu değil"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit sistemde kurulu değil."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit yeni sistem yöneticileri için mükemmeldir; depolama yönetimi, günlükleri inceleme, hizmetleri başlatma ve durdurma gibi basit görevleri kolayca gerçekleştirmelerine olanak tanır. Aynı anda birkaç sunucuyu izleyebilir ve yönetebilirsiniz. Bunları tek bir tıklama ile ekleyin ve makineleriniz arkadaşlarıyla ilgilensin."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Tanılama ve destek verilerini topla ve paketle"
 ],
 "Collect kernel crash dumps": [
  null,
  "Çekirdek çökme dökümlerini topla"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Confirm key password": [
  null,
  "Anahtar parolasını onayla"
 ],
 "Connection has timed out.": [
  null,
  "Bağlantı zaman aşımına uğradı."
 ],
 "Continue": [
  null,
  "Devam"
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Copied": [
  null,
  "Kopyalandı"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Create $0": [
  null,
  "$0 oluştur"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Yeni bir SSH anahtarı oluştur ve yetkilendir"
 ],
 "Create new task file with this content.": [
  null,
  "Bu içerikle yeni görev dosyası oluştur."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Danger alert:": [
  null,
  "Tehlike uyarısı:"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Disabled": [
  null,
  "Etkisizleştirildi"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "Downloaded": [
  null,
  "İndirildi"
 ],
 "Downloading": [
  null,
  "İndiriliyor"
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Enable": [
  null,
  "Etkinleştir"
 ],
 "Enabled": [
  null,
  "Etkinleştirildi"
 ],
 "Enhancement updates available": [
  null,
  "İyileştirme güncellemeleri mevcut"
 ],
 "Errata": [
  null,
  "Düzeltme"
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld içinde $0 etkinleştirme başarısız oldu"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "dnf-automatic.timer veya dnf-automatic-install.timer için birim dosyalarını ayrıştırma başarısız oldu. Lütfen otomatik güncellemeleri yapılandırmak için özel geçersiz kılmaları kaldırın."
 ],
 "Failed to restart service": [
  null,
  "Hizmeti yeniden başlatma başarısız oldu"
 ],
 "Fridays": [
  null,
  "Cuma günleri"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Hide confirmation password": [
  null,
  "Onay parolasını gizle"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "History package count": [
  null,
  "Geçmiş paket sayısı"
 ],
 "Host key is incorrect": [
  null,
  "Anamakine anahtarı yanlış"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Eğer parmak izi eşleşirse, 'Anamakineye güven ve ekle'ye tıklayın. Aksi takdirde, bağlanmayın ve yöneticinize başvurun."
 ],
 "Ignore": [
  null,
  "Yoksay"
 ],
 "Info": [
  null,
  "Bilgi"
 ],
 "Initializing...": [
  null,
  "Başlatılıyor..."
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Install all updates": [
  null,
  "Tüm güncellemeleri kur"
 ],
 "Install kpatch updates": [
  null,
  "kpatch güncellemelerini kur"
 ],
 "Install security updates": [
  null,
  "Güvenlik güncellemelerini kur"
 ],
 "Install software": [
  null,
  "Yazılım kur"
 ],
 "Installed": [
  null,
  "Kuruldu"
 ],
 "Installing": [
  null,
  "Kuruluyor"
 ],
 "Installing $0": [
  null,
  "$0 kuruluyor"
 ],
 "Internal error": [
  null,
  "İç hata"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid file permissions": [
  null,
  "Geçersiz dosya izinleri"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Çekirdek canlı yaması $0 etkin"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Çekirdek canlı yaması $0 kuruldu"
 ],
 "Kernel live patch settings": [
  null,
  "Çekirdek canlı yaması ayarları"
 ],
 "Kernel live patching": [
  null,
  "Çekirdek canlı yamalama"
 ],
 "Key password": [
  null,
  "Anahtar parolası"
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Last checked: $0": [
  null,
  "Son denetleme: $0"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "Loading available updates failed": [
  null,
  "Mevcut güncellemeleri yükleme başarısız oldu"
 ],
 "Loading available updates, please wait...": [
  null,
  "Mevcut güncellemeler yükleniyor, lütfen bekleyin..."
 ],
 "Loading system modifications...": [
  null,
  "Sistem değişiklikleri yükleniyor..."
 ],
 "Log in": [
  null,
  "Oturum aç"
 ],
 "Log in to $0": [
  null,
  "$0 üzerinde oturum aç"
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "Login failed": [
  null,
  "Oturum açma başarısız oldu"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Manage storage": [
  null,
  "Depolamayı yönet"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mondays": [
  null,
  "Pazartesi günleri"
 ],
 "More info...": [
  null,
  "Daha fazla bilgi..."
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "No system modifications": [
  null,
  "Sistem değişiklikleri yok"
 ],
 "No updates": [
  null,
  "Güncellemeler yok"
 ],
 "Not a valid private key": [
  null,
  "Geçerli bir özel anahtar değil"
 ],
 "Not available": [
  null,
  "Mevcut değil"
 ],
 "Not installed": [
  null,
  "Kurulmadı"
 ],
 "Not permitted to perform this action.": [
  null,
  "Bu eylemi gerçekleştirmeye izinli değil."
 ],
 "Not registered": [
  null,
  "Kayıtlı değil"
 ],
 "Not set up": [
  null,
  "Ayarlanmadı"
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Oluşumlar"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit kurulduktan sonra, \"systemctl enable --now cockpit.socket\" komutuyla etkinleştirin."
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "Package information": [
  null,
  "Paket bilgileri"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit kurulu değil"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit $0 hata kodunu bildirdi"
 ],
 "Packages": [
  null,
  "Paketler"
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Password not accepted": [
  null,
  "Parola kabul edilmedi"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "Lütfen sorunu çözün ve bu sayfayı yeniden yükleyin."
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen aracılığıyla sorma zaman aşımına uğradı"
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Reboot after completion": [
  null,
  "Tamamlandıktan sonra yeniden başlat"
 ],
 "Reboot recommended": [
  null,
  "Yeniden başlatma önerilir"
 ],
 "Reboot system...": [
  null,
  "Sistemi yeniden başlat..."
 ],
 "Refreshing package information": [
  null,
  "Paket bilgileri yenileniyor"
 ],
 "Register…": [
  null,
  "Kaydol…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Kalan hizmetlerin durumu yeniden yükleniyor"
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Restart services": [
  null,
  "Hizmetleri yeniden başlat"
 ],
 "Restart services...": [
  null,
  "Hizmetleri yeniden başlat..."
 ],
 "Restarting": [
  null,
  "Yeniden başlatılıyor"
 ],
 "Row expansion": [
  null,
  "Satır genişletme"
 ],
 "Row select": [
  null,
  "Satır seçimi"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Bu komutu güvenilir bir ağ üzerinden veya fiziksel olarak uzaktaki makinede çalıştırın:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH anahtarı"
 ],
 "SSH key login": [
  null,
  "SSH anahtarı oturum açma"
 ],
 "Saturdays": [
  null,
  "Cumartesi günleri"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Save changes": [
  null,
  "Değişiklikleri kaydet"
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Güvenlik Gelişmiş Linux yapılandırması ve sorun giderme"
 ],
 "Security updates available": [
  null,
  "Güvenlik güncellemeleri mevcut"
 ],
 "Security updates only": [
  null,
  "Sadece güvenlik güncellemeleri"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Güvenlik güncellemeleri, $0 saat $1'da uygulanacaktır"
 ],
 "Server has closed the connection.": [
  null,
  "Sunucu bağlantıyı kapattı."
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Set up": [
  null,
  "Ayarlandı"
 ],
 "Setting up": [
  null,
  "Ayarlanıyor"
 ],
 "Settings": [
  null,
  "Ayarlar"
 ],
 "Severity": [
  null,
  "Önem derecesi"
 ],
 "Shell script": [
  null,
  "Kabuk betiği"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Onay parolasını göster"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Software updates": [
  null,
  "Yazılım güncellemeleri"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Şu anda başka bir program paket yöneticisini kullanıyor, lütfen bekleyin..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Bazı yazılımların el ile yeniden başlatılması gerekiyor"
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Status": [
  null,
  "Durum"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Strong password": [
  null,
  "Güçlü parola"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Sundays": [
  null,
  "Pazar günleri"
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "System is up to date": [
  null,
  "Sistem güncel"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerindeki $1 kullanıcısının $0 SSH anahtarı, $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "$0 SSH anahtarı, oturumun geri kalanı için kullanılabilir olacak ve diğer anamakinelerde oturum açmak için de kullanılabilecektir."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı ve anamakine bir parola ile oturum açmaya izin vermiyor. Lütfen $1 konumundaki anahtarın parolasını sağlayın."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı. Oturum açma parolanızla veya $1 konumundaki anahtarın parolasını sağlayarak oturum açabilirsiniz."
 ],
 "The fingerprint should match:": [
  null,
  "Parmak izi eşleşmeli:"
 ],
 "The following service will be restarted:": [
  null,
  "Aşağıdaki hizmet yeniden başlatılacaktır:",
  "Aşağıdaki hizmetler yeniden başlatılacaktır:"
 ],
 "The key password can not be empty": [
  null,
  "Anahtar parolası boş olamaz"
 ],
 "The key passwords do not match": [
  null,
  "Anahtar parolaları eşleşmiyor"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Oturum açmış kullanıcının sistem değişikliklerini görüntülemesine izin verilmiyor"
 ],
 "The password can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Ortaya çıkan parmak izinin, e-posta dahil olmak üzere herkese açık yöntemlerle paylaşılması uygundur."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Ortaya çıkan parmak izi, e-posta dahil ortak yöntemler aracılığıyla paylaşılabilir. Eğer başka birinden doğrulamayı sizin için yapmasını istiyorsanız, sonuçları herhangi bir yöntemi kullanarak gönderebilirler."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Sunucu, desteklenen herhangi bir yöntemi kullanarak kimlik doğrulamayı reddetti."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Güncellemeler kurulduktan sonra bu anamakine yeniden başlayacak."
 ],
 "This system is not registered": [
  null,
  "Bu sistem kayıtlı değil"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Bu araç, SELinux ilkesini yapılandırır ve ilke ihlallerinin anlaşılmasına ve çözülmesine yardımcı olabilir."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Bu araç, sistemi çekirdek çökme dökümlerini yazmak için yapılandırır. \"Yerel\" (disk), \"ssh\" ve \"nfs\" döküm hedeflerini destekler."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Bu araç, çalışan sistemden bir yapılandırma ve tanılama bilgileri arşivi oluşturur. Arşiv, kayıt veya izleme amacıyla yerel veya merkezi olarak depolanabilir veya teknik hata bulma ve hata ayıklamaya yardımcı olması için teknik destek temsilcilerine, geliştiricilere veya sistem yöneticilerine gönderilebilir."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Bu araç, dosya sistemleri, LVM2 birim grupları ve NFS bağlamaları gibi yerel depolamayı yönetir."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Bu araç, NetworkManager ve Firewalld kullanarak birleştirmeler, köprüler, takımlar, VLAN'lar ve güvenlik duvarları gibi ağları yönetir. NetworkManager, Ubuntu'nun varsayılan systemd-networkd ve Debian'ın ifupdown betikleriyle uyumsuzdur."
 ],
 "Thursdays": [
  null,
  "Perşembe günleri"
 ],
 "Time": [
  null,
  "Zaman"
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Bağlantınızın kötü niyetli bir üçüncü tarafça engellenmediğinden emin olmak için lütfen anamakine anahtar parmak izini doğrulayın:"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Yazılım güncellemelerini almak için bu sistemin Red Hat Müşteri Portalı veya yerel bir abonelik sunucusu kullanılarak Red Hat'e kaydedilmesi gerekir."
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Bir parmak izini doğrulamak için makinede fiziksel olarak bulunurken veya güvenilir bir ağ aracılığıyla $0 üzerinde aşağıdakileri çalıştırın:"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Too much data": [
  null,
  "Çok fazla veri"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust and add host": [
  null,
  "Anamakineye güven ve ekle"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "Tuesdays": [
  null,
  "Salı günleri"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 için oturum açılamıyor. Lütfen parolayı girin."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 üzerinde oturum açılamıyor. Anamakine, parola ile oturum açmayı veya SSH anahtarlarınızdan hiçbirini kabul etmiyor."
 ],
 "Unavailable packages": [
  null,
  "Kullanılamayan paketler"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Unknown host: $0": [
  null,
  "Bilinmeyen anamakine: $0"
 ],
 "Untrusted host": [
  null,
  "Güvenilmeyen anamakine"
 ],
 "Update Success Table": [
  null,
  "Başarı Tablosunu Güncelle"
 ],
 "Update history": [
  null,
  "Güncelleme geçmişi"
 ],
 "Update was successful": [
  null,
  "Güncelleme başarılı oldu"
 ],
 "Updated": [
  null,
  "Güncellendi"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Güncellenen paketlerin etkili olması için yeniden başlatma gerekebilir."
 ],
 "Updates available": [
  null,
  "Güncellemeler mevcut"
 ],
 "Updates history": [
  null,
  "Güncellemelerin geçmişi"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Güncellemeler, $0 saat $1'da uygulanacaktır"
 ],
 "Updating": [
  null,
  "Güncellenen"
 ],
 "Verified": [
  null,
  "Doğrulandı"
 ],
 "Verify fingerprint": [
  null,
  "Parmak izini doğrula"
 ],
 "Verifying": [
  null,
  "Doğrulanıyor"
 ],
 "Version": [
  null,
  "Sürüm"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "View automation script": [
  null,
  "Otomatikleştirme betiğini görüntüle"
 ],
 "View update log": [
  null,
  "Güncelleme günlüğünü görüntüle"
 ],
 "Visit firewall": [
  null,
  "Güvenlik duvarını ziyaret et"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Weak password": [
  null,
  "Zayıf parola"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux sunucuları için Web Konsolu"
 ],
 "Web Console will restart": [
  null,
  "Web Konsolu yeniden başlayacak"
 ],
 "Wednesdays": [
  null,
  "Çarşamba günleri"
 ],
 "When": [
  null,
  "Zamanı"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Web Konsolu yeniden başlatıldığında, ilerleme bilgilerini artık görmeyeceksiniz. Ancak güncelleme işlemi arka planda devam edecek. Güncelleme işlemini izlemeye devam etmek için yeniden bağlanın."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "İlk kez $0 için bağlanıyorsunuz."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Sunucunuz bağlantıyı yakında kapatacak. Yeniden başlatıldıktan sonra yeniden bağlanabilirsiniz."
 ],
 "Your session has been terminated.": [
  null,
  "Oturumunuz sonlandırıldı."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Oturumunuzun süresi doldu. Lütfen tekrar oturum açın."
 ],
 "Zone": [
  null,
  "Bölge"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "at": [
  null,
  "saat"
 ],
 "bug fix": [
  null,
  "hata düzeltme"
 ],
 "enhancement": [
  null,
  "iyileştirme"
 ],
 "every Friday": [
  null,
  "her Cuma"
 ],
 "every Monday": [
  null,
  "her Pazartesi"
 ],
 "every Saturday": [
  null,
  "her Cumartesi"
 ],
 "every Sunday": [
  null,
  "her Pazar"
 ],
 "every Thursday": [
  null,
  "her Perşembe"
 ],
 "every Tuesday": [
  null,
  "her Salı"
 ],
 "every Wednesday": [
  null,
  "her Çarşamba"
 ],
 "every day": [
  null,
  "her gün"
 ],
 "for current and future kernels": [
  null,
  "şu anki ve gelecek çekirdekler için"
 ],
 "for current kernel only": [
  null,
  "sadece şu anki çekirdek için"
 ],
 "in less than a minute": [
  null,
  "bir dakikadan az süre"
 ],
 "less than a minute ago": [
  null,
  "bir dakikadan az bir süre önce"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "patches": [
  null,
  "yamalar"
 ],
 "security": [
  null,
  "güvenlik"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ]
});
