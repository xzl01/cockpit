cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 package": [
  null,
  "$0 pacchetto",
  "$0 pacchetti"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 pacchetto richiede un riavvio di sistema",
  "$0 pacchetti richiedono un riavvio di sistema"
 ],
 "$0 security fix available": [
  null,
  "Aggiornamento di sicurezza disponibile",
  "Aggiornamenti di sicurezza disponibili"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 servizio deve essere riavviato",
  "$0 servizi devono essere riavviati"
 ],
 "$0 update available": [
  null,
  "$0 aggiornamento disponibile",
  "$0 aggiornamenti disponibili"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 ", including $1 security fix": [
  null,
  ", compresa $1 correzione di sicurezza",
  ", comprese $1 correzioni di sicurezza"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Un pacchetto richiede un riavvio di sistema perché gli aggiornamenti prendano effetto:",
  "Alcuni pacchietti richiedono un riavvio di sistema perché gli aggiornamenti prendano effetto:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Un servizio deve essere riavviato perché gli aggiornamenti prendano effetto:",
  "Alcuni servizi devono essere riavviati perché gli aggiornamenti prendano effetto:"
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "All updates": [
  null,
  "Tutti gli aggiornamenti"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Apply kernel live patches": [
  null,
  "Applicare le patch live del kernel"
 ],
 "Applying updates": [
  null,
  "Sto installando gli aggiornamenti"
 ],
 "Applying updates failed": [
  null,
  "Impossibile installare gli aggiornamenti"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ],
 "Automatic updates": [
  null,
  "Aggiornamenti automatici"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "Available updates": [
  null,
  "Aggiornamenti disponibili"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Bug fix updates available": [
  null,
  "Aggiornamenti per bug fix disponibili"
 ],
 "Bugs": [
  null,
  "Bug"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "Change": [
  null,
  "Cambia"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Check for updates": [
  null,
  "Controlla gli aggiornamenti"
 ],
 "Checking for package updates...": [
  null,
  "Verifica aggiornamento pacchetti..."
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "Checking software status": [
  null,
  "Controllo stato software"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Continue": [
  null,
  "Continua"
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Copy": [
  null,
  "Copia"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Danger alert:": [
  null,
  "Avviso di pericolo:"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Disabled": [
  null,
  "Disabilitato"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "Downloaded": [
  null,
  "Scaricato"
 ],
 "Downloading": [
  null,
  "Download in corso"
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Enable": [
  null,
  "Abilita"
 ],
 "Enabled": [
  null,
  "Attivato"
 ],
 "Enhancement updates available": [
  null,
  "Aggiornamenti disponibili"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Impossibile analizzare i file dell'unità per dnf-automatic.timer o dnf-automatic-install.timer. Rimuovi le impostazioni personalizzate per configurare gli aggiornamenti automatici."
 ],
 "Failed to restart service": [
  null,
  "Impossibile riavviare il servizio"
 ],
 "Fridays": [
  null,
  "Venerdì"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "History package count": [
  null,
  "Conteggio pacchetti cronologia"
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "Ignore": [
  null,
  "Ignora"
 ],
 "Info": [
  null,
  "Info"
 ],
 "Initializing...": [
  null,
  "Inizializzazione..."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Install all updates": [
  null,
  "Installa tutti gli aggiornamenti"
 ],
 "Install kpatch updates": [
  null,
  "Installa gli aggiornamenti kpatch"
 ],
 "Install security updates": [
  null,
  "Installa gli aggiornamenti di sicurezza"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "Installed": [
  null,
  "Installato"
 ],
 "Installing": [
  null,
  "Installazione in corso"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Kernel live patch $0 is active": [
  null,
  "La patch live Kernel $0 è attiva"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "La patch live Kernel $0 è installata"
 ],
 "Kernel live patch settings": [
  null,
  "Impostazioni della patch live del kernel"
 ],
 "Kernel live patching": [
  null,
  "Patch live del kernel"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Last checked: $0": [
  null,
  "Ultimo controllo: $0"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "Loading available updates failed": [
  null,
  "Caricamento degli aggiornamenti disponibili non riuscito"
 ],
 "Loading available updates, please wait...": [
  null,
  "Caricamento degli aggiornamenti disponibili, attendere....."
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mondays": [
  null,
  "Lunedì"
 ],
 "More info...": [
  null,
  "Più informazioni..."
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "No updates": [
  null,
  "Nessun aggiornamento"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Not available": [
  null,
  "Non disponibile"
 ],
 "Not installed": [
  null,
  "Non installato"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Not registered": [
  null,
  "Non Registrato"
 ],
 "Not set up": [
  null,
  "Nessun set up"
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Other": [
  null,
  "Altro"
 ],
 "Package information": [
  null,
  "Informazioni sul pacchetto"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit non è installato"
 ],
 "PackageKit reported error code $0": [
  null,
  "Codice di errore segnalato da PackageKit $0"
 ],
 "Packages": [
  null,
  "Pacchetti"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "Per favore risolvi il problema e ricarica questa pagina."
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Reboot after completion": [
  null,
  "Riavvio dopo il completamento"
 ],
 "Reboot recommended": [
  null,
  "Riavvio consigliato"
 ],
 "Reboot system...": [
  null,
  "Riavvio del sistema..."
 ],
 "Refreshing package information": [
  null,
  "Aggiorno le informazioni sul pacchetto"
 ],
 "Register…": [
  null,
  "Registrati…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Ricaricare lo stato dei servizi rimanenti"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Removing $0": [
  null,
  "Rimozione $0"
 ],
 "Restart services": [
  null,
  "Riavvia i servizi"
 ],
 "Restart services...": [
  null,
  "Riavvia i servizi..."
 ],
 "Restarting": [
  null,
  "Riavvio"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "Sabati"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Save changes": [
  null,
  "Salva modifiche"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "Security updates available": [
  null,
  "Aggiornamenti di sicurezza disponibili"
 ],
 "Security updates only": [
  null,
  "Solo aggiornamenti di sicurezza"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Gli aggiornamenti di sicurezza saranno applicati $0 a $1"
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Set up": [
  null,
  "Configura"
 ],
 "Setting up": [
  null,
  "Impostazione"
 ],
 "Settings": [
  null,
  "Impostazioni"
 ],
 "Severity": [
  null,
  "Severità"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shut down": [
  null,
  "Arresto"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Software updates": [
  null,
  "Aggiornamenti software"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Qualche altro programma sta attualmente utilizzando il gestore di pacchetti, si prega di attendere..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Alcuni software devono essere riavviati manualmente"
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Status": [
  null,
  "Stato"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Sundays": [
  null,
  "Domeniche"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "System is up to date": [
  null,
  "Il sistema è aggiornato"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "The following service will be restarted:": [
  null,
  "Verrà riavviato il seguente servizio:",
  "Verranno riavviati i seguenti servizi:"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "The passwords do not match.": [
  null,
  "Le password non corrispondono."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Questo host verrà riavviato quando gli aggiornamenti saranno installati."
 ],
 "This system is not registered": [
  null,
  "Questo sistema non è registrato"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Questo strumento configura il sistema per scrivere i crash dump del kernel su disco."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "Thursdays": [
  null,
  "Giovedì"
 ],
 "Time": [
  null,
  "Ora"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Per ottenere gli aggiornamenti software, questo sistema deve essere registrato con Red Hat, utilizzando il portale clienti Red Hat o un server locale in abbonamento."
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Tuesdays": [
  null,
  "Martedì"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "Update history": [
  null,
  "Cronologia degli aggiornamenti"
 ],
 "Updated": [
  null,
  "Aggiornato"
 ],
 "Updates available": [
  null,
  "Aggiornamenti disponibili"
 ],
 "Updates history": [
  null,
  "Cronologia degli aggiornamenti"
 ],
 "Updating": [
  null,
  "Aggiornamento"
 ],
 "Verified": [
  null,
  "Verificato"
 ],
 "Verifying": [
  null,
  "Verifica"
 ],
 "Version": [
  null,
  "Versione"
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "Wednesdays": [
  null,
  "Mercoledì"
 ],
 "When": [
  null,
  "Quando"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Quando la console Web viene riavviata, non vedrai più le informazioni sullo stato di avanzamento. Tuttavia, il processo di aggiornamento continuerà in background. Riconnettiti per continuare a monitorare il processo di aggiornamento."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Il server chiuderà presto la connessione. È possibile riconnettersi dopo che è stato riavviato."
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "at": [
  null,
  "a"
 ],
 "bug fix": [
  null,
  "bug fix"
 ],
 "enhancement": [
  null,
  "miglioramento"
 ],
 "every day": [
  null,
  "quotidianamente"
 ],
 "for current and future kernels": [
  null,
  "per kernel attuali e futuri"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "patches": [
  null,
  "patch"
 ],
 "security": [
  null,
  "sicurezza"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ]
});
