cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Managing software updates": [
  null,
  "ניהול עדכוני תכנה"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "עדכוני תכנה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "package": [
  null,
  "חבילה"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "אבטחה"
 ],
 "yum": [
  null,
  "yum"
 ]
});
