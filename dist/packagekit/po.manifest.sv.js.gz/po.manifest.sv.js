cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Managing software updates": [
  null,
  "Hantera programuppdateringar"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Programvaruuppdateringar"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kpatch"
 ],
 "package": [
  null,
  "paket"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "säkerhet"
 ],
 "updates": [
  null,
  "uppdateringar"
 ],
 "yum": [
  null,
  "yum"
 ]
});
