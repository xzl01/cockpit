cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Managing software updates": [
  null,
  "Administrere programvareoppdateringer"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Programvare oppdateringer"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  ""
 ],
 "package": [
  null,
  "pakke"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "sikkerhet"
 ],
 "yum": [
  null,
  "yum"
 ]
});
