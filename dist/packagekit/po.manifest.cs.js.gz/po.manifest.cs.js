cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Managing software updates": [
  null,
  "Správa aktualizací software"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Aktualizace software"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kpatch"
 ],
 "package": [
  null,
  "balíček"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "zabezpečení"
 ],
 "updates": [
  null,
  "aktualizace"
 ],
 "yum": [
  null,
  "yum"
 ]
});
