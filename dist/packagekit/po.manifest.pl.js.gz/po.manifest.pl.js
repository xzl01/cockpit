cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Managing software updates": [
  null,
  "Zarządzanie aktualizacjami oprogramowania"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Aktualizacje oprogramowania"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "DNF"
 ],
 "package": [
  null,
  "pakiet"
 ],
 "packagekit": [
  null,
  "PackageKit"
 ],
 "security": [
  null,
  "bezpieczeństwo"
 ],
 "yum": [
  null,
  "yum"
 ]
});
