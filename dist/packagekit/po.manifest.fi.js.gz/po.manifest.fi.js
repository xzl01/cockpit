cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Managing software updates": [
  null,
  "Ohjelmistopäivitysten hallinta"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Ohjelmistopäivitykset"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "package": [
  null,
  "paketti"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "turvallisuus"
 ],
 "updates": [
  null,
  "päivitykset"
 ],
 "yum": [
  null,
  "yum"
 ]
});
