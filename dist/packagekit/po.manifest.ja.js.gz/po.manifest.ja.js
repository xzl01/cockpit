cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Managing software updates": [
  null,
  "ソフトウェアアップデート管理"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "ソフトウェア更新"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kpatch"
 ],
 "package": [
  null,
  "パッケージ"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "セキュリティー"
 ],
 "updates": [
  null,
  "更新"
 ],
 "yum": [
  null,
  "yum"
 ]
});
