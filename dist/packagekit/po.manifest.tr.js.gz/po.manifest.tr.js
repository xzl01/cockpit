cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Managing software updates": [
  null,
  "Yazılım güncellemelerini yönetme"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Yazılım güncellemeleri"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kpatch"
 ],
 "package": [
  null,
  "paket"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "güvenlik"
 ],
 "updates": [
  null,
  "güncellemeler"
 ],
 "yum": [
  null,
  "yum"
 ]
});
