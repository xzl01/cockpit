cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Managing software updates": [
  null,
  "Gestion des mises à jour logicielles"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Mises à jour de logiciel"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "package": [
  null,
  "package"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "sécurité"
 ],
 "yum": [
  null,
  "yum"
 ]
});
