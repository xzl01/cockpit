cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "აპლიკაციები"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "add-on": [
  null,
  "დამატება"
 ],
 "addon": [
  null,
  "დამატება"
 ],
 "apps": [
  null,
  "აპები"
 ],
 "extension": [
  null,
  "გაფართოება"
 ],
 "install": [
  null,
  "დაყენება"
 ],
 "plugin": [
  null,
  "ჩადგმა"
 ]
});
