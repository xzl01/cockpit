cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "アプリケーション"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "add-on": [
  null,
  "アドオン"
 ],
 "addon": [
  null,
  "アドオン"
 ],
 "apps": [
  null,
  "アプリ"
 ],
 "extension": [
  null,
  "拡張"
 ],
 "install": [
  null,
  "インストール"
 ],
 "plugin": [
  null,
  "プラグイン"
 ]
});
