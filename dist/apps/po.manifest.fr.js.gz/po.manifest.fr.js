cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Applications"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "add-on": [
  null,
  "greffon"
 ],
 "addon": [
  null,
  "greffon"
 ],
 "apps": [
  null,
  "applis"
 ],
 "extension": [
  null,
  "extension"
 ],
 "install": [
  null,
  "Installer"
 ],
 "plugin": [
  null,
  "plugin"
 ]
});
