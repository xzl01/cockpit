cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Uygulamalar"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "add-on": [
  null,
  "eklenti"
 ],
 "addon": [
  null,
  "eklenti"
 ],
 "apps": [
  null,
  "uygulamalar"
 ],
 "extension": [
  null,
  "uzantı"
 ],
 "install": [
  null,
  "kur"
 ],
 "plugin": [
  null,
  "eklenti"
 ]
});
