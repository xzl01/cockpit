cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Acceptable password": [
  null,
  "Прийнятний пароль"
 ],
 "Actions": [
  null,
  "Дії"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Адміністрування за допомогою вебконсолі Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документація з ролей Ansible"
 ],
 "Application information is missing": [
  null,
  "Немає даних щодо програми"
 ],
 "Applications": [
  null,
  "Програми"
 ],
 "Applications list": [
  null,
  "Список програм"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Щоб отримати доступ до виконання привілейованих завдань за допомогою вебконсолі Cockpit, слід пройти розпізнавання"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматично за допомогою додаткових серверів NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Automation script": [
  null,
  "Скрипт автоматизації"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Checking for new applications": [
  null,
  "Шукаємо нові програми"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Налаштування Cockpit для NetworkManager і Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit — програма для керування сервером, яка полегшує адміністрування ваших серверів під керуванням Linux за допомогою програми для перегляду сторінок інтернету. Ви зможете одночасно використовувати термінал і вебінструмент. Службу, яку було запущено за допомогою Cockpit, можна зупинити за допомогою термінала. І навпаки, якщо трапиться помилка у терміналі, ви побачите її у інтерфейсі журналу Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit — чудовий інструмент для системних адміністраторів-початківців. За його допомогою вони без проблем впораються із простими завданнями, зокрема адмініструванням сховищ даних, інспектуванням журналів та запуском і зупиненням служб. Ви зможете одночасно стежити за роботою декількох серверів і адмініструвати ці сервери. Просто додайте їх одним клацанням кнопкою миші і ваш комп’ютер сам нагляне за своїми приятелями."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Збирати і пакувати діагностичні дані і дані щодо підтримки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Збирати дампи аварій ядра"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Create new task file with this content.": [
  null,
  "Створити файл завдання із цим вмістом."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "Downloading $0": [
  null,
  "Отримуємо $0"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Go to application": [
  null,
  "Перейти до програми"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "Hide confirmation password": [
  null,
  "Приховати підтвердження пароля"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Install application information": [
  null,
  "Встановити дані щодо програми"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "Installing": [
  null,
  "Встановлення"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Loading system modifications...": [
  null,
  "Завантажуємо модифікації системи…"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Manage storage": [
  null,
  "Керування сховищем"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "No applications installed or available.": [
  null,
  "Немає встановлених або доступних програм."
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "No description provided.": [
  null,
  "Опису не надано."
 ],
 "No installation package found for this application.": [
  null,
  "Для цієї програми не знайдено пакунка для встановлення."
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "No system modifications": [
  null,
  "Немає модифікацій системи"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "Випадки"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Після встановлення Cockpit його можна увімкнути за допомогою команди «systemctl enable --now cockpit.socket»."
 ],
 "Other": [
  null,
  "Інше"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Paste error": [
  null,
  "Помилка вставлення"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Removing": [
  null,
  "Вилучаємо"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Row expansion": [
  null,
  "Розгортання рядка"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Налаштування Security Enhanced Linux та усування вад"
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Shell script": [
  null,
  "Скрипт оболонки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Показати підтвердження пароля"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Strong password": [
  null,
  "Складний пароль"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Користувач, який увійшов до системи, не має права переглядати модифікації системи"
 ],
 "The passwords do not match.": [
  null,
  "Паролі не збігаються."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Цей інструмент налаштовує правила SELinux і може допомогти зрозуміти та усунути порушення правил."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Цей інструмент налаштовує систему на запис дампів аварій ядра на диск."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Цей інструмент створюдє архів даних щодо налаштувань та діагностики для запущеної системи. Архів може бути збережено локально або централізовано з метою журналювання або стеження або надіслано до представників технічної підтримки, розробників або адміністраторів системи, щоб допомогти з пошуком технічних проблем та діагностикою."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Цей інструмент керує локальним сховищем даних, зокрема файловими системами, групами томів LVM2 та монтуваннями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Цей інструмент керує можливостями роботи у мережі, зокрема зв'язками, містками, командами, віртуальними LAN та брандмауерами, за допомогою NetworkManager і Firewalld. NetworkManager є несумісним із типовим для Ubuntu systemd-networkd та скриптами ifupdown Debian."
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Unknown application": [
  null,
  "Невідома програма"
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Update package information": [
  null,
  "Оновити дані щодо пакунків"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "View automation script": [
  null,
  "Переглянути скрипт автоматизації"
 ],
 "View project website": [
  null,
  "Переглянути сайт проєкту"
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Очікуємо на завершення роботи з програмою для керування пакунками інших програм…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Weak password": [
  null,
  "Простий пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Вебконсоль для серверів під керуванням Linux"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "У вашій програмі для перегляду не передбачено можливості вставлення з контекстного меню. Ви можете скористатися для вставлення комбінацією Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ]
});
