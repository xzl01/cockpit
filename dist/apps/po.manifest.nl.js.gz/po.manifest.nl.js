cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Toepassingen"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "add-on": [
  null,
  "toevoeging"
 ],
 "addon": [
  null,
  "toevoeging"
 ],
 "apps": [
  null,
  "apps"
 ],
 "extension": [
  null,
  "extensie"
 ],
 "install": [
  null,
  "installeren"
 ],
 "plugin": [
  null,
  "plug-in"
 ]
});
