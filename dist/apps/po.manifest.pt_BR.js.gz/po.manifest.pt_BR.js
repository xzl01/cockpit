cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Aplicações"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do Kernel"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "add-on": [
  null,
  "complemento"
 ],
 "addon": [
  null,
  "complemento"
 ],
 "extension": [
  null,
  "extensão"
 ],
 "install": [
  null,
  ""
 ]
});
