cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Applicazioni"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "add-on": [
  null,
  "add-on"
 ],
 "addon": [
  null,
  "componente aggiuntivo"
 ],
 "apps": [
  null,
  "applicazioni"
 ],
 "extension": [
  null,
  "estensione"
 ],
 "install": [
  null,
  "installa"
 ],
 "plugin": [
  null,
  "plugin"
 ]
});
