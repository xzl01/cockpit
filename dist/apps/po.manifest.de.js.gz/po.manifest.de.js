cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Anwendungen"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "add-on": [
  null,
  "Add-on"
 ],
 "addon": [
  null,
  "AddOn"
 ],
 "apps": [
  null,
  "Programme"
 ],
 "extension": [
  null,
  "Erweiterung"
 ],
 "install": [
  null,
  "Installation"
 ],
 "plugin": [
  null,
  "Plugin"
 ]
});
