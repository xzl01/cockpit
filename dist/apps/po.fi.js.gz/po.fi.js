cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 exited with code $1": [
  null,
  "$0 poistui koodilla $1"
 ],
 "$0 failed": [
  null,
  "$0 epäonnistui"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 tapettu signaalilla $1"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "1 minute": [
  null,
  "1 minuutti"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "20 minutes": [
  null,
  "20 minuuttia"
 ],
 "40 minutes": [
  null,
  "40 minuuttia"
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "60 minutes": [
  null,
  "60 minuuttia"
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Actions": [
  null,
  "Toimet"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Hallinta Cockpit-verkkokonsolilla"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-roolien dokumentaatio"
 ],
 "Application information is missing": [
  null,
  ""
 ],
 "Applications": [
  null,
  "Sovellukset"
 ],
 "Applications list": [
  null,
  "Sovellusten luettelo"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Todennus vaaditaan etuoikeutettujen tehtävien suorittamiseen Cockpit Web Console:ssa"
 ],
 "Automatically using NTP": [
  null,
  "Käytetään automaattisesti NTP:tä"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Käytetään automaattisesti lisättyjä NTP-palvelimia"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Käytetään automaattisesti tiettyjä NTP-palvelimia"
 ],
 "Automation script": [
  null,
  "Automaatio-komentosarja"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Cannot forward login credentials": [
  null,
  "Kirjautumistietoja ei voi välittää eteenpäin"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tapahtumaa ei voi aikatauluttaa menneisyyteen"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Change system time": [
  null,
  "Vaihda järjestelmän aika"
 ],
 "Checking for new applications": [
  null,
  "Etsitään uusia sovelluksia"
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManagerin ja Firewalld:n Cockit-asetukset"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ei saanut yhteyttä koneeseen."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit on palvelinhallintatyökalu, joka tekee ylläpidon helpoksi selaimen kautta. Liikkuminen päätteen ja verkkokäyttöliittymän välillä ei ole ongelma. Cockpitissä aloitettu palvelu voidaan lopettaa päätteessä. Samaten päätteessä näkyvä virheilmoitus voidaan nähdä myös Cockpitin journal-näkymässä."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ei ole yhteensopiva järjestelmän ohjelmiston kanssa."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ei ole asennettu järjestelmässä."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit on täydellinen uusille ylläpitäjille. Sen avulla voi tehdä helposti toimenpiteitä kuten tallennustilan hallintaa, lokien tarkistamista sekä palveluiden käynnistämistä ja lopettamista. Voit monitoroida ja hallita useita palvelimia samanaikaisesti. Lisää ne yhdellä napsautuksella ja koneesi katsovat kavereidensa perään."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kerää ja paketoi diagnostiikkaa ja tukitietoja"
 ],
 "Collect kernel crash dumps": [
  null,
  "Kerää ytimen kaatumisvedoksia"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Connection has timed out.": [
  null,
  "Yhteys aikakatkaistiin."
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Create new task file with this content.": [
  null,
  "Luo uusi tehtävätiedosto tällä sisällöllä."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Viive"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Go to application": [
  null,
  "Siirry sovellukseen"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "Host key is incorrect": [
  null,
  "Koneen avain on väärin"
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "Installing": [
  null,
  "Asennetaan"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Internal error": [
  null,
  "Sisäinen virhe"
 ],
 "Invalid date format": [
  null,
  "Virheellinen päivämuoto"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Virheellinen päivämuoto ja aikamuoto"
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Invalid time format": [
  null,
  "Virheellinen aikamuoto"
 ],
 "Invalid timezone": [
  null,
  "Virheellinen aikavyöhyke"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "Loading system modifications...": [
  null,
  "Ladataan järjestelmän muutoksia ..."
 ],
 "Log messages": [
  null,
  "Kirjaa viestit"
 ],
 "Login failed": [
  null,
  "Kirjautuminen epäonnistui"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Manage storage": [
  null,
  "Tallennustilan hallinta"
 ],
 "Manually": [
  null,
  "Manuaalisesti"
 ],
 "Message to logged in users": [
  null,
  "Viesti sisäänkirjautuneille käyttäjille"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "NTP server": [
  null,
  "NTP-palvelin"
 ],
 "Need at least one NTP server": [
  null,
  "Tarvitaan vähintään yksi NTP-palvelin"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "No applications installed or available.": [
  null,
  "Ei sovelluksia asennettuna tai saatavilla."
 ],
 "No delay": [
  null,
  "Ei viivettä"
 ],
 "No description provided.": [
  null,
  "Kuvausta ei annettu."
 ],
 "No installation package found for this application.": [
  null,
  "Tälle sovellukselle ei löytynyt asennuspakettia."
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "No system modifications": [
  null,
  "Ei järjestelmän muutoksia"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ei oikeutta suorittaa tätä toimintoa."
 ],
 "Not synchronized": [
  null,
  "Ei synkronisoitu"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Occurrences": [
  null,
  "Tapahtumat"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Kun Cockpit on asennettu, ota se käyttöön 'systemctl enable --now cockpit.socket'."
 ],
 "Other": [
  null,
  "Muu"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Paste": [
  null,
  "Siirrä"
 ],
 "Paste error": [
  null,
  "Liittämisvirhe"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Removing": [
  null,
  "Poistetaan"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linuxin asetukset ja ongelmanratkaisu"
 ],
 "Server has closed the connection.": [
  null,
  "Palvelin on sulkenut yhteyden."
 ],
 "Set time": [
  null,
  "Aseta aika"
 ],
 "Shell script": [
  null,
  "Komentotulkin komentosarja"
 ],
 "Shift+Insert": [
  null,
  "Vaihto + Syöttö"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Specific time": [
  null,
  "Tietty aika"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Synchronized": [
  null,
  "Synkronoitu"
 ],
 "Synchronized with $0": [
  null,
  "Synkronoi palvelimen $0 kanssa"
 ],
 "Synchronizing": [
  null,
  "Synkronoidaan"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Sisäänkirjautunut käyttäjä ei saa tarkastella järjestelmän muutoksia"
 ],
 "The passwords do not match.": [
  null,
  "Salasanat eivät täsmää."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Palvelin kieltäytyi tunnistautumista käyttäen mitään tuetuista tavoista."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tämä työkalu asettaa SELinux-käytännön ja auttaa käytäntörikkeiden ymmärtämisessä ja ratkaisemisessa."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Tämä työkalu asettaa järjestelmän kirjoittamaan ytimen kaatumisvedokset levylle."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tämä työkalu luo arkiston konfiguraatio- ja diagnostiikkatiedoista käynnissä olevasta järjestelmästä. Arkisto voidaan tallentaa paikallisesti tai keskitetysti tallennus- tai seurantatarkoituksiin tai se voidaan lähettää teknisen tuen edustajille, kehittäjille tai järjestelmänvalvojille auttamaan teknisten vikojen etsinnässä ja virheenkorjauksessa."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tämä työkalu hallinnoi paikallista tallennustilaa, kuten tiedostojärjestelmiä, LVM2-taltioryhmiä ja NFS-liitoksia."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tämä työkalu hallitsee verkkoyhteyksiä, kuten sidoksia, siltoja, ryhmiä, VLAN-verkkoja ja palomuureja NetworkManagerin ja Firewalld:n avulla. NetworkManager ei ole yhteensopiva Ubuntun oletusarvoisten systemd-networkd- ja Debianin ifupdown-komentosarjojen kanssa."
 ],
 "Time zone": [
  null,
  "Aikavyöhyke"
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Too much data": [
  null,
  "Liian paljon dataa"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Trying to synchronize with $0": [
  null,
  "Yritetään synkronoida palvelimen $0 kanssa"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Unknown application": [
  null,
  "Tuntematon sovellus"
 ],
 "Untrusted host": [
  null,
  "Epäluotettava kone"
 ],
 "Update package information": [
  null,
  "Päivitä pakettitiedot"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "View automation script": [
  null,
  "Näytä automaatio-komentosarja"
 ],
 "View project website": [
  null,
  "Näytä projektin verkkosivusto"
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Odotetaan muiden ohjelmien paketinhallinnan käyttämisen päättymistä..."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Web Console for Linux servers": [
  null,
  "Verkkokonsoli Linux-palvelimille"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Selaimesi ei salli liittämistä pikavalikosta. Voit käyttää Vaihto+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Istuntosi on päätetty."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Istuntosi on vahventunut. Ole hyvä ja kirjaudu uudelleen sisään."
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ]
});
