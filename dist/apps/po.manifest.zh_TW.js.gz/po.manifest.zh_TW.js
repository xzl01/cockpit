cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "應用程式"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "add-on": [
  null,
  "附加元件"
 ],
 "addon": [
  null,
  "附加元件"
 ],
 "apps": [
  null,
  "應用程式"
 ],
 "extension": [
  null,
  "擴充"
 ],
 "install": [
  null,
  "安裝"
 ],
 "plugin": [
  null,
  "外掛程式"
 ]
});
