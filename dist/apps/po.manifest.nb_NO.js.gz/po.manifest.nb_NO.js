cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Applikasjoner"
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "add-on": [
  null,
  "tillegg"
 ],
 "addon": [
  null,
  "tillegg"
 ],
 "apps": [
  null,
  "apper"
 ],
 "extension": [
  null,
  "utvidelse"
 ],
 "install": [
  null,
  "installer"
 ],
 "plugin": [
  null,
  "utvidelse"
 ]
});
