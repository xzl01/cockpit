cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Program"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "add-on": [
  null,
  "tillägg"
 ],
 "addon": [
  null,
  "tillägg"
 ],
 "apps": [
  null,
  "program"
 ],
 "extension": [
  null,
  "tillägg"
 ],
 "install": [
  null,
  "installera"
 ],
 "plugin": [
  null,
  "insticksmodul"
 ]
});
