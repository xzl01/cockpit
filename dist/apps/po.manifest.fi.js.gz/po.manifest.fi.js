cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Sovellukset"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "add-on": [
  null,
  "lisäosa"
 ],
 "addon": [
  null,
  "lisäosa"
 ],
 "apps": [
  null,
  "sovellukset"
 ],
 "extension": [
  null,
  "laajennus"
 ],
 "install": [
  null,
  "asenna"
 ],
 "plugin": [
  null,
  "kytkettävä"
 ]
});
