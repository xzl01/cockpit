cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Applications": [
  null,
  "Aplicaciones"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "add-on": [
  null,
  "complemento"
 ],
 "addon": [
  null,
  "complemento"
 ],
 "apps": [
  null,
  "aplicaciones"
 ],
 "extension": [
  null,
  "extensión"
 ],
 "install": [
  null,
  "instalar"
 ],
 "plugin": [
  null,
  "plugin"
 ]
});
