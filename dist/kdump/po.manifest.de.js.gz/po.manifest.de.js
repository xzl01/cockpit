cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Configuring kdump": [
  null,
  "Konfiguriere kdump"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "crash": [
  null,
  "Absturz"
 ],
 "kdump": [
  null,
  "kdump"
 ]
});
