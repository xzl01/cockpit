cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Configuring kdump": [
  null,
  "正在設定 kdump"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "crash": [
  null,
  "當機"
 ],
 "kdump": [
  null,
  "kdump"
 ]
});
