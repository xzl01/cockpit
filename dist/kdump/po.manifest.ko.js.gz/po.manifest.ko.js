cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Configuring kdump": [
  null,
  "kdump 설정"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "crash": [
  null,
  "충돌"
 ],
 "kdump": [
  null,
  "K덤프"
 ]
});
