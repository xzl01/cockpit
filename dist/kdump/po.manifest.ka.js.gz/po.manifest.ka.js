cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Configuring kdump": [
  null,
  "kdump-ის მორგება"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "crash": [
  null,
  "ავარია"
 ],
 "kdump": [
  null,
  "kdump"
 ]
});
