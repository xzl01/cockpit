cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Configuring kdump": [
  null,
  "Configurando el servicio de kdump"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "crash": [
  null,
  "colapso"
 ],
 "kdump": [
  null,
  "kdump"
 ]
});
