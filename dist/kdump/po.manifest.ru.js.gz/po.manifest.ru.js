cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "Configuring kdump": [
  null,
  "Настройка kdump"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "crash": [
  null,
  "сбой"
 ],
 "kdump": [
  null,
  "kdump"
 ]
});
