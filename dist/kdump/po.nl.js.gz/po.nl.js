cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagen"
 ],
 "$0 exited with code $1": [
  null,
  "$0 verlaten met code $1"
 ],
 "$0 failed": [
  null,
  "$0 mislukte"
 ],
 "$0 hour": [
  null,
  "$0 uur",
  "$0 uren"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 is van geen enkele repository beschikbaar."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 is afgeschoten met signaal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuut",
  "$0 minuten"
 ],
 "$0 month": [
  null,
  "$0 maand",
  "$0 maanden"
 ],
 "$0 week": [
  null,
  "$0 week",
  "$0 weken"
 ],
 "$0 will be installed.": [
  null,
  "$0 zal geïnstalleerd worden."
 ],
 "$0 year": [
  null,
  "$0 jaar",
  "$0 jaren"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 uur"
 ],
 "1 minute": [
  null,
  "1 minuut"
 ],
 "1 week": [
  null,
  "1 week"
 ],
 "20 minutes": [
  null,
  "20 minuten"
 ],
 "40 minutes": [
  null,
  "40 minuten"
 ],
 "5 minutes": [
  null,
  "5 minuten"
 ],
 "6 hours": [
  null,
  "6 uren"
 ],
 "60 minutes": [
  null,
  "60 minuten"
 ],
 "Absent": [
  null,
  "Afwezig"
 ],
 "Acceptable password": [
  null,
  "Acceptabel wachtwoord"
 ],
 "Add $0": [
  null,
  "Toevoegen $0"
 ],
 "Additional packages:": [
  null,
  "Extra pakketten:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Beheer met Cockpit Web Console"
 ],
 "Advanced TCA": [
  null,
  "Geavanceerde TCA"
 ],
 "All-in-one": [
  null,
  "Alles in een"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rollen documentatie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Authenticatie is vereist voor het uitvoeren van bevoorrechte taken met de Cockpit Web Console"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch gebruik van NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatisch gebruik van extra NTP servers"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch gebruik van specifieke NTP servers"
 ],
 "Automation script": [
  null,
  "Automatiserings-script"
 ],
 "Blade": [
  null,
  "Antenne"
 ],
 "Blade enclosure": [
  null,
  "Antennebehuizing"
 ],
 "Bus expansion chassis": [
  null,
  "Busuitbreidingschassis"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inloggegevens niet doorsturen"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan evenement niet in het verleden plannen"
 ],
 "Change": [
  null,
  "Verandering"
 ],
 "Change system time": [
  null,
  "Verander systeemtijd"
 ],
 "Checking installed software": [
  null,
  "Controleren op geïnstalleerde software"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit configuratie van NetworkManager en Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kon geen contact maken met de opgegeven host."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit is een serverbeheerder waarmee je Linux-servers eenvoudig kunt beheren via een webbrowser. Omschakelen tussen de terminal en het webgereedschap is geen probleem. Een service gestart via Cockpit kan via de terminal worden gestopt. Evenzo, als er een fout optreedt in de terminal, kan deze worden gezien in de Cockpit-logboekinterface."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit is niet compatibel met de software op het systeem."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit is niet op het systeem geïnstalleerd."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit is perfect voor nieuwe systeembeheerders, waardoor ze eenvoudig eenvoudige taken kunnen uitvoeren, zoals opslagbeheer, het inspecteren van logboeken en het starten en stoppen van services. Je kunt meerdere servers tegelijkertijd bewaken en beheren. Voeg ze gewoon toe met een enkele klik en je machines zullen voor zijn maatjes zorgen."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Verzamel en verpak diagnostische en ondersteuningsdata"
 ],
 "Collect kernel crash dumps": [
  null,
  "Verzamel kernelcrashdumps"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Compress crash dumps to save space": [
  null,
  "Comprimeer crashdumps om ruimte te besparen"
 ],
 "Compression": [
  null,
  "Compressie"
 ],
 "Connection has timed out.": [
  null,
  "Er is een time-out opgetreden voor de verbinding."
 ],
 "Convertible": [
  null,
  "Converteerbaar"
 ],
 "Copy": [
  null,
  "Kopiëren"
 ],
 "Copy to clipboard": [
  null,
  "Kopiëren naar clipboard"
 ],
 "Crash dump location": [
  null,
  "Crashdump locatie"
 ],
 "Crash system": [
  null,
  "Crash systeem"
 ],
 "Create": [
  null,
  "Aanmaken"
 ],
 "Create new task file with this content.": [
  null,
  "Maak nieuw taakbestand aan met deze inhoud."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Vertraging"
 ],
 "Desktop": [
  null,
  "Bureaublad"
 ],
 "Detachable": [
  null,
  "Demonteerbaar"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Directory": [
  null,
  "Map"
 ],
 "Directory $0 isn't writable or doesn't exist.": [
  null,
  "Map $0 is niet schrijfbaar of bestaat niet."
 ],
 "Disabled": [
  null,
  "Uitgeschakeld"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "Downloading $0": [
  null,
  "$0 downloaden"
 ],
 "Dual rank": [
  null,
  "Dubbele rangorde"
 ],
 "Edit": [
  null,
  "Bewerken"
 ],
 "Embedded PC": [
  null,
  "Ingebouwde pc"
 ],
 "Enabled": [
  null,
  "Ingeschakeld"
 ],
 "Excellent password": [
  null,
  "Uitstekend wachtwoord"
 ],
 "Expansion chassis": [
  null,
  "Uitbreidingschassis"
 ],
 "Export": [
  null,
  "Exporteren"
 ],
 "Failed to change password": [
  null,
  "Kan wachtwoord niet veranderen"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Kan $0 niet inschakelen in firewalld"
 ],
 "Go to now": [
  null,
  "Ga nu naar"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Hide confirmation password": [
  null,
  "Bevestigingswachtwoord verbergen"
 ],
 "Hide password": [
  null,
  "Wachtwoord verbergen"
 ],
 "Host key is incorrect": [
  null,
  "Hostsleutel is onjuist"
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Install software": [
  null,
  "Installeer software"
 ],
 "Installing $0": [
  null,
  "$0 installeren"
 ],
 "Internal error": [
  null,
  "Interne fout"
 ],
 "Invalid date format": [
  null,
  "Ongeldige datum"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ongeldige datumnotatie en ongeldige tijdnotatie"
 ],
 "Invalid file permissions": [
  null,
  "Ongeldige bestandsrechten"
 ],
 "Invalid time format": [
  null,
  "Ongeldige tijdnotatie"
 ],
 "Invalid timezone": [
  null,
  "Ongeldige tijdzone"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Kernel crash dump": [
  null,
  "Kernelcrashdump"
 ],
 "Kernel did not boot with the $0 setting": [
  null,
  ""
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "Loading system modifications...": [
  null,
  "Systeemwijzigingen laden..."
 ],
 "Loading...": [
  null,
  "Laden..."
 ],
 "Local filesystem": [
  null,
  "Lokaal bestandssysteem"
 ],
 "Location": [
  null,
  "Locatie"
 ],
 "Log messages": [
  null,
  "Log berichten"
 ],
 "Login failed": [
  null,
  "Inloggen mislukte"
 ],
 "Low profile desktop": [
  null,
  "Laag profiel bureaublad"
 ],
 "Lunch box": [
  null,
  "Lunchbox"
 ],
 "Main server chassis": [
  null,
  "Hoofdserverchassis"
 ],
 "Manage storage": [
  null,
  "Beheerde opslag"
 ],
 "Manually": [
  null,
  "Handmatig"
 ],
 "Message to logged in users": [
  null,
  "Bericht aan ingelogde gebruikers"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Multi-system chassis": [
  null,
  "Chassis met meerdere systemen"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Need at least one NTP server": [
  null,
  "Minimaal één NTP-server nodig"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "New password was not accepted": [
  null,
  "Nieuw wachtwoord is niet geaccepteerd"
 ],
 "No configuration found": [
  null,
  "Geen configuratie gevonden"
 ],
 "No delay": [
  null,
  "Geen vertraging"
 ],
 "No such file or directory": [
  null,
  "Bestand of map bestaat niet"
 ],
 "No system modifications": [
  null,
  "Geen systeemwijzigingen"
 ],
 "None": [
  null,
  "Geen"
 ],
 "Not a valid private key": [
  null,
  "Geen geldige privésleutel"
 ],
 "Not permitted to perform this action.": [
  null,
  "Niet toegestaan om deze actie uit te voeren."
 ],
 "Not synchronized": [
  null,
  "Niet gesynchroniseerd"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Voorvallen"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Oude wachtwoord niet geaccepteerd"
 ],
 "On a mounted device": [
  null,
  "Op een aangekoppeld apparaat"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Nadat Cockpit geïnstalleerd is, schakel je het in met \"systemctl enable --now cockpit.socket\"."
 ],
 "Other": [
  null,
  "Andere"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "Password is not acceptable": [
  null,
  "Wachtwoord is niet acceptabel"
 ],
 "Password is too weak": [
  null,
  "Wachtwoord is te zwak"
 ],
 "Password not accepted": [
  null,
  "Wachtwoord wordt niet geaccepteerd"
 ],
 "Paste": [
  null,
  "Plakken"
 ],
 "Paste error": [
  null,
  "Plakfout"
 ],
 "Path to file": [
  null,
  "Pad naar bestand"
 ],
 "Peripheral chassis": [
  null,
  "Randchassis"
 ],
 "Pick date": [
  null,
  "Kies datum"
 ],
 "Pizza box": [
  null,
  "Pizzadoos"
 ],
 "Portable": [
  null,
  "Draagbaar"
 ],
 "Present": [
  null,
  "Aanwezig"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Vragen via ssh-add is verlopen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Vragen ssh-keygen is verlopen"
 ],
 "RAID chassis": [
  null,
  "RAID-chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rackmontagechassis"
 ],
 "Raw to a device": [
  null,
  "Raw naar een apparaat"
 ],
 "Reading...": [
  null,
  "Lezend..."
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Remote over CIFS/SMB": [
  null,
  "Op afstand via CIFS/SMB"
 ],
 "Remote over FTP": [
  null,
  "Op afstand via FTP"
 ],
 "Remote over NFS": [
  null,
  "Op afstand via NFS"
 ],
 "Remote over SFTP": [
  null,
  "Op afstand via SFTP"
 ],
 "Remote over SSH": [
  null,
  "Op afstand via SSH"
 ],
 "Removals:": [
  null,
  "Verwijderingen:"
 ],
 "Removing $0": [
  null,
  "$0 verwijderen"
 ],
 "Reserve memory at boot time by setting a '$0' option on the kernel command line. For example, append '$1' to $2  in $3 or use your distribution's kernel argument editor.": [
  null,
  ""
 ],
 "Reserved memory": [
  null,
  "Gereserveerd geheugen"
 ],
 "Results of the crash will be copied through $0 to $1 as $2, if kdump is properly configured.": [
  null,
  "De resultaten van de crash zullen via $0 naar $1 worden gekopieerd als $2, als kdump correct is geconfigureerd."
 ],
 "Results of the crash will be stored in $0 as $1, if kdump is properly configured.": [
  null,
  "De resultaten van de crash zullen in $0 worden opgeslagen als $1 als kdump correct is geconfigureerd."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-sleutel"
 ],
 "SSH key isn't a path": [
  null,
  "SSH-sleutel is geen pad"
 ],
 "Save changes": [
  null,
  "Sla veranderingen op"
 ],
 "Sealed-case PC": [
  null,
  "Gesloten PC"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux configuratie en probleemoplossing"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server has closed the connection.": [
  null,
  "Server heeft de verbinding verbroken."
 ],
 "Service has an error": [
  null,
  "Service heeft een fout"
 ],
 "Set time": [
  null,
  "Stel tijd in"
 ],
 "Shell script": [
  null,
  "Shell-script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Bevestigingswachtwoord tonen"
 ],
 "Show password": [
  null,
  "Wachtwoord tonen"
 ],
 "Shut down": [
  null,
  "Afsluiten"
 ],
 "Single rank": [
  null,
  "Enkele rang"
 ],
 "Space-saving computer": [
  null,
  "Ruimtebesparende computer"
 ],
 "Specific time": [
  null,
  "Specifieke tijd"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Strong password": [
  null,
  "Sterk wachtwoord"
 ],
 "Sub-Chassis": [
  null,
  "Sub-chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-notebook"
 ],
 "Synchronized": [
  null,
  "Gesynchroniseerd"
 ],
 "Synchronized with $0": [
  null,
  "Gesynchroniseerd met $0"
 ],
 "Synchronizing": [
  null,
  "Synchroniseren"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Test configuration": [
  null,
  "Test configuratie"
 ],
 "Test is only available while the kdump service is running.": [
  null,
  "Test is alleen beschikbaar terwijl de kdump-service actief is."
 ],
 "Test kdump settings": [
  null,
  "Test kdump instellingen"
 ],
 "Test kdump settings by crashing the kernel. This may take a while and the system might not automatically reboot. Do not purposefully crash the system while any important task is running.": [
  null,
  "Test kdump-instellingen door de kernel te laten crashen. Dit kan enige tijd duren en het systeem wordt mogelijk niet automatisch opnieuw opgestart. Laat het systeem niet doelbewust crashen terwijl er een belangrijke taak wordt uitgevoerd."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "De ingelogde gebruiker mag geen systeemwijzigingen bekijken"
 ],
 "The passwords do not match.": [
  null,
  "De wachtwoorden komen niet overeen."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "De server weigerde te verifiëren met behulp van ondersteunde methoden."
 ],
 "The user $0 is not permitted to test crash the kernel": [
  null,
  "Het is gebruiker $0 niet toegestaan om de kernel als test te laten crashen"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dit gereedschap configureert het SELinux-beleid en kan helpen bij het begrijpen en oplossen van beleidsschendingen."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Dit gereedschap configureert het systeem om kernelcrashdumps naar schijf te schrijven."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dit gereedschap genereert een archief met configuratie- en diagnostische informatie van het draaiende systeem. Het archief kan lokaal of centraal worden opgeslagen voor opname- of trackingsoeleinden of kan worden verzonden naar vertegenwoordigers van de technische ondersteuning, ontwikkelaars of systeembeheerders om te helpen bij het opsporen van technische fouten en het debuggen."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dit gereedschap beheert lokale opslag, zoals bestandssystemen, LVM2-volumegroepen en NFS-koppelingen."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dit gereedschap beheert netwerken zoals bindingen, bruggen, teams, VLAN's en firewalls met behulp van NetworkManager en Firewalld. NetworkManager is niet compatibel met Ubuntu's standaard systemd-networkd en Debian's ifupdown-scripts."
 ],
 "Time zone": [
  null,
  "Tijdzone"
 ],
 "Toggle date picker": [
  null,
  "Datumkiezer omschakelen"
 ],
 "Too much data": [
  null,
  "Teveel data"
 ],
 "Total size: $0": [
  null,
  "Totale grootte: $0"
 ],
 "Tower": [
  null,
  "Toren"
 ],
 "Trying to synchronize with $0": [
  null,
  "Bezig met synchroniseren met $0"
 ],
 "Unable to save settings": [
  null,
  "Kan instellingen niet opslaan"
 ],
 "Unable to save settings: $0": [
  null,
  "Kan instellingen niet opslaan: $0"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Untrusted host": [
  null,
  "Niet vertrouwde host"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "View automation script": [
  null,
  "Bekijk automatiseringsscript"
 ],
 "Visit firewall": [
  null,
  "Bezoek firewall"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Wachten tot andere softwarebeheerhandelingen voltooid zijn"
 ],
 "Weak password": [
  null,
  "Zwak wachtwoord"
 ],
 "Web Console for Linux servers": [
  null,
  "Webconsole voor Linux-servers"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Je browser staat plakken vanuit het contextmenu niet toe. Je kunt Shift+Insert gebruiken."
 ],
 "Your session has been terminated.": [
  null,
  "Je sessie is beëindigd."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Je sessie is verlopen. Log nogmaals in."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "invalid: multiple targets defined": [
  null,
  "ongeldig: meerdere doelen gedefinieerd"
 ],
 "kdump status": [
  null,
  "kdump status"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "more details": [
  null,
  "meer details"
 ],
 "nfs export is empty": [
  null,
  "nfs-server is leeg"
 ],
 "nfs server is empty": [
  null,
  "NFS-server is leeg"
 ],
 "nfs server is not valid IPv6": [
  null,
  "NFS-server is geen geldige IPv6"
 ],
 "password quality": [
  null,
  "wachtwoordkwaliteit"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "ssh key isn't a path": [
  null,
  "ssh-sleutel is geen pad"
 ],
 "ssh server is empty": [
  null,
  "ssh-server is leeg"
 ]
});
