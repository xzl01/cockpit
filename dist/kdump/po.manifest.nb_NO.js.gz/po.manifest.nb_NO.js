cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Configuring kdump": [
  null,
  "Konfigurerer kdump"
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "crash": [
  null,
  "krasj"
 ],
 "kdump": [
  null,
  "kdump"
 ]
});
