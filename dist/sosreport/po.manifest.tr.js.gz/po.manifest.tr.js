cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "sos": [
  null,
  "sos"
 ]
});
