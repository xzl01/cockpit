cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "sos": [
  null,
  "sos"
 ]
});
