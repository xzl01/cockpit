cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 deň",
  "$0 dni",
  "$0 dní"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódom $1"
 ],
 "$0 failed": [
  null,
  "$0 sa nepodarilo"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodín"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "$0 key changed": [
  null,
  "$0 kľúč sa zmenil"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 nútene ukončené signálom $1"
 ],
 "$0 minute": [
  null,
  "$0 minúta",
  "$0 minúty",
  "$0 minút"
 ],
 "$0 month": [
  null,
  "$0 mesiac",
  "$0 mesiace",
  "$0 mesiacov"
 ],
 "$0 week": [
  null,
  "$0 týždeň",
  "$0 týždne",
  "$0 týždňov"
 ],
 "$0 will be installed.": [
  null,
  "Nainštaluje sa $0."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 rokov"
 ],
 "1 day": [
  null,
  "1 deň"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "1 week": [
  null,
  "1 týždeň"
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "6 hours": [
  null,
  "6 hodín"
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie je nainštalovaná kompatibilná verzia Cockpitu."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vygenerovaný nový kľúč SSH $1 na $2 a bude pridaný do súboru $3 $4 na $5."
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Acceptable password": [
  null,
  "Prijateľné heslo"
 ],
 "Add $0": [
  null,
  "Pridať $0"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocou webovej konzole Cockpit"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Aby ste mohli vytvárať výkazy, je potrebné mať oprávnenia na úrovni správcu."
 ],
 "Administrative access required": [
  null,
  "Vyžaduje sa prístup na úrovni správcu"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentácia k Ansible roliam"
 ],
 "Attributes": [
  null,
  "Atribúty"
 ],
 "Authentication": [
  null,
  "Overovanie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pre vykonávanie privilegovaných úloh pomocou webovej konzole Cockpit je potrebné overiť svoju totožnosť"
 ],
 "Authorize SSH key": [
  null,
  "Poveriť SSH kľúč"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické využitím ďalších NTP serverov"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "Automation script": [
  null,
  "Automatizačný skript"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Bus expansion chassis": [
  null,
  "Šasi pre rozšírenie zbernice"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Cannot forward login credentials": [
  null,
  "Nie je možné preposlať prístupové údaje"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmenené kľúče sú často výsledkom preinštalovania operačného systému. Avšak neočakávaná zmena môže znamenať, že sa tretia strana snaží odpočúvať vaše spojenie."
 ],
 "Checking installed software": [
  null,
  "Zisťujem nainštalovaný softvér"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurácia NetworkManagera a Firewalld v Cockpite"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpitu sa nepodarilo kontaktovať daného hostiteľa."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správca serveru, který uľahčuje správu Linuxových serverov cez webový prehliadač. Nie je žiadnym problémom prechádzať medzi terminálom a webovým nástrojom. Služba spustená cez Cockpit môže byť zastavená v termináli. Podobne, pokiaľ dôjde k chybe v termináli, je toto vidieť v rozhraní žurnálu v Cockpite."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie je kompatibilný so sofvérom na systéme."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie je nainštalovaný"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie je nainštalovaný na tomto systéme."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je skvelý nástroj pre nových správcov serverov, ktorým jednoducho umožňuje vykonávať úlohy ako správa úložiska, kontrola žurnálu a spúšťanie či zastavovanie služieb. Môžte monitorovať a spravovať viacero serverov naraz. Stačí ich pridať jedným kliknutím a vaše stroje sa budú starať o svojích kamarátov."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zhromaždiť a zabaliť dáta pre diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Zhromaždiť výpisy pádov jadra systému"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Confirm key password": [
  null,
  "Potvrdiť heslo ku kľúči"
 ],
 "Connection has timed out.": [
  null,
  "Časový limit spojenia vypršal."
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copied": [
  null,
  "Skopírované"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Copy to clipboard": [
  null,
  "Kopírovať do schránky"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvoriť nový SSH kľúč a poveriť ho"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvoriť nový súbor s úlohou s týmto obsahom."
 ],
 "Created": [
  null,
  "Vytvorená"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Delete": [
  null,
  "Odstrániť"
 ],
 "Delete report permanently?": [
  null,
  "Odstrániť výkaz bez možnosti jeho obnovenia?"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "Download": [
  null,
  "Stiahnúť"
 ],
 "Downloading $0": [
  null,
  "Sťahujem $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Embedded PC": [
  null,
  "Jednodoskový počítač"
 ],
 "Encrypted": [
  null,
  "Šifrované"
 ],
 "Encryption passphrase": [
  null,
  "Šifrovacia heslová fráza"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Excellent password": [
  null,
  "Skvelé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozširujúce šasi"
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodarilo sa povoliť $0 vo firewalld"
 ],
 "Go to now": [
  null,
  "Prejsť na súčasnosť"
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "Hide confirmation password": [
  null,
  "Skryť potvrdenie hesla"
 ],
 "Hide password": [
  null,
  "Skryť heslo"
 ],
 "Host key is incorrect": [
  null,
  "Kľúč stroja nie je správny"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Ak sa odtlačok zhoduje, kliknite na „Dôverovať a pridať stroj\". V opačnom prípade sa nepripájajte a obráťte sa na správcu systému."
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Install software": [
  null,
  "Nainštalovať softvér"
 ],
 "Installing $0": [
  null,
  "Inštalujem $0"
 ],
 "Internal error": [
  null,
  "Interná chyba"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatné práva súborov"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "IoT gateway": [
  null,
  "Brána internetu vecí (IoT)"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Key password": [
  null,
  "Heslo ku kľúču"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "Leave empty to skip encryption": [
  null,
  "Ak nechcete šifrovať, nechajte prázdne"
 ],
 "Loading system modifications...": [
  null,
  "Načítavam systémové zmeny..."
 ],
 "Log in": [
  null,
  "Prihlásiť"
 ],
 "Log in to $0": [
  null,
  "Prihlásiť sa k $0"
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "Login failed": [
  null,
  "Prihlásenie sa nepodarilo"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "Main server chassis": [
  null,
  "Šasi hlavného servera"
 ],
 "Manage storage": [
  null,
  "Spravovať úložisko"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Message to logged in users": [
  null,
  "Správa pre prihlásených používateľov"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Miniveža"
 ],
 "Multi-system chassis": [
  null,
  "Šasi pre viac systémov"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Need at least one NTP server": [
  null,
  "Je potrebný aspoň jeden server NTP"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "No delay": [
  null,
  "Bez oneskorenia"
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "No such file or directory": [
  null,
  "Žiaden taký súbor alebo adresár neexistuje"
 ],
 "No system modifications": [
  null,
  "Žiadne systémové zmeny"
 ],
 "No system reports.": [
  null,
  "Žiadne výkazy o systéme."
 ],
 "Not a valid private key": [
  null,
  "Nie je platná súkromná časť kľúča"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávený k vykonaniu tejto akcie."
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Zamaskovať sieťové adresy, názvy hostiteľov a mená používateľov"
 ],
 "Obfuscated": [
  null,
  "Zamaskované"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Keď bude Cockpit nainštalovaný, povoľte ho pomocou \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Možnosti"
 ],
 "Other": [
  null,
  "Iný"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo nie je prijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je príliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nebolo prijaté"
 ],
 "Paste": [
  null,
  "Vložiť"
 ],
 "Paste error": [
  null,
  "Chyba vkladania"
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "Peripheral chassis": [
  null,
  "Šasi pre periférie"
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Pizza box": [
  null,
  "Veľkosť „krabice od pizzy“"
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "Progress: $0": [
  null,
  "Stav postupu: $0"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-add bol prekročený"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-keygen bol prekročený"
 ],
 "RAID chassis": [
  null,
  "Šasi pre RAID"
 ],
 "Rack mount chassis": [
  null,
  "Šasi pre umiestnenie do racku"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Removing $0": [
  null,
  "Odstraňujem $0"
 ],
 "Report": [
  null,
  "Nahlásiť"
 ],
 "Report label": [
  null,
  "Štítok výkazu"
 ],
 "Reports": [
  null,
  "Výkazy"
 ],
 "Row expansion": [
  null,
  "Rozšírenie riadka"
 ],
 "Row select": [
  null,
  "Výber riadka"
 ],
 "Run new report": [
  null,
  "Vytvoriť nový výkaz"
 ],
 "Run report": [
  null,
  "Vytvoriť výkaz"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdialenom stroji spustite – cez dôveryhodnú sieť alebo fyzicky priamo na ňom – tento príkaz:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS hlásenie zhromažďuje systémové informácie napomáhajúce diagnostike problémov."
 ],
 "SSH key": [
  null,
  "SSH kľúč"
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavenie SELinuxu a riešenie problémov"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavrel spojenie."
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Zobraziť potvrdenie hesla"
 ],
 "Show password": [
  null,
  "Zobraziť heslo"
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Space-saving computer": [
  null,
  "Priestorovo úsporný počítač"
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Stick PC": [
  null,
  "Počítač vo forme USB kľúča"
 ],
 "Stop report": [
  null,
  "Zastaviť výkaz"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Strong password": [
  null,
  "Silné heslo"
 ],
 "Sub-Chassis": [
  null,
  "Menšie šasi"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizujem"
 ],
 "System diagnostics": [
  null,
  "Diagnostika systému"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kľúč SSH $0 používateľa $1 na $2 bude pridaný do súboru $3 používateľa $4 na $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH kľúč $0 bude sprístupnený po celú reláciu a bude k dispozícií tiež pre prihlasovanie se k ostatním strojom."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený a hostiteľ neumožňuje prihlásenie pomocou hesla. Zadajte, prosím, heslo pre kľúč na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený. Môžete sa pripojiť buď pomocou prihlasovacím heslom alebo zadaním hesla ku kľúču na $1."
 ],
 "The file $0 will be deleted.": [
  null,
  "Súbor $0 bude odstránený."
 ],
 "The fingerprint should match:": [
  null,
  "Odtlačok by sa mal zhodovať:"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ku kľúču nemôže byť prázdne"
 ],
 "The key passwords do not match": [
  null,
  "Heslá ku kľúču sa líšia"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Prihlásený používateľ nie je oprávnený zobrazovať modifikácie systému"
 ],
 "The password can not be empty": [
  null,
  "Heslo nemôže byť prázdne"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný odtlačok je možné zdieľať verejnými spôsobmi, vrátane e-mailu."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný odtlačok je bez problémov možné zdieľať prostredníctvom verejných spôsobov, vrátane e-mailu. Ak niekoho iného žiadate, aby urobil overovanie za vás, môže poslať výsledky ľubovoľnou cestou."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmietol overovanie pri všetkých podporovaných metódach."
 ],
 "This information is stored only on the system.": [
  null,
  "Táto informácia je uložená iba lokálne na systéme."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje politiky pre SELinux a môže pomôcť s porozumením a riešením porušenia pravidiel."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytvára archív nastavení a diagnostických informácií z bežiaceho systému. Archív je možné uložiť lokálne alebo centrálne pre účely sledovania či záznamu alebo je možné ho poslať zástupcom technickej podpory, vývojárom alebo správcom systému, aby tak mohli pomôcť s nájdením technického nedostatku alebo ladením chyby."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje miestne úložisko, ako sú napríklad systémy súborov, LVM2 skupiny zväzkov a NFS pripojenia."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje sieťovanie ako napríklad sieťové spojenia (bond), teaming, mosty (bridge), VLAN siete a brány firewall pomocou nástroja NetworkManager a FIrewalld. NetworkManager nie je kompatibilný s Ubuntu v predvolenom stave pri používaní systemd-networkd a skriptami ifupdown v distribúcii Debian."
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby ste zaistili, že do vášho pripojenia nie je zasahované záškodníckou treťou stranou, overte odtlačok kľúča hostiteľa:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Ak chcete odtlačok overiť, spustite nasledujúce príkazy na $0 počas fyzickej prítomnosti pri stroji alebo prostredníctvom dôveryhodnej siete:"
 ],
 "Toggle date picker": [
  null,
  "Prepnúť vyberač dátumov"
 ],
 "Too much data": [
  null,
  "Príliš veľa dát"
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Trust and add host": [
  null,
  "Dôverovať a pridať hostiteľa"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizáciu s $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedarí sa prihlásiť k $0. Hostiteľ neprijíma prihlasovanie heslom ani žiaden z vašich SSH kľúčov."
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Untrusted host": [
  null,
  "Nedôveryhodnotný stroj"
 ],
 "Use verbose logging": [
  null,
  "Zaznamenávať podrobnejšie"
 ],
 "Verify fingerprint": [
  null,
  "Overiť odtlačok"
 ],
 "View all logs": [
  null,
  "Zobraziť všetky záznamy udalostí"
 ],
 "View automation script": [
  null,
  "Zobraziť automatizačný skript"
 ],
 "Visit firewall": [
  null,
  "Prejsť na bránu firewall"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čakám na dokončenie ostatných operácií správy balíčkov"
 ],
 "Weak password": [
  null,
  "Ľahko prelomiteľné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzola pre linuxové servery"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 sa pripájate prvýkrát."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vami používaný prehliadač neumožňuje vkladanie z kontextovej ponuky. Ako náhradu môžete použiť Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaša relácia bola ukončená."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnosť vašej relácie skončila. Prihláste sa, prosím, znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "in less than a minute": [
  null,
  "o menej ako minútu"
 ],
 "less than a minute ago": [
  null,
  "pred menej ako minútou"
 ],
 "password quality": [
  null,
  "kvalita hesla"
 ],
 "show less": [
  null,
  "zobraziť menej"
 ],
 "show more": [
  null,
  "zobraziť viac"
 ],
 "sos report failed": [
  null,
  "Nahlasovanie problému zlyhalo"
 ]
});
