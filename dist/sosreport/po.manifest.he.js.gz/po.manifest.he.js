cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "sos": [
  null,
  "חירום"
 ]
});
