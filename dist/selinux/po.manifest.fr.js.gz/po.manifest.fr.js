cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "avc": [
  null,
  "avc"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ]
});
