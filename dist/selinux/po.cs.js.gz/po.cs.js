cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainstalováno."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "Alert": [
  null,
  "Výstraha"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Apply this solution": [
  null,
  "Použít toto řešení"
 ],
 "Applying solution...": [
  null,
  "Aplikace řešení…"
 ],
 "Audit log": [
  null,
  "Záznam auditu"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ],
 "Automatically using NTP": [
  null,
  "Automatické použití NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické použití dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatické použití uvedených NTP serverů"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správce serveru, který usnadňuje správu Linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce serverů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Můžete současně sledovat a spravovat několik serverů najednou. Stačí je přidat jedním kliknutím a vaše stroje se budou starat o své kamarády."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Connecting to SETroubleshoot daemon...": [
  null,
  "Připojování k procesu služby SETroubleshoot…"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořit nový soubor s úlohou s tímto obsahem."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Dismiss $0 alert": [
  null,
  "Zahodit $0 výstrahu",
  "Zahodit $0 výstrahy",
  "Zahodit $0 výstrah"
 ],
 "Dismiss selected alerts": [
  null,
  "Zahodit označené výstrahy"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Enforcing": [
  null,
  "Vynucující"
 ],
 "Error message": [
  null,
  "Chybové hlášení"
 ],
 "Error running semanage to discover system modifications": [
  null,
  "Chyba při spouštění semanage pro objevení změn v systému"
 ],
 "Error while setting SELinux mode: '$0'": [
  null,
  "Chyba při nastavování SELinux režimu: „$0“"
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "Failed to delete alert: $0": [
  null,
  "Nepodařilo se smazat výstrahu: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install setroubleshoot-server to troubleshoot SELinux events.": [
  null,
  "Nainstalovat setroubleshoot-server pro řešení potíží s SELinux."
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná souborová práva"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "No SELinux alerts.": [
  null,
  "Žádné výstrahy SELinux."
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Not connected": [
  null,
  "Nepřipojeno"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurred $0": [
  null,
  "Vyskytlo se $0"
 ],
 "Occurred between $0 and $1": [
  null,
  "Vyskytlo se mezi $0 a $1"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nebylo přijato"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Path to file": [
  null,
  "Popis umístění serveru"
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "Permissive": [
  null,
  "Permisivní"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SELinux access control errors": [
  null,
  "Chyby řízení přístup SELinux"
 ],
 "SELinux is disabled on the system": [
  null,
  "SELinux je na tomto systému vypnutý"
 ],
 "SELinux is disabled on the system.": [
  null,
  "SELinux je na tomto systému vypnutý."
 ],
 "SELinux policy": [
  null,
  "SELinux zásada"
 ],
 "SELinux system status is unknown.": [
  null,
  "Systémový stav SELinux není znám."
 ],
 "SELinux troubleshoot": [
  null,
  "Řešení problémů s SELinux"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Setting deviates from the configured state and will revert on the next boot.": [
  null,
  "Nastavení se odchyluje od nastaveného stavu a bude navráceno při příštím restartu."
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Solution applied successfully": [
  null,
  "Řešení úspěšně uplatněno"
 ],
 "Solution failed": [
  null,
  "Řešení se nezdařilo"
 ],
 "Solutions": [
  null,
  "Řešení"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "System modifications": [
  null,
  "Modifikace systému"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "The configured state is unknown, it might change on the next boot.": [
  null,
  "Nastavený stav není znám, může se změnit při příštím startu."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "The passwords do not match.": [
  null,
  "Zadání hesla se neshodují."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje pravidla pro SELinux a může pomoci s porozuměním a řešením porušení pravidel."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Tento nástroj nastavuje systém pro zapisování výpisů pádů jádra na disk."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení, mosty, spojení, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s Ubuntu ve výchozím stavu používaným systemd-networkd a skripty ifupdown v distribuci Debian."
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Unable to apply this solution automatically": [
  null,
  "Nedaří se automaticky uplatnit toto řešení"
 ],
 "Unable to get alert details.": [
  null,
  "Nedaří se získat podrobnosti o výstraze."
 ],
 "Unable to run fix: $0": [
  null,
  "Nedaří se spustit opravu: $0"
 ],
 "Unable to start setroubleshootd": [
  null,
  "Nedaří se spustit setroubleshootd"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Waiting for details...": [
  null,
  "Čeká se na podrobnosti…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "solution": [
  null,
  "řešení"
 ],
 "solution details": [
  null,
  "podrobnosti řešení"
 ]
});
