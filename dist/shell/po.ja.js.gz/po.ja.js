cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 documentation": [
  null,
  "$0 ドキュメント"
 ],
 "$0 exited with code $1": [
  null,
  "$0 がコード $1 で終了しました"
 ],
 "$0 failed": [
  null,
  "$0 が失敗しました"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 key changed": [
  null,
  "$0 キーが変更されました"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 がシグナル $1 で終了しました"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Cockpit の互換バージョンが $0 にインストールされていません。"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 で新しい SSH キーが $2 の $1 用に作成され、$5 上の $3 の $3 ファイルに追加されました。"
 ],
 "About Web Console": [
  null,
  "Webコンソールについて"
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Acceptable password": [
  null,
  "受け入れられるパスワード"
 ],
 "Active pages": [
  null,
  "アクティブページ"
 ],
 "Add": [
  null,
  "追加"
 ],
 "Add $0": [
  null,
  "$0 の追加"
 ],
 "Add key": [
  null,
  "キーの追加"
 ],
 "Add new host": [
  null,
  "新規ホストの追加"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの管理"
 ],
 "Administrative access": [
  null,
  "管理アクセス"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible ロールのドキュメント"
 ],
 "Apps": [
  null,
  "アプリ"
 ],
 "Authenticate": [
  null,
  "認証する"
 ],
 "Authentication": [
  null,
  "認証"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの特権タスクの実行には、認証が必要です"
 ],
 "Authorize SSH key": [
  null,
  "SSH キーの認証"
 ],
 "Automatic login": [
  null,
  "自動ログイン"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using additional NTP servers": [
  null,
  "追加の NTP サーバーを自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "Automation script": [
  null,
  "オートメーションスクリプト"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "SSH キー $0 のパスワードを $2 の $1 のログインパスワードに変更することで、自動的にキーが使えるようになります。これで、パスワードなしで $3 にログインできるようになります。"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "ホスト名、IP アドレス、エイリアス名、または ssh:// URI を指定できます"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Cannot connect to an unknown host": [
  null,
  "不明なホストには接続できません"
 ],
 "Cannot forward login credentials": [
  null,
  "ログインのクレデンシャルをフォワードできません"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change password": [
  null,
  "パスワードの変更"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Change the password of $0": [
  null,
  "$0 のパスワードを変更します"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "キーを変更すると、オペレーティングシステムを再インストールすることになることが多くあります。ただし、予期しない変更により接続の傍受が試行される場合もあります。"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Choose the language to be used in the application": [
  null,
  "アプリケーションで使用する言語の選択"
 ],
 "Clear search": [
  null,
  "検索の消去"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Close selected pages": [
  null,
  "選択されたページを閉じる"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit の NetworkManager と Firewalld の設定"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit は該当するホストに接続できませんでした。"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "cockpit で予期しない内部エラーが発生しました。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit は、Web ブラウザーで Linux サーバーを簡単に管理できるサーバーマネージャーです。端末と Web ツールを区別せずに使用できます。Cockpit で起動されたサービスは端末で停止できます。同様に、端末でエラーが発生した場合は、そのエラーを Cockpit ジャーナルインターフェースで確認できます。"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit は対話型 Linux サーバー管理インターフェースです。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit にはシステム上のそのソフトウェアとの互換性がありません。"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit はインストールされていません"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit はシステムにインストールされていません。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit は経験が少ないシステム管理者に最適です。これらのシステム管理者はストレージの管理、ジャーナルの検査、サービスの起動および停止などの単純なタスクを簡単に実行できるようになります。また、複数のサーバーを同時に監視および管理できます。これらのサーバーはクリックするだけで追加できます。追加後に、ご使用のマシンは他のマシンを管理するようになります。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "診断およびサポートデータの収集とパッケージ化"
 ],
 "Collect kernel crash dumps": [
  null,
  "カーネルクラッシュダンプの収集"
 ],
 "Color": [
  null,
  "色"
 ],
 "Comment": [
  null,
  "コメント"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Confirm key password": [
  null,
  "キーパスワードの確認"
 ],
 "Confirm new key password": [
  null,
  "新しいキーパスワードの確認"
 ],
 "Confirm password": [
  null,
  "パスワードの確認"
 ],
 "Connecting to the machine": [
  null,
  "マシンへ接続中"
 ],
 "Connection error": [
  null,
  "接続エラー"
 ],
 "Connection failed": [
  null,
  "接続に失敗しました"
 ],
 "Connection has timed out.": [
  null,
  "接続がタイムアウトしました。"
 ],
 "Contains:": [
  null,
  "次を含む:"
 ],
 "Continue session": [
  null,
  "セッションを続ける"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Copied": [
  null,
  "コピー済み"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Could not contact $0": [
  null,
  "$0 に問い合わせられませんでした"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "新しい SSH キーを作成して承認します"
 ],
 "Create new task file with this content.": [
  null,
  "このコンテンツで新しいタスクファイルを作成します。"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "ダーク"
 ],
 "Default": [
  null,
  "デフォルト"
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "Details": [
  null,
  "詳細"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Disconnected": [
  null,
  "切断されています"
 ],
 "Display language": [
  null,
  "表示言語"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "Edit": [
  null,
  "編集"
 ],
 "Edit host": [
  null,
  "ホストを編集する"
 ],
 "Edit hosts": [
  null,
  "ホストを編集する"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Excellent password": [
  null,
  "優れたパスワード"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Failed to add machine: $0": [
  null,
  "マシンの追加に失敗しました: $0"
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "Failed to edit machine: $0": [
  null,
  "マシンの編集に失敗しました: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld での $0 の有効化に失敗しました"
 ],
 "Filter menu items": [
  null,
  "フィルターメニューアイテム"
 ],
 "Fingerprint": [
  null,
  "フィンガープリント"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "Help": [
  null,
  "ヘルプ"
 ],
 "Hide confirmation password": [
  null,
  "確認パスワードの非表示"
 ],
 "Hide password": [
  null,
  "パスワードの非表示"
 ],
 "Host": [
  null,
  "ホスト"
 ],
 "Host key is incorrect": [
  null,
  "ホスト鍵が正しくありません"
 ],
 "Hosts": [
  null,
  "ホスト"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "フィンガープリントが一致している場合は、'ホストを信頼して追加' をクリックします。一致していない場合は、接続せずに管理者にお問い合わせください。"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "今後、$0 にパスワードなしで $1 としてログインできるようにするには、$3 上の $2 のログインパスワードをキーパスワードとして使用するか、キーパスワードを空欄のままにしてください。"
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Internal error": [
  null,
  "内部エラー"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid file permissions": [
  null,
  "無効なファイルパーミッション"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd が別のポートで実行されていますか?"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Key password": [
  null,
  "キーパスワード"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "GNU LGPL バージョン 2.1 でのライセンス"
 ],
 "Light": [
  null,
  "ライト"
 ],
 "Limit access": [
  null,
  "アクセスの制限"
 ],
 "Limited access": [
  null,
  "制限付きアクセス"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限定アクセスモードでは、管理者権限が制限されます。Web コンソールの一部の機能が低下します。"
 ],
 "Loading packages...": [
  null,
  "パッケージの読み込み中..."
 ],
 "Loading system modifications...": [
  null,
  "システム変更をロード中..."
 ],
 "Log in": [
  null,
  "ログイン"
 ],
 "Log in to $0": [
  null,
  "$0 へのログイン"
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "Log out": [
  null,
  "ログアウト"
 ],
 "Login failed": [
  null,
  "ログインが失敗しました"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Lunch box": [
  null,
  "ランチボックス"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "リモートマシン上の悪意のあるページが、接続されている他のホストに影響を与える可能性があります"
 ],
 "Manage storage": [
  null,
  "ストレージの管理"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "障害に関連するメッセージは、ジャーナルで見つかる場合があります:"
 ],
 "Method": [
  null,
  "方法"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "New host: $0": [
  null,
  "新しいホスト: $0"
 ],
 "New key password": [
  null,
  "新しいキーパスワード"
 ],
 "New password": [
  null,
  "新規パスワード"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "No languages match": [
  null,
  "一致する言語がありません"
 ],
 "No results found": [
  null,
  "結果が見つかりません"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "No system modifications": [
  null,
  "システム変更がありません"
 ],
 "Not a valid private key": [
  null,
  "有効な秘密鍵ではありません"
 ],
 "Not connected to host": [
  null,
  "ホストに接続されていません"
 ],
 "Not permitted to perform this action.": [
  null,
  "この動作を実行する権限がありません。"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Occurrences": [
  null,
  "発生"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit がインストールされたら、\"systemctl enable --now cockpit.socket\" コマンドで有効にします。"
 ],
 "Ooops!": [
  null,
  "問題が発生しました!"
 ],
 "Other": [
  null,
  "その他"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "Page name": [
  null,
  "ページ名"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Password changed successfully": [
  null,
  "パスワードが正しく変更されました"
 ],
 "Password is not acceptable": [
  null,
  "パスワードは受け入れられません"
 ],
 "Password is too weak": [
  null,
  "パスワードが弱すぎます"
 ],
 "Password not accepted": [
  null,
  "パスワードは受け入れられません"
 ],
 "Password tip": [
  null,
  "パスワードヒント"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Paste error": [
  null,
  "貼り付けエラー"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "管理者アクセスを得るために認証を行ってください"
 ],
 "Port": [
  null,
  "ポート"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Problem becoming administrator": [
  null,
  "管理者への切り替えに問題が発生しました"
 ],
 "Project website": [
  null,
  "プロジェクト Web サイト"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add によるプロンプトがタイムアウトしました"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen によるプロンプトがタイムアウトしました"
 ],
 "Public key": [
  null,
  "公開鍵"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Reconnect": [
  null,
  "再接続"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "信頼できるネットワーク経由で、またはリモートマシンで直接、次のコマンドを実行します:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH キー"
 ],
 "SSH keys": [
  null,
  "SSH キー"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari ユーザーは、自己署名 CA 証明書をインポートし、信頼する必要があります:"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Search": [
  null,
  "検索"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux の設定とトラブルシューティング"
 ],
 "Select": [
  null,
  "選択"
 ],
 "Server has closed the connection.": [
  null,
  "サーバーの接続が終了しました。"
 ],
 "Session": [
  null,
  "セッション"
 ],
 "Session is about to expire": [
  null,
  "セッションはまもなく終了します"
 ],
 "Set": [
  null,
  "セット"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Shell script": [
  null,
  "シェルスクリプト"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "確認パスワードの表示"
 ],
 "Show password": [
  null,
  "パスワードを表示する"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Skip main navigation": [
  null,
  "メインナビゲーションをスキップします"
 ],
 "Skip to content": [
  null,
  "コンテンツへスキップ"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "Stop editing hosts": [
  null,
  "ホストの編集を停止"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Strong password": [
  null,
  "強固なパスワード"
 ],
 "Style": [
  null,
  "スタイル"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Switch to administrative access": [
  null,
  "管理者アクセスへの切り替え"
 ],
 "Switch to limited access": [
  null,
  "アクセス制限への切り替え"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "System": [
  null,
  "システム"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP アドレスまたはホスト名には空白を含めることができません。"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 の $1 の SSH キー $0 は、$5 上の $4 の $3 ファイルに追加されます。"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH キー $0 はセッションの残りの時間に利用できるようになり、他のホストにもログインできるようになります。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーはパスワードで保護され、パスワードによるログインを許可しません。$1 にキーのパスワードを指定してください。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーは保護されています。ログインパスワードでログインするか、$1 で鍵のパスワードを提供することでログインできます。"
 ],
 "The fingerprint should match:": [
  null,
  "フィンガープリントは次のものと一致する必要があります:"
 ],
 "The key password can not be empty": [
  null,
  "キーのパスワードは空にすることはできません"
 ],
 "The key passwords do not match": [
  null,
  "キーのパスワードが一致しません"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ログインしているユーザーには、システム変更を表示する権限がありません"
 ],
 "The machine is rebooting": [
  null,
  "マシンが再起動中です"
 ],
 "The new key password can not be empty": [
  null,
  "新しいキーのパスワードは空にすることはできません"
 ],
 "The password can not be empty": [
  null,
  "パスワードは空にできません"
 ],
 "The passwords do not match.": [
  null,
  "パスワードが一致しません。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "作成されたフィンガープリントは、電子メールを含むパブリックメソッドを介して共有すると問題ありません。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成されたフィンガープリントは、メールなどのパブリックな方法で共有しても問題ありません。他の人に検証を依頼した場合、その人は任意の方法で結果を送信できます。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "サーバーはサポートされた方法を使用した認証を拒否しました。"
 ],
 "There are currently no active pages": [
  null,
  "現在アクティブなページはありません"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "マシンへの接続中に予期しないエラーが発生しました。"
 ],
 "This machine has already been added.": [
  null,
  "このマシンはすでに追加されています。"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "このツールは、SELinux ポリシーを設定します。また、ポリシー違反の把握と解決に役立ちます。"
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "このツールは、カーネルクラッシュダンプをディスクに書き込むようにシステムを設定します。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "このツールは、実行中のシステムから設定および診断情報のアーカイブを生成します。アーカイブは、記録や追跡の目的でローカルまたは一元的に保存することも、技術的な障害の発見やデバッグを支援するためにテクニカルサポート担当者、開発者、システム管理者に送信することもできます。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "このツールは、ファイルシステム、LVM2 ボリュームグループ、NFS マウントなどのローカルストレージを管理します。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "このツールは、NetworkManager と Firewalld を使用して、ボンディング、ブリッジ、チーム、VLAN、ファイアウォールなどのネットワーク設定を管理します。NetworkManager は、Ubuntu のデフォルトの systemd-networkd および Debian の ifupdown スクリプトと互換性がありません。"
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "これにより、今後はパスワードなしでログインできるようになります。"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "ヒント: 他のシステムに対して自動的に認証する場合は、鍵のパスワードをログインパスワードに一致させます。"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "悪意のあるサードパーティーによって接続がインターセプトされないようにするには、ホストキーフィンガープリントを確認してください:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "フィンガープリントを確認するには、マシン上に物理的に置かれるか、信頼できるネットワークを介して $0 で次のコマンドを実行します:"
 ],
 "Toggle": [
  null,
  "切り替え"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Too much data": [
  null,
  "データが多すぎます"
 ],
 "Tools": [
  null,
  "ツール"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Trust and add host": [
  null,
  "ホストを信頼して追加"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "Turn on administrative access": [
  null,
  "管理者アクセスをオンにする"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Unable to contact $0.": [
  null,
  "$0 と通信できません。"
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "該当するホスト $0 に接続できませんでした。そのホストのポート $1 で ssh が実行されていることを確認するか、アドレスで別のポートを指定します。"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "SSH キー認証で $0 にログインできません。パスワードを入力してください。SSH キーを自動ログイン用に設定しておいてください。"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 にログインできません。ホストが、パスワードログインまたは SSH キーを受け付けていません。"
 ],
 "Unexpected error": [
  null,
  "予期しないエラー"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unlock": [
  null,
  "ロック解除"
 ],
 "Unlock key $0": [
  null,
  "ロック解除キー $0"
 ],
 "Untrusted host": [
  null,
  "信用できないホスト"
 ],
 "Update": [
  null,
  "更新"
 ],
 "Use key": [
  null,
  "キーの使用"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "他のシステムに対して認証する場合は次の鍵を使用します"
 ],
 "User name": [
  null,
  "ユーザー名"
 ],
 "Verify fingerprint": [
  null,
  "フィンガープリントの検証"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "View automation script": [
  null,
  "オートメーションスクリプトの表示"
 ],
 "Visit firewall": [
  null,
  "ファイアウォールへのアクセス"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Weak password": [
  null,
  "脆弱なパスワード"
 ],
 "Web Console": [
  null,
  "Webコンソール"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux サーバー用 Web コンソール"
 ],
 "Web console logo": [
  null,
  "Web コンソールロゴ"
 ],
 "When empty, connect with the current user": [
  null,
  "空の場合は、現在のユーザーに接続します"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "初めて $0 に接続しています。"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "アクティビティーがないためログアウトされました。"
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "自動ログイン用の鍵のパスワードの変更が必要な場合があります。"
 ],
 "You now have administrative access.": [
  null,
  "これで管理者アクセスが可能になりました。"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "$0 秒後にログアウトされます。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "お使いのブラウザーでは、コンテキストメニューからの貼り付けが許可されていません。Shift+Insert を使用できます。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ブラウザーはセッション間のアクセスレベルを記憶します。"
 ],
 "Your session has been terminated.": [
  null,
  "セッションが終了しました。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "セッションの有効期限が切れました。再度ログインしてください。"
 ],
 "Zone": [
  null,
  "ゾーン"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "active": [
  null,
  "アクティブ"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "in most browsers": [
  null,
  "多くのブラウザー"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "パスワードの強度"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ]
});
