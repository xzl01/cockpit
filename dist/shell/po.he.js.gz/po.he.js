cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 documentation": [
  null,
  "התיעוד של $0"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "About Web Console": [
  null,
  "על המסוף המקוון"
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Active pages": [
  null,
  "עמודים פעילים"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "Add key": [
  null,
  "הוספת מפתח"
 ],
 "Add new host": [
  null,
  "הוספת מארח חדש"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Administrative access": [
  null,
  "גישה ניהולית"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Apps": [
  null,
  "יישומים"
 ],
 "Authenticate": [
  null,
  "אימות"
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "Automatic login": [
  null,
  "כניסה אוטומטית"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "החלפת סיסמת מפתח ה־SSH‏ $0 לסיסמת הכניסה של $1 על גבי $2, תוביל לכך שהמפתח אוטומטית יהיה זמין ותהיה לך אפשרות להיכנס אל $3 ללא סיסמה בעתיד."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "יכול להיות שם מארח, כתובת IP, שם כינוי או כתובת ssh://‎ מלאה"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Cannot connect to an unknown host": [
  null,
  "לא ניתן להתחבר למארח לא ידוע"
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Change password": [
  null,
  "החלפת סיסמה"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Change the password of $0": [
  null,
  "החלפת הסיסמה של $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "Choose the language to be used in the application": [
  null,
  "נא לבחור את שפת היישום לשימוש"
 ],
 "Clear search": [
  null,
  "ניקוי החיפוש"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Close selected pages": [
  null,
  "סגירת העמודים הנבחרים"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "ב־Cockpit אירעה שגיאה בלתי צפויה."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit הוא מנשק אינטראקטיבי לניהול שרתי לינוקס."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Color": [
  null,
  "צבע"
 ],
 "Comment": [
  null,
  "הערה"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Confirm new key password": [
  null,
  "אישור סיסמה חדשה למפתח"
 ],
 "Confirm password": [
  null,
  "אישור סיסמה"
 ],
 "Connecting to the machine": [
  null,
  "מתבצעת התחברות למכונה"
 ],
 "Connection error": [
  null,
  "שגיאת התחברות"
 ],
 "Connection failed": [
  null,
  "ההתחברות נכשלה"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Contains:": [
  null,
  "מכיל:"
 ],
 "Continue session": [
  null,
  "להמשיך הפעלה"
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Could not contact $0": [
  null,
  "לא ניתן ליצור קשר עם $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "כהה"
 ],
 "Default": [
  null,
  "בררת מחדל"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "Details": [
  null,
  "פרטים"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Disconnected": [
  null,
  "מנותק"
 ],
 "Display language": [
  null,
  "שפת התצוגה"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Edit host": [
  null,
  "עריכת מארח"
 ],
 "Edit hosts": [
  null,
  "עריכת מארחים"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Failed to add machine: $0": [
  null,
  "הוספת המכונה נכשלה: $0"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "Failed to edit machine: $0": [
  null,
  "עריכת המכונה נכשלה: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Filter menu items": [
  null,
  "סינון פריטי תפריט"
 ],
 "Fingerprint": [
  null,
  "טביעת אצבע"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Help": [
  null,
  "עזרה"
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "Host": [
  null,
  "מארח"
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "Hosts": [
  null,
  "מארחים"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "כדי לאפשר כניסה אל $0 בתור $1 ללא סיסמה בעתיד, עליך להשתמש בסיסמת הכניסה של $2 על גבי $3 כסיסמת המפתח או להשאיר את סיסמת המפתח ריקה."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Is sshd running on a different port?": [
  null,
  "האם sshd פועל על פתחה אחרת?"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "בכפוף לרישיון LGPL מבית GNU בגרסה 2.1"
 ],
 "Light": [
  null,
  "בהירה"
 ],
 "Limit access": [
  null,
  "הגבלת גישה"
 ],
 "Limited access": [
  null,
  "גישה מוגבלת"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "מצב גישה מוגבלת מגביל את ההרשאות הניהוליות. חלקים מסוימים במסוף המקוון יפעלו באופן חלקי."
 ],
 "Loading packages...": [
  null,
  "החבילות נטענות…"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "Log out": [
  null,
  "יציאה"
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  ""
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "ניתן למצוא הודעות שקשורות בכשל בז׳ורנל:"
 ],
 "Method": [
  null,
  "שיטה"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "New key password": [
  null,
  "סיסמה חדשה למפתח"
 ],
 "New password": [
  null,
  "סיסמה חדשה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "No languages match": [
  null,
  "אין שפות תואמות"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Not connected to host": [
  null,
  "לא מחובר למארח"
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Ooops!": [
  null,
  "אופס!"
 ],
 "Other": [
  null,
  "אחר"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "Page name": [
  null,
  "שם העמוד"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Password changed successfully": [
  null,
  "הסיסמה הוחלפה בהצלחה"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "Password tip": [
  null,
  "רמז לסיסמה"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "נא לעבור אימות כדי לקבל גישת ניהול"
 ],
 "Port": [
  null,
  "פתחה"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Problem becoming administrator": [
  null,
  "תקלה בהעברה לניהול"
 ],
 "Project website": [
  null,
  "אתר המיזם"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Public key": [
  null,
  "מפתח ציבורי"
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Reconnect": [
  null,
  "התחברות מחדש"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "SSH keys": [
  null,
  "מפתחות SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "משתמשי Safari צריכים לייבא ולתת אמון באישור מרשות האישורים שנחתמה עצמית:"
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Search": [
  null,
  "חיפוש"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "Select": [
  null,
  "בחירה"
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Session": [
  null,
  "הפעלה"
 ],
 "Session is about to expire": [
  null,
  "תוקף ההפעלה עומד לפוג"
 ],
 "Set": [
  null,
  "הגדרה"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Skip main navigation": [
  null,
  "דילוג על הניווט הראשי"
 ],
 "Skip to content": [
  null,
  "דילוג לתוכן"
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "Stop editing hosts": [
  null,
  "הפסקת עריכת מארחים"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Style": [
  null,
  "סגנון"
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Switch to administrative access": [
  null,
  "מעבר לגישה ניהולית"
 ],
 "Switch to limited access": [
  null,
  "העברה לגישה מוגבלת"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "System": [
  null,
  "מערכת"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "כתובת ה־IP או שם המארח לא יכולים להכיל רווח."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "The machine is rebooting": [
  null,
  "המכונה מופעלת מחדש"
 ],
 "The new key password can not be empty": [
  null,
  "סיסמת המפתח החדשה לא יכולה להישאר ריקה"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "There are currently no active pages": [
  null,
  "אין דפים פעילים כרגע"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "הייתה שגיאה בלתי צפויה בעת ההתחברות למכונה."
 ],
 "This machine has already been added.": [
  null,
  "מכונה זו כבר נוספה."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "הגדרה זו תאפשר לך להיכנס ללא סיסמה בעתיד."
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "עצה: אפשר להגדיר את סיסמת המפתח שלך כמו סיסמת הכניסה שלך כדי להתאמת אוטומטית מול מערכות אחרות."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "Toggle": [
  null,
  "בורר"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "Tools": [
  null,
  "כלים"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Turn on administrative access": [
  null,
  "הפעלת גישה ניהולית"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Unable to contact $0.": [
  null,
  "לא ניתן לצור קשר עם $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "לא ניתן ליצור קשר עם המארח שסופק $0. נא לוודא שיש לו ssh פעיל בפתחה $1 או לציין פתחה אחרת בכתובת."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "לא ניתן להיכנס אל $0 באמצעות אימות עם מפתח SSH. נא לספק את הסיסמה. ייתכן שעידף לך להגדיר את מפתחות ה־SSH שלך לכניסה אוטומטית."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "Unexpected error": [
  null,
  "שגיאה בלתי צפויה"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Unlock": [
  null,
  "שחרור"
 ],
 "Unlock key $0": [
  null,
  "שחרור המפתח $0"
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "Update": [
  null,
  "עדכון"
 ],
 "Use key": [
  null,
  "להשתמש במפתח"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "להשתמש במפתחות הבאים כדי להתאמת מול שרתים אחרים"
 ],
 "User name": [
  null,
  "שם משתמש"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Web Console": [
  null,
  "מסוף מקוון"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "Web console logo": [
  null,
  "לוגו המסוף המקוון"
 ],
 "When empty, connect with the current user": [
  null,
  "כאשר ריק, להתחבר עם המשתמש הנוכחי"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "יצאת מהמערכת עקב חוסר פעילות."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "יתכן שעדיף לך להחליף את הסיסמה של המפתח לטובת כניסה אוטומטית."
 ],
 "You now have administrative access.": [
  null,
  "מעתה יש לך גישה ניהולית."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "המערכת תוציא אותך בעוד $0 שניות."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "הדפדפן שלך יזכור את רמת הגישה שלך בין הפעלות."
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "active": [
  null,
  "פעיל"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "in most browsers": [
  null,
  "ברוב הדפדפנים"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ]
});
