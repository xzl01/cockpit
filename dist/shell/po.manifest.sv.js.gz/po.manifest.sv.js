cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Web Console": [
  null,
  "Webbkonsol"
 ]
});
