cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Web Console": [
  null,
  "Web Konsole"
 ]
});
