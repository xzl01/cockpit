cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Web Console": [
  null,
  "Web Console"
 ]
});
