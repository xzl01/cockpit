cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 documentation": [
  null,
  "$0 Dokumentation"
 ],
 "$0 exited with code $1": [
  null,
  "$0 mit Code $1 beendet"
 ],
 "$0 failed": [
  null,
  "$0 fehlgeschlagen"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "$0 key changed": [
  null,
  "$0 Schlüssel geändert"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mit Signal $1 beendet"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Eine kompatible Version von Cockpit ist auf $0 nicht installiert."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Ein neuer SSH-Schlüssel unter $0 wird für $1 auf $2 erstellt und zur Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "About Web Console": [
  null,
  "Über Web Console"
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Acceptable password": [
  null,
  "Akzeptables Passwort"
 ],
 "Active pages": [
  null,
  "Aktive Seiten"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "Add key": [
  null,
  "Schlüssel hinzufügen"
 ],
 "Add new host": [
  null,
  "Neuen Host hinzufügen"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Mit der Cockpit Web Konsole administrieren"
 ],
 "Administrative access": [
  null,
  "Administrativer Zugang"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible Rollendokumentation"
 ],
 "Apps": [
  null,
  "Apps"
 ],
 "Authenticate": [
  null,
  "Authentifiziere"
 ],
 "Authentication": [
  null,
  "Authentifizierung"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Privilegierte Aktionen der Cockpit Web-Konsole benötigen Berechtigung"
 ],
 "Authorize SSH key": [
  null,
  "SSH-Schlüssel autorisieren"
 ],
 "Automatic login": [
  null,
  "Automatische Anmeldung"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatische Benutzung zusätzlicher NTP-Server"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "Automation script": [
  null,
  "Automatisierungs-Skript"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Wenn Sie das Passwort des SSH-Schlüssels $0 in das Anmeldepasswort von $1 auf $2 ändern, wird der Schlüssel automatisch verfügbar gemacht und Sie können sich in Zukunft ohne Passwort auf $3 anmelden."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Kann ein Hostname, eine IP-Adresse, ein Alias-Name oder ein ssh:// URI sein"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Verbindung zu einer unbekannten Maschine nicht möglich"
 ],
 "Cannot forward login credentials": [
  null,
  "Anmeldeinformationen können nicht weitergeleitet werden"
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Change password": [
  null,
  "Passwort ändern"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Change the password of $0": [
  null,
  "Passwort von $0 ändern"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Geänderte Schlüssel sind oft das Ergebnis einer Neuinstallation des Betriebssystems. Allerdings kann eine unerwartete Änderung auf einen Versuch eines Dritten hinweisen, Ihre Verbindung auszuspähen."
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "Choose the language to be used in the application": [
  null,
  "Wählen Sie die in der Applikation zu verwendende Sprache"
 ],
 "Clear search": [
  null,
  "Suche zurücksetzen"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Close selected pages": [
  null,
  "Ausgewählte Seiten schließen"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit Konfiguration von NetworkManager und Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit konnte den angegebenen Host nicht erreichen."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit hatte einen unerwarteten Fehler."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ist ein Server Manager zur einfachen Verwaltung Ihrer Linux Server via Web Browser. Ein Wechsel zwischen dem Terminal und der Weboberfläche ist kein Problem. Ein Service, der via Cockpit gestartet wurde, kann im Terminal beendet werden. Genauso können Fehler, welche im Terminal vorkommen, im Cockpit Journal angezeigt werden."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit ist ein interaktives Administrationsinterface für Linux Server."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ist mit der Software auf dem System nicht kompatibel."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ist nicht installiert"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ist auf dem System nicht installiert."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ist perfekt für neue Systemadministratoren, da es ihnen auf einfache Weise ermöglicht, simple Aufgaben wie Speicherverwaltung, Journal / Logfile Analyse oder das Starten und Stoppen von Diensten durchzuführen. Sie können gleichzeitig mehrere Server überwachen und verwalten. Fügen Sie weitere Maschinen mit einem Klick hinzu und Ihre Maschinen schauen zu ihren Kumpels."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Sammeln und Packen von Diagnose und Support Daten"
 ],
 "Collect kernel crash dumps": [
  null,
  "Sammeln von Kernel-Absturz-Auszügen"
 ],
 "Color": [
  null,
  "Farbe"
 ],
 "Comment": [
  null,
  "Kommentar"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Confirm key password": [
  null,
  "Neues Passwort wiederholen"
 ],
 "Confirm new key password": [
  null,
  "Neues Schlüssel-Passwort wiederholen"
 ],
 "Confirm password": [
  null,
  "Passwort bestätigen"
 ],
 "Connecting to the machine": [
  null,
  "Verbindung zur Maschine wird hergestellt"
 ],
 "Connection error": [
  null,
  "Fehler bei der Verbindung"
 ],
 "Connection failed": [
  null,
  "Verbindung fehlgeschlagen"
 ],
 "Connection has timed out.": [
  null,
  "Zeitüberschreitung bei der Verbindung."
 ],
 "Contains:": [
  null,
  "Enthält:"
 ],
 "Continue session": [
  null,
  "Sitzung Fortsetzen"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Kopiert"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Could not contact $0": [
  null,
  "Konnte $0 nicht kontaktieren"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Einen neuen SSH-Schlüssel erstellen und ihn autorisieren"
 ],
 "Create new task file with this content.": [
  null,
  "Neue Task-Datei mit diesem Inhalt erstellen."
 ],
 "Ctrl+Insert": [
  null,
  "Strg+Einfügen"
 ],
 "Ctrl-Shift-I": [
  null,
  "Strg-Shift-I"
 ],
 "Dark": [
  null,
  "Dunkel"
 ],
 "Default": [
  null,
  "Standard"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Disconnected": [
  null,
  "Getrennt"
 ],
 "Display language": [
  null,
  "Anzeigesprache"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Edit host": [
  null,
  "Host bearbeiten"
 ],
 "Edit hosts": [
  null,
  "Hosts bearbeiten"
 ],
 "Embedded PC": [
  null,
  "Embedded PC"
 ],
 "Excellent password": [
  null,
  "Perfektes Passwort"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Failed to add machine: $0": [
  null,
  "Maschine konnte nicht hinzugefügt werden: $0"
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "Failed to edit machine: $0": [
  null,
  "Maschine konnte nicht editiert werden: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0 konnte nicht in firewalld aktiviert werden"
 ],
 "Filter menu items": [
  null,
  "Menüpunkte filtern"
 ],
 "Fingerprint": [
  null,
  "Fingerabdruck"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Help": [
  null,
  "Hilfe"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Host key is incorrect": [
  null,
  "Host-Schlüssel ist falsch"
 ],
 "Hosts": [
  null,
  "Hosts"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Um in Zukunft die Anmeldung bei $0 als $1 ohne Passwort zu ermöglichen, verwenden Sie das Anmeldepasswort von $2 auf $3 als Schlüsselpasswort oder lassen Sie das Schlüsselpasswort leer."
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "Installing $0": [
  null,
  "$0 wird installiert"
 ],
 "Internal error": [
  null,
  "Interner Fehler"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid file permissions": [
  null,
  "Ungültige Dateiberechtigungen"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Is sshd running on a different port?": [
  null,
  "Läuft sshd auf einem anderen Port?"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Key password": [
  null,
  "Schlüsselpasswort"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Lizenziert unter der GNU LGPL Version 2.1"
 ],
 "Light": [
  null,
  "Hell"
 ],
 "Limit access": [
  null,
  "Zugang einschränken"
 ],
 "Limited access": [
  null,
  "Eingeschränkter Zugang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Der eingeschränkte Zugriffsmodus schränkt die administrativen Rechte ein. Einige Teile der Web-Konsole sind in ihrer Funktionalität eingeschränkt."
 ],
 "Loading packages...": [
  null,
  "Pakete werden geladen..."
 ],
 "Loading system modifications...": [
  null,
  "System-Änderungen laden..."
 ],
 "Log in": [
  null,
  "Anmelden"
 ],
 "Log in to $0": [
  null,
  "Bei $0 anmelden"
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "Log out": [
  null,
  "Abmelden"
 ],
 "Login failed": [
  null,
  "Anmeldung fehlgeschlagen"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  ""
 ],
 "Manage storage": [
  null,
  "Speicher verwalten"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Im Journal finden sich möglicherweise Meldungen zu dem Fehler:"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "New key password": [
  null,
  "Neues Schlüsselpasswort"
 ],
 "New password": [
  null,
  "Neues Passwort"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "No languages match": [
  null,
  "Keine passenden Sprachen"
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "No system modifications": [
  null,
  "Keine Systemänderungen"
 ],
 "Not a valid private key": [
  null,
  "Ungültiger privater Schlüssel"
 ],
 "Not connected to host": [
  null,
  "Nicht mit Host verbunden"
 ],
 "Not permitted to perform this action.": [
  null,
  "Diese Aktion darf nicht ausgeführt werden."
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Occurrences": [
  null,
  "Vorkommnisse"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Wenn Cockpit installiert ist, aktivieren Sie es mit \"systemctl enable --now cockpit.socket\"."
 ],
 "Ooops!": [
  null,
  "Uuups!"
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "Page name": [
  null,
  "Seitenname"
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Password changed successfully": [
  null,
  "Passwort erfolgreich geändert"
 ],
 "Password is not acceptable": [
  null,
  "Das Passwort kann nicht akzeptiert werden"
 ],
 "Password is too weak": [
  null,
  "Das gewählte Passwort ist zu schwach"
 ],
 "Password not accepted": [
  null,
  "Passwort wurde nicht akzeptiert"
 ],
 "Password tip": [
  null,
  "Passworthinweis"
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Paste error": [
  null,
  "Fehler beim Einfügen"
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Bitte authentifizieren Sie sich, um administrativen Zugriff zu erhalten"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "Problem becoming administrator": [
  null,
  "Problem beim Administrator werden"
 ],
 "Project website": [
  null,
  "Projekt-Website"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Die Aufforderung über ssh-add ist abgelaufen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Die Aufforderung über ssh-keygen ist abgelaufen"
 ],
 "Public key": [
  null,
  "Öffentlicher Schlüssel"
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Reconnect": [
  null,
  "Erneut verbinden"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Removing $0": [
  null,
  "Entfernen $0"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-Schlüssel"
 ],
 "SSH keys": [
  null,
  "SSH-Schlüssel"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari Benutzer müssen das selbst signierten Zertifikat importieren:"
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Search": [
  null,
  "Suche"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Sicherheitsverstärkte Linuxkonfiguration und Problemlösung"
 ],
 "Select": [
  null,
  "Auswählen"
 ],
 "Server has closed the connection.": [
  null,
  "Der Server hat die Verbindung beendet."
 ],
 "Session": [
  null,
  "Sitzung"
 ],
 "Session is about to expire": [
  null,
  "Sitzung läuft bald ab"
 ],
 "Set": [
  null,
  "Einstellen"
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Einfügen"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Skip main navigation": [
  null,
  "Hauptnavigation überspringen"
 ],
 "Skip to content": [
  null,
  "Zum Inhalt springen"
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop editing hosts": [
  null,
  "Bearbeitung von Hosts beenden"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Style": [
  null,
  "Stil"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Switch to administrative access": [
  null,
  "Auf administrativen Zugang umschalten"
 ],
 "Switch to limited access": [
  null,
  "Auf eingeschränkten Zugang umschalten"
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "System": [
  null,
  "System"
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "Die IP-Adresse oder der Hostname darf keine Leerzeichen enthalten."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Der SSH-Schlüssel $0 von $1 auf $2 wird der Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Der SSH-Schlüssel $0 wird für den Rest der Sitzung zur Verfügung gestellt und steht auch für die Anmeldung bei anderen Hosts zur Verfügung."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist durch ein Passwort geschützt, und der Host erlaubt keine Anmeldung mit einem Passwort. Bitte geben Sie das Passwort des Schlüssels auf $1 an."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist geschützt. Sie können sich entweder mit Ihrem Anmeldepasswort oder mit dem Passwort des Schlüssels bei $1 anmelden."
 ],
 "The key password can not be empty": [
  null,
  "Das Schlüsselpasswort darf nicht leer sein"
 ],
 "The key passwords do not match": [
  null,
  "Die Schlüsselpasswörter stimmen nicht überein"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Der angemeldete Benutzer ist nicht berechtigt, Systemänderungen einzusehen"
 ],
 "The machine is rebooting": [
  null,
  "Die Maschine startet neu"
 ],
 "The new key password can not be empty": [
  null,
  "Das neue Schlüsselpasswort darf nicht leer sein"
 ],
 "The password can not be empty": [
  null,
  "Das Passwort darf nicht leer sein"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Der entstandene Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Der Server hat die Authentifizierung mit allen unterstützten Methoden abgelehnt."
 ],
 "There are currently no active pages": [
  null,
  "Derzeit sind keine aktiven Seiten vorhanden"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Bei der Verbindung zur Maschine ist ein unerwarteter Fehler aufgetreten."
 ],
 "This machine has already been added.": [
  null,
  "Diese Maschine wurde bereits hinzugefügt"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dieses Tool konfiguriert die SELinux Policy und hilft dabei Verletzungen der Policy zu verstehen und aufzulösen."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dieses Tool generiert ein Archiv der Konfiguration und Diagnoseinformation des laufenden Systems.Das Archiv kann lokal oder zentral abgespeichert werden zum Zweck der Archivierung oder Nachverfolgung oder kann an den Technischen Support, Entwickler oder Systemadministratoren gesendet werden, um bei der Fehlersuche oder Debugging zu helfen."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dieses Tool verwaltet den lokalen Speicher, wie etwa Dateisysteme, LVM2 Volume Gruppen und NFS Einhängepunkte."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dieses Tool verwaltet die Netzwerkumgebung wie etwa Bindungen, Bridges, Teams, VLANs und Firewalls durch den NetworkManager und Firewalld. Der NetworkManager ist inkompatibel mit dem Ubuntus Standard systemd-networkd und Debians ifupdown Scipts."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Dies ermöglicht es Ihnen, sich in Zukunft ohne Passwort anzumelden."
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tipp: Wenn Ihr Schlüsselpasswort mit Ihrem Login-Passwort übereinstimmt, können Sie sich an anderen Systemen automatisiert anmelden."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Überprüfen Sie bitte den Fingerabdruck des Host-Schlüssels, um sicherzustellen, dass Ihre Verbindung nicht von einem böswilligen Dritten ausgespäht wird:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Um einen Fingerabdruck zu überprüfen, führen Sie die folgenden Schritte auf $0 aus, während Sie physisch an der Maschine sitzen oder über ein vertrauenswürdiges Netzwerk:"
 ],
 "Toggle": [
  null,
  "Umschalten"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Too much data": [
  null,
  "Zu viele Daten"
 ],
 "Tools": [
  null,
  "Werkzeuge"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit {{Server}} zu synchronisieren"
 ],
 "Turn on administrative access": [
  null,
  "Administrator-Zugriff aktivieren"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to contact $0.": [
  null,
  "$0 kann nicht kontaktiert werden."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Der angegebene Host $0 kann nicht kontaktiert werden. Stellen Sie sicher, dass ssh auf Port $1 läuft, oder geben Sie einen anderen Port in der Adresse an."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Die Anmeldung bei $0 mit SSH-Schlüsselauthentifizierung ist nicht möglich. Bitte geben Sie das Passwort ein. Vielleicht möchten Sie Ihre SSH-Schlüssel für die automatische Anmeldung einrichten."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Die Anmeldung bei $0 ist nicht möglich. Der Host akzeptiert weder ein Passwort noch einen Ihrer SSH-Schlüssel."
 ],
 "Unexpected error": [
  null,
  "Unerwarteter Fehler"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Unlock": [
  null,
  "Öffnen"
 ],
 "Unlock key $0": [
  null,
  "Schlüssel $0 entsperren"
 ],
 "Untrusted host": [
  null,
  "Nicht vertrauenswürdiger Host"
 ],
 "Update": [
  null,
  "Update"
 ],
 "Use key": [
  null,
  "Schlüssel verwenden"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Benutze die folgenen Schlüssel zur Authentifizierung an anderen Systemen"
 ],
 "User name": [
  null,
  "Benutzername"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "View automation script": [
  null,
  "Automatisierungs-Script anzeigen"
 ],
 "Visit firewall": [
  null,
  "Firewall besuchen"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Web Console": [
  null,
  "Web Konsole"
 ],
 "Web Console for Linux servers": [
  null,
  "Webkonsole für Linux-Server"
 ],
 "Web console logo": [
  null,
  "Logo der Web-Konsole"
 ],
 "When empty, connect with the current user": [
  null,
  "Wenn leer, mit dem aktuellen Benutzer verbinden"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Sie stellen zum ersten Mal eine Verbindung zu $0 her."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Sie wurden wegen Inaktivität abgemeldet."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Vielleicht möchten Sie das Passwort des Schlüssels für die automatische Anmeldung ändern."
 ],
 "You now have administrative access.": [
  null,
  "Sie haben nun Administrator Zugriff."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Sie werden in $0 Sekunden abgemeldet."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Ihr Browser lässt das Einfügen über das Kontextmenü nicht zu. Sie können Umschalt+Einfügen verwenden."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ihr Browser speichert Ihre Zugriffsstufe über mehrere Sitzungen hinweg."
 ],
 "Your session has been terminated.": [
  null,
  "Ihre Sitzung wurde beendet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Die Session ist abgelaufen. Bitte neu einloggen."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "active": [
  null,
  "Aktiv"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "in most browsers": [
  null,
  "in den meisten Browsern"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "Passwortqualität"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ]
});
