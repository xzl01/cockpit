cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 procesor",
  "$0 procesory",
  "$0 procesorů"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 k dispozici"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "$0 free": [
  null,
  "$0 volné"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 page": [
  null,
  "$0 stránka",
  "$0 stránky",
  "$0 stránek"
 ],
 "$0 spike": [
  null,
  "$0 špička",
  "$0 špičky",
  "$0 špiček"
 ],
 "$0 total": [
  null,
  "$0 celkem"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainstalováno."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 min": [
  null,
  "1 minuta"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "15 min": [
  null,
  "15 min"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ],
 "Automatically using NTP": [
  null,
  "Automatické použití NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické použití dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatické použití uvedených NTP serverů"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "CPU usage": [
  null,
  "Využití procesoru"
 ],
 "CPU usage/load": [
  null,
  "Využití/vytížení procesoru"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správce serveru, který usnadňuje správu Linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce serverů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Můžete současně sledovat a spravovat několik serverů najednou. Stačí je přidat jedním kliknutím a vaše stroje se budou starat o své kamarády."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "Collect metrics": [
  null,
  "Shromažďovat metriky"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Core $0": [
  null,
  "Jádro $0"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořit nový soubor s úlohou s tímto obsahem."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current top CPU usage": [
  null,
  "Stávající vytížení procesoru"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "Device": [
  null,
  "Zařízení"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Disk I/O": [
  null,
  "Diskový vstup/výst."
 ],
 "Disks": [
  null,
  "Disky"
 ],
 "Disks usage": [
  null,
  "Využití disku"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Error has occurred": [
  null,
  "Došlo k chybě"
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Export to network": [
  null,
  "Exportovat do sítě"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "Failed to configure PCP": [
  null,
  "Nepodařilo se nastavit PCP"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "Graph visibility": [
  null,
  "Viditelnost grafu"
 ],
 "Graph visibility options menu": [
  null,
  "Nabídka možností viditelnosti grafu"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "In": [
  null,
  "V"
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install cockpit-pcp": [
  null,
  "Nainstalovat cockpit-pcp"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installation not supported without installed cockpit package": [
  null,
  "Instalace není podporována bez nainstalovaného balíčku cockpit"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Interface": [
  null,
  "Rozhraní",
  "Rozhraní",
  "Rozhraní"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná souborová práva"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Jump to": [
  null,
  "Přeskočit na"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "Load": [
  null,
  "Načíst"
 ],
 "Load earlier data": [
  null,
  "Načíst dřívější data"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "Log out": [
  null,
  "Odhlásit"
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Memory": [
  null,
  "Paměť"
 ],
 "Memory usage": [
  null,
  "Využití paměti"
 ],
 "Memory usage/swap": [
  null,
  "Využití paměti / odkládacího prostoru (swap)"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Metrics and history": [
  null,
  "Metriky a historie"
 ],
 "Metrics history could not be loaded": [
  null,
  "Nepodařilo se načíst historické metriky"
 ],
 "Metrics settings": [
  null,
  "Nastavení metrik"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Network": [
  null,
  "Síť"
 ],
 "Network I/O": [
  null,
  "Síťový vstup/výstup"
 ],
 "Network usage": [
  null,
  "Využití sítě"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "No data available": [
  null,
  "Nejsou k dispozici žádná data"
 ],
 "No data available between $0 and $1": [
  null,
  "Nejsou k dispozici žádná data z rozmezí $0 až $1"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "No events": [
  null,
  "Žádné události"
 ],
 "No log entries": [
  null,
  "Žádné položky záznamu událostí"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Pokud chcete sdílet metriky, otevřete na bráně firewall komunikaci pro službu pmproxy."
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Out": [
  null,
  "Výstup"
 ],
 "Overview": [
  null,
  "Přehled"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Chybí balíček cockpit-pcp a proto není k dispozici historie metrik"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nebylo přijato"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Path to file": [
  null,
  "Popis umístění serveru"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot shromažďuje a analyzuje výkonnostní metriky z vašeho systému."
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "RAM": [
  null,
  "Operační paměť"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Read": [
  null,
  "Čtení"
 ],
 "Read more...": [
  null,
  "Zjistit více…"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Swap": [
  null,
  "Odkládací oddíl"
 ],
 "Swap out": [
  null,
  "Odstránkováno"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "The passwords do not match.": [
  null,
  "Zadání hesla se neshodují."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje pravidla pro SELinux a může pomoci s porozuměním a řešením porušení pravidel."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Tento nástroj nastavuje systém pro zapisování výpisů pádů jádra na disk."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení, mosty, spojení, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s Ubuntu ve výchozím stavu používaným systemd-networkd a skripty ifupdown v distribuci Debian."
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Today": [
  null,
  "Dnes"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "Top 5 CPU services": [
  null,
  "5 služeb nejvíce vytěžujících procesor"
 ],
 "Top 5 disk usage services": [
  null,
  "5 služeb nejvíce vytěžujících úložiště"
 ],
 "Top 5 memory services": [
  null,
  "5 služeb zabírajících nejvíce paměti"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Troubleshoot": [
  null,
  "Řešit potíže"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "Usage": [
  null,
  "Použití"
 ],
 "Used": [
  null,
  "Využito"
 ],
 "View all CPUs": [
  null,
  "Zobrazit všechny procesory"
 ],
 "View all disks": [
  null,
  "Zobrazit všechny disky"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "View detailed logs": [
  null,
  "Zobrazit podrobné záznamy událostí"
 ],
 "View per-disk throughput": [
  null,
  "Zobrazit toky dat pro jednotlivé disky"
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "Write": [
  null,
  "Zápis"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Pro zobrazení historie metrik je třeba, abyste se odhlásili a znovu přihlásili"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "average: $0%": [
  null,
  "průměr: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman není nainstalován"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "max: $0%": [
  null,
  "max: $0%"
 ],
 "nice": [
  null,
  "pořadí přednosti (nice)"
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "pmlogger.service has failed": [
  null,
  "služba pmlogger.service zhavarovala"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "službě pmlogger.service se nedaří shromažďovat data"
 ],
 "pmlogger.service is not running": [
  null,
  "služba pmlogger.service není spuštěná"
 ],
 "pod": [
  null,
  "pod"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "uživatel"
 ]
});
