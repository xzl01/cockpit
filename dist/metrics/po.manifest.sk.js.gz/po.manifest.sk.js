cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "Overview": [
  null,
  "Prehľad"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "user": [
  null,
  "používateľ"
 ]
});
