cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "Overview": [
  null,
  "Genel Bakış"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "user": [
  null,
  "kullanıcı"
 ]
});
