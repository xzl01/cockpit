cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "Overview": [
  null,
  "概览"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "user": [
  null,
  "用户"
 ]
});
