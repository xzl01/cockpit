cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Overview": [
  null,
  "概要"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "user": [
  null,
  "ユーザー"
 ]
});
