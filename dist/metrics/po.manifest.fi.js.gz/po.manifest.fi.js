cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "Overview": [
  null,
  "Esittely"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "user": [
  null,
  "käyttäjä"
 ]
});
