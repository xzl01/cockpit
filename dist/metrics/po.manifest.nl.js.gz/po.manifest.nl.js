cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "Overview": [
  null,
  "Overzicht"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "user": [
  null,
  "gebruiker"
 ]
});
