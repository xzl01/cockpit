cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 chunk size": [
  null,
  "$0 Chunk Größe"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 Overhead verwendet von $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 disk is missing": [
  null,
  "$0 Festplatte fehlt",
  "$0 Festplatten fehlen"
 ],
 "$0 disks": [
  null,
  "$0 Datenträger"
 ],
 "$0 exited with code $1": [
  null,
  "$0 mit Code $1 beendet"
 ],
 "$0 failed": [
  null,
  "$0 fehlgeschlagen"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 is in use": [
  null,
  "$0 verwendet"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mit Signal $1 beendet"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 slot remains": [
  null,
  "$0 Slot verbleibend",
  "$0 Slots verbleibend"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 verwendet von $1 ($2 gespeichert)"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 "$name (from $host)": [
  null,
  "$name (von $host)"
 ],
 "(recommended)": [
  null,
  "(empfohlen)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Ein Dateisystem mit diesem Namen existiert bereits in diesem Pool."
 ],
 "A pool with this name exists already.": [
  null,
  "Ein Pool mit diesem Namen existiert bereits."
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Action": [
  null,
  "Aktion"
 ],
 "Actions": [
  null,
  "Aktionen"
 ],
 "Activate": [
  null,
  "Aktivieren"
 ],
 "Activate before resizing": [
  null,
  ""
 ],
 "Activating $target": [
  null,
  "Aktiviere $target"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Netzwerkgebundene Festplattenverschlüsselung hinzufügen"
 ],
 "Add Tang keyserver": [
  null,
  "Tang Keyserver hinzufügen"
 ],
 "Add block devices": [
  null,
  "Blockorientierte Geräte hinzufügen"
 ],
 "Add disk": [
  null,
  "Datenträger hinzufügen"
 ],
 "Add disks": [
  null,
  "Datenträger hinzufügen"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI-Portal hinzufügen"
 ],
 "Add key": [
  null,
  "Schlüssel hinzufügen"
 ],
 "Add passphrase": [
  null,
  "Passwort hinzufügen"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Hinzufügen von \"$0\" zu Verschlüsselungsoptionen"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Hinzufügen von \"$0\" zu Dateisystemoptionen"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Das Hinzufügen eines neuen Schlüsselserver erfordert das Entsperren des Bereichs . Bitte geben Sie ein aktuelles Passwort an."
 ],
 "Adding key": [
  null,
  "Schlüssel wird hinzugefügt"
 ],
 "Adding physical volume to $target": [
  null,
  "Füge physikalischen Datenträger zu $target hinzu"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Hinzufügen von rd.neednet=1 zur kernel command line"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address cannot be empty": [
  null,
  "Adresse darf nicht leer sein"
 ],
 "Address is not a valid URL": [
  null,
  "Adresse ist keine gültige URL"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Mit der Cockpit Web Konsole administrieren"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "All $0 selected physical volumes are needed for the choosen layout.": [
  null,
  ""
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "An additional $0 must be selected": [
  null,
  ""
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible Rollendokumentation"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Angemessen für wichtige mounts, wie /var"
 ],
 "At boot": [
  null,
  "Beim Starten"
 ],
 "At least $0 disk is needed.": [
  null,
  "Mindestens $0 Datenträger ist nötig.",
  "Mindestens $0 Datenträger sind nötig."
 ],
 "At least one block device is needed.": [
  null,
  "Mindestens ein blockorientiertes Gerät ist erforderlich."
 ],
 "At least one disk is needed.": [
  null,
  "Mindestens ein Datenträger ist nötig."
 ],
 "At least one parent needs to be mounted writable": [
  null,
  ""
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Privilegierte Aktionen der Cockpit Web-Konsole benötigen Berechtigung"
 ],
 "Authentication required": [
  null,
  "Authentifikation erforderlich"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatische Benutzung zusätzlicher NTP-Server"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "Automation script": [
  null,
  "Automatisierungs-Skript"
 ],
 "Available targets on $0": [
  null,
  "Verfügbare Ziele am $0"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Block device": [
  null,
  "Blockorientiertes Gerät"
 ],
 "Block device for filesystems": [
  null,
  "Gerät für Dateisysteme blockieren"
 ],
 "Block devices": [
  null,
  "Blockorientierte Geräte"
 ],
 "Blocked": [
  null,
  "Gesperrt"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Bootvorgang schlägt fehl, falls das Dateisystem nicht mountet, verhindert Fernzugriff"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Bootvorgang ist erfolgreich, auch wenn das Dateisystem nicht eingehängt ist"
 ],
 "Btrfs volume is mounted": [
  null,
  ""
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Cannot forward login credentials": [
  null,
  "Anmeldeinformationen können nicht weitergeleitet werden"
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "Capacity": [
  null,
  "Kapazität"
 ],
 "Category": [
  null,
  ""
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Change iSCSI initiator name": [
  null,
  "Ändern Sie den Namen des iSCSI-Initiators"
 ],
 "Change passphrase": [
  null,
  "Passwort ändern"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  ""
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Überprüfen Sie, ob der SHA-256- oder SHA-1-Hash des Befehls mit diesem Dialogfeld übereinstimmt."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Überprüfen Sie den Schlüsselhash mit dem Tang-Server."
 ],
 "Checking $target": [
  null,
  "$target wird überprüft"
 ],
 "Checking for $0 package": [
  null,
  "Prüfung auf Paket $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Prüfung auf NBDE Unterstützung in der initrd"
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "Chunk size": [
  null,
  "Datenblock Grösse"
 ],
 "Cleaning up for $target": [
  null,
  "$target wird aufgeräumt"
 ],
 "Cleartext device": [
  null,
  "Klartext-Gerät"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit Konfiguration von NetworkManager und Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit konnte den angegebenen Host nicht erreichen."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ist ein Server Manager zur einfachen Verwaltung Ihrer Linux Server via Web Browser. Ein Wechsel zwischen dem Terminal und der Weboberfläche ist kein Problem. Ein Service, der via Cockpit gestartet wurde, kann im Terminal beendet werden. Genauso können Fehler, welche im Terminal vorkommen, im Cockpit Journal angezeigt werden."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ist mit der Software auf dem System nicht kompatibel."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ist auf dem System nicht installiert."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ist perfekt für neue Systemadministratoren, da es ihnen auf einfache Weise ermöglicht, simple Aufgaben wie Speicherverwaltung, Journal / Logfile Analyse oder das Starten und Stoppen von Diensten durchzuführen. Sie können gleichzeitig mehrere Server überwachen und verwalten. Fügen Sie weitere Maschinen mit einem Klick hinzu und Ihre Maschinen schauen zu ihren Kumpels."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Sammeln und Packen von Diagnose und Support Daten"
 ],
 "Collect kernel crash dumps": [
  null,
  "Sammeln von Kernel-Absturz-Auszügen"
 ],
 "Command": [
  null,
  "Befehl"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibel mit allen Systemen und Geräten (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibel mit modernen Systemen und Festplatten > 2TB (GPT)"
 ],
 "Compression": [
  null,
  "Komprimierung"
 ],
 "Confirm": [
  null,
  "Bestätigen"
 ],
 "Confirm deletion of $0": [
  null,
  "Löschen von $0 bestätigen"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Bestätigen Sie die Entfernung mit einem alternativen Passwort"
 ],
 "Confirm stopping of $0": [
  null,
  "Stoppen von $0 bestätigen"
 ],
 "Connection has timed out.": [
  null,
  "Zeitüberschreitung bei der Verbindung."
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2-Volumengruppe erstellen"
 ],
 "Create RAID device": [
  null,
  "RAID-Gerät erzeugen"
 ],
 "Create Stratis pool": [
  null,
  "Stratis Pool erstellen"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Einen Schnappschuss des Dateisystems $0 erstellen"
 ],
 "Create and mount": [
  null,
  "Anlegen und Einhängen"
 ],
 "Create filesystem": [
  null,
  "Dateisystem erstellen"
 ],
 "Create logical volume": [
  null,
  "Logischen Datenträger erstellen"
 ],
 "Create new filesystem": [
  null,
  "Neues Dateisystem erstellen"
 ],
 "Create new logical volume": [
  null,
  "Logischen Datenträger erstellen"
 ],
 "Create new task file with this content.": [
  null,
  "Neue Task-Datei mit diesem Inhalt erstellen."
 ],
 "Create only": [
  null,
  "Nur anlegen"
 ],
 "Create partition": [
  null,
  "Partition erzeugen"
 ],
 "Create partition on $0": [
  null,
  "Partition auf $0 anlegen"
 ],
 "Create partition table": [
  null,
  "Partitionstabelle anlegen"
 ],
 "Create snapshot": [
  null,
  "Snapshot erzeugen"
 ],
 "Create snapshot and mount": [
  null,
  "Snapshot erzeugen und einhängen"
 ],
 "Create snapshot only": [
  null,
  "Nur Snapshot erzeugen"
 ],
 "Create thin volume": [
  null,
  "Thin Volume erstellen"
 ],
 "Create volume group": [
  null,
  "Datenträgerverbund erstellen"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2-Volumengruppe $target erstellt"
 ],
 "Creating VDO device": [
  null,
  "VDO-Gerät wird erstellt"
 ],
 "Creating filesystem on $target": [
  null,
  "Dateisystem auf $target wird erzeugt"
 ],
 "Creating logical volume $target": [
  null,
  "Erzeuge logischen Datenträger $target"
 ],
 "Creating partition $target": [
  null,
  "Erzeuge Partition $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Erzeuge Snapshot von $target"
 ],
 "Ctrl+Insert": [
  null,
  "Strg+Einfügen"
 ],
 "Currently in use": [
  null,
  "Aktuell verwendet"
 ],
 "Custom mount options": [
  null,
  "Benutzerdefinierte Einhängeoptionen"
 ],
 "Data": [
  null,
  "Daten"
 ],
 "Data used": [
  null,
  "Verwendete Daten"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  ""
 ],
 "Deactivate": [
  null,
  "Deaktivieren"
 ],
 "Deactivating $target": [
  null,
  "Deaktiviere $target"
 ],
 "Deduplication": [
  null,
  "Deduplizierung"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Delete group": [
  null,
  "Gruppe löschen"
 ],
 "Deleting $target": [
  null,
  "Lösche $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2-Volumengruppe $target wird gelöscht"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Das Löschen eines Stratis Pools entfernt alle sich darin befindlichen Daten."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Beim Löschen eines Dateisystems werden alle darin enthaltenen Daten gelöscht."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Beim Löschen eines logischen Datenträgers werden alle darin enthaltenen Daten gelöscht."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Beim Löschen einer Partition werden alle darin enthaltenen Daten gelöscht."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Beim Löschen werden alle Daten auf einem VDO-Gerät gelöscht."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Beim Löschen werden alle Daten auf einer Volumengruppe gelöscht."
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "Device": [
  null,
  "Gerät"
 ],
 "Device file": [
  null,
  "Gerätedatei"
 ],
 "Device is read-only": [
  null,
  "Gerät ist schreibgeschützt"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Disconnect": [
  null,
  "Verbindung trennen"
 ],
 "Disk is OK": [
  null,
  "Datenträger ist OK"
 ],
 "Disk is failing": [
  null,
  "Festplatte versagt"
 ],
 "Disk passphrase": [
  null,
  "Disk-Passwort"
 ],
 "Disks": [
  null,
  "Datenträger"
 ],
 "Do not mount": [
  null,
  "Nicht einhängen"
 ],
 "Do not mount automatically on boot": [
  null,
  "Nicht beim Systemstart automatisch einhängen"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "Does not mount during boot": [
  null,
  "Wird beim Systemstart nicht automatisch eingehängt"
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Drive": [
  null,
  "Speichergerät"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang-Keyserver bearbeiten"
 ],
 "Editing a key requires a free slot": [
  null,
  "Das Bearbeiten eines Schlüssels erfordert einen freien Steckplatz"
 ],
 "Ejecting $target": [
  null,
  "Auswerfen $target"
 ],
 "Embedded PC": [
  null,
  "Embedded PC"
 ],
 "Emptying $target": [
  null,
  "Leere $target"
 ],
 "Enabling $0": [
  null,
  "$0 wird aktiviert"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Daten mit einem Tang-Schlüsselserver verschlüsseln"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Verschlüsseln von Daten mit einem Passwort"
 ],
 "Encrypted $0": [
  null,
  "Verschlüsselt $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Verschlüsselter logischer Datenträger von $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Verschlüsselte Partition von $0"
 ],
 "Encryption": [
  null,
  "Verschlüsselung"
 ],
 "Encryption options": [
  null,
  "Verschlüsselungsoptionen"
 ],
 "Encryption type": [
  null,
  "Verschlüsselungstyp"
 ],
 "Erasing $target": [
  null,
  "$target wird gelöscht"
 ],
 "Error": [
  null,
  "Fehler"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  ""
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  ""
 ],
 "Excellent password": [
  null,
  "Perfektes Passwort"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Extended partition": [
  null,
  "Erweiterte Partition"
 ],
 "Failed": [
  null,
  "Fehlgeschlagen"
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0 konnte nicht in firewalld aktiviert werden"
 ],
 "Filesystem": [
  null,
  "Dateisystem"
 ],
 "Filesystem is locked": [
  null,
  "Dateisystem ist gesperrt"
 ],
 "Filesystem name": [
  null,
  "Dateisystemname"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Dateisysteme sind bereits unter diesem Einhängepunkt eingehängt."
 ],
 "Fix NBDE support": [
  null,
  "NBDE-Unterstützung beheben"
 ],
 "Format": [
  null,
  "Formatieren"
 ],
 "Format $0": [
  null,
  "$0 formatieren"
 ],
 "Format and mount": [
  null,
  "Formatieren und einhängen"
 ],
 "Format only": [
  null,
  "Nur Formatieren"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Beim Formatieren werden alle Daten auf einem Speichergerät gelöscht."
 ],
 "Free space": [
  null,
  "Freiraum"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "Grow": [
  null,
  "Wachsen"
 ],
 "Grow content": [
  null,
  "Inhalte erweitern"
 ],
 "Grow logical size of $0": [
  null,
  "Vergrößern Sie die logische Größe von $0"
 ],
 "Grow logical volume": [
  null,
  "Logisches Volumen erhöhen"
 ],
 "Grow partition": [
  null,
  "Partition erweitern"
 ],
 "Grow the pool to take all space": [
  null,
  "Den Pool so vergrößern, dass er den gesamten Platz einnimmt"
 ],
 "Grow to take all space": [
  null,
  "Wachsen Sie, um den gesamten Raum einzunehmen"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Host key is incorrect": [
  null,
  "Host-Schlüssel ist falsch"
 ],
 "I confirm I want to lose this data forever": [
  null,
  ""
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  ""
 ],
 "Important data might be deleted:": [
  null,
  ""
 ],
 "In a terminal, run: ": [
  null,
  "Führen Sie in einem Terminal folgenden Befehl aus: "
 ],
 "In sync": [
  null,
  "Synchron"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Inkonsistenter Dateisystem-Einhängepunkt"
 ],
 "Index memory": [
  null,
  "Indexspeicher"
 ],
 "Initialize": [
  null,
  "Initialisieren"
 ],
 "Initialize disk $0": [
  null,
  "Festplatte $0 initialisieren"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Beim Initialisieren werden alle Daten auf einem Datenträger gelöscht."
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Install NFS support": [
  null,
  "NFS-Unterstützung installieren"
 ],
 "Install Stratis support": [
  null,
  "Stratis-Unterstützung installieren"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "Installing $0": [
  null,
  "$0 wird installiert"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Die Installation von $0 würde $1 entfernen."
 ],
 "Installing packages": [
  null,
  "Pakete werden installiert"
 ],
 "Internal error": [
  null,
  "Interner Fehler"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid file permissions": [
  null,
  "Ungültige Dateiberechtigungen"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "Invalid username or password": [
  null,
  "Benutzername oder Passwort ungültig"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Jobs": [
  null,
  "Jobs"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Schlüsselplätze mit unbekannten Typen können hier nicht bearbeitet werden"
 ],
 "Key source": [
  null,
  "Schlüsselquelle"
 ],
 "Keys": [
  null,
  "Schlüssel"
 ],
 "Keyserver": [
  null,
  "Schlüsselserver"
 ],
 "Keyserver address": [
  null,
  "Keyserver-Adresse"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Das Entfernen des Keyservers verhindert möglicherweise das Entsperren $0."
 ],
 "LVM2 volume group": [
  null,
  "LVM2-Volumengruppe"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2-Volumengruppe $0"
 ],
 "Label": [
  null,
  ""
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last modified: $0": [
  null,
  "Zuletzt geändert: $0"
 ],
 "Layout": [
  null,
  ""
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Linear": [
  null,
  ""
 ],
 "Loading system modifications...": [
  null,
  "System-Änderungen laden..."
 ],
 "Loading...": [
  null,
  "Lade..."
 ],
 "Local mount point": [
  null,
  "Lokaler Einhängepunkt"
 ],
 "Location": [
  null,
  "Ort"
 ],
 "Lock": [
  null,
  "Schließen"
 ],
 "Locking $target": [
  null,
  "Sperren $target"
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "Logical": [
  null,
  "Logisch"
 ],
 "Logical size": [
  null,
  "Logische Größe"
 ],
 "Logical volume": [
  null,
  "Logischer Datenträger"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logisches Volume (Momentaufnahme)"
 ],
 "Logical volume of $0": [
  null,
  "Logisches Volumen von $0"
 ],
 "Login failed": [
  null,
  "Anmeldung fehlgeschlagen"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Manage filesystem sizes": [
  null,
  "Dateisystemgrößen bearbeiten"
 ],
 "Manage storage": [
  null,
  "Speicher verwalten"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Marking $target as faulty": [
  null,
  "$target als fehlerhaft markieren"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Metadata used": [
  null,
  "Verwendete Metadaten"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Mirrored (RAID 1)": [
  null,
  ""
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Modifying $target": [
  null,
  "Ändern $target"
 ],
 "Mount": [
  null,
  "Einhängen"
 ],
 "Mount Point": [
  null,
  "Einhängepunkt"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Einhängen nachdem das Netzwerk wieder zur Verfügung steht, Fehlermeldung ignorieren"
 ],
 "Mount also automatically on boot": [
  null,
  "Automatisch bei Start einhängen"
 ],
 "Mount at boot": [
  null,
  "beim Start einhängen"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Automatisch bei Start unter $0 einhängen"
 ],
 "Mount before services start": [
  null,
  "Einhängen bevor die Dienste starten"
 ],
 "Mount configuration": [
  null,
  "Einhängekonfiguration"
 ],
 "Mount filesystem": [
  null,
  "Dateisystem einhängen"
 ],
 "Mount now": [
  null,
  "Jetzt einbinden"
 ],
 "Mount on $0 now": [
  null,
  "Jetzt unter $0 einhängen"
 ],
 "Mount options": [
  null,
  "Einhängoptionen"
 ],
 "Mount point": [
  null,
  "Einhängepunkt"
 ],
 "Mount point cannot be empty": [
  null,
  "Einhängepunkt darf nicht leer sein"
 ],
 "Mount point cannot be empty.": [
  null,
  "Einhängepunkt darf nicht leer sein."
 ],
 "Mount point is already used for $0": [
  null,
  "Einhängepunkt wird bereits von $0 verwendet"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Einhängepunkt muss mit \"/\" beginnen."
 ],
 "Mount read only": [
  null,
  "Dateisystem als nur lesbar einhängen"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Einhängen ohne abzuwarten, Fehlermeldung ignorieren"
 ],
 "Mounting $target": [
  null,
  "$target wird eingehängt"
 ],
 "Mounts before services start": [
  null,
  "Hängt sich ein, bevor die Dienste starten"
 ],
 "Mounts in parallel with services": [
  null,
  "Hängt sich parallel zu den Diensten ein"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Hängt sich parallel zu den Diensten ein, aber erst wenn das Netzwerk zur Vefügung steht"
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "NFS mount": [
  null,
  "NFS-Mount"
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Name can not be empty.": [
  null,
  "Name darf nicht leer sein."
 ],
 "Name cannot be empty.": [
  null,
  "Name darf nicht leer sein."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Name darf nicht länger als $0 Bytes sein"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Name darf nicht länger als $0 Zeichen sein"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Name darf nicht länger als 127 Zeichen sein."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Name darf nicht das Zeichen '$0' enthalten."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Name darf keine Leerzeichen enthalten."
 ],
 "Need a spare disk": [
  null,
  ""
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "New NFS mount": [
  null,
  "Neuer NFS-Mount"
 ],
 "New passphrase": [
  null,
  "Neues Passwort"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "Next": [
  null,
  "Weiter"
 ],
 "No available slots": [
  null,
  "Keine verfügbaren Slots"
 ],
 "No block devices are available.": [
  null,
  "Es sind keine blockorientierten Geräte verfügbar."
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "No disks are available.": [
  null,
  "Es sind keine Festplatten verfügbar."
 ],
 "No encryption": [
  null,
  "Keine Verschlüsselung"
 ],
 "No filesystem": [
  null,
  "Kein Dateisystem"
 ],
 "No filesystems": [
  null,
  "Keine Dateisysteme"
 ],
 "No free key slots": [
  null,
  "Keine freien Schlüsselplätze"
 ],
 "No free space": [
  null,
  "Kein freier Platz"
 ],
 "No free space after this partition": [
  null,
  "Kein freier Speicherplatz nach dieser Partition"
 ],
 "No keys added": [
  null,
  "Keine Schlüssel hinzugefügt"
 ],
 "No logical volumes": [
  null,
  "Keine logischen Volumes"
 ],
 "No media inserted": [
  null,
  "Keine Medien eingelegt"
 ],
 "No partitioning": [
  null,
  "Keine Partitionierung"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "No system modifications": [
  null,
  "Keine Systemänderungen"
 ],
 "Not a valid private key": [
  null,
  "Ungültiger privater Schlüssel"
 ],
 "Not enough space": [
  null,
  "Nicht genügend Platz"
 ],
 "Not found": [
  null,
  "Nicht gefunden"
 ],
 "Not permitted to perform this action.": [
  null,
  "Diese Aktion darf nicht ausgeführt werden."
 ],
 "Not running": [
  null,
  "Läuft nicht"
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Occurrences": [
  null,
  "Vorkommnisse"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "Altes Passwort"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Wenn Cockpit installiert ist, aktivieren Sie es mit \"systemctl enable --now cockpit.socket\"."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Nur $0 von $1 werden verwendet."
 ],
 "Operation '$operation' on $target": [
  null,
  "Operation '$operation' auf $target"
 ],
 "Options": [
  null,
  "Einstellungen"
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "Overwrite": [
  null,
  "Überschreiben"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Vorhandene Daten mit Nullen überschreiben (langsamer)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "Partition": [
  null,
  "Partition"
 ],
 "Partition of $0": [
  null,
  "Partition von $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Die Größe der Partition beträgt $0. Die Größe des Inhalts beträgt $1."
 ],
 "Partitioning": [
  null,
  "Partitionierung"
 ],
 "Partitions": [
  null,
  "Partitionen"
 ],
 "Passphrase": [
  null,
  "Passwort"
 ],
 "Passphrase can not be empty": [
  null,
  "Passwort darf nicht leer sein"
 ],
 "Passphrase cannot be empty": [
  null,
  "Passwort darf nicht leer sein"
 ],
 "Passphrase from any other key slot": [
  null,
  "Passwort-Satz von irgendeinem anderen Schlüsselplatz"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Das Entfernen des Passwortes verhindert möglicherweise das Entsperren $0."
 ],
 "Passphrases do not match": [
  null,
  "Passwörter stimmen nicht überein."
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Password is not acceptable": [
  null,
  "Das Passwort kann nicht akzeptiert werden"
 ],
 "Password is too weak": [
  null,
  "Das gewählte Passwort ist zu schwach"
 ],
 "Password not accepted": [
  null,
  "Passwort wurde nicht akzeptiert"
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Paste error": [
  null,
  "Fehler beim Einfügen"
 ],
 "Path on server": [
  null,
  "Pfad auf dem Server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Pfad auf dem Server darf nicht leer sein."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Pfad auf dem Server muss mit \"/\" beginnen."
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "Permanently delete $0?": [
  null,
  "$0 dauerhaft löschen?"
 ],
 "Physical": [
  null,
  "Physisch"
 ],
 "Physical volumes": [
  null,
  "Physikalische Volumen"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Please unmount them first.": [
  null,
  "Bitte hängen Sie diese zuerst aus."
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool für Thin Logical Volumes"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool für dünn bereitgestellte Datenträger"
 ],
 "Pool passphrase": [
  null,
  "Pool-Passwort"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "Processes using the location": [
  null,
  "Prozesse, die den Ort nutzen"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Die Aufforderung über ssh-add ist abgelaufen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Die Aufforderung über ssh-keygen ist abgelaufen"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Passwort für den Pool dieser Block-Geräte:"
 ],
 "Purpose": [
  null,
  "Verwendungszweck"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (verteilt)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (gespiegelt)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (verteilt & gespiegelt)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (verteilte Daten & feste Parität)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (verteilte Daten & verteilte Parität)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (verteilte Daten & doppelt verteilte Parität)"
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "RAID level": [
  null,
  "RAID Ebene"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  ""
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Reading": [
  null,
  "Wird gelesen"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Recovering": [
  null,
  "Am Erholen"
 ],
 "Regenerating initrd": [
  null,
  "initrd wird neu generiert"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Zugehörige Prozesse und Dienste werden zwangsweise gestoppt."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Zugehörige Prozesse werden zwangsweise gestoppt."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Zugehörige Dienste werden zwangsweise gestoppt."
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Remove $0?": [
  null,
  "Löschen $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang-Schlüsselserver entfernen?"
 ],
 "Remove device": [
  null,
  "Gerät entfernen"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Passwort von Schlüsselplatz $0 entfernen?"
 ],
 "Remove passphrase?": [
  null,
  "Passwort entfernen?"
 ],
 "Removing $0": [
  null,
  "Entfernen $0"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Das Entfernen eines Passworts ohne Bestätigung mit einem anderen Passwort kann das Entsperren oder die Schlüsselverwaltung verhindern, wenn andere Passwörter vergessen oder verloren werden."
 ],
 "Removing physical volume from $target": [
  null,
  "Entferne physikalischen Datenträger von $target"
 ],
 "Rename": [
  null,
  "Umbenennen"
 ],
 "Rename Stratis pool": [
  null,
  "Stratis Pool umbenennen"
 ],
 "Rename filesystem": [
  null,
  "Dateisystem umbenennen"
 ],
 "Rename logical volume": [
  null,
  "Logischen Datenträger umbenennen"
 ],
 "Rename volume group": [
  null,
  "Datenträgerverbund umbennen"
 ],
 "Renaming $target": [
  null,
  "$target wird umbenannt"
 ],
 "Repair": [
  null,
  ""
 ],
 "Repairing $target": [
  null,
  "Reparieren $target"
 ],
 "Repeat passphrase": [
  null,
  "Passwort wiederholen"
 ],
 "Resizing $target": [
  null,
  "Größenänderung von $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Die Größenänderung eines verschlüsselten Dateisystems benötigt das entsperren der Festplatte. Bitte geben sie das Passwort ein."
 ],
 "Reuse existing encryption": [
  null,
  "Vorhandene Verschlüsselung wiederverwenden"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Vorhandene Verschlüsselung wiederverwenden ($0)"
 ],
 "Running": [
  null,
  "Läuft"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART-Selbsttest von $target"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Speicherplatz durch komprimieren der einzelnen Blöcke mit LZ4 spare"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Sparen Sie Platz, indem identische Datenblöcke nur einmal gespeichert werden"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Das Speichern eines neuen Passworts erfordert das Entsperren der Festplatte. Bitte geben Sie ein aktuelles Disk-Passwort an."
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Securely erasing $target": [
  null,
  "$target wird sicher gelöscht"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Sicherheitsverstärkte Linuxkonfiguration und Problemlösung"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At leat $0 are needed.": [
  null,
  ""
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server address": [
  null,
  "Serveradresse"
 ],
 "Server address cannot be empty.": [
  null,
  "Serveradresse darf nicht leer sein."
 ],
 "Server cannot be empty.": [
  null,
  "Server darf nicht leer sein"
 ],
 "Server has closed the connection.": [
  null,
  "Der Server hat die Verbindung beendet."
 ],
 "Service": [
  null,
  "Dienst"
 ],
 "Services using the location": [
  null,
  "Dienste, die den Ort nutzen"
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Setting up loop device $target": [
  null,
  "Richte Loop Device $target ein"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Einfügen"
 ],
 "Shrink": [
  null,
  "Verkleinern"
 ],
 "Shrink logical volume": [
  null,
  "Logisches Volumen verkleinern"
 ],
 "Shrink partition": [
  null,
  "Partition verkleinern"
 ],
 "Shrink volume": [
  null,
  "Volumen verkleinern"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "Size cannot be negative": [
  null,
  "Größe darf nicht negativ sein"
 ],
 "Size cannot be zero": [
  null,
  "Größe darf nicht Null sein"
 ],
 "Size is too large": [
  null,
  "Größe zu groß"
 ],
 "Size must be a number": [
  null,
  "Größe muss eine Zahl sein"
 ],
 "Size must be at least $0": [
  null,
  "Größe muss mindestens sein $0"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Snapshot": [
  null,
  "Schnappschuss"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Einige Blockgeräte dieses Pools haben sich nach der Erstellung des Pools vergrößert. Der Pool kann sicher erweitert werden, um den neu verfügbaren Platz zu nutzen."
 ],
 "Sorry": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Spare": [
  null,
  "Ersatz"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Start": [
  null,
  "Starten"
 ],
 "Start multipath": [
  null,
  "Multipath starten"
 ],
 "Started": [
  null,
  "Gestartet"
 ],
 "Starting swapspace $target": [
  null,
  "Auslagerungsbereich $target wird gestartet"
 ],
 "State": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Stoppen"
 ],
 "Stop and remove": [
  null,
  "Anhalten und entfernen"
 ],
 "Stop and unmount": [
  null,
  "Anhalten und aushängen"
 ],
 "Stop device": [
  null,
  "Gerät anhalten"
 ],
 "Stopping swapspace $target": [
  null,
  "Auslagerungsbereich $target wird angehalten"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Der Speicher kann auf diesem System nicht verwaltet werden."
 ],
 "Storage logs": [
  null,
  "Speicherprotokolle"
 ],
 "Store passphrase": [
  null,
  "Passwort speichern"
 ],
 "Stored passphrase": [
  null,
  "Gespeichertes Passwort"
 ],
 "Stratis pool": [
  null,
  "Stratis Pool"
 ],
 "Striped (RAID 0)": [
  null,
  ""
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  ""
 ],
 "Stripes": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Subvolume needs to be mounted": [
  null,
  ""
 ],
 "Subvolume needs to be mounted writable": [
  null,
  ""
 ],
 "Successfully copied to clipboard!": [
  null,
  "Erfolgreich in die Zwischenablage kopiert!"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "Tang keyserver": [
  null,
  "Tang Keyserver"
 ],
 "Target": [
  null,
  "Ziel"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Das Paket $0 ist in keinem Repositorium verfügbar."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Das $0 Paket muss installiert werden, um Stratis Pools erzeugen zu können."
 ],
 "The $0 package must be installed.": [
  null,
  "Das Paket $0 muss installiert sein."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Das Paket $0 wird installiert, um VDO-Geräte zu erstellen."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Die Erstellung dieses VDO-Geräts wurde nicht abgeschlossen und das Gerät kann nicht verwendet werden."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Der aktuell angemeldete Benutzer kann keine Informationen zu Schlüsseln anzeigen."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Die Festplatte muss vor dem Formatieren entsperrt werden. Bitte geben Sie ein bestehendes Passwort an."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Das Dateisystem hat keinen permanenten Einhängepunkt"
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Das Dateisystem ist so konfiguriert, dass es beim Booten automatisch eingehängt wird, aber sein Verschlüsselungscontainer wird zu diesem Zeitpunkt nicht entsperrt."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Das Dateisystem ist momentan eingehangen, wird aber bei nächsten Systemstart nicht eingehangen."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Das Dateisystem ist momentan als $0 eingehangen und wird beim nächsten Systemstart als $1 eingehangen."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Das Dateisystem ist momentan als $0 eingehangen und wird beim nächsten Systemstart nicht eingehangen."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Das Dateisystem ist momentan als nicht eingehangen und wird beim nächsten Systemstart eingehangen."
 ],
 "The filesystem is not mounted.": [
  null,
  "Das Dateisystem ist nicht eingehängt."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Das Dateisystem wird beim nächsten Booten entsperrt und eingehängt. Dies kann die Eingabe eines Passworts erfordern."
 ],
 "The initrd must be regenerated.": [
  null,
  "Die initrd muss neu generiert werden."
 ],
 "The last key slot can not be removed": [
  null,
  "Der letzte Schlüsselschlitz kann nicht entfernt werden"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Die aufgelisteten Prozesse und Dienste werden zwangsweise gestoppt."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Die aufgelisteten Prozesse werden zwangsweise gestoppt."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Die aufgelisteten Dienste werden zwangsweise gestoppt."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Der angemeldete Benutzer ist nicht berechtigt, Systemänderungen einzusehen"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Der Einhängepunkt $0 wird von diesen Prozessen verwendet:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Der Einhängepunkt $0 wird von diesen Diensten verwendet:"
 ],
 "The passwords do not match.": [
  null,
  "Die Passwörter stimmen nicht überein."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Der Server hat die Authentifizierung mit allen unterstützten Methoden abgelehnt."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Das System unterstützt momentan nicht das Entsperren eines Dateisystems mit einem Tang Schlüsselserver während des Bootvorgangs."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Das System unterstützt momentan nicht das Entsperren des root-Dateisystems mit einem Tang Schlüsselserver."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Es gibt Geräte mit mehreren Pfaden im System, der Multipath-Dienst wird jedoch nicht ausgeführt."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  ""
 ],
 "There is not enough space in the pool to make a snapshot of this filesystem. At least $0 are required but only $1 are available.": [
  null,
  "Der Platz im Pool reicht nicht aus, um einen Snapshot von diesem Dateisystem zu erstellen. Mindestens $0 sind erforderlich, aber nur $1 sind verfügbar."
 ],
 "These additional steps are necessary:": [
  null,
  "Diese zusätzlichen Schritte sind notwendig:"
 ],
 "These changes will be made:": [
  null,
  "Diese Änderungen werden vorgenommen:"
 ],
 "Thin logical volume": [
  null,
  "Dünnes logisches Volumen"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Dieser NFS-Mount wird verwendet und nur die Optionen können geändert werden."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Dieses VDO-Gerät verwendet nicht alle seine Hintergrundgeräte."
 ],
 "This device is currently in use.": [
  null,
  "Dieses Gerät ist derzeit in Gebrauch."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Dieser Schlüsselserver ist die einzige Möglichkeit, den Pool zu entsperren und kann nicht entfernt werden."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  ""
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Dieses logische Volumen ist nicht vollständig durch seinen Inhalt belegt."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Diese Partition ist nicht vollständig durch seinen Inhalt belegt."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Dieses Passwort ist die einzige Möglichkeit, den Pool zu entsperren und kann nicht entfernt werden."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Dieser Pool nutzt nicht den gesamten Speicherplatz auf seinen Blockgeräten."
 ],
 "This pool is in a degraded state.": [
  null,
  "Dieser Pool befindet sich in einem schlechten Zustand."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dieses Tool konfiguriert die SELinux Policy und hilft dabei Verletzungen der Policy zu verstehen und aufzulösen."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Dieses Tool konfiguriert das System zum Schreiben von Kernel Absturz Auszügen auf Datenträger."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dieses Tool generiert ein Archiv der Konfiguration und Diagnoseinformation des laufenden Systems.Das Archiv kann lokal oder zentral abgespeichert werden zum Zweck der Archivierung oder Nachverfolgung oder kann an den Technischen Support, Entwickler oder Systemadministratoren gesendet werden, um bei der Fehlersuche oder Debugging zu helfen."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dieses Tool verwaltet den lokalen Speicher, wie etwa Dateisysteme, LVM2 Volume Gruppen und NFS Einhängepunkte."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dieses Tool verwaltet die Netzwerkumgebung wie etwa Bindungen, Bridges, Teams, VLANs und Firewalls durch den NetworkManager und Firewalld. Der NetworkManager ist inkompatibel mit dem Ubuntus Standard systemd-networkd und Debians ifupdown Scipts."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  ""
 ],
 "Tier": [
  null,
  "Ebene"
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Too much data": [
  null,
  "Zu viele Daten"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Trust key": [
  null,
  "Schlüssel vertrauen"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit {{Server}} zu synchronisieren"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  ""
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  ""
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Kann Server nicht erreichen"
 ],
 "Unable to remove mount": [
  null,
  "Mount kann nicht entfernt werden"
 ],
 "Unable to unmount filesystem": [
  null,
  "Das Aushängen des Dateisystems ist nicht möglich"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Unerwarteter PackageKit-Fehler bei der Installation von $0: $1"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Unknown ($0)": [
  null,
  "Unbekannt ($0)"
 ],
 "Unknown host name": [
  null,
  "Unbekannter Host-Name"
 ],
 "Unknown type": [
  null,
  "Unbekannter Typ"
 ],
 "Unlock": [
  null,
  "Öffnen"
 ],
 "Unlock automatically on boot": [
  null,
  "Beim Booten automatisch entsperren"
 ],
 "Unlock before resizing": [
  null,
  ""
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Verschlüsselten Stratis-Pool freischalten"
 ],
 "Unlocking $target": [
  null,
  "Entsperren $target"
 ],
 "Unlocking disk": [
  null,
  "Festplatte wird entsperrt"
 ],
 "Unmount": [
  null,
  "Aushängen"
 ],
 "Unmount filesystem $0": [
  null,
  "Dateisystem $0 aushängen"
 ],
 "Unmount now": [
  null,
  "Jetzt aushängen"
 ],
 "Unmounting $target": [
  null,
  "$target wird ausgehängt"
 ],
 "Unrecognized data": [
  null,
  "Unerkannte Daten"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Nicht erkannte Daten können hier nicht verkleinert werden."
 ],
 "Untrusted host": [
  null,
  "Nicht vertrauenswürdiger Host"
 ],
 "Usage": [
  null,
  "Nutzung"
 ],
 "Usage of $0": [
  null,
  "Nutzung von $0"
 ],
 "Use": [
  null,
  "Verwenden"
 ],
 "Use compression": [
  null,
  "Komprimierung verwenden"
 ],
 "Use deduplication": [
  null,
  "Deduplizierung verwenden"
 ],
 "Used": [
  null,
  "Benutzt"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Nützlich für Montierungen, die optional sind oder Interaktion erfordern (z. B. Passwörter)"
 ],
 "User": [
  null,
  "Benutzer"
 ],
 "Username": [
  null,
  "Benutzername"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-Sicherungsgeräte können nicht kleiner gemacht werden"
 ],
 "VDO device $0": [
  null,
  "VDO-Gerät $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-Dateisystemvolumen (Komprimierung/Deduplizierung)"
 ],
 "Vendor": [
  null,
  "Anbieter"
 ],
 "Verify key": [
  null,
  "Schlüssel überprüfen"
 ],
 "Very securely erasing $target": [
  null,
  "$target wird sehr sicher gelöscht"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "View automation script": [
  null,
  "Automatisierungs-Script anzeigen"
 ],
 "View logs": [
  null,
  "Protokolle ansehen"
 ],
 "Visit firewall": [
  null,
  "Firewall besuchen"
 ],
 "Volume group": [
  null,
  "Datenträgerverbund"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Die Größe des Volumens beträgt $0. Die Größe des Inhalts beträgt $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Web Console for Linux servers": [
  null,
  "Webkonsole für Linux-Server"
 ],
 "When this option is checked, the new pool will not allow overprovisioning. You need to specify a maximum size for each filesystem that is created in the pool. Filesystems can not be made larger after creation. Snapshots are fully allocated on creation. The sum of all maximum sizes can not exceed the size of the pool. The advantage of this is that filesystems in this pool can not run out of space in a surprising way. The disadvantage is that you need to know the maximum size for each filesystem in advance and creation of snapshots is limited.": [
  null,
  "Wenn diese Option aktiviert ist, erlaubt der neue Pool kein Overprovisioning. Sie müssen für jedes Dateisystem, das im Pool erstellt wird, eine maximale Größe angeben. Dateisysteme können nach der Erstellung nicht mehr vergrößert werden. Snapshots werden bei der Erstellung vollständig zugewiesen. Die Summe aller Maximalgrößen darf die Größe des Pools nicht überschreiten. Dies hat den Vorteil, dass der Speicherplatz für Dateisysteme in diesem Pool nicht auf überraschende Weise erschöpft werden kann. Der Nachteil ist, dass Sie die maximale Größe für jedes Dateisystem im Voraus kennen müssen und die Erstellung von Snapshots begrenzt ist."
 ],
 "Write-mostly": [
  null,
  "Hauptsächlich Schreiben"
 ],
 "Writing": [
  null,
  "Schreiben"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Ihr Browser lässt das Einfügen über das Kontextmenü nicht zu. Sie können Umschalt+Einfügen verwenden."
 ],
 "Your session has been terminated.": [
  null,
  "Ihre Sitzung wurde beendet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Die Session ist abgelaufen. Bitte neu einloggen."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "backing device for VDO device": [
  null,
  ""
 ],
 "btrfs subvolume $0 of $1": [
  null,
  ""
 ],
 "delete": [
  null,
  "löschen"
 ],
 "device of btrfs volume": [
  null,
  ""
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "format": [
  null,
  "Formatieren"
 ],
 "grow": [
  null,
  "wachsen"
 ],
 "ignore failure": [
  null,
  "Ausfall ignorieren"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "initialize": [
  null,
  "initialisieren"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "member of Stratis pool": [
  null,
  ""
 ],
 "mount": [
  null,
  "Einhängen"
 ],
 "never mount at boot": [
  null,
  "beim Booten nie einhängen"
 ],
 "none": [
  null,
  "kein"
 ],
 "password quality": [
  null,
  "Passwortqualität"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "physisches Volumen der LVM2-Volumengruppe"
 ],
 "read only": [
  null,
  "nur lesbar"
 ],
 "remove from LVM2": [
  null,
  "aus LVM2 entfernen"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "shrink": [
  null,
  "verkleinern"
 ],
 "stop": [
  null,
  "Stopp"
 ],
 "unknown target": [
  null,
  "Unbekanntes Ziel"
 ],
 "unmount": [
  null,
  "Aushängen"
 ],
 "unpartitioned space on $0": [
  null,
  "nicht partitionierter Speicherplatz auf $0"
 ],
 "yes": [
  null,
  "Ja"
 ],
 "format-bytes\u0004bytes": [
  null,
  "Bytes"
 ]
});
