cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Managing LVMs": [
  null,
  "LVM's beheren"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-aankoppelingen beheren"
 ],
 "Managing RAIDs": [
  null,
  "RAID's beheren"
 ],
 "Managing VDOs": [
  null,
  "VDO's beheren"
 ],
 "Managing partitions": [
  null,
  "Partities beheren"
 ],
 "Managing physical drives": [
  null,
  "Fysieke schijven beheren"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Using LUKS encryption": [
  null,
  "Gebruikt LUKS-versleuteling"
 ],
 "Using Tang server": [
  null,
  "Gebruikt Tang-server"
 ],
 "disk": [
  null,
  "schijf"
 ],
 "drive": [
  null,
  "station"
 ],
 "encryption": [
  null,
  "versleuteling"
 ],
 "filesystem": [
  null,
  "bestandssysteem"
 ],
 "format": [
  null,
  "formatteren"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "aankoppelen"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "partitie"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "afkoppelen"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volume"
 ]
});
