cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Managing LVMs": [
  null,
  "管理 LVM"
 ],
 "Managing NFS mounts": [
  null,
  "管理 NFS 掛載"
 ],
 "Managing RAIDs": [
  null,
  "管理 RAID"
 ],
 "Managing VDOs": [
  null,
  "管理 VDO"
 ],
 "Managing partitions": [
  null,
  "管理分割區"
 ],
 "Managing physical drives": [
  null,
  "管理實體硬碟"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Using LUKS encryption": [
  null,
  "使用 LUKS 加密"
 ],
 "Using Tang server": [
  null,
  "使用 Tang 伺服器"
 ],
 "disk": [
  null,
  "磁碟"
 ],
 "drive": [
  null,
  "硬碟"
 ],
 "encryption": [
  null,
  "加密"
 ],
 "filesystem": [
  null,
  "檔案系統"
 ],
 "format": [
  null,
  "格式化"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "掛載"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "分割區"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "卸載"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "磁碟區"
 ]
});
