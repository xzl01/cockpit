cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 nie je možné zväčšiť"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 nie je možné zmenšiť"
 ],
 "$0 can not be resized": [
  null,
  "Pre $0 nie je možné zmeniť veľkosť"
 ],
 "$0 can not be resized here": [
  null,
  "$0 tu nie je možné zmeniť veľkosť"
 ],
 "$0 chunk size": [
  null,
  "$0 Veľkosť bloku"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 dáta + $1 réžie využitéj z $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 deň",
  "$0 dni",
  "$0 dní"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk chýba",
  "$0 disky chýbajú",
  "$0 diskov chýba"
 ],
 "$0 disks": [
  null,
  "$0 Disky"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódom $1"
 ],
 "$0 failed": [
  null,
  "$0 sa nepodarilo"
 ],
 "$0 filesystem": [
  null,
  "systém súborov $0"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodín"
 ],
 "$0 is in use": [
  null,
  "$0 sa používa"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 nútene ukončené signálom $1"
 ],
 "$0 minute": [
  null,
  "$0 minúta",
  "$0 minúty",
  "$0 minút"
 ],
 "$0 month": [
  null,
  "$0 mesiac",
  "$0 mesiace",
  "$0 mesiacov"
 ],
 "$0 partitions": [
  null,
  "$0 oddiel"
 ],
 "$0 slot remains": [
  null,
  "$0 slot ostáva",
  "$0 sloty ostávajú",
  "$0 slotov ostáva"
 ],
 "$0 synchronized": [
  null,
  "$0 nesynchronizované"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 použité z $1 ($2 ušetrené)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 použité, $1 celkom"
 ],
 "$0 week": [
  null,
  "$0 týždeň",
  "$0 týždne",
  "$0 týždňov"
 ],
 "$0 will be installed.": [
  null,
  "Nainštaluje sa $0."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 rokov"
 ],
 "$name (from $host)": [
  null,
  "$name (z $host)"
 ],
 "(Not part of target)": [
  null,
  "(Nie je súčasťou cieľa)"
 ],
 "(no assigned mount point)": [
  null,
  "(nepriradený žiaden bod pripojenia)"
 ],
 "(not mounted)": [
  null,
  "(nepripojené)"
 ],
 "(recommended)": [
  null,
  "(odporúčaný)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 deň"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "1 week": [
  null,
  "1 týždeň"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 hodín"
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Systém súborov s týmto názvom už v tomto poole existuje."
 ],
 "A pool with this name exists already.": [
  null,
  "Pool s takým názvom už existuje."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Skupinu zväzkov (volume group), ktorej chýbajú fyzické zväzky, nie je možné premenovať."
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Acceptable password": [
  null,
  "Prijateľné heslo"
 ],
 "Action": [
  null,
  "Akcia"
 ],
 "Actions": [
  null,
  "Akcie"
 ],
 "Activate": [
  null,
  "Aktivovať"
 ],
 "Activate before resizing": [
  null,
  "Aktivujte pred zmenou veľkosti"
 ],
 "Activating $target": [
  null,
  "Aktivujem $target"
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "Add $0": [
  null,
  "Pridať $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Pridať šifrovanie diskov viazané na sieť"
 ],
 "Add Tang keyserver": [
  null,
  "Pridať Tang server s kľúčmi"
 ],
 "Add a bitmap": [
  null,
  "Pridať bitovú mapu"
 ],
 "Add block devices": [
  null,
  "Pridať blokové zariadenie"
 ],
 "Add disk": [
  null,
  "Pridať disk"
 ],
 "Add disks": [
  null,
  "Pridať disky"
 ],
 "Add iSCSI portal": [
  null,
  "Pridať iSCSI portál"
 ],
 "Add key": [
  null,
  "Pridať kĺúč"
 ],
 "Add keyserver": [
  null,
  "Pridať server s kľúčmi"
 ],
 "Add passphrase": [
  null,
  "Pridať heslovú frázu"
 ],
 "Add physical volume": [
  null,
  "Pridať fyzický zväzok"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Pridávam „$0\" do možností pre šifrovanie"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Pridávam „$0\" do možností pre systém súborov"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Pridanie servera s kľúčmi vyžaduje odomknutie poolu. Zadajte súčasnú heslovú frázu k poolu."
 ],
 "Adding key": [
  null,
  "Pridávam kľúč"
 ],
 "Adding physical volume to $target": [
  null,
  "Pridávam fyzický zväzok do $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Pridávam rd.neednet=1 do parametrov pri zavádzaní jadra"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "Address cannot be empty": [
  null,
  "Adresa nemôže byť prázdna"
 ],
 "Address is not a valid URL": [
  null,
  "Adresa nie je platné URL"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocou webovej konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All $0 selected physical volumes are needed for the choosen layout.": [
  null,
  "Pre zvolené rozvrhnutie je potrebných všetkých $0 vybraných fyzických zväzkov."
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "An additional $0 must be selected": [
  null,
  "Je potrebné vybrať ďalšie $0"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentácia k Ansible roliam"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Vhodné pre kriticky dôležité body pripojenia, ako napríklad /var"
 ],
 "Assessment": [
  null,
  "Posudok"
 ],
 "At boot": [
  null,
  "Pri štarte systému"
 ],
 "At least $0 disk is needed.": [
  null,
  "Vyžaduje sa aspoň $0 disk.",
  "Vyžadujú sa aspoň $0 disky.",
  "Vyžaduje sa aspoň $0 diskov."
 ],
 "At least one block device is needed.": [
  null,
  "Vyžaduje sa aspoň jedno blokové zariadenie."
 ],
 "At least one disk is needed.": [
  null,
  "Vyžaduje sa aspoň jeden disk."
 ],
 "At least one parent needs to be mounted writable": [
  null,
  "Je potrebné, aby aspoň jeden rodič bol pripojený na zápis"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pre vykonávanie privilegovaných úloh pomocou webovej konzole Cockpit je potrebné overiť svoju totožnosť"
 ],
 "Authentication required": [
  null,
  "Vyžaduje sa overenie"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické využitím ďalších NTP serverov"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "Automation script": [
  null,
  "Automatizačný skript"
 ],
 "Available targets on $0": [
  null,
  "Dostupné ciele na $0"
 ],
 "BIOS boot partition": [
  null,
  "Spúšťací oddiel BIOSu"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Block device": [
  null,
  "Blokové zariadenie"
 ],
 "Block device for filesystems": [
  null,
  "Blokové zariadenie pre súborové systémy"
 ],
 "Block devices": [
  null,
  "Blokové zariadenia"
 ],
 "Blocked": [
  null,
  "Blokované"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Ak systém súborov nebude pripojený, spustenie operačného systému skončí s chybou a vzdialený prístup tak nebude fungovať"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Operačný systém sa podarí spustiť, aj keď systém súborov nebude pripojený"
 ],
 "Btrfs volume is mounted": [
  null,
  "Zväzok Btrfs je pripojený"
 ],
 "Bus expansion chassis": [
  null,
  "Šasi pre rozšírenie zbernice"
 ],
 "Cache": [
  null,
  "Vyrovnávacia pamäť"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Cannot forward login credentials": [
  null,
  "Nie je možné preposlať prístupové údaje"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "Capacity": [
  null,
  "Kapacita"
 ],
 "Category": [
  null,
  "Kategória"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Change iSCSI initiater name": [
  null,
  "Zmeniť názov iSCSI iniciátora"
 ],
 "Change iSCSI initiator name": [
  null,
  "Zmeniť názov iSCSI iniciátoru"
 ],
 "Change label": [
  null,
  "Zmeniť štítok"
 ],
 "Change passphrase": [
  null,
  "Zmeniť heslovú frázu"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Zmena typov oddielov môže spôsobiť problémy pri štarte systému."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Skontrolujte, či sa SHA-256 alebo SHA-1 odtlačok z príkazu zhoduje s týmto dialógovým oknom."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Skontrolovať odtlačok kľúča voči Tang serveru."
 ],
 "Checking $target": [
  null,
  "Overujem $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Overujem zariadenie MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Kontrolujem a opravujem MDRAID zariadenie $target"
 ],
 "Checking filesystem usage": [
  null,
  "Kontrolujem využitie systému súborov"
 ],
 "Checking for $0 package": [
  null,
  "Kontrolujem balíček $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Zisťujem prítomnosť podpory NBDE v initrd"
 ],
 "Checking installed software": [
  null,
  "Zisťujem nainštalovaný softvér"
 ],
 "Chunk size": [
  null,
  "Veľkosť bloku"
 ],
 "Cleaning up for $target": [
  null,
  "Čistím pre $target"
 ],
 "Cleartext device": [
  null,
  "Znakové zariadenie"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurácia NetworkManagera a Firewalld v Cockpite"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpitu sa nepodarilo kontaktovať daného hostiteľa."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správca serveru, který uľahčuje správu Linuxových serverov cez webový prehliadač. Nie je žiadnym problémom prechádzať medzi terminálom a webovým nástrojom. Služba spustená cez Cockpit môže byť zastavená v termináli. Podobne, pokiaľ dôjde k chybe v termináli, je toto vidieť v rozhraní žurnálu v Cockpite."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie je kompatibilný so sofvérom na systéme."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie je nainštalovaný na tomto systéme."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je skvelý nástroj pre nových správcov serverov, ktorým jednoducho umožňuje vykonávať úlohy ako správa úložiska, kontrola žurnálu a spúšťanie či zastavovanie služieb. Môžte monitorovať a spravovať viacero serverov naraz. Stačí ich pridať jedným kliknutím a vaše stroje sa budú starať o svojích kamarátov."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zhromaždiť a zabaliť dáta pre diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Zhromaždiť výpisy pádov jadra systému"
 ],
 "Command": [
  null,
  "Príkaz"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibilné so všetkými systémami a zariadeniami (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibilné s modernými systémami a pevnými diskami > 2TB (GPT)"
 ],
 "Compression": [
  null,
  "Kompresia"
 ],
 "Confirm": [
  null,
  "Potvrdiť"
 ],
 "Confirm deletion of $0": [
  null,
  "Potvrďte odstránenie $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Potvrdiť odstránenie pomocou alternatívnej heslovej fráze"
 ],
 "Confirm stopping of $0": [
  null,
  "Potvrďte zastavenie $0"
 ],
 "Connection has timed out.": [
  null,
  "Časový limit spojenia vypršal."
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Copy to clipboard": [
  null,
  "Kopírovať do schránky"
 ],
 "Create": [
  null,
  "Vytvoriť"
 ],
 "Create LVM2 volume group": [
  null,
  "Vytvoriť LVM2 skupinu zväzkov (volume group)"
 ],
 "Create MDRAID device": [
  null,
  "Vytvoriť zariadenie MDRAID"
 ],
 "Create RAID device": [
  null,
  "Vytvoriť RAID zariadenie"
 ],
 "Create Stratis pool": [
  null,
  "Vytvoriť Stratis pool"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Vytvoriť snímku stavu súborového systému $0"
 ],
 "Create and mount": [
  null,
  "Vytvoriť a pripojiť"
 ],
 "Create and start": [
  null,
  "Vytvoriť a spustiť"
 ],
 "Create filesystem": [
  null,
  "Vytvoriť systém súborov"
 ],
 "Create logical volume": [
  null,
  "Vytvoriť logický zväzok"
 ],
 "Create new filesystem": [
  null,
  "Vytvoriť nový systém súborov"
 ],
 "Create new logical volume": [
  null,
  "Vytvoriť nový logický zväzok"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvoriť nový súbor s úlohou s týmto obsahom."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Vytvoriť nový tenko poskytovaný logický zväzok (thin provisioning)"
 ],
 "Create only": [
  null,
  "Iba vytvoriť"
 ],
 "Create partition": [
  null,
  "Vytvoriť oddiel"
 ],
 "Create partition on $0": [
  null,
  "Vytvoriť oddiel na $0"
 ],
 "Create partition table": [
  null,
  "Vytvoriť tabuľku oddielov"
 ],
 "Create snapshot": [
  null,
  "Zachytiť stav"
 ],
 "Create snapshot and mount": [
  null,
  "Vytvoriť snímku (snapshot) a pripojiť ju"
 ],
 "Create snapshot only": [
  null,
  "Iba vytvoriť snímku"
 ],
 "Create storage device": [
  null,
  "Vytvoriť zariadenie úložiska"
 ],
 "Create subvolume": [
  null,
  "Vytvoriť podzväzok (subvolume)"
 ],
 "Create thin volume": [
  null,
  "Vytvoriť tenko poskytovaný (thin provisioned) zväzok"
 ],
 "Create volume group": [
  null,
  "Vytvoriť skupinu zväzkov (volume group)"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Vytváram LVM2 skupinu zväzkov $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "Vytváram MDRAID zariadenie $target"
 ],
 "Creating VDO device": [
  null,
  "Vytváram VDO zariadenie"
 ],
 "Creating filesystem on $target": [
  null,
  "Vytváram systém súborov na $target"
 ],
 "Creating logical volume $target": [
  null,
  "Vytváram logický zväzok $target"
 ],
 "Creating partition $target": [
  null,
  "Vytváram oddiel $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Vytváram snímku stavu $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Aktuálne využité"
 ],
 "Custom": [
  null,
  "Vlastné"
 ],
 "Custom mount options": [
  null,
  "Používateľom definované možnosti pripojenia"
 ],
 "Custom type": [
  null,
  "Používateľom definovaný typ"
 ],
 "Data": [
  null,
  "Údaje"
 ],
 "Data used": [
  null,
  "Využitých dát"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Údaje budú uložené ako dve kópie a tiež striedavo na označených fyzických zväzkoch, čo zvýši spoľahlivosť aj výkon. Je potrebné vybrať aspoň dva zväzky."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Pre zvýšenie spoľahlivosti budú údaje uložené ako dve či viacero kópií na vybraných fyzických zväzkoch. Je potrebné vybrať aspoň dva zväzky."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Pre zlepšenie výkonu budú údaje na vybraných fyzických zväzkoch uložené striedavo. Je potrebné vybrať aspoň dva zväzky."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Údaje budú na vybraných fyzických zväzkoch uložené tak, že bude možné o jeden z nich prísť bez toho, aby došlo ku strate dát. Je potrebné vybrať aspoň tri zväzky."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Údaje budú na vybraných fyzických zväzkoch uložené tak, že bude možné o jeden z nich prísť bez toho, aby došlo ku strate dát. Dáta sú tiež ukladané striedavo, čo vedie k vyššiemu výkonu. Je potrebné vybrať aspoň tri zväzky."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Údaje budú na vybraných fyzických zväzkoch uložené tak, že bude možné o dva z nich prísť bez toho, aby došlo ku strate dát. Dáta sú tiež ukladané striedavo, čo vedie k vyššiemu výkonu. Je potrebné vybrať aspoň päť zväzkov."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Údaje budú na vybraných fyzických zväzkoch bez akejkoľvek dodatočnej odolnosti či zlepšení výkonu."
 ],
 "Deactivate": [
  null,
  "Deaktivovať"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Deaktivovať logický zväzok $0/$1?"
 ],
 "Deactivating $target": [
  null,
  "Deaktivujem $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Vyhradená parita (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Deduplikácia"
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Delete": [
  null,
  "Zmazať"
 ],
 "Delete group": [
  null,
  "Odstrániť skupinu"
 ],
 "Delete pool": [
  null,
  "Odstrániť pool"
 ],
 "Deleting $target": [
  null,
  "Odstraňujem $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Odstraňujem LVM2 skupinu zväzkov $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Odstránením Stratis poolu sa vymažú všetky údaje v ňom."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Odstránením systému súborov sa odstránia všetky údaje v ňom."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Odstránením logického zväzku sa zmažú všetky údaje v ňom."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Odstránením oddielu sa zmažú všetky dáta na ňom."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Odstránením sa zmažú všetky údaje na zariadení MDRAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Odstránením sa zmažú všetky údaje na zariadení VDO."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Odstránením sa zmažú všetky údaje v skupine zväzkov (volume group)."
 ],
 "Deleting erases all data on this subvolume and all it's children.": [
  null,
  "Odstránenie vymaže všetky údaje na tomto podzväzku a všetkých jeho potomkoch."
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "Device": [
  null,
  "Zariadenie"
 ],
 "Device contains unrecognized data": [
  null,
  "Zariadenie obsahuje nerozpoznané dáta"
 ],
 "Device file": [
  null,
  "Súbor zariadenia"
 ],
 "Device is read-only": [
  null,
  "Zariadenie je len na čítanie"
 ],
 "Device number": [
  null,
  "Číslo zariadenia"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Disconnect": [
  null,
  "Odpojiť"
 ],
 "Disk is OK": [
  null,
  "Disk je OK"
 ],
 "Disk is failing": [
  null,
  "Disk zlyháva"
 ],
 "Disk passphrase": [
  null,
  "Heslová fráza k disku"
 ],
 "Disks": [
  null,
  "Disky"
 ],
 "Dismiss": [
  null,
  "Zahodiť"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Distribuovaná parita (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Nepripájať"
 ],
 "Do not mount automatically on boot": [
  null,
  "Nepripájať automaticky pri štarte systému"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "Does not mount during boot": [
  null,
  "Nepripája sa pri štarte systému"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Dvojitá distribuovaná parita (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "Sťahujem $0"
 ],
 "Drive": [
  null,
  "Jednotka"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "EFI system partition": [
  null,
  "Systémový oddiel EFI"
 ],
 "Edit": [
  null,
  "Upraviť"
 ],
 "Edit Tang keyserver": [
  null,
  "Upraviť Tang server s kľúčami"
 ],
 "Edit mount point": [
  null,
  "Upraviť bod pripojenia"
 ],
 "Editing a key requires a free slot": [
  null,
  "Úprava kľúča vyžaduje voľný slot"
 ],
 "Ejecting $target": [
  null,
  "Vysúvam $target"
 ],
 "Embedded PC": [
  null,
  "Jednodoskový počítač"
 ],
 "Emptying $target": [
  null,
  "Vyprázdňujem $target"
 ],
 "Enabling $0": [
  null,
  "Povoľujem $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Šifrovať údaje pomocou Tang servera s kľúčmi"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Šifrovať údaje pomocou heslovej fráze"
 ],
 "Encrypted $0": [
  null,
  "Šifrované $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "Šifrovaný Stratis pool"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Šifrovaný logický zväzok na $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Šifrovaný oddiel na $0"
 ],
 "Encryption": [
  null,
  "Šifrovanie"
 ],
 "Encryption options": [
  null,
  "Možnosti šifrovania"
 ],
 "Encryption type": [
  null,
  "Typ šifrovania"
 ],
 "Erasing $target": [
  null,
  "Mažem $target"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Chyba pri inštalovaní $0: PackageKit nie je nainštalovaný"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Je potrebných vybrať presne $0 fyzických zväzkov"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Je potrebné vybrať presne $0 fyzických zväzkov – jeden pre každý z prúžkov (stripe) logického zväzku."
 ],
 "Excellent password": [
  null,
  "Skvelé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozširujúce šasi"
 ],
 "Extended partition": [
  null,
  "Rozšírený oddiel"
 ],
 "Failed": [
  null,
  "Neúspešné"
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodarilo sa povoliť $0 vo firewalld"
 ],
 "Filesystem": [
  null,
  "Súborový systém"
 ],
 "Filesystem is locked": [
  null,
  "Systém súborov je zamknutý"
 ],
 "Filesystem name": [
  null,
  "Názov systému súborov"
 ],
 "Filesystem outside the target": [
  null,
  "Systém súborov mimo cieľa"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "V tomto bode pripojenia už sú pripojené systémy súborov."
 ],
 "Firmware version": [
  null,
  "Verzia firmvéru"
 ],
 "Fix NBDE support": [
  null,
  "Opraviť podporu pre NBDE"
 ],
 "Format": [
  null,
  "Formátovať"
 ],
 "Format $0": [
  null,
  "Formátovať $0"
 ],
 "Format and mount": [
  null,
  "Naformátovať a pripojiť"
 ],
 "Format and start": [
  null,
  "Naformátovať a spustiť"
 ],
 "Format only": [
  null,
  "Iba naformátovať"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formátovanie vymaže všetky údaje na úložnom zariadení."
 ],
 "Free space": [
  null,
  "Voľný priestor"
 ],
 "Go to now": [
  null,
  "Prejsť na súčasnosť"
 ],
 "Grow": [
  null,
  "Zväčšiť"
 ],
 "Grow content": [
  null,
  "Zväčšiť obsah"
 ],
 "Grow logical size of $0": [
  null,
  "Zväčšiť logickú veľkosť $0"
 ],
 "Grow logical volume": [
  null,
  "Zväčšiť logický zväzok"
 ],
 "Grow partition": [
  null,
  "Zväčšiť oddiel"
 ],
 "Grow the pool to take all space": [
  null,
  "Zväčšiť pool tak, aby využiť celý dostupný priestor"
 ],
 "Grow to take all space": [
  null,
  "Zväčšiť a využiť celý dostupný priestor"
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "Hard Disk Drive": [
  null,
  "Jednotka pevného disku"
 ],
 "Hide confirmation password": [
  null,
  "Skryť potvrdenie hesla"
 ],
 "Hide password": [
  null,
  "Skryť heslo"
 ],
 "Host key is incorrect": [
  null,
  "Kľúč stroja nie je správny"
 ],
 "How to check": [
  null,
  "Ako skontrolovať"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Týmto potvrdzujem, že chcem bez možnosti odvolania zmazať tieto dáta"
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "INTERNÁ CHYBA – Tento logický zväzok je označený ako aktívny a mal by mať priradené blokové zariadenie. Žiadne také blokové zariadenie sa však nenašlo."
 ],
 "Important data might be deleted:": [
  null,
  "Týmto môžete vymazať dôležité údaje:"
 ],
 "In a terminal, run: ": [
  null,
  "V terminále spustite: "
 ],
 "In sync": [
  null,
  "Synchronizované"
 ],
 "Inactive logical volume": [
  null,
  "Neaktívny logický zväzok"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Nekonzistentný bod pripojenia systému súborov"
 ],
 "Index memory": [
  null,
  "Pamäť indexu"
 ],
 "Initialize": [
  null,
  "Inicializovať"
 ],
 "Initialize disk $0": [
  null,
  "Inicializovať disk $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Inicializácia vymaže všetky údaje na disku."
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Install NFS support": [
  null,
  "Nainštalovať podporu pre NFS"
 ],
 "Install Stratis support": [
  null,
  "Nainštalovať podporu pre Stratis"
 ],
 "Install software": [
  null,
  "Nainštalovať softvér"
 ],
 "Installing $0": [
  null,
  "Inštalujem $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Inštalácia $0 by odobrala $1."
 ],
 "Installing packages": [
  null,
  "Inštalujem balíčky"
 ],
 "Internal error": [
  null,
  "Interná chyba"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatné práva súborov"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "Invalid username or password": [
  null,
  "Neplatné meno používateľa alebo heslo"
 ],
 "IoT gateway": [
  null,
  "Brána internetu vecí (IoT)"
 ],
 "Jobs": [
  null,
  "Úlohy"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Sloty kľúčov s neznámym typom tu nie je možné upraviť"
 ],
 "Key source": [
  null,
  "Zdroj pre kľúč"
 ],
 "Keys": [
  null,
  "Kľúče"
 ],
 "Keyserver": [
  null,
  "Server s kľúčami"
 ],
 "Keyserver address": [
  null,
  "Adresa servera s kľúčmi"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Odobranie servera s kľúčmi môže zabrániť odomknutiu $0."
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO pool"
 ],
 "LVM2 logical volume": [
  null,
  "Logický zväzok LVM2"
 ],
 "LVM2 logical volumes": [
  null,
  "Logické zväzky LVM2"
 ],
 "LVM2 physical volume": [
  null,
  "Fyzický zväzok LVM2"
 ],
 "LVM2 physical volumes": [
  null,
  "Fyzické zväzky LVM2"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 skupina zväzkov"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 skupina zväzkov $0"
 ],
 "Label": [
  null,
  "Štítok"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Last cannot be removed": [
  null,
  "Posledný zostávajúci nie je možné odobrať"
 ],
 "Last disk can not be removed": [
  null,
  "Posledný disk nie je možné odstrániť"
 ],
 "Last modified: $0": [
  null,
  "Naposledy zmenené: $0"
 ],
 "Layout": [
  null,
  "Rozvrhnutie"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "Linear": [
  null,
  "Lineárny"
 ],
 "Linux filesystem data": [
  null,
  "Údaje linuxového systému súborov"
 ],
 "Linux swap space": [
  null,
  "Odkladací priestor pre Linux"
 ],
 "Loading system modifications...": [
  null,
  "Načítavam systémové zmeny..."
 ],
 "Loading...": [
  null,
  "Načítavam..."
 ],
 "Local mount point": [
  null,
  "Lokálny bod pripojenia"
 ],
 "Local storage": [
  null,
  "Lokálne úložisko"
 ],
 "Location": [
  null,
  "Umiestnenie"
 ],
 "Lock": [
  null,
  "Zamknúť"
 ],
 "Locked data": [
  null,
  "Uzamknuté dáta"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Uzamknuté zašifrované zariadenie môže obsahovať dáta"
 ],
 "Locking $target": [
  null,
  "Zamykám $target"
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "Logical": [
  null,
  "Logický"
 ],
 "Logical Volume Manager partition": [
  null,
  "Oddiel správy logických zväzkov"
 ],
 "Logical size": [
  null,
  "Logická veľkosť"
 ],
 "Logical volume": [
  null,
  "Logický zväzok"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logický zväzok (zachytený stav)"
 ],
 "Logical volume of $0": [
  null,
  "Logický zväzok na $0"
 ],
 "Login failed": [
  null,
  "Prihlásenie sa nepodarilo"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "MDRAID device": [
  null,
  "Zariadenie MDRAID"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID zariadenie $0"
 ],
 "MDRAID device is recovering": [
  null,
  "Zariadenie MDRAID sa zotavuje"
 ],
 "MDRAID device must be running": [
  null,
  "Je potrebné, aby zariadenie MDRAID bolo spustené"
 ],
 "MDRAID disk": [
  null,
  "Disk MDRAID"
 ],
 "MDRAID disks": [
  null,
  "Disky MDRAID"
 ],
 "Main server chassis": [
  null,
  "Šasi hlavného servera"
 ],
 "Manage filesystem sizes": [
  null,
  "Spravovať veľkosti súborových systémov"
 ],
 "Manage storage": [
  null,
  "Spravovať úložisko"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Marking $target as faulty": [
  null,
  "Označujem $target ako chybný"
 ],
 "Media drive": [
  null,
  "Jednotka média"
 ],
 "Message to logged in users": [
  null,
  "Správa pre prihlásených používateľov"
 ],
 "Metadata used": [
  null,
  "Využité metadáta"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Miniveža"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Zrkadlenie (RAID 1)"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Modifying $target": [
  null,
  "Upravujem $target"
 ],
 "Mount": [
  null,
  "Pripojiť (mount)"
 ],
 "Mount Point": [
  null,
  "Bod pripojenia"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Pripojiť, keď bude sieť k dispozícii, ignorovať neúspech"
 ],
 "Mount also automatically on boot": [
  null,
  "Pripájať tiež automaticky pri štarte systému"
 ],
 "Mount at boot": [
  null,
  "Pripojiť pri štarte"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Pri štarte systému automaticky pripojiť na $0"
 ],
 "Mount before services start": [
  null,
  "Pripojiť pred spustením služieb"
 ],
 "Mount configuration": [
  null,
  "Nastavenie pripojenia (mount)"
 ],
 "Mount filesystem": [
  null,
  "pojiť súborový systém"
 ],
 "Mount now": [
  null,
  "Pripojiť teraz"
 ],
 "Mount on $0 now": [
  null,
  "Pripojiť na $0 teraz"
 ],
 "Mount options": [
  null,
  "Možnosti pripojenia"
 ],
 "Mount point": [
  null,
  "Bod pripojenia"
 ],
 "Mount point cannot be empty": [
  null,
  "Je potrebné zadať bod pripojenia"
 ],
 "Mount point cannot be empty.": [
  null,
  "Je potrebné zadať bod pripojenia."
 ],
 "Mount point is already used for $0": [
  null,
  "Bod pripojenia sa už používa pre $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Bod pripojenia musí začínať lomkou („/\")."
 ],
 "Mount read only": [
  null,
  "Pripojiť iba na čítanie"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Pripojiť bez čakania, ignorovať neúspech"
 ],
 "Mounting $target": [
  null,
  "Pripájam $target"
 ],
 "Mounts before services start": [
  null,
  "Pripojenia pred spustením služieb"
 ],
 "Mounts in parallel with services": [
  null,
  "Bude pripojené súbežne so službami"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Bude sa pripájať súbežne so službami, ale až po tom, ako bude dostupná sieť"
 ],
 "Multi-system chassis": [
  null,
  "Šasi pre viac systémov"
 ],
 "Multipathed devices": [
  null,
  "Zariadenie s viacerými cestami (multipath)"
 ],
 "NFS mount": [
  null,
  "Pripojenie NFS"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Name can not be empty.": [
  null,
  "Názov je potrebné vyplniť."
 ],
 "Name cannot be empty.": [
  null,
  "Názov je potrebné vyplniť."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Názov nemôže byť dlhší ako $0 bytov"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Názov nemôže byť dlhší ako $0 znakov"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Názov nemôže byť dlhší ako 127 znakov."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Názov nemôže byť dlhší ako 255 znakov."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Názov nesmie obsahovať znak „$0\"."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Nazov nesmie obsahovať znak „/\"."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Názov nesmie obsahovať prázdny znak."
 ],
 "Need a spare disk": [
  null,
  "Potrebujete rezervný disk"
 ],
 "Need at least one NTP server": [
  null,
  "Je potrebný aspoň jeden server NTP"
 ],
 "Networked storage": [
  null,
  "Sieťové úložisko"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "New NFS mount": [
  null,
  "Nové NFS pripojenie"
 ],
 "New passphrase": [
  null,
  "Nová heslová fráza"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "Next": [
  null,
  "Ďalej"
 ],
 "No available slots": [
  null,
  "Nie sú dostupné žiadne sloty"
 ],
 "No block devices are available.": [
  null,
  "Nie sú dostupné žiadne blokové zariadenia."
 ],
 "No block devices found": [
  null,
  "Nenájdené žiadne blokové zariadenie"
 ],
 "No delay": [
  null,
  "Bez oneskorenia"
 ],
 "No devices found": [
  null,
  "Žiadne zariadene nebolo nájdené"
 ],
 "No disks are available.": [
  null,
  "Nie sú k dispozícii žiadne disky."
 ],
 "No disks found": [
  null,
  "Neboli nájdené žiadne disky"
 ],
 "No drives found": [
  null,
  "Neboli nájdené žiadne jednotky"
 ],
 "No encryption": [
  null,
  "Bez šifrovania"
 ],
 "No filesystem": [
  null,
  "Bez systému súborov"
 ],
 "No filesystems": [
  null,
  "Systém súborov"
 ],
 "No free key slots": [
  null,
  "Žiadne volné sloty pre kľúče"
 ],
 "No free space": [
  null,
  "Žiadne voľné miesto"
 ],
 "No free space after this partition": [
  null,
  "Za týmto oddielom už nie je žiadne voľné miesto"
 ],
 "No keys added": [
  null,
  "Žiadne pridané kľúče"
 ],
 "No logical volumes": [
  null,
  "Žiadne logické zväzky"
 ],
 "No media inserted": [
  null,
  "Nie je vložené žiadne médium"
 ],
 "No partitioning": [
  null,
  "Žiaden oddiel"
 ],
 "No partitions found": [
  null,
  "Nenašli sa žiadne oddiely"
 ],
 "No physical volumes found": [
  null,
  "Nenájdené žiadne fyzické zväzky"
 ],
 "No snapshots found": [
  null,
  "Nenašli sa žiadne snímky"
 ],
 "No storage found": [
  null,
  "Nenašlo sa žiadne úložisko"
 ],
 "No subvolumes": [
  null,
  "Žiadne podzväzky"
 ],
 "No such file or directory": [
  null,
  "Žiaden taký súbor alebo adresár neexistuje"
 ],
 "No system modifications": [
  null,
  "Žiadne systémové zmeny"
 ],
 "Not a valid private key": [
  null,
  "Nie je platná súkromná časť kľúča"
 ],
 "Not enough free space": [
  null,
  "Nedostatok voľného miesta"
 ],
 "Not enough space": [
  null,
  "Nedostatok miesta"
 ],
 "Not enough space to grow": [
  null,
  "Pre zväčšenie nie je dostatok miesta"
 ],
 "Not found": [
  null,
  "Nenájdené"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávený k vykonaniu tejto akcie."
 ],
 "Not running": [
  null,
  "Nespustená"
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Pôvodná heslová fráza"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Keď bude Cockpit nainštalovaný, povoľte ho pomocou \"systemctl enable --now cockpit.socket\"."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Využíva sa len $0 z $1."
 ],
 "Operation '$operation' on $target": [
  null,
  "Operácia '$operation' na $target"
 ],
 "Options": [
  null,
  "Možnosti"
 ],
 "Other": [
  null,
  "Iný"
 ],
 "Overwrite": [
  null,
  "Prepísať"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Prepísať existujúce dáta nulami (pomalšie)"
 ],
 "PID": [
  null,
  "Identifikátor procesu (PID)"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Partition": [
  null,
  "Oddiel"
 ],
 "Partition of $0": [
  null,
  "Oddiel na $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Veľkosť oddielu je $0. Veľkosť obsahu na ňom je $1."
 ],
 "Partitioning": [
  null,
  "Vytváranie oddielov"
 ],
 "Partitions": [
  null,
  "Oddiely"
 ],
 "Passphrase": [
  null,
  "Heslová fráza"
 ],
 "Passphrase can not be empty": [
  null,
  "Heslová fráza nemôže byť prázdna"
 ],
 "Passphrase cannot be empty": [
  null,
  "Heslová fráza nemôže byť prázdna"
 ],
 "Passphrase from any other key slot": [
  null,
  "Heslová fráza z ľubovoľného iného slotu s kľúčom"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Zmazanie heslovej fráze môže brániť odomknutiu $0."
 ],
 "Passphrases do not match": [
  null,
  "Heslové frázy sa líšia"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo nie je prijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je príliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nebolo prijaté"
 ],
 "Paste": [
  null,
  "Vložiť"
 ],
 "Paste error": [
  null,
  "Chyba vkladania"
 ],
 "Path on server": [
  null,
  "Cesta na serveri"
 ],
 "Path on server cannot be empty.": [
  null,
  "Cestu na server je potrebné zadať."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Je potrebné, aby cesta na serveri začínala lomkou („/\")."
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "Peripheral chassis": [
  null,
  "Šasi pre periférie"
 ],
 "Permanently delete $0?": [
  null,
  "Nenávratne zmazať $0?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Nenávratne zmazať logický zväzok $0/$1?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Nenávratne zmazať podzväzok $0?"
 ],
 "Physical": [
  null,
  "Fyzické"
 ],
 "Physical Volumes": [
  null,
  "Fyzické zväzky"
 ],
 "Physical volumes": [
  null,
  "Fyzické zväzky"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Tu nie je možné meniť veľkosti fyzických zväzkov"
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Pizza box": [
  null,
  "Veľkosť „krabice od pizzy“"
 ],
 "Please unmount them first.": [
  null,
  "Prosím, najprv ich odpojte."
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool pre tenké logické zväzky"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool pre tenko poskytované (thin provisioned) logické zväzky LVM2"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool pre tenko poskytované (thin provisioned) zväzky"
 ],
 "Pool passphrase": [
  null,
  "Heslová fráza k poolu"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Štartovací oddiel PReP architektúry PowerPC"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "Processes using the location": [
  null,
  "Procesy využívajúce toto umiestnenie"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-add bol prekročený"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-keygen bol prekročený"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Zadajte heslovú frázu pre pool na týchto blokových zariadeniach:"
 ],
 "Purpose": [
  null,
  "Účel"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (prekladanie)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (zrkadlenie)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (prekladanie zrkadiel)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (vyhradená parita)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (distribuovaná parita)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dvojitá distribuovaná parita)"
 ],
 "RAID chassis": [
  null,
  "Šasi pre RAID"
 ],
 "RAID level": [
  null,
  "RAID level"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "Pre RAID 10 je potrebný párny počet fyzických zväzkov"
 ],
 "Rack mount chassis": [
  null,
  "Šasi pre umiestnenie do racku"
 ],
 "Reading": [
  null,
  "Čítanie"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Recovering": [
  null,
  "Zotavuje sa"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Zotavuje sa zariadenie MDRAID $target"
 ],
 "Regenerating initrd": [
  null,
  "Znovuvytváram initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Súvisiace procesy a služby budú násilne zastavené."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Súvisiace procesy budú násilne zastavené."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Súvisiace služby budú násilne zastavené."
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Remove": [
  null,
  "Odobrať"
 ],
 "Remove $0?": [
  null,
  "Odobrať $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Odstrániť Tang server s kľúčami?"
 ],
 "Remove device": [
  null,
  "Odstrániť zariadenie"
 ],
 "Remove missing physical volumes?": [
  null,
  "Odstrániť chýbajúce fyzické zväzky?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Odobrať heslovú frázu v slote pre kľúč $0?"
 ],
 "Remove passphrase?": [
  null,
  "Odobrať heslovú frázu?"
 ],
 "Removing $0": [
  null,
  "Odstraňujem $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Odstraňujem $target zo zariadenia MDRAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Odstránenie heslovej fráze bez potvrdenia inej heslovej fráze môže zabrániť v odomknutí alebo správe kľúčov pri strate alebo zabudnutí zostávajúcich heslových fráz."
 ],
 "Removing physical volume from $target": [
  null,
  "Odstraňujem fyzický zväzok z $target"
 ],
 "Rename": [
  null,
  "Premenovať"
 ],
 "Rename Stratis pool": [
  null,
  "Premenovať Stratis pool"
 ],
 "Rename filesystem": [
  null,
  "Premenovať systém súborov"
 ],
 "Rename logical volume": [
  null,
  "Premenovať logický zväzok"
 ],
 "Rename volume group": [
  null,
  "Premenovať skupinu zväzkov (volume group)"
 ],
 "Renaming $target": [
  null,
  "Premenovávam $target"
 ],
 "Repair": [
  null,
  "Opraviť"
 ],
 "Repair logical volume $0": [
  null,
  "Opraviť logický zväzok $0"
 ],
 "Repairing $target": [
  null,
  "Opravujem $target"
 ],
 "Repeat passphrase": [
  null,
  "Zopakujte heslovú frázu"
 ],
 "Resizing $target": [
  null,
  "Mením veľkosť $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Zmena veľkosti šifrovaného systému súborov vyžaduje jeho odomknutie. Zadajte heslovú frázu."
 ],
 "Reuse existing encryption": [
  null,
  "Použiť existujúce šifrovanie"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Použiť existujúce šifrovanie ($0)"
 ],
 "Row expansion": [
  null,
  "Rozšírenie riadka"
 ],
 "Row select": [
  null,
  "Výber riadka"
 ],
 "Running": [
  null,
  "Beží"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART samotest $target"
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Šetriť priestor kompresiou jednotlivých blokov pomocou LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Šetriť priestor ukladaním rovnakých dátových blokov iba raz"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Uloženie novej heslovej frázy vyžaduje odomknutie disku. Zadajte súčasnú heslovú frázu k disku."
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Securely erasing $target": [
  null,
  "Bezpečne mažem $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavenie SELinuxu a riešenie problémov"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At leat $0 are needed.": [
  null,
  "Vyberte fyzické zväzky, ktoré majú byť použité na opravu logického zväzku. Je ich potrebných aspoň $0."
 ],
 "Serial number": [
  null,
  "Sériové číslo"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server address": [
  null,
  "Adresa server"
 ],
 "Server address cannot be empty.": [
  null,
  "Adresa server nemôže byť prázdna."
 ],
 "Server cannot be empty.": [
  null,
  "Server nemôže byť prázdny."
 ],
 "Server has closed the connection.": [
  null,
  "Server zavrel spojenie."
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Services using the location": [
  null,
  "Služby využívajúce toto umiestnenie"
 ],
 "Set partition type of $0": [
  null,
  "Nastaviť typ oddielu na $0"
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Setting up loop device $target": [
  null,
  "Nastavujem zariadenie spätnej slučky $target"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "Zobraziť všetkých $0 riadkov"
 ],
 "Show confirmation password": [
  null,
  "Zobraziť potvrdenie hesla"
 ],
 "Show password": [
  null,
  "Zobraziť heslo"
 ],
 "Shrink": [
  null,
  "Zmenšiť"
 ],
 "Shrink logical volume": [
  null,
  "Zmenšiť logický zväzok"
 ],
 "Shrink partition": [
  null,
  "Zmenšiť oddiel"
 ],
 "Shrink volume": [
  null,
  "Zmenšiť oddiel"
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Size": [
  null,
  "Veľkosť"
 ],
 "Size cannot be negative": [
  null,
  "Veľkosť nemôže byť záporná"
 ],
 "Size cannot be zero": [
  null,
  "Veľkosť nemôže byť nulová"
 ],
 "Size is too large": [
  null,
  "Veľkosť je príliš veľká"
 ],
 "Size must be a number": [
  null,
  "Veľkosť musí byť číslo"
 ],
 "Size must be at least $0": [
  null,
  "Veľkosť musí byť aspoň $0"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Snapshot": [
  null,
  "Zachytený stav"
 ],
 "Snapshot origin": [
  null,
  "Pôvod snímku stavu"
 ],
 "Snapshots": [
  null,
  "Snímky stavu"
 ],
 "Solid State Drive": [
  null,
  "Jednotka bez pohyblivých častí"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Veľkosť niektorých blokových zariadení bola pre vytvorenie poolu zväčšená. Pool je možné bezpečne zväčšiť a využiť tak novo dostupné miesto."
 ],
 "Sorry": [
  null,
  "Prepáčte"
 ],
 "Space-saving computer": [
  null,
  "Priestorovo úsporný počítač"
 ],
 "Spare": [
  null,
  "Náhradný"
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Start": [
  null,
  "Spustiť"
 ],
 "Start multipath": [
  null,
  "Spustiť multipath"
 ],
 "Started": [
  null,
  "Spustené"
 ],
 "Starting MDRAID device $target": [
  null,
  "Spúšťam zariadenie MDRAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "Spúšťam odkladací (swap) priestor $target"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Stick PC": [
  null,
  "Počítač vo forme USB kľúča"
 ],
 "Stop": [
  null,
  "Zastaviť"
 ],
 "Stop and remove": [
  null,
  "Zastaviť a odstrániť"
 ],
 "Stop and unmount": [
  null,
  "Zastaviť a odpojiť"
 ],
 "Stop device": [
  null,
  "Zastaviť zariadenie"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Zastavujem zariadenie MDRAID $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Zastavujem odkladací (swap) priestor $target"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Úložisko nie je možné na tomto systéme spravovať."
 ],
 "Storage logs": [
  null,
  "Záznamy udalostí úložiska"
 ],
 "Store passphrase": [
  null,
  "Uložiť heslovú frázu"
 ],
 "Stored passphrase": [
  null,
  "Uložená heslová fráza"
 ],
 "Stratis block device": [
  null,
  "Blokové zariadenie Stratis"
 ],
 "Stratis block devices": [
  null,
  "Blokové zariadenia Stratis"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Blokové zariadenia Stratis nie je možné zmenšovať"
 ],
 "Stratis filesystem": [
  null,
  "Systém súborov Stratis"
 ],
 "Stratis filesystems": [
  null,
  "Systémy súborov Stratis"
 ],
 "Stratis filesystems pool": [
  null,
  "Pool súborových systémov Stratis"
 ],
 "Stratis pool": [
  null,
  "Stratis pool"
 ],
 "Striped (RAID 0)": [
  null,
  "Prúžkované (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Prúžkované a zrkadlené (RAID 10)"
 ],
 "Stripes": [
  null,
  "Prúžky"
 ],
 "Strong password": [
  null,
  "Silné heslo"
 ],
 "Sub-Chassis": [
  null,
  "Menšie šasi"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Subvolume needs to be mounted": [
  null,
  "Je potrebné, aby bol podzväzok pripojený"
 ],
 "Subvolume needs to be mounted writable": [
  null,
  "Je potrebné, aby bol podzväzok pripojený pre zápis"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Úspešne skopírované do schránky!"
 ],
 "Swap": [
  null,
  "Odkladanie"
 ],
 "Swap can not be resized here": [
  null,
  "Veľkosť odkladacieho oddielu (swap) tu nie je možné meniť"
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizujem"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synchronizujem zariadenie MDRAID $target"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Tang keyserver": [
  null,
  "Tang server s kľúčami"
 ],
 "Target": [
  null,
  "Cieľ"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Balíček $0 nie je k dispozícii v žiadnom repozitári."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Na vytvorenie Stratis poolu je potrebné, aby bol nainštalovaný balíček $0."
 ],
 "The $0 package must be installed.": [
  null,
  "Je potrebné nainštalovať balíček $0."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Aby bolo možné vytvárať zariadenia VDO, nainštaluje sa balíček $0."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Zariadenie MDRAID je v degradovanom stave"
 ],
 "The MDRAID device must be running": [
  null,
  "Je potrebné, aby bolo zariadenie MDRAID spustené"
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Vytváranie tohoto VDO zariadenia nedokončilo a toto zariadenie nemôže byť použité."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Prihlásený užívateľ nie je oprávnený zobrazovať informácie o kľúčoch."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Aby bolo disk možné naformátovať, je potrebné ho odomknúť. Zadajte existujúcu heslovú frázu."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Systém súborov nemá priradený bod pripojenia."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Systém súborov nemá trvalý bod pripojenia."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Systém súborov je nastavený tak, aby bol automaticky pripájaný pri štarte systému, ale šifrovaný kontajner, v ktorom sa nachádza, nebude v tom čase odomknutý."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Systém súborov je teraz pripojený, ale pri ďalšom štarte systému už nebude."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Systém súborov je teraz pripojený do $0, ale pri ďalšom štarte systému bude pripojený do $1."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Systém súborov je teraz pripojený do $0, ale pri ďalšom štarte systému už nebude pripojený vôbec."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Systém súborov nie je pripojený, ale pri ďalšom štarte systéme už bude."
 ],
 "The filesystem is not mounted.": [
  null,
  "Systém súborov nie je pripojený."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Systém súborov bude odomknutý pri ďalšom štarte systému. Toto môže vyžadovať zadanie heslovej fráze."
 ],
 "The initrd must be regenerated.": [
  null,
  "Je potrebné znovu vytvoriť initrd."
 ],
 "The last key slot can not be removed": [
  null,
  "Posledný slot kľúča nemôže byť odobraný"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Uvedené procesy a služby budú násilne ukončené."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Uvedené procesy budú násilne zastavené."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Uvedené služby budú násilne zastavené."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Prihlásený používateľ nie je oprávnený zobrazovať modifikácie systému"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Bod pripojenia $0 je používaný nasledujúcimi procesmi:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Bod pripojenia $0 je používaný nasledujúcimi službami:"
 ],
 "The passwords do not match.": [
  null,
  "Heslá sa líšia."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmietol overovanie pri všetkých podporovaných metódach."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Systém v tejto chvíli nepodporuje odomykanie systému súborov pomocou Tang servera s kľúčmi v priebehu štartu systému."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Systém aktuálne nepodporuje odomykanie koreňového systému súborov pomocou Tang servera s kľúčmi."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "V systéme sú zariadenia s viacerými cestami, ale služba multipath nie je spustená."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Pre opravu nie je k dispozícii dostatok voľného miesta. Na fyzických zväzkoch je potrebných aspoň $0, ktoré ešte nie sú využité týmto logickým zväzkom."
 ],
 "There is not enough space in the pool to make a snapshot of this filesystem. At least $0 are required but only $1 are available.": [
  null,
  "V poole nie je dostatok miesta pre vytvorenie snímky stavu systému súborov. Je potrebných aspoň $0, ale k dispozícii je len $1."
 ],
 "These additional steps are necessary:": [
  null,
  "Sú potrebné tieto ďalšie kroky:"
 ],
 "These changes will be made:": [
  null,
  "Vykonajú sa tieto zmeny:"
 ],
 "Thin logical volume": [
  null,
  "Tenký logický zväzok"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Tenko poskytované LVM2 logické zväzky"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce sychronization times significantly.": [
  null,
  "Toto zariadenie MDRAID nemá bitovú mapu pre write-intent. Takáto mapa môže významne skrátiť čas potrebný na synchronizáciu."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Toto NFS pripojenie je používané a je možné meniť len jeho možnosti."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Toto zariadenie VDI nepožíva zo svojho podkladového zariadenia všetko."
 ],
 "This device can not be used for the installation target.": [
  null,
  "Toto zariadenie nie je možné použiť ako cieľ inštalácie."
 ],
 "This device is currently in use.": [
  null,
  "Toto zariadenie sa aktuálne používa."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Tento server s kľúčmi je jediný spôsob ako pool odomknúť a nie je ho preto možné odobrať."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Tento logický zväzok stratil všetky svoje fyzické zväzky a už ho nie je možné používať. Je potrebné ho vymazať a vytvoriť nový na jeho mieste."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Tento logický zväzok stratil niektoré svoje fyzické zväzky, ale zatiaľ nedošlo ku strate žiadnych dát. Mali by ste ho opraviť a obnoviť tak jeho pôvodnú redundanciu."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Tento logický zväzok stratil niektoré svoje fyzické zväzky, ale pravdepodobne ešte nedošlo ku strate dát. Mali by ste byť schopný ho opraviť."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Tento logický zväzok nie je úplne využitý obsahom, ktorý sa na ňom nachádza."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Tento oddiel nie je úplne využívaný obsahom, ktorý sa na ňom nachádza."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Táto heslová fráza je jediným spôsobom, ako fond odomknúť a preto ho nie je možné odobrať."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Tento pool nevyužíva zo svojich podkladových zariadení všetok priestor."
 ],
 "This pool is in a degraded state.": [
  null,
  "Tento pool sa nachádza v degradovanom stave."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje politiky pre SELinux a môže pomôcť s porozumením a riešením porušenia pravidiel."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Tento nástroj nastavuje systém pre zapisovanie výpisov pádov jadra na disk."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytvára archív nastavení a diagnostických informácií z bežiaceho systému. Archív je možné uložiť lokálne alebo centrálne pre účely sledovania či záznamu alebo je možné ho poslať zástupcom technickej podpory, vývojárom alebo správcom systému, aby tak mohli pomôcť s nájdením technického nedostatku alebo ladením chyby."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje miestne úložisko, ako sú napríklad systémy súborov, LVM2 skupiny zväzkov a NFS pripojenia."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje sieťovanie ako napríklad sieťové spojenia (bond), teaming, mosty (bridge), VLAN siete a brány firewall pomocou nástroja NetworkManager a FIrewalld. NetworkManager nie je kompatibilný s Ubuntu v predvolenom stave pri používaní systemd-networkd a skriptami ifupdown v distribúcii Debian."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Tejto skupine zväzkov chýbajú niektoré fyzické zväzky."
 ],
 "Tier": [
  null,
  "Vrstva (tier)"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Toggle date picker": [
  null,
  "Prepnúť vyberač dátumov"
 ],
 "Too much data": [
  null,
  "Príliš veľa dát"
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Trust key": [
  null,
  "Dôveryhodný kľúč"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizáciu s $0"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Typ môže obsahovať iba znaky 0 až 9, A až F a „-“ (mínus, spojovník)."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Typ musí mať podobu NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Typ musí obsahovať presne dva znaky šestnástkovej sústavy (0 až 9, A až F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "So serverom sa nepodarilo spojiť"
 ],
 "Unable to remove mount": [
  null,
  "Účet sa nepodarilo odstrániť"
 ],
 "Unable to repair logical volume $0": [
  null,
  "Nepodarilo sa opraviť logický zväzok $0"
 ],
 "Unable to unmount filesystem": [
  null,
  "Nepodarilo sa odpojiť systém súborov"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Neočakávaná chyba PackageKit v priebehu inštalácie $0: $1"
 ],
 "Unformatted data": [
  null,
  "Neformátované dáta"
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Unknown ($0)": [
  null,
  "Neznáme ($0)"
 ],
 "Unknown host name": [
  null,
  "Neznámy názov stroja"
 ],
 "Unknown type": [
  null,
  "Neznámy typ"
 ],
 "Unlock": [
  null,
  "Odomknúť"
 ],
 "Unlock automatically on boot": [
  null,
  "Automaticky odomknúť pri štarte systému"
 ],
 "Unlock before resizing": [
  null,
  "Odomknúť pred zmenou veľkosti"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Odomknúť šifrovaný Stratis pool"
 ],
 "Unlocking $target": [
  null,
  "Odomykám $target"
 ],
 "Unlocking disk": [
  null,
  "Odomykám disk"
 ],
 "Unmount": [
  null,
  "Odpojiť"
 ],
 "Unmount filesystem $0": [
  null,
  "Odpojiť systém súborov $0"
 ],
 "Unmount now": [
  null,
  "Odpojiť teraz"
 ],
 "Unmounting $target": [
  null,
  "Odpájam $target"
 ],
 "Unrecognized data": [
  null,
  "Nerozpoznané dáta"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Nerozpoznané dáta tu nie je možné zmenšiť"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Nerozpoznané dáta tu nie je možné zmenšiť."
 ],
 "Unsupported logical volume": [
  null,
  "Nepodporovaný logický zväzok"
 ],
 "Untrusted host": [
  null,
  "Nedôveryhodnotný stroj"
 ],
 "Usage": [
  null,
  "Využitie"
 ],
 "Usage of $0": [
  null,
  "Využitie $0"
 ],
 "Use": [
  null,
  "Použiť"
 ],
 "Use compression": [
  null,
  "Použiť kompresiu"
 ],
 "Use deduplication": [
  null,
  "Použiť deduplikáciu"
 ],
 "Used": [
  null,
  "Využité"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Užitočné pre body pripojenia, ktoré sú voliteľné alebo vyžadujú interakciu (ako napr. heslovú frázu)"
 ],
 "User": [
  null,
  "Používateľ"
 ],
 "Username": [
  null,
  "Meno používateľa"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Zariadenia, ktoré sú podkladom pre VDO, nie je možné zmenšovať"
 ],
 "VDO device $0": [
  null,
  "VDO zariadenie $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Zväzok systému súborov VDO (kompresia/deduplikácia)"
 ],
 "Vendor": [
  null,
  "Výrobca"
 ],
 "Verify key": [
  null,
  "Overiť kľúč"
 ],
 "Very securely erasing $target": [
  null,
  "Naozaj bezpečne mažem $target"
 ],
 "View all logs": [
  null,
  "Zobraziť všetky záznamy udalostí"
 ],
 "View automation script": [
  null,
  "Ukázať automatizačný skript"
 ],
 "View logs": [
  null,
  "Zobraziť záznamy udalostí"
 ],
 "Visit firewall": [
  null,
  "Prejsť na bránu firewall"
 ],
 "Volume group": [
  null,
  "Skupina zväzkov"
 ],
 "Volume group is missing physical volumes": [
  null,
  "Skupine zväzkov (volume group) chýbajú fyzické zväzky"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Veľkosť zväzku je $0. Veľkosť obsahu je $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čakám na dokončenie ostatných operácií správy balíčkov"
 ],
 "Weak password": [
  null,
  "Ľahko prelomiteľné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzola pre linuxové servery"
 ],
 "When this option is checked, the new pool will not allow overprovisioning. You need to specify a maximum size for each filesystem that is created in the pool. Filesystems can not be made larger after creation. Snapshots are fully allocated on creation. The sum of all maximum sizes can not exceed the size of the pool. The advantage of this is that filesystems in this pool can not run out of space in a surprising way. The disadvantage is that you need to know the maximum size for each filesystem in advance and creation of snapshots is limited.": [
  null,
  "Ak je táto možnosť zaškrtnutá, nový pool neumožní prideľovanie miesta nad rámec celkovej kapacity (overprovisioning). Pre každý zo systému súborov vytváraných v poole je potrebné zadať jeho maximálnu veľkosť. Po tom, ako budú vytvorené, už nebude možné systémy súborov zväčšovať. Snímky stavu sú vytvárané v plnej veľkosti. Súčet všetkých maximálnych veľkostí nemôže prekračovať veľkosť poolu. Výhodou tohto prístupu je, že žiadnemu systému súborov v poole nemôže neočakávane dôjsť miesto. Nevýhodou je, že je potrebné vopred poznať maximálnu veľkosť pre každý systém súborov a vytváranie snímok stavu je obmedzené."
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "Write-mostly": [
  null,
  "Prevažne zápis"
 ],
 "Writing": [
  null,
  "Zápis"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vami používaný prehliadač neumožňuje vkladanie z kontextovej ponuky. Ako náhradu môžete použiť Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaša relácia bola ukončená."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnosť vašej relácie skončila. Prihláste sa, prosím, znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "after network": [
  null,
  "po sieti"
 ],
 "backing device for VDO device": [
  null,
  "zariadenie, na ktorom je zariadenie VDO založené"
 ],
 "btrfs device": [
  null,
  "zariadenie btrfs"
 ],
 "btrfs devices": [
  null,
  "btrfs zariadenia"
 ],
 "btrfs filesystem": [
  null,
  "systém súborov btrfs"
 ],
 "btrfs subvolume": [
  null,
  "podzväzok btrfs"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "podzväzok btrfs $0 z $1"
 ],
 "btrfs subvolumes": [
  null,
  "podzväzky btrfs"
 ],
 "btrfs volume": [
  null,
  "zväzok btrfs"
 ],
 "cache": [
  null,
  "medzipamäť (cache)"
 ],
 "data": [
  null,
  "údaje"
 ],
 "deactivate": [
  null,
  "deaktivovať"
 ],
 "delete": [
  null,
  "odstrániť"
 ],
 "device of btrfs volume": [
  null,
  "zariadenie zväzku btrfs"
 ],
 "edit": [
  null,
  "upraviť"
 ],
 "encrypted": [
  null,
  "šifrované"
 ],
 "format": [
  null,
  "Formátovať"
 ],
 "grow": [
  null,
  "zväčšiť"
 ],
 "iSCSI Drive": [
  null,
  "Jednotka iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Jednotky iSCSI"
 ],
 "iSCSI portal": [
  null,
  "Portál iSCSI"
 ],
 "ignore failure": [
  null,
  "ignorovať neúspech"
 ],
 "in less than a minute": [
  null,
  "o menej ako minútu"
 ],
 "initialize": [
  null,
  "inicializovať"
 ],
 "less than a minute ago": [
  null,
  "pred menej ako minútou"
 ],
 "member of MDRAID device": [
  null,
  "člen zariadenia MDRAID"
 ],
 "member of Stratis pool": [
  null,
  "člen Stratis poolu"
 ],
 "mount": [
  null,
  "mount"
 ],
 "never mount at boot": [
  null,
  "nikdy nepripájať pri štarte systému"
 ],
 "none": [
  null,
  "žiaden"
 ],
 "password quality": [
  null,
  "kvalita hesla"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fyzický zväzok LVM2 skupiny zväzkov (volume group)"
 ],
 "read only": [
  null,
  "iba na čítanie"
 ],
 "remove from LVM2": [
  null,
  "odobrať z LVM2"
 ],
 "remove from MDRAID": [
  null,
  "odobrať z MDRAID"
 ],
 "remove from btrfs volume": [
  null,
  "odobrať zo zväzku btrfs"
 ],
 "show less": [
  null,
  "ukázať menej"
 ],
 "show more": [
  null,
  "ukázať viac"
 ],
 "shrink": [
  null,
  "zmenšiť"
 ],
 "snapshot": [
  null,
  "snímka stavu"
 ],
 "stop": [
  null,
  "zastaviť"
 ],
 "stop boot on failure": [
  null,
  "pri chybe zastaviť štart systému"
 ],
 "stopped": [
  null,
  "zastavené"
 ],
 "unknown target": [
  null,
  "neznámy cieľ"
 ],
 "unmount": [
  null,
  "odpojiť"
 ],
 "unpartitioned space on $0": [
  null,
  "nerozdelené miesto na $0"
 ],
 "using key description $0": [
  null,
  "s použitím popisu kľúča $0"
 ],
 "yes": [
  null,
  "áno"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bajty"
 ]
});
