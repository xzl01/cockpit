cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Managing LVMs": [
  null,
  "LVM の管理"
 ],
 "Managing NFS mounts": [
  null,
  "NFS マウントの管理"
 ],
 "Managing RAIDs": [
  null,
  "RAID の管理"
 ],
 "Managing VDOs": [
  null,
  "VDO の管理"
 ],
 "Managing partitions": [
  null,
  "パーティション管理"
 ],
 "Managing physical drives": [
  null,
  "物理ドライブの管理"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS 暗号化の使用"
 ],
 "Using Tang server": [
  null,
  "Tang サーバーの使用"
 ],
 "disk": [
  null,
  "ディスク"
 ],
 "drive": [
  null,
  "ドライブ"
 ],
 "encryption": [
  null,
  "暗号化"
 ],
 "filesystem": [
  null,
  "ファイルシステム"
 ],
 "format": [
  null,
  "フォーマット"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "LUKS"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "マウント"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "パーティション"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "アンマウント"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "ボリューム"
 ]
});
