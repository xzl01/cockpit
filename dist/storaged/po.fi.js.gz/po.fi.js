cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "$0 chunk size": [
  null,
  "$0 palan koko"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 ylikäyttö $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 disk is missing": [
  null,
  "$0 levyä ei löydy",
  "$0 levyjä ei löydy"
 ],
 "$0 disks": [
  null,
  "$0 levyt"
 ],
 "$0 exited with code $1": [
  null,
  "$0 poistui koodilla $1"
 ],
 "$0 failed": [
  null,
  "$0 epäonnistui"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 is in use": [
  null,
  "$0 on käytössä"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "$0 key changed": [
  null,
  "$0 avain muuttunut"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 tapettu signaalilla $1"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 slot remains": [
  null,
  "$0 paikka on jäljellä",
  "$0 paikkaa on jäljellä"
 ],
 "$0 synchronized": [
  null,
  "$0 synkronisoitu"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 käytetty kohteesta $1 ($2 tallennettu)"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 "$name (from $host)": [
  null,
  "$name (kohteesta $host)"
 ],
 "(recommended)": [
  null,
  "(suositeltu)"
 ],
 "1 MiB": [
  null,
  "1 Mit"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "1 minute": [
  null,
  "1 minuutti"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "128 KiB": [
  null,
  "128 Kit"
 ],
 "16 KiB": [
  null,
  "16 Kit"
 ],
 "2 MiB": [
  null,
  "2 Mit"
 ],
 "20 minutes": [
  null,
  "20 minuuttia"
 ],
 "32 KiB": [
  null,
  "32 Kit"
 ],
 "4 KiB": [
  null,
  "4 Kit"
 ],
 "40 minutes": [
  null,
  "40 minuuttia"
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "512 KiB": [
  null,
  "512 Kit"
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "60 minutes": [
  null,
  "60 minuuttia"
 ],
 "64 KiB": [
  null,
  "64 Kit"
 ],
 "8 KiB": [
  null,
  "8 Kit"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Yhteensopivaa versiota Cockpitistä ei ole asennettu kohteessa $0."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Tämänniminen tiedostojärjestelmä on jo tässä varannossa."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uusi SSH-avain nimellä $0 luodaan käyttäjälle $1 koneella $2 ja se lisätään käyttäjän $3 tiedostoon $4 koneella $5."
 ],
 "A pool with this name exists already.": [
  null,
  "Tämän niminen varanto on jo olemassa."
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Action": [
  null,
  "Toiminto"
 ],
 "Actions": [
  null,
  "Toimet"
 ],
 "Activate": [
  null,
  "Aktivoi"
 ],
 "Activate before resizing": [
  null,
  ""
 ],
 "Activating $target": [
  null,
  "Aktivoidaan $target"
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Lisää verkkoon sidottu levyn salaus"
 ],
 "Add Tang keyserver": [
  null,
  "Lisää Tang-avainpalvelin"
 ],
 "Add block devices": [
  null,
  "Lisää lohkolaitteita"
 ],
 "Add disk": [
  null,
  "Lisää levy"
 ],
 "Add disks": [
  null,
  "Lisää levyjä"
 ],
 "Add iSCSI portal": [
  null,
  "Lisää iSCSI-portaali"
 ],
 "Add key": [
  null,
  "Lisää avain"
 ],
 "Add passphrase": [
  null,
  "Lisää tunnuslause"
 ],
 "Add physical volume": [
  null,
  "Lisää fyysinen taltio"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Lisätään \"$0\" salauksen valintoihin"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Lisätään \"$0\" tiedostojärjestelmän asetuksiin"
 ],
 "Adding key": [
  null,
  "Avainta lisätään"
 ],
 "Adding physical volume to $target": [
  null,
  "Lisätään fyysinen taltio $target:een"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Lisätään rd.neednet=1 kernelin komentoriville"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Address": [
  null,
  "Osoite"
 ],
 "Address cannot be empty": [
  null,
  "Osoite ei voi olla tyhjä"
 ],
 "Address is not a valid URL": [
  null,
  "Osoite ei ole kelvollinen URL"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Hallinta Cockpit-verkkokonsolilla"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  ""
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Allow overprovisioning": [
  null,
  ""
 ],
 "An additional $0 must be selected": [
  null,
  ""
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-roolien dokumentaatio"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Soveltuu kriittisiin liitoksiin, kuten /var"
 ],
 "Assessment": [
  null,
  "Arviointi"
 ],
 "At boot": [
  null,
  "Käynnistyksen yhteydessä"
 ],
 "At least $0 disk is needed.": [
  null,
  "Vähintään $0 levy tarvitaan.",
  "Vähintään $0 levyä tarvitaan."
 ],
 "At least one block device is needed.": [
  null,
  "Vähintään yksi lohkolaite tarvitaan."
 ],
 "At least one disk is needed.": [
  null,
  "Vähintään yksi levy tarvitaan."
 ],
 "Authentication": [
  null,
  "Tunnistautuminen"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Todennus vaaditaan etuoikeutettujen tehtävien suorittamiseen Cockpit Web Console:ssa"
 ],
 "Authentication required": [
  null,
  "Tunnistautuminen vaaditaan"
 ],
 "Authorize SSH key": [
  null,
  "Valtuuta SSH-avain"
 ],
 "Automatically using NTP": [
  null,
  "Käytetään automaattisesti NTP:tä"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Käytetään automaattisesti lisättyjä NTP-palvelimia"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Käytetään automaattisesti tiettyjä NTP-palvelimia"
 ],
 "Automation script": [
  null,
  "Automaatio-komentosarja"
 ],
 "Available targets on $0": [
  null,
  "Käytettävät kohteet osoitteessa $0"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Block device": [
  null,
  "lohkolaite"
 ],
 "Block device for filesystems": [
  null,
  "Lohkolaite tiedostojärjestelmille"
 ],
 "Block devices": [
  null,
  "Lohkolaitteet"
 ],
 "Blocked": [
  null,
  "Estetty"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Käynnistys epäonnistuu, jos tiedostojärjestelmä ei liity, mikä estää etäkäytön"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Käynnistys onnistuu vaikka tiedostojärjestelmä ei liity"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "Cache": [
  null,
  "Välimuisti"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Cannot forward login credentials": [
  null,
  "Kirjautumistietoja ei voi välittää eteenpäin"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tapahtumaa ei voi aikatauluttaa menneisyyteen"
 ],
 "Capacity": [
  null,
  "Koko"
 ],
 "Category": [
  null,
  ""
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Change iSCSI initiater name": [
  null,
  "Vaihda iSCSI-aloittajan nimi"
 ],
 "Change iSCSI initiator name": [
  null,
  "Vaihda iSCSI-aloittajan nimi"
 ],
 "Change label": [
  null,
  "Vaihda nimiö"
 ],
 "Change passphrase": [
  null,
  "Vaihda tunnuslause"
 ],
 "Change system time": [
  null,
  "Vaihda järjestelmän aika"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Muutetut avaimet ovat usein seurausta käyttöjärjestelmän uudelleenasennuksesta. Odottamaton muutos voi kuitenkin tarkoittaa kolmannen osapuolen yritystä siepata yhteys."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  ""
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Tarkasta että komennon tuottama SHA-256- tai SHA-1-tarkistesumma vastaa tätä ikkunaa."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Tarkasta avaimen tarkistussumma käyttäen Tang-palvelinta."
 ],
 "Checking $target": [
  null,
  "Tarkistetaan $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Tarkistetaan MDRAID-laite $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Tarkistetaan ja korjataan MDRAID-laite $target"
 ],
 "Checking for $0 package": [
  null,
  "Etsitään $0 pakettia"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Tarkistetaan NBDE-tukea initrd:ssä"
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "Chunk size": [
  null,
  "Palan koko"
 ],
 "Cleaning up for $target": [
  null,
  "Siivotaan kohteelle $target"
 ],
 "Cleartext device": [
  null,
  "Selkotekstilaite"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManagerin ja Firewalld:n Cockit-asetukset"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ei saanut yhteyttä koneeseen."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit on palvelinhallintatyökalu, joka tekee ylläpidon helpoksi selaimen kautta. Liikkuminen päätteen ja verkkokäyttöliittymän välillä ei ole ongelma. Cockpitissä aloitettu palvelu voidaan lopettaa päätteessä. Samaten päätteessä näkyvä virheilmoitus voidaan nähdä myös Cockpitin journal-näkymässä."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ei ole yhteensopiva järjestelmän ohjelmiston kanssa."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ei ole asennettu"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ei ole asennettu järjestelmässä."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit on täydellinen uusille ylläpitäjille. Sen avulla voi tehdä helposti toimenpiteitä kuten tallennustilan hallintaa, lokien tarkistamista sekä palveluiden käynnistämistä ja lopettamista. Voit monitoroida ja hallita useita palvelimia samanaikaisesti. Lisää ne yhdellä napsautuksella ja koneesi katsovat kavereidensa perään."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kerää ja paketoi diagnostiikkaa ja tukitietoja"
 ],
 "Collect kernel crash dumps": [
  null,
  "Kerää ytimen kaatumisvedoksia"
 ],
 "Command": [
  null,
  "Komento"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Yhteensopiva kaikkien järjestelmien ja laitteiden kanssa (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Yhteensopiva modernien järjestelmien ja kovalevyjen kanssa > 2 Tt (GPT)"
 ],
 "Compression": [
  null,
  "Pakkaus"
 ],
 "Confirm": [
  null,
  "Vahvista"
 ],
 "Confirm deletion of $0": [
  null,
  "Vahvista kohteen $0 poistaminen"
 ],
 "Confirm key password": [
  null,
  "Vahvista avaimen salasana"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Vahvista poisto vaihtoehtoisella tunnuslauseella"
 ],
 "Confirm stopping of $0": [
  null,
  "Vahvista kohteen $0 pysäyttäminen"
 ],
 "Connection has timed out.": [
  null,
  "Yhteys aikakatkaistiin."
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Copied": [
  null,
  "Kopioitu"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Create LVM2 volume group": [
  null,
  "Luo LVM2-taltioryhmä"
 ],
 "Create MDRAID device": [
  null,
  "Luo MDRAID-laite"
 ],
 "Create RAID device": [
  null,
  "Luo RAID-laite"
 ],
 "Create Stratis pool": [
  null,
  "Luo stratisvaranto"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Luo uusi SSH-avain ja valtuuta se"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Luodaan tilannevedos tiedostojärjestelmästä $0"
 ],
 "Create and mount": [
  null,
  "Luo ja liitä"
 ],
 "Create filesystem": [
  null,
  "Luo tiedostojärjestelmä"
 ],
 "Create logical volume": [
  null,
  "Luo looginen taltio"
 ],
 "Create new filesystem": [
  null,
  "Luo uusi tiedostojärjestelmä"
 ],
 "Create new logical volume": [
  null,
  "Luo uusi looginen taltio"
 ],
 "Create new task file with this content.": [
  null,
  "Luo uusi tehtävätiedosto tällä sisällöllä."
 ],
 "Create only": [
  null,
  "Vain luominen"
 ],
 "Create partition": [
  null,
  "Luo osio"
 ],
 "Create partition on $0": [
  null,
  "Luo osio $0:een"
 ],
 "Create partition table": [
  null,
  "Luo osiotaulukko"
 ],
 "Create snapshot": [
  null,
  "Luo tilannevedos"
 ],
 "Create snapshot and mount": [
  null,
  "Luo tilannevedos ja liitä"
 ],
 "Create snapshot only": [
  null,
  "Luo vain tilannevedos"
 ],
 "Create thin volume": [
  null,
  "Luo ohut taltio"
 ],
 "Create volume group": [
  null,
  "Luo taltioryhmä"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Luodaan LVM2 taltioryhmä $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "Luodaan MDRAID-laite $target"
 ],
 "Creating VDO device": [
  null,
  "Luodaan VDO-laitetta"
 ],
 "Creating filesystem on $target": [
  null,
  "Luodaan tiedostojärjestelmää $target:een"
 ],
 "Creating logical volume $target": [
  null,
  "Luodan loogista taltiota $target"
 ],
 "Creating partition $target": [
  null,
  "Luodaan osiota $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Luodaan tilannevedos $target:sta"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Tällä hetkellä käytössä"
 ],
 "Custom": [
  null,
  "Mukautettu"
 ],
 "Custom mount options": [
  null,
  "Mukautetut liitosvalinnat"
 ],
 "Data": [
  null,
  "Tiedot"
 ],
 "Data used": [
  null,
  "Dataa käytetty"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  ""
 ],
 "Deactivate": [
  null,
  "Deaktivoi"
 ],
 "Deactivating $target": [
  null,
  "Deaktivoidaan $target"
 ],
 "Deduplication": [
  null,
  "Päällekkäisyyden poisto"
 ],
 "Delay": [
  null,
  "Viive"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Delete group": [
  null,
  "Poista ryhmä"
 ],
 "Delete pool": [
  null,
  "Poista varanto"
 ],
 "Deleting $target": [
  null,
  "Poistetaan $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Tuhotaan LVM2 taltioryhmä $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Stratisvarannon poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Tiedostojärjestelmän poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Loogisen taltion poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Osion poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Poistaminen tuhoaa kaiken MDRAID-laitteella olevan datan."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "VDO-laitteen poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Poistaminen poistaa kaikki taltioryhmässä olevat tiedot."
 ],
 "Description": [
  null,
  "Kuvaus"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "Device": [
  null,
  "Laite"
 ],
 "Device file": [
  null,
  "Laitetiedosto"
 ],
 "Device is read-only": [
  null,
  "Laite on vain-luku-muotoa"
 ],
 "Device number": [
  null,
  "Laitenumero"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Disconnect": [
  null,
  "Katkaise yhteys"
 ],
 "Disk is OK": [
  null,
  "Levy on kunnossa"
 ],
 "Disk is failing": [
  null,
  "Levy on rikkoutumassa"
 ],
 "Disk passphrase": [
  null,
  "Levyn tunnuslause"
 ],
 "Disks": [
  null,
  "Levyt"
 ],
 "Dismiss": [
  null,
  "Hylkää"
 ],
 "Do not mount": [
  null,
  "Älä liitä"
 ],
 "Do not mount automatically on boot": [
  null,
  "Älä liitä automaattisesti käynnistyksen yhteydessä"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "Does not mount during boot": [
  null,
  "Ei liitetä käynnistyksen yhteydessä"
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Drive": [
  null,
  "Asema"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "EFI system partition": [
  null,
  "EFI-järjestelmäosio"
 ],
 "Edit": [
  null,
  "Muokkaa"
 ],
 "Edit Tang keyserver": [
  null,
  "Muokkaa Tang-avainpalvelinta"
 ],
 "Editing a key requires a free slot": [
  null,
  "Avaimen muokkaaminen vaatii vapaan paikan"
 ],
 "Ejecting $target": [
  null,
  "Työnnetään $target ulos"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Emptying $target": [
  null,
  "Tyhjennetään $target"
 ],
 "Enabling $0": [
  null,
  "Otetaan käyttöön $0"
 ],
 "Encrypted $0": [
  null,
  "Salattu $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "Salattu Stratisvaranto"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Salattu looginen taltio $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Salattu osio $0"
 ],
 "Encryption": [
  null,
  "Salaus"
 ],
 "Encryption options": [
  null,
  "Salauksen valinnat"
 ],
 "Encryption type": [
  null,
  "Salauksen tyyppi"
 ],
 "Erasing $target": [
  null,
  "Tyhjennetään $target"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Virhe asennettaessa pakettia $0: PackageKit ei ole asennettu"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  ""
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  ""
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "Extended partition": [
  null,
  "Laajennettu osio"
 ],
 "Failed": [
  null,
  "Epäonnistui"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Filesystem": [
  null,
  "Tiedostojärjestelmä"
 ],
 "Filesystem is locked": [
  null,
  "Tiedostojärjestelmä on lukittu"
 ],
 "Filesystem name": [
  null,
  "Tiedostojärjestelmän nimi"
 ],
 "Firmware version": [
  null,
  "Laiteohjelmiston versio"
 ],
 "Fix NBDE support": [
  null,
  "Korjaa NBDE-tuki"
 ],
 "Format": [
  null,
  "Alusta"
 ],
 "Format $0": [
  null,
  "Alusta $0"
 ],
 "Format and mount": [
  null,
  "Alusta ja liitä"
 ],
 "Format only": [
  null,
  "Vain alustus"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Talletuslaitteen alustaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Free space": [
  null,
  "Vapaa tila"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "Grow": [
  null,
  "Kasvata"
 ],
 "Grow content": [
  null,
  "Kasvata sisältöä"
 ],
 "Grow logical size of $0": [
  null,
  "Kasvata loogista kokoa $0"
 ],
 "Grow logical volume": [
  null,
  "Kasvata loogista taltiota"
 ],
 "Grow to take all space": [
  null,
  "Kasvata viemään koko tilan"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "Host key is incorrect": [
  null,
  "Koneen avain on väärin"
 ],
 "How to check": [
  null,
  "Kuinka tarkastaa"
 ],
 "I confirm I want to lose this data forever": [
  null,
  ""
 ],
 "ID": [
  null,
  "Tunniste"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  ""
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jos sormenjälki on sama, napsauta 'Luota ja lisää yhteys'. Muussa tapauksessa älä muodosta yhteyttä ja ota yhteyttä järjestelmänvalvojaan."
 ],
 "Important data might be deleted:": [
  null,
  ""
 ],
 "In a terminal, run: ": [
  null,
  "Suorita päätteessä: "
 ],
 "In sync": [
  null,
  "Synkronoitu"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Epäjohdonmukainen tiedostojärjestelmän liitos"
 ],
 "Index memory": [
  null,
  "Indeksin muisti"
 ],
 "Initialize": [
  null,
  "Alusta"
 ],
 "Initialize disk $0": [
  null,
  "Alusta levy $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Taltion alustaminen tuhoaa kaikki sillä olevat tiedot."
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Install NFS support": [
  null,
  "Asenna NFS-tuki"
 ],
 "Install Stratis support": [
  null,
  "Asenna Stratis-tuki"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Paketin $0 asentaminen poistaa paketin $1."
 ],
 "Installing packages": [
  null,
  "Asennetaan paketit"
 ],
 "Internal error": [
  null,
  "Sisäinen virhe"
 ],
 "Invalid date format": [
  null,
  "Virheellinen päivämuoto"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Virheellinen päivämuoto ja aikamuoto"
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Invalid time format": [
  null,
  "Virheellinen aikamuoto"
 ],
 "Invalid timezone": [
  null,
  "Virheellinen aikavyöhyke"
 ],
 "Invalid username or password": [
  null,
  "Virheellinen käyttäjätunnus tai salasana"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Jobs": [
  null,
  "Työt"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Key password": [
  null,
  "Avaimen salasana"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Avainpaikkoja tuntemattomilla tyypeillä ei voi muokata täällä"
 ],
 "Key source": [
  null,
  "Avainlähde"
 ],
 "Keys": [
  null,
  "Avaimet"
 ],
 "Keyserver": [
  null,
  "Avainpalvelin"
 ],
 "Keyserver address": [
  null,
  "Avainpalvelimen osoite"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Avaimenpalvelimen poisto voi estää lukituksen avaamisen$0."
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 looginen taltio"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 loogiset taltiot"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fyysinen taltio"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 fyysiset taltiot"
 ],
 "LVM2 volume group": [
  null,
  "LVM-taltioryhmä"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2-taltioryhmä $0"
 ],
 "Label": [
  null,
  "Nimiö"
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Last modified: $0": [
  null,
  "Viimeksi muokattu: $0 sitten"
 ],
 "Layout": [
  null,
  ""
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "Linear": [
  null,
  ""
 ],
 "Loading system modifications...": [
  null,
  "Ladataan järjestelmän muutoksia ..."
 ],
 "Loading...": [
  null,
  "Ladataan..."
 ],
 "Local mount point": [
  null,
  "Paikallinen liitoskohta"
 ],
 "Location": [
  null,
  "Sijainti"
 ],
 "Lock": [
  null,
  "Lukitse"
 ],
 "Lock $0?": [
  null,
  "Lukitse $0?"
 ],
 "Locking $target": [
  null,
  "Lukitaan $target"
 ],
 "Log in": [
  null,
  "Kirjaudu sisään"
 ],
 "Log in to $0": [
  null,
  "Kirjaudu kohteeseen $0"
 ],
 "Log messages": [
  null,
  "Kirjaa viestit"
 ],
 "Logical": [
  null,
  "Looginen"
 ],
 "Logical size": [
  null,
  "Looginen koko"
 ],
 "Logical volume": [
  null,
  "Looginen taltio"
 ],
 "Logical volume (snapshot)": [
  null,
  "Looginen taltio (tilannevedos)"
 ],
 "Logical volume of $0": [
  null,
  "$0:n looginen taltio"
 ],
 "Login failed": [
  null,
  "Kirjautuminen epäonnistui"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "MDRAID device": [
  null,
  "MDRAID-laite"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID-laite $0"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Manage storage": [
  null,
  "Tallennustilan hallinta"
 ],
 "Manually": [
  null,
  "Manuaalisesti"
 ],
 "Marking $target as faulty": [
  null,
  "Merkitään $target virheelliseksi"
 ],
 "Message to logged in users": [
  null,
  "Viesti sisäänkirjautuneille käyttäjille"
 ],
 "Metadata used": [
  null,
  "Metadataa käytetty"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Mirrored (RAID 1)": [
  null,
  ""
 ],
 "Model": [
  null,
  "Malli"
 ],
 "Modifying $target": [
  null,
  "Muokataan $target"
 ],
 "Mount": [
  null,
  "Liitos"
 ],
 "Mount Point": [
  null,
  "Liitoskohta"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Liitä, kun verkko tulee saataville, jätä vika huomiotta"
 ],
 "Mount also automatically on boot": [
  null,
  "Liitä myös automaattisesti käynnistyksessä"
 ],
 "Mount at boot": [
  null,
  "Liitä käynnistyksen yhteydessä"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Liitä automaattisesti $0:een käynnistyksessä"
 ],
 "Mount before services start": [
  null,
  "Liitä ennen palveluiden aloittamista"
 ],
 "Mount configuration": [
  null,
  "Liitoksen kokoonpano"
 ],
 "Mount filesystem": [
  null,
  "Liitoksen tiedostojärjestelmä"
 ],
 "Mount now": [
  null,
  "Liitä nyt"
 ],
 "Mount on $0 now": [
  null,
  "Liitä hakemistoon $0 nyt"
 ],
 "Mount options": [
  null,
  "Liitosvalinnat"
 ],
 "Mount point": [
  null,
  "Liitoskohta"
 ],
 "Mount point cannot be empty": [
  null,
  "Liitoskohta ei voi olla tyhjä"
 ],
 "Mount point cannot be empty.": [
  null,
  "Liitoskohta ei voi olla tyhjä."
 ],
 "Mount point is already used for $0": [
  null,
  "Liitoskohta on jo käytetty lohkolaitetta $0 varten"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Liitoskohdan täytyy alkaa \"/\":lla."
 ],
 "Mount read only": [
  null,
  "Liitä vain luku -tilassa"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Liitä odottamatta, jätä vika huomiotta"
 ],
 "Mounting $target": [
  null,
  "Liitetään $target"
 ],
 "Mounts before services start": [
  null,
  "Liittyy ennen palveluiden aloittamista"
 ],
 "Mounts in parallel with services": [
  null,
  "Liittyy yhtäaikaa palveluiden aloittamisten kanssa"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Liittyy yhtäaikaa palveluiden aloittamisten kanssa, mutta sen jälkeen, kun verkko on käytettävissä"
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "Multipathed devices": [
  null,
  "Monipolkuiset laitteet"
 ],
 "NFS mount": [
  null,
  "NFS-liitos"
 ],
 "NTP server": [
  null,
  "NTP-palvelin"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Name can not be empty.": [
  null,
  "Nimi ei voi olla tyhjä."
 ],
 "Name cannot be empty.": [
  null,
  "Nimi ei voi olla tyhjä."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Nimi voi olla enintään $0 tavua pitkä"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Nimi voi sisältää enintään $0 merkkiä"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Nimi voi sisältää enintään 127 merkkiä."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Nimi ei voi sisältää merkkiä '$0'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nimi ei voi sisältää välilyöntiä."
 ],
 "Need a spare disk": [
  null,
  ""
 ],
 "Need at least one NTP server": [
  null,
  "Tarvitaan vähintään yksi NTP-palvelin"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "New NFS mount": [
  null,
  "Uusi NFS-liitos"
 ],
 "New passphrase": [
  null,
  "Uusi tunnuslause"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "Next": [
  null,
  "Seuraava"
 ],
 "No available slots": [
  null,
  "Ei käytettävissä olevia paikkoja"
 ],
 "No block devices are available.": [
  null,
  "Lohkolaitteita ei ole saatavilla."
 ],
 "No block devices found": [
  null,
  "Lohkolaitetta ei löytynyt"
 ],
 "No delay": [
  null,
  "Ei viivettä"
 ],
 "No disks are available.": [
  null,
  "Levyjä ei ole saatavilla."
 ],
 "No encryption": [
  null,
  "Ei salausta"
 ],
 "No filesystem": [
  null,
  "Ei tiedostojärjestelmää"
 ],
 "No filesystems": [
  null,
  "Ei tiedostojärjestelmää"
 ],
 "No free key slots": [
  null,
  "Ei vapaita avainpaikkoja"
 ],
 "No free space": [
  null,
  "Ei vapaata tilaa"
 ],
 "No keys added": [
  null,
  "Ei avaimia lisätty"
 ],
 "No logical volumes": [
  null,
  "Ei loogisia taltioita"
 ],
 "No media inserted": [
  null,
  "Ei välinettä asetettuna"
 ],
 "No partitioning": [
  null,
  "Ei osiointia"
 ],
 "No results found": [
  null,
  "Tuloksia ei löytynyt"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "No system modifications": [
  null,
  "Ei järjestelmän muutoksia"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Not enough free space": [
  null,
  "Ei tarpeeksi levytilaa vapaana"
 ],
 "Not enough space": [
  null,
  "Ei tarpeeksi tilaa"
 ],
 "Not enough space to grow": [
  null,
  "Ei tarpeeksi tilaa kasvaa"
 ],
 "Not found": [
  null,
  "Ei löytynyt"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ei oikeutta suorittaa tätä toimintoa."
 ],
 "Not running": [
  null,
  "Ei käynnissä"
 ],
 "Not synchronized": [
  null,
  "Ei synkronisoitu"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Occurrences": [
  null,
  "Tapahtumat"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "Vanha tunnuslause"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Kun Cockpit on asennettu, ota se käyttöön 'systemctl enable --now cockpit.socket'."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Vain $0 ja $1 ovat käytössä."
 ],
 "Operation '$operation' on $target": [
  null,
  "Toimi '$operation' $target:lla"
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Other": [
  null,
  "Muu"
 ],
 "Overwrite": [
  null,
  "Korvaa"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Korvaa olemassa olevat tiedot nollilla (hitaampi)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "Partition": [
  null,
  "Osio"
 ],
 "Partition of $0": [
  null,
  "$0:n osio"
 ],
 "Partitioning": [
  null,
  "Osiointi"
 ],
 "Partitions": [
  null,
  "Osiot"
 ],
 "Passphrase": [
  null,
  "Tunnuslause"
 ],
 "Passphrase can not be empty": [
  null,
  "Tunnuslause ei voi olla tyhjä"
 ],
 "Passphrase cannot be empty": [
  null,
  "Tunnuslause ei voi olla tyhjä"
 ],
 "Passphrase from any other key slot": [
  null,
  "Tunnuslause mistä tahansa muusta avainpaikasta"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Salalauseen poisto voi estää laitteen $0 lukituksen avaamisen."
 ],
 "Passphrases do not match": [
  null,
  "Tunnuslauseet eivät täsmää"
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Paste": [
  null,
  "Siirrä"
 ],
 "Paste error": [
  null,
  "Liittämisvirhe"
 ],
 "Path on server": [
  null,
  "Polku palvelimella"
 ],
 "Path on server cannot be empty.": [
  null,
  "Polku palvelimella ei voi olla tyhjä."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Polun palvelimella täytyy alkaa \"/\"."
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "Permanently delete $0?": [
  null,
  "Poista $0 pysyvästi?"
 ],
 "Physical": [
  null,
  "Fyysinen"
 ],
 "Physical Volumes": [
  null,
  "Fyysiset taltiot"
 ],
 "Physical volumes": [
  null,
  "Fyysiset taltiot"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Fyysisten taltioiden kokoja ei voida muuttaa tässä"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Please unmount them first.": [
  null,
  ""
 ],
 "Pool for thin logical volumes": [
  null,
  "Varanto ohuita loogisia taltioita varten"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Varanto ohuesti varattuja taltioita varten"
 ],
 "Port": [
  null,
  "Portti"
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "Processes using the location": [
  null,
  "Prosessit, jotka käyttävät sijaintia"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Anna tunnuslause näiden lohkolaitteiden varannolle:"
 ],
 "Purpose": [
  null,
  "Tarkoitus"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (raita)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (peili)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (peilien raita)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (omistettu pariteetti)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (hajautettu pariteetti)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (kaksinkertainen hajautettu pariteetti)"
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "RAID level": [
  null,
  "RAID-taso"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  ""
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Reading": [
  null,
  "Luetaan"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Recovering": [
  null,
  "Palautetaan"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Palautetaan MDRAID-laite $target"
 ],
 "Regenerating initrd": [
  null,
  "Luodaan uudelleen initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Liittyvät prosessit ja palvelut lopetetaan väkisin."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Liittyvät prosessit lopetetaan väkisin."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Liittyvät palvelut lopetetaan väkisin."
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Remove $0?": [
  null,
  "Poistetaanko $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Poista Tang-avainpalvelin?"
 ],
 "Remove device": [
  null,
  "Poista laite"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Poista tunnuslause avainpaikasta $0?"
 ],
 "Remove passphrase?": [
  null,
  "Poista tunnuslause?"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "$Target poistetaan MDRAID-laitteesta"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Salasanan poistaminen ilman toisen salasanan vahvistamista saattaa estää lukituksen avaamisen tai avaimen hallinnan, jos muut salasanat unohdetaan tai menetetään."
 ],
 "Removing physical volume from $target": [
  null,
  "Fyysinen taltio poistetaan $Target:sta"
 ],
 "Rename": [
  null,
  "Nimeä uudelleen"
 ],
 "Rename Stratis pool": [
  null,
  "Nimeä uudelleen Stratisvaranto"
 ],
 "Rename filesystem": [
  null,
  "Nimeä uudelleen tiedostojärjestelmä"
 ],
 "Rename logical volume": [
  null,
  "Nimeä uudelleen looginen taltio"
 ],
 "Rename volume group": [
  null,
  "Nimeä uudelleen taltioryhmä"
 ],
 "Renaming $target": [
  null,
  "Nimetään uudelleen $target"
 ],
 "Repair": [
  null,
  ""
 ],
 "Repairing $target": [
  null,
  "Korjataan $target"
 ],
 "Repeat passphrase": [
  null,
  "Toista tunnuslause"
 ],
 "Resizing $target": [
  null,
  "Muutetaan $target kokoa"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Salatun tiedostojärjestelmän koon muuttaminen edellyttää levyn lukituksen avaamista. Anna nykyinen levyn tunnuslause."
 ],
 "Reuse existing encryption": [
  null,
  "Käytä olemassa olevaa salausta uudelleen"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Käytä olemassa olevaa salausta uudelleen ($0)"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Running": [
  null,
  "Käynnissä"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "Levyn $target SMART-itsetesti"
 ],
 "SSH key": [
  null,
  "SSH-avain"
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Säästä tilaa pakkaamalla yksittäisiä lohkoja LZ4:llä"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Säästä tilaa tallentamalla identtiset tietolohkot vain kerran"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Uuden salasanan tallentaminen edellyttää levyn lukituksen avaamista. Anna nykyinen levyn tunnuslause."
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Securely erasing $target": [
  null,
  "Poistaa turvallisesti $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linuxin asetukset ja ongelmanratkaisu"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  ""
 ],
 "Serial number": [
  null,
  "Sarjanumero"
 ],
 "Server": [
  null,
  "Palvelin"
 ],
 "Server address": [
  null,
  "Palvelimen osoite"
 ],
 "Server address cannot be empty.": [
  null,
  "Palvelimen osoite ei voi olla tyhjä."
 ],
 "Server cannot be empty.": [
  null,
  "Palvelin ei voi olla tyhjä."
 ],
 "Server has closed the connection.": [
  null,
  "Palvelin on sulkenut yhteyden."
 ],
 "Service": [
  null,
  "Palvelu"
 ],
 "Services using the location": [
  null,
  "Palvelut, jotka käyttävät sijaintia"
 ],
 "Set": [
  null,
  "Aseta"
 ],
 "Set limit of virtual filesystem size": [
  null,
  ""
 ],
 "Set time": [
  null,
  "Aseta aika"
 ],
 "Setting up loop device $target": [
  null,
  "Silmukkalaitteen $target asettaminen"
 ],
 "Shell script": [
  null,
  "Komentotulkin komentosarja"
 ],
 "Shift+Insert": [
  null,
  "Vaihto + Syöttö"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Shrink": [
  null,
  "Kutista"
 ],
 "Shrink logical volume": [
  null,
  "Kutista looginen taltio"
 ],
 "Shrink volume": [
  null,
  "Kutista taltio"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "Size cannot be negative": [
  null,
  "Koko ei voi olla negatiivinen"
 ],
 "Size cannot be zero": [
  null,
  "Koko ei voi olla nolla"
 ],
 "Size is too large": [
  null,
  "Koko on liian suuri"
 ],
 "Size must be a number": [
  null,
  "Koon tulee olla numero"
 ],
 "Size must be at least $0": [
  null,
  "Koon tulee olla vähintään $0"
 ],
 "Slot $0": [
  null,
  "Paikka $0"
 ],
 "Snapshot": [
  null,
  "Tilannevedos"
 ],
 "Snapshots": [
  null,
  "Tilannevedokset"
 ],
 "Solid State Drive": [
  null,
  ""
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Joidenkin tämän varannon lohkolaitteiden koko on kasvanut varannon luomisen jälkeen. Varantoa voidaan turvallisesti kasvattaa hyödyntämään nyt vapaana olevaa tilaa."
 ],
 "Sorry": [
  null,
  "Pahoittelut"
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Spare": [
  null,
  "Varaosa"
 ],
 "Specific time": [
  null,
  "Tietty aika"
 ],
 "Start": [
  null,
  "Käynnistä"
 ],
 "Start multipath": [
  null,
  "Käynnistä monipolku"
 ],
 "Started": [
  null,
  "Aloitettu"
 ],
 "Starting MDRAID device $target": [
  null,
  "Käynnistetään MDRAID-laite $target"
 ],
 "Starting swapspace $target": [
  null,
  "Aloitetaan sivutustila $target"
 ],
 "State": [
  null,
  "Tila"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "Stop": [
  null,
  "Pysäytä"
 ],
 "Stop and remove": [
  null,
  "Pysäytä ja poista"
 ],
 "Stop and unmount": [
  null,
  "Pysäytä ja irrota"
 ],
 "Stop device": [
  null,
  "Pysäytä laite"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Pysäytetään MDRAID-laite $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Lopetetaan sivutustilan $target"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Tallennustilaa ei voida hallita tässä järjestelmässä."
 ],
 "Storage logs": [
  null,
  "Tallennustilan lokit"
 ],
 "Store passphrase": [
  null,
  "Tallenna tunnuslause"
 ],
 "Stored passphrase": [
  null,
  "Tallennettu tunnuslause"
 ],
 "Stratis block device": [
  null,
  "Stratis-lohkolaite"
 ],
 "Stratis block devices": [
  null,
  "Stratis-lohkolaiteet"
 ],
 "Stratis pool": [
  null,
  "Stratis-varanto"
 ],
 "Striped (RAID 0)": [
  null,
  ""
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  ""
 ],
 "Stripes": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Kopioitu onnistuneesti leikepöydälle!"
 ],
 "Swap": [
  null,
  "Sivutus"
 ],
 "Synchronized": [
  null,
  "Synkronoitu"
 ],
 "Synchronized with $0": [
  null,
  "Synkronoi palvelimen $0 kanssa"
 ],
 "Synchronizing": [
  null,
  "Synkronoidaan"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synkronoidaan MDRAID-laitetta $target"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "Tang keyserver": [
  null,
  "Tang-avainpalvelin"
 ],
 "Target": [
  null,
  "Kohde"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 paketti ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Paketti $0 on asennettava Stratis-varannon luomiseen."
 ],
 "The $0 package must be installed.": [
  null,
  "Paketti $0 on asennettava."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Paketti $0 asennetaan VDO-laitteiden luomiseksi."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID-laite on heikentyneessä tilassa"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Käyttäjän $0:n SSH-avain $1 koneella $2 lisätään käyttäjän $4 tiedostoon $3 koneella $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-avain $0 on käytettävissä koko istunnon ajan ja on käytettävissä myös muille koneille sisäänkirjautumista varten."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu salasanalla, eikä kone salli salasanalla kirjautumista. Anna avaimen $1 salasana."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu. Voit kirjautua sisään joko kirjautumissalasanallasi tai antamalla avaimen $1 salasanan."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Tämän VDO-laitteen luominen ei päättynyt eikä laitetta voida käyttää."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Tällä hetkellä kirjautuneena oleva käyttäjä ei saa nähdä tietoja avaimista."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Levy on avattava ennen alustamista. Anna olemassa oleva tunnuslause."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Tiedostojärjestelmällä ei ole pysyvää liitoskohtaa."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Tiedostojärjestelmä on määritetty asennettavaksi automaattisesti käynnistykseen, mutta sen salauskontin lukitusta ei avata silloin."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Tiedostojärjestelmä on tällä hetkellä liitettynä, mutta sitä ei liitetä seuraavan käynnistyksen jälkeen."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Tiedostojärjestelmä on tällä hetkellä liitettynä hakemistoon $0, mutta se liitetään seuraavan käynnistyksen jälkeen hakemistoon $1."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Tiedostojärjestelmä on tällä hetkellä liitettynä hakemistoon $0, mutta sitä ei liitetä seuraavan käynnistyksen jälkeen."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Tiedostojärjestelmä ei tällä hetkellä ole liitettynä, mutta se liitetään seuraavan käynnistyksen jälkeen."
 ],
 "The filesystem is not mounted.": [
  null,
  "Tiedostojärjestelmä ei ole liitettynä."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Tiedostojärjestelmän lukitus avataan ja se liitetään järjestelmään seuraavassa käynnistyksessä. Tämä saattaa edellyttää salasanan syöttämistä."
 ],
 "The initrd must be regenerated.": [
  null,
  "Initrd on luotava uudelleen."
 ],
 "The key password can not be empty": [
  null,
  "Avaimen salasana ei voi olla tyhjä"
 ],
 "The key passwords do not match": [
  null,
  "Avainsalasanat eivät täsmää"
 ],
 "The last key slot can not be removed": [
  null,
  "Viimeistä avaimen paikkaa ei voida poistaa"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Listatut prosessit ja palvelut lopetetaan väkisin."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Listatut palvelut lopetetaan väkisin."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Listatut palvelut lopetetaan väkisin."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Sisäänkirjautunut käyttäjä ei saa tarkastella järjestelmän muutoksia"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Liitoskohta $0 on näiden prosessien käytössä:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Liitoskohta $0 on näiden palveluiden käytössä:"
 ],
 "The password can not be empty": [
  null,
  "Salasana ei voi olla tyhjä"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Tuloksena oleva sormenjälki sopii jakaa julkisilla menetelmillä, mukaan lukien sähköposti."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Palvelin kieltäytyi tunnistautumista käyttäen mitään tuetuista tavoista."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Järjestelmä ei tällä hetkellä tue tiedostojärjestelmän lukituksen avaamista Tang-avainpalvelimella käynnistyksen aikana."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Järjestelmä ei tällä hetkellä tue root-tiedostojärjestelmän lukituksen avaamista Tang-avainpalvelimella."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Järjestelmässä on laitteita, joilla on useita polkuja, mutta monitiepalvelu ei ole käynnissä."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  ""
 ],
 "These additional steps are necessary:": [
  null,
  "Nämä lisävaiheet ovat välttämättömiä:"
 ],
 "These changes will be made:": [
  null,
  "Nämä muutokset tullaan tekemään:"
 ],
 "Thin logical volume": [
  null,
  "Ohut looginen taltio"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Tämä NFS-liitos on käytössä ja vain sen valintoja on mahdollista muokata."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Tämä VDO-laite ei käytä kaikkia sen tukilaitetta."
 ],
 "This device is currently in use.": [
  null,
  "Tämä laite on tällä hetkellä käytössä."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Tämä avainpalvelin on ainoa tapa avata varannon lukitus, eikä sitä voi poistaa."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  ""
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Sisältö ei käytä tätä loogista taltiota kokonaan."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Tämä salalause on ainoa tapa avata varannon lukitus, eikä sitä voi poistaa."
 ],
 "This pool is in a degraded state.": [
  null,
  "Varanto on heikentyneessä tilassa."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tämä työkalu asettaa SELinux-käytännön ja auttaa käytäntörikkeiden ymmärtämisessä ja ratkaisemisessa."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tämä työkalu luo arkiston konfiguraatio- ja diagnostiikkatiedoista käynnissä olevasta järjestelmästä. Arkisto voidaan tallentaa paikallisesti tai keskitetysti tallennus- tai seurantatarkoituksiin tai se voidaan lähettää teknisen tuen edustajille, kehittäjille tai järjestelmänvalvojille auttamaan teknisten vikojen etsinnässä ja virheenkorjauksessa."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tämä työkalu hallinnoi paikallista tallennustilaa, kuten tiedostojärjestelmiä, LVM2-taltioryhmiä ja NFS-liitoksia."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tämä työkalu hallitsee verkkoyhteyksiä, kuten sidoksia, siltoja, ryhmiä, VLAN-verkkoja ja palomuureja NetworkManagerin ja Firewalld:n avulla. NetworkManager ei ole yhteensopiva Ubuntun oletusarvoisten systemd-networkd- ja Debianin ifupdown-komentosarjojen kanssa."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  ""
 ],
 "Tier": [
  null,
  "Kerros"
 ],
 "Time zone": [
  null,
  "Aikavyöhyke"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Tarkista koneen avaimen sormenjälki varmistaaksesi, että haitallinen kolmas osapuoli ei sieppaa yhteyttä:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Vahvistaaksesi sormenjäljen, suorita seuraava koneella $0 istuessasi fyysisesti koneen ääressä tai luotettavan verkon kautta:"
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Too much data": [
  null,
  "Liian paljon dataa"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Trust key": [
  null,
  "Luottamusavain"
 ],
 "Trying to synchronize with $0": [
  null,
  "Yritetään synkronoida palvelimen $0 kanssa"
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  ""
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  ""
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Ei voida kirjautua sisään koneelle $0. Kone ei hyväksy salasanakirjautumista tai mitään SSH-avaimistasi."
 ],
 "Unable to reach server": [
  null,
  "Palvelimeen ei saada yhteyttä"
 ],
 "Unable to remove mount": [
  null,
  "Liitosta ei voi poistaa"
 ],
 "Unable to unmount filesystem": [
  null,
  "Tiedostojärjestelmää ei voi irrottaa"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Odottamaton PackageKit-virhe paketin $0 asennuksen aikana: $1"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Unknown ($0)": [
  null,
  "Tuntematon ($0)"
 ],
 "Unknown host name": [
  null,
  "Tuntematon konenimi"
 ],
 "Unknown type": [
  null,
  "Tuntematon tyyppi"
 ],
 "Unlock": [
  null,
  "Avaa"
 ],
 "Unlock automatically on boot": [
  null,
  "Avaa lukitus automaattisesti käynnistyksessä"
 ],
 "Unlock before resizing": [
  null,
  ""
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Avaa salattu Stratis-varanto"
 ],
 "Unlocking $target": [
  null,
  "Avataan $target"
 ],
 "Unlocking disk": [
  null,
  "Avataan levyn lukitus"
 ],
 "Unmount": [
  null,
  "Irroita"
 ],
 "Unmount filesystem $0": [
  null,
  "Irrota tiedostojärjestelmä $0"
 ],
 "Unmount now": [
  null,
  "Irrota nyt"
 ],
 "Unmounting $target": [
  null,
  "Irrotetaan $target"
 ],
 "Unrecognized data": [
  null,
  "Tunnistamaton data"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Tunnistamatonta dataa ei voi pienentää täällä"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Tunnistamatonta dataa ei voi pienentää täällä."
 ],
 "Untrusted host": [
  null,
  "Epäluotettava kone"
 ],
 "Usage": [
  null,
  "Käyttö"
 ],
 "Usage of $0": [
  null,
  "$0 käyttö"
 ],
 "Use": [
  null,
  "Käytä"
 ],
 "Use compression": [
  null,
  "Käytä pakkausta"
 ],
 "Use deduplication": [
  null,
  "Käytä päällekkäisyyden poistoa"
 ],
 "Used": [
  null,
  "Käytetty"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Hyödyllinen liitoksille, jotka ovat valinnaisia tai tarvitsevat vuorovaikutusta (kuten tunnuslauseita)"
 ],
 "User": [
  null,
  "Käyttäjä"
 ],
 "Username": [
  null,
  "Käyttäjätunnus"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-taustalaitteita ei voi tehdä pienemmiksi"
 ],
 "VDO device $0": [
  null,
  "VDO-laite $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-tiedostojärjestelmän taltio (pakkaus/kopioiden poisto)"
 ],
 "Vendor": [
  null,
  "Toimittaja"
 ],
 "Verify fingerprint": [
  null,
  "Vahvista sormenjälki"
 ],
 "Verify key": [
  null,
  "Vahvista avain"
 ],
 "Very securely erasing $target": [
  null,
  "Poistetaan hyvin turvallisesti $target"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "View automation script": [
  null,
  "Näytä automaatio-komentosarja"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  ""
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Volume group": [
  null,
  "Taltioryhmä"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Taltion koko on $0. Sisällön koko on $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Web Console for Linux servers": [
  null,
  "Verkkokonsoli Linux-palvelimille"
 ],
 "World wide name": [
  null,
  "Maailmanlaajuinen nimi"
 ],
 "Write-mostly": [
  null,
  "Kirjoitus-enimmäkseen"
 ],
 "Writing": [
  null,
  "Kirjoitetaan"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Yhdistät koneeseen $0 ensimmäistä kertaa."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Selaimesi ei salli liittämistä pikavalikosta. Voit käyttää Vaihto+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Istuntosi on päätetty."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Istuntosi on vahventunut. Ole hyvä ja kirjaudu uudelleen sisään."
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "after network": [
  null,
  "verkon jälkeen"
 ],
 "backing device for VDO device": [
  null,
  "taustalaite VDO-laitteelle"
 ],
 "btrfs subvolume": [
  null,
  "Btrfs-alataltio"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  ""
 ],
 "btrfs volume": [
  null,
  "Btrfs-taltio"
 ],
 "cache": [
  null,
  "välimuisti"
 ],
 "data": [
  null,
  "tiedot"
 ],
 "deactivate": [
  null,
  "Deaktivoi"
 ],
 "delete": [
  null,
  "Poista"
 ],
 "device of btrfs volume": [
  null,
  ""
 ],
 "edit": [
  null,
  "muokkaa"
 ],
 "encrypted": [
  null,
  "salattu"
 ],
 "format": [
  null,
  "alusta"
 ],
 "grow": [
  null,
  "kasvata"
 ],
 "ignore failure": [
  null,
  "jätä virhe huomiotta"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "initialize": [
  null,
  "alusta"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "member of MDRAID device": [
  null,
  "MDRAID-laitteen jäsen"
 ],
 "member of Stratis pool": [
  null,
  "Stratis-varannon jäsen"
 ],
 "mount": [
  null,
  "liitos"
 ],
 "never mount at boot": [
  null,
  "Älä koskaan liitä käynnistyksen yhteydessä"
 ],
 "none": [
  null,
  "Ei mitään"
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2-taltioryhmän fyysinen taltio"
 ],
 "read only": [
  null,
  "luku-vain"
 ],
 "remove from LVM2": [
  null,
  "poista LVM2:sta"
 ],
 "remove from MDRAID": [
  null,
  "poista MDRAID:ista"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "shrink": [
  null,
  "kutista"
 ],
 "snapshot": [
  null,
  "tilannevedos"
 ],
 "stop": [
  null,
  "pysäytä"
 ],
 "stop boot on failure": [
  null,
  "pysäyttä käynnistyksen epäonnistuessa"
 ],
 "stopped": [
  null,
  "pysäytetty"
 ],
 "unknown target": [
  null,
  "tuntematon kohde"
 ],
 "unmount": [
  null,
  "irrota"
 ],
 "unpartitioned space on $0": [
  null,
  "osioimaton tila levyllä $0"
 ],
 "yes": [
  null,
  "kyllä"
 ],
 "format-bytes\u0004bytes": [
  null,
  "tavua"
 ]
});
