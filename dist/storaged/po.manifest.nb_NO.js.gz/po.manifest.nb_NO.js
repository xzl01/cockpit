cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Managing LVMs": [
  null,
  "Administrere LVMer"
 ],
 "Managing NFS mounts": [
  null,
  "Administrere NFS-monteringer"
 ],
 "Managing RAIDs": [
  null,
  "Administrere RAIDer"
 ],
 "Managing VDOs": [
  null,
  "Administrere VDOer"
 ],
 "Managing partitions": [
  null,
  "Administrere partisjoner"
 ],
 "Managing physical drives": [
  null,
  "Administrere fysiske disker"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Using LUKS encryption": [
  null,
  "Bruker LUKS-kryptering"
 ],
 "Using Tang server": [
  null,
  "Bruker Tang-server"
 ],
 "disk": [
  null,
  "disk"
 ],
 "drive": [
  null,
  "dIsk"
 ],
 "encryption": [
  null,
  "kryptering"
 ],
 "filesystem": [
  null,
  "filsystem"
 ],
 "format": [
  null,
  "format"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "monter"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "partisjon"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "unmount"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volum"
 ]
});
