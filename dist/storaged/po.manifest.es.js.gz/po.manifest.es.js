cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Managing LVMs": [
  null,
  "Gestión de LVMs"
 ],
 "Managing NFS mounts": [
  null,
  "Gestión de montajes NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestión de RAIDs"
 ],
 "Managing VDOs": [
  null,
  "Gestión de VDOs"
 ],
 "Managing partitions": [
  null,
  "Gestión de particiones"
 ],
 "Managing physical drives": [
  null,
  "Gestión de discos físicos"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Using LUKS encryption": [
  null,
  "Usar cifrado LUKS"
 ],
 "Using Tang server": [
  null,
  "Usar un servidor Tang"
 ],
 "disk": [
  null,
  "disco"
 ],
 "drive": [
  null,
  "disco"
 ],
 "encryption": [
  null,
  "cifrado"
 ],
 "filesystem": [
  null,
  "sistema de archivos"
 ],
 "format": [
  null,
  "formato"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "mount"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "partición"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "desmontar"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volumen"
 ]
});
