cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Managing LVMs": [
  null,
  "Správa LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Správa NFS pripojení"
 ],
 "Managing RAIDs": [
  null,
  "Správa RAID polí"
 ],
 "Managing VDOs": [
  null,
  "Správa VDO optimalizátorov"
 ],
 "Managing partitions": [
  null,
  "Správa oddielov"
 ],
 "Managing physical drives": [
  null,
  "Správa fyzických diskov"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Using LUKS encryption": [
  null,
  "S použitím LUKS šifrovania"
 ],
 "Using Tang server": [
  null,
  "S použitím servera Tang"
 ],
 "disk": [
  null,
  "disk"
 ],
 "drive": [
  null,
  "jednotka"
 ],
 "encryption": [
  null,
  "Šifrovanie"
 ],
 "filesystem": [
  null,
  "Súborový systém"
 ],
 "format": [
  null,
  "Formátovať"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "mount"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "oddiel"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "odpojiť"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "zväzok"
 ]
});
