cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Managing LVMs": [
  null,
  "Zarządzanie LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Zarządzanie punktami montowania NFS"
 ],
 "Managing RAIDs": [
  null,
  "Zarządzanie RAID"
 ],
 "Managing VDOs": [
  null,
  "Zarządzanie VDO"
 ],
 "Managing partitions": [
  null,
  "Zarządzanie partycjami"
 ],
 "Managing physical drives": [
  null,
  "Zarządzanie napędami fizycznymi"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Using LUKS encryption": [
  null,
  "Używanie szyfrowania LUKS"
 ],
 "Using Tang server": [
  null,
  "Używanie serwera Tang"
 ],
 "disk": [
  null,
  "dysk"
 ],
 "drive": [
  null,
  "napęd"
 ],
 "encryption": [
  null,
  "szyfrowanie"
 ],
 "filesystem": [
  null,
  "system plików"
 ],
 "format": [
  null,
  "format"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iSCSI"
 ],
 "luks": [
  null,
  "LUKS"
 ],
 "lvm2": [
  null,
  "LVM2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "montowanie"
 ],
 "nbde": [
  null,
  "NBDE"
 ],
 "nfs": [
  null,
  "NFS"
 ],
 "partition": [
  null,
  "partycja"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "tang": [
  null,
  "Tang"
 ],
 "udisks": [
  null,
  "UDisks"
 ],
 "unmount": [
  null,
  "odmontowanie"
 ],
 "vdo": [
  null,
  "VDO"
 ],
 "volume": [
  null,
  "wolumin"
 ]
});
