cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Managing LVMs": [
  null,
  "LVM-ის მართვა"
 ],
 "Managing NFS mounts": [
  null,
  "NFS მიმაგრებების მართვა"
 ],
 "Managing RAIDs": [
  null,
  "RAID-ის მართვა"
 ],
 "Managing VDOs": [
  null,
  "VDO-ის მართვა"
 ],
 "Managing partitions": [
  null,
  "დამაყოფების მართვა"
 ],
 "Managing physical drives": [
  null,
  "ფიზიკური დისკების მართვა"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS დაშიფვრის გამოყენებით"
 ],
 "Using Tang server": [
  null,
  "Tang სერვერის გამოყენებით"
 ],
 "disk": [
  null,
  "დისკი"
 ],
 "drive": [
  null,
  "დისკი"
 ],
 "encryption": [
  null,
  "დაშიფვრა"
 ],
 "filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "format": [
  null,
  "ფორმატი"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "მიმაგრება"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "განყოფილება"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "მოძრობა"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "საცავი"
 ]
});
