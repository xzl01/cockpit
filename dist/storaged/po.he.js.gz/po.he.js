cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 chunk size": [
  null,
  "גודל נתח $0"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 נתונים + $1 תוספת מנוצלים מתוך $2 ($3)"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 disk is missing": [
  null,
  "כונן אחד חסר",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים"
 ],
 "$0 disks": [
  null,
  "$0 כוננים"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 is in use": [
  null,
  "$0 בשימוש"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 slot remains": [
  null,
  "נותרה משבצת אחת",
  "נותרו $0 משבצות",
  "נותרו $0 משבצות",
  "נותרו $0 משבצות"
 ],
 "$0 synchronized": [
  null,
  "$0 מסונכרן"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 בשימוש מתוך $1 ($2 נחסכו)"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$name (from $host)": [
  null,
  "$name (מ־$host)"
 ],
 "(recommended)": [
  null,
  "(מומלץ)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "כבר קיימת מערכת קבצים בשם הזה במאגר הזה."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "A pool with this name exists already.": [
  null,
  "כבר קיים מאגר בשם הזה."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "לא ניתן לשנות שם לקבוצת כרכים שחסרים לה כרכים פיזיים."
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Action": [
  null,
  "פעולה"
 ],
 "Actions": [
  null,
  "פעולות"
 ],
 "Activate": [
  null,
  "הפעלה"
 ],
 "Activate before resizing": [
  null,
  ""
 ],
 "Activating $target": [
  null,
  "$target מופעל"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "הוספת הצפנת כונן תלוית רשת"
 ],
 "Add Tang keyserver": [
  null,
  "הוספת שרת מפתחות Tang"
 ],
 "Add a bitmap": [
  null,
  "הוספת מפת סיביות"
 ],
 "Add block devices": [
  null,
  "הוספת התקני בלוק"
 ],
 "Add disk": [
  null,
  "הוספת כונן"
 ],
 "Add disks": [
  null,
  "הוספת כוננים"
 ],
 "Add iSCSI portal": [
  null,
  "הוספת שער גישה ל־iSCSI"
 ],
 "Add key": [
  null,
  "הוספת מפתח"
 ],
 "Add keyserver": [
  null,
  "הוספת שרת מפתחות"
 ],
 "Add passphrase": [
  null,
  "הוספת מילת צופן"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "„$0” נוספה לאפשרויות הצפנה"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "„$0” נוספת לאפשרויות מערכת הקבצים"
 ],
 "Adding key": [
  null,
  "נוסף מפתח"
 ],
 "Adding physical volume to $target": [
  null,
  "הוספת כרך פיזי אל $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "rd.neednet=1 מתווספת לשורת הפקודה של הליבה"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Address": [
  null,
  "כתובת"
 ],
 "Address cannot be empty": [
  null,
  "הכתובת לא יכולה להיות ריקה"
 ],
 "Address is not a valid URL": [
  null,
  "הכתובת אינה תקנית"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Allow overprovisioning": [
  null,
  ""
 ],
 "An additional $0 must be selected": [
  null,
  "חובה לבחור ב־$0 נוסף"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "מתאים לעיגונים מהותיים כגון ‎/var"
 ],
 "At boot": [
  null,
  "עם העלייה"
 ],
 "At least $0 disk is needed.": [
  null,
  "נדרש כונן אחד לפחות.",
  "נדרשים $0 כוננים לפחות.",
  "נדרשים $0 כוננים לפחות.",
  "נדרשים $0 כוננים לפחות."
 ],
 "At least one block device is needed.": [
  null,
  "נדרש התקן בלוק אחד לפחות."
 ],
 "At least one disk is needed.": [
  null,
  "נדרש כונן אחד לפחות."
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ],
 "Authentication required": [
  null,
  "נדרש אימות"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "Available targets on $0": [
  null,
  "יעדים זמינים על $0"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Block device": [
  null,
  "התקן בלוק"
 ],
 "Block device for filesystems": [
  null,
  "התקן בלוק למערכות הפעלה"
 ],
 "Block devices": [
  null,
  "התקני בלוק"
 ],
 "Blocked": [
  null,
  "חסום"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "העלייה נכשלת אם מערכת הקבצים לא מעוגנת, ובכך נמנעת גישה מרחוק"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "העלייה עדיין תצליח כאשר מערכת הקבצים לא מתעגנת"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "Cache": [
  null,
  "מכלא"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "Capacity": [
  null,
  "קיבולת"
 ],
 "Category": [
  null,
  ""
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Change iSCSI initiator name": [
  null,
  "החלפת שם מאתחל ה־iSCSI"
 ],
 "Change passphrase": [
  null,
  "החלפת מילת צופן"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  ""
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "כדאי לבדוק שגיבוב ה־SHA-256 או SHA-1 מהפקודה תואם לחלונית הזאת."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "בדיקת גיבוב המפתח מול שרת ה־Tang."
 ],
 "Checking $target": [
  null,
  "$target בבדיקה"
 ],
 "Checking for $0 package": [
  null,
  "מתבצע איתור של החבילה $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "מתבצעת בדיקה לאיתור תמיכה ב־NBDE ב־initrd"
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "Chunk size": [
  null,
  "גודל נתח"
 ],
 "Cleaning up for $target": [
  null,
  "מתבצע ניקוי לכבוד $target"
 ],
 "Cleartext device": [
  null,
  "התקן טקסט גלוי"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Command": [
  null,
  "פקודה"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "תואם לכל המערכות וההתקנים (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "תואם למערכות ולכוננים חדישים > 2 ט״ב (GPT)"
 ],
 "Compression": [
  null,
  "דחיסה"
 ],
 "Confirm": [
  null,
  "אישור"
 ],
 "Confirm deletion of $0": [
  null,
  "אישור המחיקה של $0"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "אישור הסרה עם מילת צופן חלופית"
 ],
 "Confirm stopping of $0": [
  null,
  "אישור עצירת $0"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Create": [
  null,
  "יצירה"
 ],
 "Create LVM2 volume group": [
  null,
  "יצירת קבוצת כרכים מסוג LVM2"
 ],
 "Create RAID device": [
  null,
  "יצירת התקן RAID"
 ],
 "Create Stratis pool": [
  null,
  "יצירת מאגר Stratis"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "יצירת תמונת מצב של מערכת הקבצים $0"
 ],
 "Create and mount": [
  null,
  "יצירה ועיגון"
 ],
 "Create filesystem": [
  null,
  "יצירת מערכת קבצים"
 ],
 "Create logical volume": [
  null,
  "יצירת כרך לוגי"
 ],
 "Create new filesystem": [
  null,
  "יצירת מערכת קבצים חדשה"
 ],
 "Create new logical volume": [
  null,
  "יצירת כרך לוגי חדש"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Create only": [
  null,
  "יצירה בלבד"
 ],
 "Create partition": [
  null,
  "יצירת מחיצה"
 ],
 "Create partition on $0": [
  null,
  "יצירת מחיצה על $0"
 ],
 "Create partition table": [
  null,
  "יצירת טבלת מחיצות"
 ],
 "Create snapshot": [
  null,
  "יצירת תמונת מצב"
 ],
 "Create snapshot and mount": [
  null,
  "יצירת תמונת מצב ועיגון"
 ],
 "Create snapshot only": [
  null,
  "יצירת תמונת מצב בלבד"
 ],
 "Create thin volume": [
  null,
  "יצירת כרך רזה"
 ],
 "Create volume group": [
  null,
  "יצירת קבוצת כרכים"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "קבוצת הכרכים $target מסוג LVM2 נוצרת"
 ],
 "Creating VDO device": [
  null,
  "נוצר התקן VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "נוצרת מערכת קבצים על $target"
 ],
 "Creating logical volume $target": [
  null,
  "נוצר כרך לוגי על $target"
 ],
 "Creating partition $target": [
  null,
  "נוצרת מחיצה $target"
 ],
 "Creating snapshot of $target": [
  null,
  "נוצרת תמונת מצב של $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "בשימוש כרגע"
 ],
 "Custom mount options": [
  null,
  "אפשרויות עיגון מותאמות אישית"
 ],
 "Data": [
  null,
  "נתונים"
 ],
 "Data used": [
  null,
  "נתונים בשימוש"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "הנתונים יאוחסנו כשני עותקים וגם באופן מתחלף בכרכים הפיזיים הנבחרים כדי לשבר את האמינות ואת הביצועים. יש לבחור בארבעה כרכים לפחות."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "הנתונים יאוחסנו כשני עותקים ויותר בכרכים הפיזיים הנבחרים, כדי לשפר את האמינות. יש לבחור בשני כרכים לפחות."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "הנתונים יאוחסנו בכרכים הפיזיים הנבחרים באופן מתחלף כדי לשפר את הביצועים. יש לבחור לפחות שני כרכים."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "הנתונים יאוחסנו בכרכים הפיזיים הנבחרים כדי שאם אחד מהם יושבת לא תהיה השפעה על המידע. יש לבחור לפחות שלושה כרכים."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  ""
 ],
 "Deactivate": [
  null,
  "השבתה"
 ],
 "Deactivating $target": [
  null,
  "מתבצעת השבתה של $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "פיזור+זוגיות בכונן ייעודי (RAID 4)"
 ],
 "Deduplication": [
  null,
  "הסרת כפילות"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Delete group": [
  null,
  "מחיקת קבוצה"
 ],
 "Deleting $target": [
  null,
  "$target נמחק"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "קבוצת הכרכים $target מסוג LVM2 נמחקת"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "מחיקת מאגר Stratis תמחק את כל הנתונים שהוא מכיל."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "מחיקת מערכת קבצים תמחק את כל הנתונים שבה."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "מחיקת כרך לוגי תמחק את כל הנתונים שבו."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "מחיקת מחיצה תמחק את כל הנתונים שבה."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "מחיקה תמחק את כל הנתונים של התקן ה־VDO."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "מחיקה מוחקת את כל הנתונים בקבוצת כרכים."
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "Device": [
  null,
  "התקן"
 ],
 "Device file": [
  null,
  "קובץ התקן"
 ],
 "Device is read-only": [
  null,
  "ההתקן הוא לקריאה בלבד"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Disconnect": [
  null,
  "ניתוק"
 ],
 "Disk is OK": [
  null,
  "הכונן תקין"
 ],
 "Disk is failing": [
  null,
  "הכונן נכשל"
 ],
 "Disk passphrase": [
  null,
  "מילת צופן לכונן"
 ],
 "Disks": [
  null,
  "כוננים"
 ],
 "Dismiss": [
  null,
  "התעלמות"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "פיזור+זוגיות מפוזרת (RAID 5)"
 ],
 "Do not mount": [
  null,
  "לא לעגן"
 ],
 "Do not mount automatically on boot": [
  null,
  "לא לעגן אוטומטית עם העלייה"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "Does not mount during boot": [
  null,
  "לא תעוגן עם העלייה"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "פיזור+קוד ריד-סולומון (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Drive": [
  null,
  "כונן"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Edit Tang keyserver": [
  null,
  "עריכת שרת מפתחות Tang"
 ],
 "Editing a key requires a free slot": [
  null,
  "עריכת מפתח דורשת משבצת פנויה"
 ],
 "Ejecting $target": [
  null,
  "$target נשלף כעת"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Emptying $target": [
  null,
  "$target מתרוקן"
 ],
 "Enabling $0": [
  null,
  "$0 מופעל"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "הצפנת הנתונים עם שרת מפתחות Tang"
 ],
 "Encrypt data with a passphrase": [
  null,
  "הצפנת נתונים עם מילת צופן"
 ],
 "Encrypted $0": [
  null,
  "$0 מוצפן"
 ],
 "Encrypted logical volume of $0": [
  null,
  "כרך לוגי מוצפן בגודל $0"
 ],
 "Encrypted partition of $0": [
  null,
  "מחיצה מוצפנת בגודל $0"
 ],
 "Encryption": [
  null,
  "הצפנה"
 ],
 "Encryption options": [
  null,
  "אפשרויות הצפנה"
 ],
 "Encryption type": [
  null,
  "סוג הצפנה"
 ],
 "Erasing $target": [
  null,
  "$target נמחק"
 ],
 "Error": [
  null,
  "שגיאה"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "שגיאה בהתקנת $0:‏ PackageKit אינו מותקן"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "יש לבחור בדיוק $0 כרכים פיזיים"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "יש לבחור בדיוק ב־$0 כרכים פיזיים, אחד לכל יחידת פיזור של הכרך הלוגי."
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Extended partition": [
  null,
  "מחיצה מורחבת"
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Filesystem": [
  null,
  "מערכת קבצים"
 ],
 "Filesystem is locked": [
  null,
  "מערכת הקבצים נעולה"
 ],
 "Filesystem name": [
  null,
  "שם מערכת קבצים"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "מערכות הקבצים כבר מעוגנות תחת נקודת העיגון הזאת."
 ],
 "Fix NBDE support": [
  null,
  "תיקון תמיכה ב־NBDE"
 ],
 "Format": [
  null,
  "פרמוט"
 ],
 "Format $0": [
  null,
  "פרמוט $0"
 ],
 "Format and mount": [
  null,
  "פרמוט ועגינה"
 ],
 "Format only": [
  null,
  "פרמוט בלבד"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "פרמוט ימחק את כל הנתונים בהתקן אחסון."
 ],
 "Free space": [
  null,
  "מקום פנוי"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "Grow": [
  null,
  "הגדלה"
 ],
 "Grow content": [
  null,
  "הגדלת התוכן"
 ],
 "Grow logical size of $0": [
  null,
  "להגדיל לגודל לוגי של $0"
 ],
 "Grow logical volume": [
  null,
  "הגדלת הכרך הלוגי"
 ],
 "Grow partition": [
  null,
  "הגדלת מחיצה"
 ],
 "Grow the pool to take all space": [
  null,
  "להגדיל את המאגר על חשבון כל המקום הפנוי"
 ],
 "Grow to take all space": [
  null,
  "להגדיל על חשבון כל המקום הפנוי"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Hard Disk Drive": [
  null,
  ""
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "How to check": [
  null,
  "איך לבדוק"
 ],
 "I confirm I want to lose this data forever": [
  null,
  ""
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  ""
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "Important data might be deleted:": [
  null,
  ""
 ],
 "In a terminal, run: ": [
  null,
  "במסוף יש להריץ: "
 ],
 "In sync": [
  null,
  "בסנכרון"
 ],
 "Inconsistent filesystem mount": [
  null,
  "עיגון בלתי אחיד של מערכת קבצים"
 ],
 "Index memory": [
  null,
  "זיכרון אינדקס"
 ],
 "Initialize": [
  null,
  "אתחול"
 ],
 "Initialize disk $0": [
  null,
  "אתחול הכונן $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "אתחול מוחק את כל הנתונים בכונן."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Install NFS support": [
  null,
  "התקנת תמיכה ב־NFS"
 ],
 "Install Stratis support": [
  null,
  "התקנת תמיכה ב־Stratis"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Installing $0 would remove $1.": [
  null,
  "התקנת $0 תסיר את $1."
 ],
 "Installing packages": [
  null,
  "חבילות מותקנות"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "Invalid username or password": [
  null,
  "שם משתמש או סיסמה שגויים"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Jobs": [
  null,
  "משימות"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "משבצות מפתח עם סוגים בלתי מוכרים אינן ניתנות לעריכה כאן"
 ],
 "Key source": [
  null,
  "מקור מפתח"
 ],
 "Keys": [
  null,
  "מפתחות"
 ],
 "Keyserver": [
  null,
  "שרת מפתחות"
 ],
 "Keyserver address": [
  null,
  "כתובת שרת מפתחות"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "הסרת שרת מפתחות עלולה למנוע את שחרור $0."
 ],
 "LVM2 volume group": [
  null,
  "קבוצת כרכים ב־LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "קבוצת כרכים LVM2‏ $0"
 ],
 "Label": [
  null,
  ""
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Last modified: $0": [
  null,
  "שינוי אחרון: $0"
 ],
 "Layout": [
  null,
  "פריסה"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "Linear": [
  null,
  "קווי"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "Loading...": [
  null,
  "בטעינה…"
 ],
 "Local mount point": [
  null,
  "נקודת עגינה מקומית"
 ],
 "Location": [
  null,
  "מיקום"
 ],
 "Lock": [
  null,
  "נעילה"
 ],
 "Locking $target": [
  null,
  "$target ננעל"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "Logical": [
  null,
  "לוגי"
 ],
 "Logical size": [
  null,
  "גודל לוגי"
 ],
 "Logical volume": [
  null,
  "כרך לוגי"
 ],
 "Logical volume (snapshot)": [
  null,
  "כרך לוגי (תמונת מצב)"
 ],
 "Logical volume of $0": [
  null,
  "כרך לוגי בגודל $0"
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Marking $target as faulty": [
  null,
  "$target מסומן כתקול"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Metadata used": [
  null,
  "נתוני על בשימוש"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Mirrored (RAID 1)": [
  null,
  ""
 ],
 "Model": [
  null,
  "דגם"
 ],
 "Modifying $target": [
  null,
  "מתבצע שינוי ב־$target"
 ],
 "Mount": [
  null,
  "עיגון"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "לעגן לאחר שהרשת זמינה, להתעלם מכשל"
 ],
 "Mount also automatically on boot": [
  null,
  "לעגן אוטומטית גם עם העלייה"
 ],
 "Mount at boot": [
  null,
  "לעגן בעלייה"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "לעגן אוטומטית אל $0 בזמן העלייה"
 ],
 "Mount before services start": [
  null,
  "לעגן לפני הפעלת השירותים"
 ],
 "Mount configuration": [
  null,
  "הגדרות עיגון"
 ],
 "Mount filesystem": [
  null,
  "עיגון מערכת קבצים"
 ],
 "Mount now": [
  null,
  "לעגן כעת"
 ],
 "Mount on $0 now": [
  null,
  "לעגן אל $0 כעת"
 ],
 "Mount options": [
  null,
  "אפשרויות עיגון"
 ],
 "Mount point": [
  null,
  "נקודת עיגון"
 ],
 "Mount point cannot be empty": [
  null,
  "נקודת העיגון לא יכולה להיות ריקה"
 ],
 "Mount point cannot be empty.": [
  null,
  "נקודת העיגון לא יכולה להיות ריקה."
 ],
 "Mount point is already used for $0": [
  null,
  "נקודת העיגון כבר משמשת לטובת $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "נקודת העיגון חייבת להתחיל ב־„/”."
 ],
 "Mount read only": [
  null,
  "עיגון לקריאה בלבד"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "לעגן בלי להמתין, התעלמות מכשל"
 ],
 "Mounting $target": [
  null,
  "מתבצע עיגון של $target"
 ],
 "Mounts before services start": [
  null,
  "מעוגן לפני הפעלת השירותים"
 ],
 "Mounts in parallel with services": [
  null,
  "מעוגן במקביל לשירותים"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "מעוגן במקביל לשירותים, אבל אחרי שהרשת זמינה"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "NFS mount": [
  null,
  "עיגון NFS"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Name can not be empty.": [
  null,
  "השם לא יכול להיות ריק."
 ],
 "Name cannot be empty.": [
  null,
  "השם לא יכול להיות ריק."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "השם לא יכול להיות יותר מ־$0 בתים"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "השם לא יכול להיות ארוך מ־$0 תווים"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "השם לא יכול להיות ארוך מ־127 תווים."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "השם לא יכול להכיל את התו ‚$0’."
 ],
 "Name cannot contain whitespace.": [
  null,
  "השם לא יכול להכיל רווח."
 ],
 "Need a spare disk": [
  null,
  ""
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "New NFS mount": [
  null,
  "עיגון NFS חדש"
 ],
 "New passphrase": [
  null,
  "מילת צופן חדשה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "Next": [
  null,
  "הבא"
 ],
 "No available slots": [
  null,
  "אין משבצות פנויות"
 ],
 "No block devices are available.": [
  null,
  "אין התקני בלוק זמינים."
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "No disks are available.": [
  null,
  "אין כוננים זמינים."
 ],
 "No encryption": [
  null,
  "אין הצפנה"
 ],
 "No filesystem": [
  null,
  "אין מערכת קבצים"
 ],
 "No filesystems": [
  null,
  "אין מערכות קבצים"
 ],
 "No free key slots": [
  null,
  "אין משבצות מפתח פנויות"
 ],
 "No free space": [
  null,
  "אין מקום פנוי"
 ],
 "No keys added": [
  null,
  "לא נוספו מפתחות"
 ],
 "No logical volumes": [
  null,
  "אין כרכים לוגיים"
 ],
 "No media inserted": [
  null,
  "לא הוכנס אמצעי מדיה"
 ],
 "No partitioning": [
  null,
  "אין חלוקה למחיצות"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Not enough space": [
  null,
  "אין מספיק מקום"
 ],
 "Not found": [
  null,
  "לא נמצא"
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Not running": [
  null,
  "לא פועל"
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Old passphrase": [
  null,
  "מילת צופן ישנה"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Only $0 of $1 are used.": [
  null,
  "רק $0 מתוך $1 מנוצלים."
 ],
 "Operation '$operation' on $target": [
  null,
  "המשימה ‚$operation’ על $target"
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Other": [
  null,
  "אחר"
 ],
 "Overwrite": [
  null,
  "שכתוב"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "שכתוב על נתונים קיימים באפסים (אטי יותר)"
 ],
 "PID": [
  null,
  "מזהה תהליך"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "Partition": [
  null,
  "מחיצה"
 ],
 "Partition of $0": [
  null,
  "מחיצה של $0"
 ],
 "Partitioning": [
  null,
  "חלוקה למחיצות"
 ],
 "Partitions": [
  null,
  "מחיצות"
 ],
 "Passphrase": [
  null,
  "מילת צופן"
 ],
 "Passphrase can not be empty": [
  null,
  "מילת הצופן לא יכולה להיות ריקה"
 ],
 "Passphrase cannot be empty": [
  null,
  "מילת הצופן לא יכולה להיות ריקה"
 ],
 "Passphrase from any other key slot": [
  null,
  "מילת צופן מכל משבצת מפתחות אחרת"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "הסרת מילת הצופן עשויה למנוע את השחרור של $0."
 ],
 "Passphrases do not match": [
  null,
  "מילות הצופן אינן תואמות"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Path on server": [
  null,
  "נתיב בשרת"
 ],
 "Path on server cannot be empty.": [
  null,
  "הנתיב בשרת לא יכול להיות ריק."
 ],
 "Path on server must start with \"/\".": [
  null,
  "הנתיב בשרת חייב להתחיל ב־„/”."
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "Permanently delete $0?": [
  null,
  "למחוק את $0 לצמיתות?"
 ],
 "Physical": [
  null,
  "פיזי"
 ],
 "Physical Volumes": [
  null,
  "כרכים פיזיים"
 ],
 "Physical volumes": [
  null,
  "כרכים פיזיים"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Please unmount them first.": [
  null,
  ""
 ],
 "Pool for thin logical volumes": [
  null,
  "מאגר לכרכים לוגיים רזים"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "מאגר לכרכים באפסנה צרה"
 ],
 "Port": [
  null,
  "פתחה"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Processes using the location": [
  null,
  "תהליכים שמשתמשים במיקום"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "נא לספק מילת צופן למאגר על התקני בלוק אלו:"
 ],
 "Purpose": [
  null,
  "תכלית"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (פיזור נתונים)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (שכפול)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (פיזור נתונים משוכפלים)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (פיזור עם זוגיות בכונן ייעודי)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (פיזור עם זוגיות מפוזרת)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (פיזור עם קוד ריד-סולומון)"
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "RAID level": [
  null,
  "רמת RAID"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  ""
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Reading": [
  null,
  "מתבצעת קריאה"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Recovering": [
  null,
  "מתבצע שיקום"
 ],
 "Regenerating initrd": [
  null,
  "initrd נוצר מחדש"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "התהליכים והשירותים הקשורים ייעצרו בכוח."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "התהליכים הקשורים ייעצרו בכוח."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "השירותים הקשורים ייעצרו בכוח."
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Remove $0?": [
  null,
  "להסיר את $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "להסיר את שרת המפתחות Tang?"
 ],
 "Remove device": [
  null,
  "הסרת התקן"
 ],
 "Remove missing physical volumes?": [
  null,
  "להסיר את הכרכים הפיזיים החסרים?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "להסיר את מילת הצופן מעל משבצת המפתחות $0?"
 ],
 "Remove passphrase?": [
  null,
  "להסיר מילת צופן?"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "הסרת מילת צופן ללא אישור של מילת צופן אחרת עשוי למנוע שחרור או את ניהול המפתחות במקרה שמילות צופן נוספות נשכחו או שאבדו."
 ],
 "Removing physical volume from $target": [
  null,
  "מתבצעת הסרה של כרך פיזי מתוך $target"
 ],
 "Rename": [
  null,
  "שינוי שם"
 ],
 "Rename Stratis pool": [
  null,
  "שינוי שם למאגר Stratis"
 ],
 "Rename filesystem": [
  null,
  "שינוי שם מערכת קבצים"
 ],
 "Rename logical volume": [
  null,
  "שינוי שם של כרך פיזי"
 ],
 "Rename volume group": [
  null,
  "שינוי שם של קבוצת כרכים"
 ],
 "Renaming $target": [
  null,
  "השם של $target מוחלף"
 ],
 "Repair": [
  null,
  ""
 ],
 "Repairing $target": [
  null,
  "$target מתוקן"
 ],
 "Repeat passphrase": [
  null,
  "חזרה על מילת הצופן"
 ],
 "Resizing $target": [
  null,
  "הגודל של $target משתנה"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "שינוי גודל של מערכת קבצים מוצפנת דורשת את שחרור הכונן. נא לספק את מילת הצופן הנוכחית של הכונן."
 ],
 "Reuse existing encryption": [
  null,
  "שימוש מחדש בהצפנה קיימת"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "שימוש מחדש בהצפנה קיימת ($0)"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Running": [
  null,
  "פועל"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  ""
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "בדיקת SMART עצמית של $0"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "ניתן לחסוך במקום על ידי דחיסת בלוקים עם LZ4 באופן פרטני"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "ניתן לחסוך במקום על ידי אחסון בלוקים עם נתונים זהים פעם אחת בלבד"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "שמירת מילת צופן חדשה דורשת את שחרור הכונן. נא לספק את מילת הצופן הנוכחית של הכונן."
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Securely erasing $target": [
  null,
  "$target נמחק בצורה מאובטחת"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  ""
 ],
 "Server": [
  null,
  "שרת"
 ],
 "Server address": [
  null,
  "כתובת השרת"
 ],
 "Server address cannot be empty.": [
  null,
  "כתובת השרת לא יכולה להיות ריקה."
 ],
 "Server cannot be empty.": [
  null,
  "השרת לא יכול להיות ריק."
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Service": [
  null,
  "שירות"
 ],
 "Services using the location": [
  null,
  "שירותים שמשתמשים במיקום"
 ],
 "Set": [
  null,
  "הגדרה"
 ],
 "Set limit of virtual filesystem size": [
  null,
  ""
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Setting up loop device $target": [
  null,
  "קם התקן לולאה $target"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Shrink": [
  null,
  "כיווץ"
 ],
 "Shrink logical volume": [
  null,
  "כיווץ הכרך הלוגי"
 ],
 "Shrink volume": [
  null,
  "כיווץ כרך"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Size": [
  null,
  "גודל"
 ],
 "Size cannot be negative": [
  null,
  "הגודל לא יכול להיות שלילי"
 ],
 "Size cannot be zero": [
  null,
  "הגודל לא יכול להיות אפס"
 ],
 "Size is too large": [
  null,
  "הגודל גדול מדי"
 ],
 "Size must be a number": [
  null,
  "הגודל חייב להיות מספר"
 ],
 "Size must be at least $0": [
  null,
  "הגודל חייב להיות לפחות $0"
 ],
 "Slot $0": [
  null,
  "משבצת $0"
 ],
 "Snapshot": [
  null,
  "תמונת מצב"
 ],
 "Solid State Drive": [
  null,
  ""
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  ""
 ],
 "Sorry": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Spare": [
  null,
  "עודף"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Start": [
  null,
  "התחלה"
 ],
 "Start multipath": [
  null,
  "הפעלת רב נתיבי"
 ],
 "Started": [
  null,
  "הופעל"
 ],
 "Starting swapspace $target": [
  null,
  "שטח ההחלפה $target מתחיל"
 ],
 "State": [
  null,
  "מצב"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "Stop": [
  null,
  "עצירה"
 ],
 "Stop and remove": [
  null,
  "עצירה והסרה"
 ],
 "Stop and unmount": [
  null,
  "עצירה וניתוק"
 ],
 "Stop device": [
  null,
  "עצירת התקן"
 ],
 "Stopping swapspace $target": [
  null,
  "שטח ההחלפה $target נעצר"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Storage can not be managed on this system.": [
  null,
  "לא ניתן לנהל את האחסון במערכת הזאת."
 ],
 "Storage logs": [
  null,
  "יומני אחסון"
 ],
 "Store passphrase": [
  null,
  "אחסון מילת צופן"
 ],
 "Stored passphrase": [
  null,
  "מילת צופן מאוחסנת"
 ],
 "Stratis pool": [
  null,
  "מאגר Stratis‏"
 ],
 "Striped (RAID 0)": [
  null,
  ""
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  ""
 ],
 "Stripes": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Successfully copied to clipboard!": [
  null,
  "ההעתקה ללוח הגזירים צלחה!"
 ],
 "Swap": [
  null,
  "החלפה"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Tang keyserver": [
  null,
  "שרת מפתחות Tang"
 ],
 "Target": [
  null,
  "יעד"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "החבילה $0 אינה זמינה באף מאגר."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "החבילה $0 חייבת להיות מותקנת כדי ליצור מאגרי Stratis."
 ],
 "The $0 package must be installed.": [
  null,
  "החבילה $0 חייבת להיות מותקנת."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "החבילה $0 תותקן כדי ליצור התקני VDO."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "יצירת התקן ה־VDO הזה לא הסתיימה ולא ניתן להשתמש בהתקן."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "המשתמש שמחובר כרגע אינו מורשה לצפות במידע על מפתחות."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "יש לשחרר את הכונן בטרם פרמוטו. נא לספק מילת צופן נוכחית."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "למערכת הקבצים אין נקודת עגינה קבועה."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "מערכת הקבצים מוגדרת להתעגן אוטומטית עם הפעלת המערכת אבל מכולת ההצפנה שלה לא תשוחרר באותו הזמן."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "מערכת הקבצים מעוגנת כעת אך העיגון ינותק לאחר העלייה הבאה של המערכת."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "מערכת הקבצים מעוגנת למיקום $0 אך תעוגן למיקום $1 עם העלייה הבאה של המערכת."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "מערכת הקבצים מעוגנת למיקום $0 אך לא תעוגן עם העלייה הבאה של המערכת."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "מערכת הקבצים אינה מעוגנת כעת אך היא תעוגן עם ההפעלה הבאה של המערכת."
 ],
 "The filesystem is not mounted.": [
  null,
  "מערכת הקבצים אינה מעוגנת."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "מערכת ההפעלה תשוחרר ותעוגן בעלייה הבאה. יכול להיות שצריך למלא מילת צופן."
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "The initrd must be regenerated.": [
  null,
  "יש לייצר את ה־initrd מחדש."
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "The last key slot can not be removed": [
  null,
  "לא ניתן להסיר את משבצת המפתח האחרונה"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "התהליכים והשירותים המוצגים ייעצרו בכוח."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "התהליכים המוצגים ייעצרו בכוח."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "אי אפשר לעצור בכוח את השירותים שמופיעים."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "נקודת העיגון $0 משמשת את התהליכים האלה:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "נקודת העיגון $0 משמשת את השירותים האלה:"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "המערכת לא תומכת כרגע בשחרור מערכת הקבצים עם שרת מפתחות Tang במהלך העלייה."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "המערכת לא תומכת כרגע בשחרור מערכת הקבצים עם שרת מפתחות Tang."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "יש התקנים עם מגוון נתיבים במערכת אך שירות ריבוי הנתיבים אינו פועל."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  ""
 ],
 "These additional steps are necessary:": [
  null,
  "הצעדים הנוספים האלו הכרחיים:"
 ],
 "These changes will be made:": [
  null,
  "אלו השינויים שיתבצעו:"
 ],
 "Thin logical volume": [
  null,
  "כרך לוגי צר"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  ""
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "עיגון NFS זה נמצא בשימוש ואפשר לשנות רק את האפשרויות שלו."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "התקן VDO זה אינו משתמש בכל ההתקן המגבה שלו."
 ],
 "This device is currently in use.": [
  null,
  "ההתקן הזה בשימוש כרגע."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  ""
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "בכרך לוגי זה לא נעשה שימוש מלא על ידי התוכן שלו."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "This pool is in a degraded state.": [
  null,
  "המאגר הזה נמצא במצב ירוד."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This volume group is missing some physical volumes.": [
  null,
  ""
 ],
 "Tier": [
  null,
  "רמה"
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "Trust key": [
  null,
  "לתת אמון במפתח"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  ""
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  ""
 ],
 "UUID": [
  null,
  "מזהה ייחודי"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "Unable to reach server": [
  null,
  "לא ניתן להגיע לשרת"
 ],
 "Unable to remove mount": [
  null,
  "לא ניתן להסיר עיגון"
 ],
 "Unable to unmount filesystem": [
  null,
  "לא ניתן לנתק את מערכת הקבצים"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "שגיאת PackageKit בלתי צפויה במהלך התקנת $0:‏ $1"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Unknown ($0)": [
  null,
  "לא ידוע ($0)"
 ],
 "Unknown host name": [
  null,
  "שם המארח לא ידוע"
 ],
 "Unknown type": [
  null,
  "סוג לא ידוע"
 ],
 "Unlock": [
  null,
  "שחרור"
 ],
 "Unlock automatically on boot": [
  null,
  "לשחרר אוטומטית עם העלייה"
 ],
 "Unlock before resizing": [
  null,
  ""
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "שחרור מאגר Stratis מוצפן"
 ],
 "Unlocking $target": [
  null,
  "$target משוחרר"
 ],
 "Unlocking disk": [
  null,
  "הכונן משוחרר"
 ],
 "Unmount": [
  null,
  "ניתוק"
 ],
 "Unmount filesystem $0": [
  null,
  "ניתוק מערכת הקבצים $0"
 ],
 "Unmount now": [
  null,
  "לנתק כעת"
 ],
 "Unmounting $target": [
  null,
  "$target מנותק"
 ],
 "Unrecognized data": [
  null,
  "נתונים לא מזוהים"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "לא ניתן להקטין כאן נתונים בלתי מזוהים."
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "Usage": [
  null,
  "שימוש"
 ],
 "Usage of $0": [
  null,
  "שימוש מתוך $0"
 ],
 "Use": [
  null,
  "שימוש"
 ],
 "Use compression": [
  null,
  "להשתמש בדחיסה"
 ],
 "Use deduplication": [
  null,
  "להשתמש בהסרת כפילות"
 ],
 "Used": [
  null,
  "בשימוש"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "חיוני לעיגוני רשות או שדורשים התערבות (כמו מילת צופן)"
 ],
 "User": [
  null,
  "משתמש"
 ],
 "Username": [
  null,
  "שם משתמש"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "אין אפשרות להקטין התקני גיבוי VDO"
 ],
 "VDO device $0": [
  null,
  "התקן VDO‏ $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "כרך מערכת קבצים VDO (דחיסה/הסרת כפולים)"
 ],
 "Vendor": [
  null,
  "ספק"
 ],
 "Verify key": [
  null,
  "אימות מפתח"
 ],
 "Very securely erasing $target": [
  null,
  "$target נמחק באופן מאוד מאובטח"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  ""
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Volume group": [
  null,
  "קבוצת כרכים"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "גודל הכרך הוא $0. גודל התוכן הוא $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "Write-mostly": [
  null,
  "בעיקר כתיבה"
 ],
 "Writing": [
  null,
  "מתבצעת כתיבה"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "after network": [
  null,
  "לאחר הרשת"
 ],
 "backing device for VDO device": [
  null,
  "התקן גיבוי להתקן VDO"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  ""
 ],
 "delete": [
  null,
  "מחיקה"
 ],
 "device of btrfs volume": [
  null,
  ""
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "format": [
  null,
  "פרמוט"
 ],
 "grow": [
  null,
  "הגדלה"
 ],
 "ignore failure": [
  null,
  "התעלמות מכשל"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "initialize": [
  null,
  "אתחול"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "member of Stratis pool": [
  null,
  "חבר במאגר Stratis"
 ],
 "mount": [
  null,
  "עיגון"
 ],
 "never mount at boot": [
  null,
  "לעולם לא לעגן בעלייה"
 ],
 "none": [
  null,
  "אין"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "כרך פיזי של קבוצת כרכים מסוג LVM2"
 ],
 "read only": [
  null,
  "קריאה בלבד"
 ],
 "remove from LVM2": [
  null,
  "הסרה מ־LVM2"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "shrink": [
  null,
  "כיווץ"
 ],
 "stop": [
  null,
  "עצירה"
 ],
 "stop boot on failure": [
  null,
  "עצירת העלייה בעת כשל"
 ],
 "unknown target": [
  null,
  "יעד לא ידוע"
 ],
 "unmount": [
  null,
  "ניתוק"
 ],
 "unpartitioned space on $0": [
  null,
  "מקום שאינו מחיצה ב־$0"
 ],
 "yes": [
  null,
  "כן"
 ],
 "format-bytes\u0004bytes": [
  null,
  "בתים"
 ]
});
