cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Managing LVMs": [
  null,
  "LVM:ien hallinta"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-liitosten hallinta"
 ],
 "Managing RAIDs": [
  null,
  "RAIDien hallinta"
 ],
 "Managing VDOs": [
  null,
  "VDO:iden hallinta"
 ],
 "Managing partitions": [
  null,
  "Osioiden hallinta"
 ],
 "Managing physical drives": [
  null,
  "Fyysisten asemien hallinta"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Using LUKS encryption": [
  null,
  "Käytetään LUKS-salausta"
 ],
 "Using Tang server": [
  null,
  "Käytetään Tang-palvelinta"
 ],
 "disk": [
  null,
  "levy"
 ],
 "drive": [
  null,
  "asema"
 ],
 "encryption": [
  null,
  "salaus"
 ],
 "filesystem": [
  null,
  "tiedostojärjestelmä"
 ],
 "format": [
  null,
  "alusta"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "liitos"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "osio"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "irrota"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "taltio"
 ]
});
