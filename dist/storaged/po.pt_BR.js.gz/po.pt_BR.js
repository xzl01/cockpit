cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 chunk size": [
  null,
  "$0 Tamanho do Bloco"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 dados + $1 sobrecarga usada de $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 disk is missing": [
  null,
  "$0 disco não encontrado",
  "$0 discos não encontrados"
 ],
 "$0 disks": [
  null,
  "$0 Discos"
 ],
 "$0 exited with code $1": [
  null,
  "$0 saiu com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 is in use": [
  null,
  "$0 está em uso"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mortos com sinal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 slot remains": [
  null,
  "$0 slot restante",
  "$0 slots restantes"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 usados of $1 ($2 salvos)"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "$name (from $host)": [
  null,
  "$nome(vindo de $host)"
 ],
 "(recommended)": [
  null,
  "(recomendado)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 Minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 Minutos"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 Minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 Minutos"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Um sistema de arquivos com esse nome já existe nessa pool."
 ],
 "A pool with this name exists already.": [
  null,
  "Já existe uma pool com esse nome."
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Action": [
  null,
  "Ação"
 ],
 "Actions": [
  null,
  "Ações"
 ],
 "Activate": [
  null,
  "Ativar"
 ],
 "Activate before resizing": [
  null,
  ""
 ],
 "Activating $target": [
  null,
  "Ativando $target"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Adicionar Criptografia de Disco Limitada à Rede"
 ],
 "Add Tang keyserver": [
  null,
  "Adicionar Servidor de chaves Tang"
 ],
 "Add disk": [
  null,
  "Adicionar disco"
 ],
 "Add disks": [
  null,
  "Adicionar Discos"
 ],
 "Add iSCSI portal": [
  null,
  "Adicionar Portal iSCSI"
 ],
 "Add key": [
  null,
  "Adicionar chave"
 ],
 "Add passphrase": [
  null,
  "Adicionar Senha"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Adicionando \"$0\" às opções do sistema de arquivos"
 ],
 "Adding key": [
  null,
  "Adicionando chave"
 ],
 "Adding physical volume to $target": [
  null,
  "Adicionando volume físico a $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Adicionando rd.neednet=1 à linha de comando do kernel"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Address": [
  null,
  "Endereço"
 ],
 "Address cannot be empty": [
  null,
  "O endereço não pode estar vazio"
 ],
 "Address is not a valid URL": [
  null,
  "O endereço não é um URL válido"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA Avançado"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Todos os $0 volumes físicos selecionados são necessários para o layout escolhido."
 ],
 "Allow overprovisioning": [
  null,
  ""
 ],
 "An additional $0 must be selected": [
  null,
  ""
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Apropriado para montagens críticas, como /var"
 ],
 "At least $0 disk is needed.": [
  null,
  "Pelo menos $0 disco é necessário.",
  "Pelo menos $0 discos são necessários."
 ],
 "At least one disk is needed.": [
  null,
  "Pelo menos um disco é necessário."
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ],
 "Authentication required": [
  null,
  "Autenticação requerida"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar chave SSH"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "Available targets on $0": [
  null,
  "Alvos disponíveis em $0"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Block device for filesystems": [
  null,
  "Dispositivo de bloqueio para sistemas de arquivos"
 ],
 "Block devices": [
  null,
  "Dispositivos de bloco"
 ],
 "Blocked": [
  null,
  "Bloqueado"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "O inicialização falha se o sistema de arquivos não é montado, impedindo o acesso remoto"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "A inicialização ainda é bem-sucedida quando o sistema de arquivos não é montado"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "Capacity": [
  null,
  "Capacidade"
 ],
 "Category": [
  null,
  ""
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change iSCSI initiator name": [
  null,
  "Alterar Nome do Iniciador iSCSI"
 ],
 "Change passphrase": [
  null,
  "Alterar senha"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "As chaves alteradas frequentemente são resultado de uma reinstalação do sistema operacional. No entanto, uma alteração inesperada pode indicar uma tentativa de terceiros de interceptar sua conexão."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  ""
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  ""
 ],
 "Check the key hash with the Tang server.": [
  null,
  ""
 ],
 "Checking $target": [
  null,
  "Vericando $target"
 ],
 "Checking for $0 package": [
  null,
  "Verificando a presença do pacote $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  ""
 ],
 "Checking installed software": [
  null,
  "Verificando o software instalado"
 ],
 "Chunk size": [
  null,
  "Tamanho do Bloco"
 ],
 "Cleaning up for $target": [
  null,
  "Limpando $target"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  ""
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Collect and package diagnostic and support data": [
  null,
  ""
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatível com todos os sistemas e dispositivos (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatível com sistema moderno e discos rígidos > 2TB (GPT)"
 ],
 "Compression": [
  null,
  "Compressão"
 ],
 "Confirm": [
  null,
  "Confirmar"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Copied": [
  null,
  ""
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Create RAID device": [
  null,
  "Criar dispositivo RAID"
 ],
 "Create a new SSH key and authorize it": [
  null,
  ""
 ],
 "Create logical volume": [
  null,
  "Criar Volume Lógico"
 ],
 "Create new logical volume": [
  null,
  "Criar novo Volume Lógico"
 ],
 "Create new task file with this content.": [
  null,
  ""
 ],
 "Create partition": [
  null,
  "Criar Partição"
 ],
 "Create partition on $0": [
  null,
  "Criar Partição em $0"
 ],
 "Create partition table": [
  null,
  "Criar tabela de partição"
 ],
 "Create snapshot": [
  null,
  "Criar Snapshot"
 ],
 "Create thin volume": [
  null,
  "Criar Thin Volume"
 ],
 "Create volume group": [
  null,
  "Criar Grupo de Volumes"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Criando o grupo de volumes LVM2 $target"
 ],
 "Creating VDO device": [
  null,
  "Criando dispositivo VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "Criando sistema de arquivos em $target"
 ],
 "Creating logical volume $target": [
  null,
  "Criando volume lógico $target"
 ],
 "Creating partition $target": [
  null,
  "Criando partição $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Criando snapshot de $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom mount options": [
  null,
  "Opções de montagem personalizadas"
 ],
 "Data used": [
  null,
  "Dados Usados"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  ""
 ],
 "Deactivate": [
  null,
  "Desativar"
 ],
 "Deactivating $target": [
  null,
  "Desativando $target"
 ],
 "Deduplication": [
  null,
  "Desduplicação"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Deleting $target": [
  null,
  "Deletando $0"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Excluindo grupo de volume LVM2 $target"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Excluindo um volume lógico irá excluir todos os dados nele."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "A exclusão de uma partição apaga todos os dados da mesma."
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Device file": [
  null,
  "Arquivo do dispositivo"
 ],
 "Device is read-only": [
  null,
  "Dispositivo é somente leitura"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Disconnect": [
  null,
  "Desconectar"
 ],
 "Disk is OK": [
  null,
  "O Disco está OK"
 ],
 "Disk passphrase": [
  null,
  "Senha de disco"
 ],
 "Disks": [
  null,
  "Discos"
 ],
 "Do not mount automatically on boot": [
  null,
  ""
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "Does not mount during boot": [
  null,
  ""
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Drive": [
  null,
  "Unidade"
 ],
 "Dual rank": [
  null,
  ""
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit Tang keyserver": [
  null,
  "Editar o servidor de chaves Tang"
 ],
 "Editing a key requires a free slot": [
  null,
  "Editar uma chave requer um espaço livre"
 ],
 "Ejecting $target": [
  null,
  "Ejetando $target"
 ],
 "Embedded PC": [
  null,
  ""
 ],
 "Emptying $target": [
  null,
  "Esvaziando $target"
 ],
 "Encrypted $0": [
  null,
  "Encriptado"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume Lógico Criptografado de $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partição Criptografada de $0"
 ],
 "Encryption": [
  null,
  "Encriptação"
 ],
 "Encryption options": [
  null,
  "Opções de Criptografia"
 ],
 "Encryption type": [
  null,
  "Tipo de encriptação"
 ],
 "Erasing $target": [
  null,
  "Apagando $target"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  ""
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  ""
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Extended partition": [
  null,
  "Partição Extendida"
 ],
 "Failed": [
  null,
  "Falhou"
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "Filesystem": [
  null,
  "Sistema de arquivos"
 ],
 "Filesystem name": [
  null,
  "Nome do Sistema de Arquivos"
 ],
 "Fix NBDE support": [
  null,
  ""
 ],
 "Format": [
  null,
  "Formate"
 ],
 "Format $0": [
  null,
  "Formate $0"
 ],
 "Format and mount": [
  null,
  "Formatar e montar"
 ],
 "Free space": [
  null,
  "Espaço Livre"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "Grow": [
  null,
  "Crescer"
 ],
 "Grow logical size of $0": [
  null,
  "Crescer tamanho lógico de $0"
 ],
 "Grow logical volume": [
  null,
  "Aumentar o Volume Lógico"
 ],
 "Grow to take all space": [
  null,
  "Crescer para tomar todo o espaço"
 ],
 "Host key is incorrect": [
  null,
  "Chave de Host incorreta"
 ],
 "How to check": [
  null,
  ""
 ],
 "I confirm I want to lose this data forever": [
  null,
  ""
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  ""
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  ""
 ],
 "Important data might be deleted:": [
  null,
  ""
 ],
 "In a terminal, run: ": [
  null,
  ""
 ],
 "In sync": [
  null,
  "Em Sincronização"
 ],
 "Inconsistent filesystem mount": [
  null,
  ""
 ],
 "Index memory": [
  null,
  "Memória de índice"
 ],
 "Initialize": [
  null,
  "Inicializar"
 ],
 "Initialize disk $0": [
  null,
  "Inicializando disco $0"
 ],
 "Install": [
  null,
  "Instale"
 ],
 "Install NFS support": [
  null,
  "Instalar o suporte ao NFS"
 ],
 "Install Stratis support": [
  null,
  "Instalar suporte ao Stratis"
 ],
 "Install software": [
  null,
  "Instale Software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "A instalação de $0 removeria $1."
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "Invalid username or password": [
  null,
  "Nome de usuário ou senha inválidos"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Jobs": [
  null,
  "Trabalhos"
 ],
 "Kernel dump": [
  null,
  "Dump do Kernel"
 ],
 "Key password": [
  null,
  "Nova senha"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Slots chave com tipos desconhecidos não podem ser editados aqui"
 ],
 "Key source": [
  null,
  "Fonte chave"
 ],
 "Keys": [
  null,
  "Chaves"
 ],
 "Keyserver": [
  null,
  "Servidor de chaves"
 ],
 "Keyserver address": [
  null,
  "Endereço do servidor de chaves"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "A remoção do Keyserver pode impedir o desbloqueio de $0."
 ],
 "LVM2 volume group": [
  null,
  "Grupo de Volumes LVM2"
 ],
 "Label": [
  null,
  ""
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last modified: $0": [
  null,
  "Última modificação: $0"
 ],
 "Layout": [
  null,
  ""
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "Linear": [
  null,
  ""
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "Local mount point": [
  null,
  "Ponto de montagem local"
 ],
 "Location": [
  null,
  "Localização"
 ],
 "Lock": [
  null,
  "Travar"
 ],
 "Locking $target": [
  null,
  "Bloqueando $target"
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "Logical": [
  null,
  "Lógico"
 ],
 "Logical size": [
  null,
  "Tamanho Lógico"
 ],
 "Logical volume": [
  null,
  "Volume Lógico"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume Lógico (Snapshot)"
 ],
 "Logical volume of $0": [
  null,
  "Volume Lógico de $0"
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Marking $target as faulty": [
  null,
  "Marcando $target como defeituoso"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Metadata used": [
  null,
  "Metadados Usados"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Mirrored (RAID 1)": [
  null,
  ""
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Modifying $target": [
  null,
  "Modificando $target"
 ],
 "Mount": [
  null,
  "Montar"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  ""
 ],
 "Mount also automatically on boot": [
  null,
  ""
 ],
 "Mount at boot": [
  null,
  "Monte na Inicialização"
 ],
 "Mount automatically on $0 on boot": [
  null,
  ""
 ],
 "Mount before services start": [
  null,
  ""
 ],
 "Mount configuration": [
  null,
  "Configuração de montagem"
 ],
 "Mount filesystem": [
  null,
  "Montar sistema de arquivos"
 ],
 "Mount now": [
  null,
  ""
 ],
 "Mount on $0 now": [
  null,
  ""
 ],
 "Mount options": [
  null,
  "Opções de Montagem"
 ],
 "Mount point": [
  null,
  "Ponto de Montagem"
 ],
 "Mount point cannot be empty": [
  null,
  "O ponto de montagem não pode estar vazio"
 ],
 "Mount point cannot be empty.": [
  null,
  "O ponto de montagem não pode estar vazio."
 ],
 "Mount point is already used for $0": [
  null,
  ""
 ],
 "Mount point must start with \"/\".": [
  null,
  "O ponto de montagem deve começar com \"/\"."
 ],
 "Mount read only": [
  null,
  "Monte só de leitura"
 ],
 "Mount without waiting, ignore failure": [
  null,
  ""
 ],
 "Mounting $target": [
  null,
  "Montando $target"
 ],
 "Mounts before services start": [
  null,
  ""
 ],
 "Mounts in parallel with services": [
  null,
  ""
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "NFS mount": [
  null,
  "Montagem NFS"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Name can not be empty.": [
  null,
  "O nome não pode estar vazio."
 ],
 "Name cannot be empty.": [
  null,
  "O nome não pode estar vazio."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "O nome não pode ser maior que $0 bytes"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "O nome não pode ser maior do que $0 caracteres"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "O nome não pode ser maior do que 127 caracteres."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "O nome não pode conter o caractere '$0'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nome não pode conter espaço em branco."
 ],
 "Need a spare disk": [
  null,
  ""
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "New NFS mount": [
  null,
  "Nova montagem de volume NFS"
 ],
 "New passphrase": [
  null,
  "Nova senha"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "Next": [
  null,
  "Próximo"
 ],
 "No available slots": [
  null,
  "Sem slots disponíveis"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "No disks are available.": [
  null,
  "Sem discos disponíveis."
 ],
 "No filesystem": [
  null,
  "Nenhum Sistema de Arquivos"
 ],
 "No free key slots": [
  null,
  "Nenhum slot de chave livre"
 ],
 "No free space": [
  null,
  "Não há espaço livre"
 ],
 "No keys added": [
  null,
  "Nenhuma chave adicionada"
 ],
 "No logical volumes": [
  null,
  "Nenhum Volume Lógico"
 ],
 "No media inserted": [
  null,
  "Nenhuma mídia inserida"
 ],
 "No partitioning": [
  null,
  "Sem particionamento"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Not found": [
  null,
  "Não encontrado"
 ],
 "Not permitted to perform this action.": [
  null,
  "Não é permitido executar esta ação."
 ],
 "Not running": [
  null,
  "Não está rodando"
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Senha antiga"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Somente $0 de $1 está em uso."
 ],
 "Operation '$operation' on $target": [
  null,
  "Operação '$operation' em $target"
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Other": [
  null,
  "De outros"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "Partition": [
  null,
  "Partição"
 ],
 "Partition of $0": [
  null,
  "Partição de $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  ""
 ],
 "Partitioning": [
  null,
  "Particionamento"
 ],
 "Partitions": [
  null,
  "Partições"
 ],
 "Passphrase": [
  null,
  "Frase-senha"
 ],
 "Passphrase can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "Passphrase cannot be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "A remoção da senha pode impedir o desbloqueio de $0."
 ],
 "Passphrases do not match": [
  null,
  "As senhas não correspondem"
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Path on server": [
  null,
  "Caminho no servidor"
 ],
 "Path on server cannot be empty.": [
  null,
  "Caminho no servidor não pode estar vazio."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Caminho no servidor deve começar com \"/\"."
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "Permanently delete $0?": [
  null,
  ""
 ],
 "Physical": [
  null,
  "Fisica"
 ],
 "Physical volumes": [
  null,
  "Volumes Físicos"
 ],
 "Pick date": [
  null,
  ""
 ],
 "Please unmount them first.": [
  null,
  ""
 ],
 "Pool for thin logical volumes": [
  null,
  "Buscando por Thin Logical Volumes"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool para volumes finamente provisionados"
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Processes using the location": [
  null,
  ""
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  ""
 ],
 "Purpose": [
  null,
  "Propósito"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Distribuição)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Espelhamento)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Distribuição de Espelhos)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Paridade Dedicada)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Paridade Distribuída)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Paridade Duplamente Distribuída)"
 ],
 "RAID level": [
  null,
  "Nível de RAID"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Recovering": [
  null,
  "Recuperação"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "Related processes will be forcefully stopped.": [
  null,
  ""
 ],
 "Related services will be forcefully stopped.": [
  null,
  ""
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Remove $0?": [
  null,
  "Remover $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Remover o servidor de chaves Tang?"
 ],
 "Remove device": [
  null,
  "Remover dispositivo"
 ],
 "Remove passphrase?": [
  null,
  "Remover senha?"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  ""
 ],
 "Removing physical volume from $target": [
  null,
  "Removendo volume físico de $target"
 ],
 "Rename": [
  null,
  "Renomear"
 ],
 "Rename logical volume": [
  null,
  "Renomear Volume Lógico"
 ],
 "Rename volume group": [
  null,
  "Renomear Grupo de Volume"
 ],
 "Renaming $target": [
  null,
  "Renomeando $target"
 ],
 "Repair": [
  null,
  ""
 ],
 "Repairing $target": [
  null,
  "Reparando $target"
 ],
 "Repeat passphrase": [
  null,
  "Repita a frase secreta"
 ],
 "Resizing $target": [
  null,
  "Redimensionando $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  ""
 ],
 "Reuse existing encryption ($0)": [
  null,
  ""
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Running": [
  null,
  "Executando"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  ""
 ],
 "SHA-256": [
  null,
  ""
 ],
 "SMART self-test of $target": [
  null,
  "SMART auto-teste de $target"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  ""
 ],
 "Save space by storing identical data blocks just once": [
  null,
  ""
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Salvar uma nova senha requer o desbloqueio do disco. Por favor, forneça uma senha de disco atual."
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Securely erasing $target": [
  null,
  "Apagando com segurança $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  ""
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Server address": [
  null,
  "Endereço do Servidor"
 ],
 "Server address cannot be empty.": [
  null,
  "O endereço do servidor não pode estar vazio."
 ],
 "Server cannot be empty.": [
  null,
  "O servidor não pode estar vazio."
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Service": [
  null,
  "Serviço"
 ],
 "Set": [
  null,
  "Definir"
 ],
 "Set limit of virtual filesystem size": [
  null,
  ""
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Setting up loop device $target": [
  null,
  "Configurando o dispositivo de loop $target"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shrink": [
  null,
  "Compactar"
 ],
 "Shrink logical volume": [
  null,
  "Compactar Logical Volume"
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Size cannot be negative": [
  null,
  "O tamanho não pode ser negativo"
 ],
 "Size cannot be zero": [
  null,
  "O tamanho não pode ser zero"
 ],
 "Size is too large": [
  null,
  "O tamanho é muito extenso"
 ],
 "Size must be a number": [
  null,
  "O tamanho deve ser um número"
 ],
 "Size must be at least $0": [
  null,
  "O tamanho deve ser pelo menos $0"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  ""
 ],
 "Sorry": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Spare": [
  null,
  "Reposição"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Start multipath": [
  null,
  "Iniciar Multipath"
 ],
 "Starting swapspace $target": [
  null,
  "Iniciando swapspace $target"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Pare"
 ],
 "Stop and remove": [
  null,
  "Pare e remova"
 ],
 "Stop and unmount": [
  null,
  "Parar e desmontar"
 ],
 "Stop device": [
  null,
  "Parar dispositivo"
 ],
 "Stopping swapspace $target": [
  null,
  "Parando swapspace $target"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Storage can not be managed on this system.": [
  null,
  "O armazenamento não pode ser gerenciado neste sistema."
 ],
 "Storage logs": [
  null,
  "Logs de Armazenamento"
 ],
 "Store passphrase": [
  null,
  "Armazene a senha"
 ],
 "Stored passphrase": [
  null,
  "Senha armazenada"
 ],
 "Striped (RAID 0)": [
  null,
  ""
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  ""
 ],
 "Stripes": [
  null,
  ""
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copiado com sucesso para a área de transferência!"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Target": [
  null,
  "Alvo"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  ""
 ],
 "The $0 package must be installed.": [
  null,
  "O pacote $0 deve estar instalado."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  ""
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  ""
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  ""
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "A criação deste dispositivo VDO não foi concluída e o dispositivo não pode ser usado."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "O usuário atualmente conectado não tem permissão para ver informações sobre chaves."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  ""
 ],
 "The filesystem has no assigned mount point.": [
  null,
  ""
 ],
 "The filesystem has no permanent mount point.": [
  null,
  ""
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  ""
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  ""
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  ""
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  ""
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  ""
 ],
 "The filesystem is not mounted.": [
  null,
  ""
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  ""
 ],
 "The initrd must be regenerated.": [
  null,
  ""
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "The last key slot can not be removed": [
  null,
  "O último slot chave não pode ser removido"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  ""
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Os serviços listados serão interrompidos à força."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  ""
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  ""
 ],
 "The mount point $0 is in use by these services:": [
  null,
  ""
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  ""
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  ""
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  ""
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Há dispositivos com vários caminhos no sistema, mas o serviço de multicaminho não está sendo executado."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  ""
 ],
 "These additional steps are necessary:": [
  null,
  ""
 ],
 "These changes will be made:": [
  null,
  "Essas mudanças serão realizadas:"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  ""
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Esta montagem NFS está em uso e somente suas opções podem ser alteradas."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Este dispositivo VDO não usa todo o seu dispositivo de apoio."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  ""
 ],
 "This logical volume is not completely used by its content.": [
  null,
  ""
 ],
 "This partition is not completely used by its content.": [
  null,
  ""
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "This pool is in a degraded state.": [
  null,
  "Esta piscina está em estado de degradação."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  ""
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  ""
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  ""
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  ""
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This volume group is missing some physical volumes.": [
  null,
  ""
 ],
 "Tier": [
  null,
  ""
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  ""
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  ""
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Trust key": [
  null,
  "Chave de confiança"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  ""
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  ""
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  ""
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  ""
 ],
 "Unable to reach server": [
  null,
  "Não é possível acessar o servidor"
 ],
 "Unable to remove mount": [
  null,
  "Não é possível remover a unidade montade"
 ],
 "Unable to unmount filesystem": [
  null,
  "Não é possível desmontar o sistema de arquivos"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  ""
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Unknown ($0)": [
  null,
  "Desconhecido ($0)"
 ],
 "Unknown host name": [
  null,
  "Nome de host desconhecido"
 ],
 "Unknown type": [
  null,
  "Tipo desconhecido"
 ],
 "Unlock": [
  null,
  "Destravar"
 ],
 "Unlock before resizing": [
  null,
  ""
 ],
 "Unlocking $target": [
  null,
  "Desbloqueando $target"
 ],
 "Unlocking disk": [
  null,
  "Desbloqueando o disco"
 ],
 "Unmount": [
  null,
  "Desmontar"
 ],
 "Unmount now": [
  null,
  ""
 ],
 "Unmounting $target": [
  null,
  "Desmontando $target"
 ],
 "Unrecognized data": [
  null,
  "Dados não reconhecidos"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Dados não reconhecidos não podem ser reduzidos aqui."
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "Used": [
  null,
  "Usado"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  ""
 ],
 "User": [
  null,
  "Usuário"
 ],
 "Username": [
  null,
  "Nome de Usuário"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Dispositivos de suporte VDO não podem ser menores"
 ],
 "VDO device $0": [
  null,
  "Dispositivo VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  ""
 ],
 "Vendor": [
  null,
  "Fabricante"
 ],
 "Verify key": [
  null,
  "Verificar chave"
 ],
 "Very securely erasing $target": [
  null,
  "Apagando com muita segurança $target"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "View automation script": [
  null,
  ""
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  ""
 ],
 "Volume group": [
  null,
  "Grupo de volumes"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando que outras operações de gerenciamento de software terminem"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "World wide name": [
  null,
  ""
 ],
 "Write-mostly": [
  null,
  "Maioria-Escrita"
 ],
 "Writing": [
  null,
  "Escrevendo"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  ""
 ],
 "device of btrfs volume": [
  null,
  ""
 ],
 "edit": [
  null,
  ""
 ],
 "format": [
  null,
  ""
 ],
 "grow": [
  null,
  ""
 ],
 "ignore failure": [
  null,
  "ignorar falhas"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "initialize": [
  null,
  "inicializar"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "member of Stratis pool": [
  null,
  "membro do grupo Stratis"
 ],
 "mount": [
  null,
  ""
 ],
 "never mount at boot": [
  null,
  "nunca montar na inicialização"
 ],
 "none": [
  null,
  "nenhum"
 ],
 "password quality": [
  null,
  ""
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volume físico do grupo de volumes LVM2"
 ],
 "read only": [
  null,
  "somente leitura"
 ],
 "remove from LVM2": [
  null,
  "remover do LVM2"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "stop": [
  null,
  ""
 ],
 "stop boot on failure": [
  null,
  "parar a inicialização em caso de falha"
 ],
 "unknown target": [
  null,
  "alvo desconhecido"
 ],
 "unpartitioned space on $0": [
  null,
  "espaço não particionado em $0"
 ],
 "using key description $0": [
  null,
  ""
 ],
 "yes": [
  null,
  "sim"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bytes"
 ]
});
