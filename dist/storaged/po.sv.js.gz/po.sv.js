cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 kan inte göras större"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 kan inte göras mindre"
 ],
 "$0 can not be resized": [
  null,
  "$0 kan inte storleksändras"
 ],
 "$0 can not be resized here": [
  null,
  "$0 kan inte storleksändras"
 ],
 "$0 chunk size": [
  null,
  "$0 styckesstorlek"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 extra använt av $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk saknas",
  "$0 diskar saknas"
 ],
 "$0 disks": [
  null,
  "$0 diskar"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avslutade med kod $1"
 ],
 "$0 failed": [
  null,
  "$0 misslyckades"
 ],
 "$0 filesystem": [
  null,
  "$0 filsystem"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 is in use": [
  null,
  "$0 används"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dödad med signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 partitions": [
  null,
  "$0 partitioner"
 ],
 "$0 slot remains": [
  null,
  "$0 fack återstår",
  "$0 fack återstår"
 ],
 "$0 synchronized": [
  null,
  "$0 synkroniserad"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 använt av $1 ($2 sparat)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 använt, $1 totalt"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$name (from $host)": [
  null,
  "$name (från $host)"
 ],
 "(Not part of target)": [
  null,
  "(Inte del av mål)"
 ],
 "(no assigned mount point)": [
  null,
  "(ingen tilldelad monteringspunkt)"
 ],
 "(not mounted)": [
  null,
  "(inte monterad)"
 ],
 "(recommended)": [
  null,
  "(rekommenderad)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Ett filsystem med detta namn finns redan i denna pool."
 ],
 "A pool with this name exists already.": [
  null,
  "En pool med detta namn finns redan."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "En volymgrupp med saknade fysiska volymer kan inte döpas om."
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Acceptable password": [
  null,
  "Acceptabelt lösenord"
 ],
 "Action": [
  null,
  "Åtgärd"
 ],
 "Actions": [
  null,
  "Åtgärder"
 ],
 "Activate": [
  null,
  "Aktivera"
 ],
 "Activate before resizing": [
  null,
  "Aktivera innan du ändrar storlek"
 ],
 "Activating $target": [
  null,
  "Aktivera $target"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Lägg till nätverksbunden diskkryptering"
 ],
 "Add Tang keyserver": [
  null,
  "Lägg till Tang-nyckelserver"
 ],
 "Add a bitmap": [
  null,
  "Lägg till en bitmap"
 ],
 "Add block devices": [
  null,
  "Lägg till blockenheter"
 ],
 "Add disk": [
  null,
  "Lägg till disk"
 ],
 "Add disks": [
  null,
  "Lägg till diskar"
 ],
 "Add iSCSI portal": [
  null,
  "Lägg till iSCSI-portal"
 ],
 "Add key": [
  null,
  "Lägg till nyckel"
 ],
 "Add keyserver": [
  null,
  "Lägg till nyckelserver"
 ],
 "Add passphrase": [
  null,
  "Lägg till lösenfras"
 ],
 "Add physical volume": [
  null,
  "Lägg till fysisk volym"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Lägger till \"$0\" till krypteringsalternativ"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Lägger till \"$0\" till filsystemsalternativ"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Att lägga till en nyckelserver kräver upplåsning av poolen. Ange den existerande poollösenfrasen."
 ],
 "Adding key": [
  null,
  "Lägger till nyckel"
 ],
 "Adding physical volume to $target": [
  null,
  "Lägger till fysisk volym till $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Lägger till rd.neednet=1 till kärnans kommandorad"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Address": [
  null,
  "Adress"
 ],
 "Address cannot be empty": [
  null,
  "Adressen kan inte vara tom"
 ],
 "Address is not a valid URL": [
  null,
  "Adressen är inte en giltig URL"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration med Cockpits webbkonsol"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "All $0 selected physical volumes are needed for the choosen layout.": [
  null,
  "Alla $0 valda fysiska volymer behövs för den valda layouten."
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "An additional $0 must be selected": [
  null,
  "Ytterligare $0 måste väljas"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentation för Ansibleroller"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Lämplig för kritiska monteringar, såsom /var"
 ],
 "Assessment": [
  null,
  "Bedömning"
 ],
 "At boot": [
  null,
  "Vid start"
 ],
 "At least $0 disk is needed.": [
  null,
  "Åtminstone $0 disk behövs.",
  "Åtminstone $0 diskar behövs."
 ],
 "At least one block device is needed.": [
  null,
  "Åtminstone en blockenhet behövs."
 ],
 "At least one disk is needed.": [
  null,
  "Åtminstone en disk behövs."
 ],
 "At least one parent needs to be mounted writable": [
  null,
  "Minst en förälder måste vara monterad skrivbar"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering krävs för att utföra privilegierade uppgifter med Cockpits webbkonsol"
 ],
 "Authentication required": [
  null,
  "Autentisering krävs"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Använder automatiskt ytterligare NTP-servrar"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Available targets on $0": [
  null,
  "Tillgängliga mål på $0"
 ],
 "BIOS boot partition": [
  null,
  "BIOS uppstartspartition"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Block device": [
  null,
  "Blockenhet"
 ],
 "Block device for filesystems": [
  null,
  "Blockenhet för filsystem"
 ],
 "Block devices": [
  null,
  "Blockenheter"
 ],
 "Blocked": [
  null,
  "Blockerat"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Uppstart misslyckas om filsystemet inte monteras, vilket förhindrar fjärråtkomst"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Uppstarten lyckas fortfarande när filsystemet inte monteras"
 ],
 "Btrfs volume is mounted": [
  null,
  "Btrfs volym är monterad"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inte vidarebefordra inloggningsuppgifterna"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "Capacity": [
  null,
  "Kapacitet"
 ],
 "Category": [
  null,
  "Kategori"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change iSCSI initiater name": [
  null,
  "Ändra namnet på iSCSI-initieraren"
 ],
 "Change iSCSI initiator name": [
  null,
  "Ändra iSCSI-initierarnamn"
 ],
 "Change label": [
  null,
  "Ändra etikett"
 ],
 "Change passphrase": [
  null,
  "Ändra lösenfras"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Att ändra partitionstyper kan förhindra att systemet startar upp."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Kontrollera att SHA-256- eller SHA-1-hash från kommandot matchar den här dialogrutan."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Kontrollera nyckelhash med Tang-server."
 ],
 "Checking $target": [
  null,
  "Kontrollerar $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Kontrollerar MDRAID-enhet $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Kontrollera och reparera MDRAID-enhet $target"
 ],
 "Checking filesystem usage": [
  null,
  "Kontrollerar filsystemsanvändning"
 ],
 "Checking for $0 package": [
  null,
  "Söker efter $0 paket"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Söker efter NBDE-stöd i initrd"
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "Chunk size": [
  null,
  "Styckesstorlek"
 ],
 "Cleaning up for $target": [
  null,
  "Rensar upp för $target"
 ],
 "Cleartext device": [
  null,
  "Klar text enhet"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit konfiguration av NetworkManager och Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunde inte kontakta den angivna värden."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit är en serverhanterare som gör det lätt att administrera dina Linuxservrar via en webbläsare. Att hoppa mellan terminalen och webbverktyget är inget problem. En tjänst som startas via Cockpit kan stoppas via terminalen. Likaledes, om ett fel uppstår i terminalen kan det ses i Cockpits journalgränssnitt."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit är inte kompatibelt med programvaran på systemet."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit är inte installerat på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit är perfekt för nya systemadministratörer, låter dem lätt utföra enkla uppgifter såsom lagringsadministration, inspektion av journaler och att starta och stoppa tjänster. Du kan övervaka och administrera flera servrar på samma gång. Lägg bara till dem med ett enda klick och dina maskiner kommer se efter sina kompisar."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Samla och paketera diagnostik och support data"
 ],
 "Collect kernel crash dumps": [
  null,
  "Samla kärnkraschdumpar"
 ],
 "Command": [
  null,
  "Kommando"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibel med alla system och enheter (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibel med moderna system och hårddiskar > 2 TB (GPT)"
 ],
 "Compression": [
  null,
  "Komprimering"
 ],
 "Confirm": [
  null,
  "Bekräfta"
 ],
 "Confirm deletion of $0": [
  null,
  "Bekräfta raderingen av $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Bekräfta borttagandet med en alternativ lösenfras"
 ],
 "Confirm stopping of $0": [
  null,
  "Bekräfta stoppandet av $0"
 ],
 "Connection has timed out.": [
  null,
  "Anslutningens tidsgräns överskreds."
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Create LVM2 volume group": [
  null,
  "Skapa LVM2 volymgrupp"
 ],
 "Create MDRAID device": [
  null,
  "Skapa en MDRAID-enhet"
 ],
 "Create RAID device": [
  null,
  "Skapa en RAID-enhet"
 ],
 "Create Stratis pool": [
  null,
  "Skapa Stratis lagringspool"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Skapa en ögonblicksbild av filsystem $0"
 ],
 "Create and mount": [
  null,
  "Skapa och montera"
 ],
 "Create and start": [
  null,
  "Skapa och starta"
 ],
 "Create filesystem": [
  null,
  "Skapa filsystem"
 ],
 "Create logical volume": [
  null,
  "Skapa en logisk volym"
 ],
 "Create new filesystem": [
  null,
  "Skapa nytt filsystem"
 ],
 "Create new logical volume": [
  null,
  "Skapa en ny logisk volym"
 ],
 "Create new task file with this content.": [
  null,
  "Skapa en ny uppgiftsfil med detta innehåll."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Skapa en ny logisk volym med tunn provisionering"
 ],
 "Create only": [
  null,
  "Skapa endast"
 ],
 "Create partition": [
  null,
  "Skapa en partition"
 ],
 "Create partition on $0": [
  null,
  "Skapa partition på $0"
 ],
 "Create partition table": [
  null,
  "Skapa partitionstabell"
 ],
 "Create snapshot": [
  null,
  "Skapa en ögonblicksbild"
 ],
 "Create snapshot and mount": [
  null,
  "Skapa en ögonblicksbild och montera"
 ],
 "Create snapshot only": [
  null,
  "Skapa en ögonblicksbild endast"
 ],
 "Create storage device": [
  null,
  "Skapa lagringsenhet"
 ],
 "Create subvolume": [
  null,
  "Skapa undervolym"
 ],
 "Create thin volume": [
  null,
  "Skapa en tunn volym"
 ],
 "Create volume group": [
  null,
  "Skapa en volymgrupp"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Skapar LVM2 volymgrupp $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "Skapar MDRAID-enhet $target"
 ],
 "Creating VDO device": [
  null,
  "Skapar VDO-enhet"
 ],
 "Creating filesystem on $target": [
  null,
  "Skapar ett filsystem på $target"
 ],
 "Creating logical volume $target": [
  null,
  "Skapar en logisk volym på $target"
 ],
 "Creating partition $target": [
  null,
  "Skapar en partition på $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Skapar en ögonblicksbild av $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Används just nu"
 ],
 "Custom": [
  null,
  "Anpassad"
 ],
 "Custom mount options": [
  null,
  "Anpassade monteringsalternativ"
 ],
 "Custom type": [
  null,
  "Anpassad typ"
 ],
 "Data": [
  null,
  "Data"
 ],
 "Data used": [
  null,
  "Data använt"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Data kommer att lagras som två kopior och även på ett alternerande sätt på de valda fysiska volymerna, för att förbättra både tillförlitlighet och prestanda. Minst fyra volymer måste väljas."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Data kommer att lagras som två eller flera kopior på de valda fysiska volymerna, för att förbättra tillförlitligheten. Minst två volymer måste väljas."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna på ett alternerande sätt för att förbättra prestandan. Minst två volymer måste väljas."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna så att en av dem kan gå förlorad utan att data påverkas. Minst tre volymer måste väljas."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna så att en av dem kan gå förlorad utan att data påverkas. Data lagras också på ett alternerande sätt för att förbättra prestandan. Minst tre volymer måste väljas."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna så att upp till två av dem kan gå förlorade samtidigt utan att data påverkas. Data lagras också på ett alternerande sätt för att förbättra prestandan. Minst fem volymer måste väljas."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna utan ytterligare redundans eller prestandaförbättringar."
 ],
 "Deactivate": [
  null,
  "Avaktivera"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Inaktivera logisk volym $0/$1?"
 ],
 "Deactivating $target": [
  null,
  "Avaktiverar $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Dedikerad paritet (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Avduplicering"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Delete group": [
  null,
  "Ta bort grupp"
 ],
 "Delete pool": [
  null,
  "Ta bort pool"
 ],
 "Deleting $target": [
  null,
  "Tar bort $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Tar bort LVM2 volymgruppen $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Om du tar bort en Stratis-pool raderas all data som den innehåller."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Att ta bort ett filsystem kommer att ta bort all data i det."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Att ta bort en logisk volym kommer att ta bort all data i den."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Att ta bort en partition kommer att ta bort all data i den."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Om du raderar raderas all data på en MDRAID-enhet."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Radering raderar all data på en VDO-enhet."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Om du raderar raderas all data i en volymgrupp."
 ],
 "Deleting erases all data on this subvolume and all it's children.": [
  null,
  "Om du raderar raderas all data på denna undervolym och alla dess barn."
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "Device": [
  null,
  "Enhet"
 ],
 "Device contains unrecognized data": [
  null,
  "Enhet innehåller okänd data"
 ],
 "Device file": [
  null,
  "Enhetsfil"
 ],
 "Device is read-only": [
  null,
  "Enheten är skrivskyddad"
 ],
 "Device number": [
  null,
  "Enhetsnummer"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Disconnect": [
  null,
  "Koppla ifrån"
 ],
 "Disk is OK": [
  null,
  "Disken är OK"
 ],
 "Disk is failing": [
  null,
  "Disken är på väg att gå sönder"
 ],
 "Disk passphrase": [
  null,
  "Disklösenfras"
 ],
 "Disks": [
  null,
  "Diskar"
 ],
 "Dismiss": [
  null,
  "Avfärda"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Distribuerad paritet (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Montera inte"
 ],
 "Do not mount automatically on boot": [
  null,
  "Montera inte automatiskt vid start"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "Does not mount during boot": [
  null,
  "Monterar inte vid uppstart"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Dubbel distribuerad paritet (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "Hämtar $0"
 ],
 "Drive": [
  null,
  "Enhet"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "EFI system partition": [
  null,
  "EFI-systempartition"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Edit Tang keyserver": [
  null,
  "Redigera Tang-nyckelserver"
 ],
 "Edit mount point": [
  null,
  "Redigera monteringspunkt"
 ],
 "Editing a key requires a free slot": [
  null,
  "Att redigera en nyckel kräver ett fritt fack"
 ],
 "Ejecting $target": [
  null,
  "Matar ut $target"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Emptying $target": [
  null,
  "Tömmer $target"
 ],
 "Enabling $0": [
  null,
  "Aktiverar $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Kryptera data med en Tang-nyckelserver"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Kryptera data med en lösenfras"
 ],
 "Encrypted $0": [
  null,
  "Krypterad $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "Krypterad Stratis-pool"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Krypterad logisk volym av $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Krypterad partition av $0"
 ],
 "Encryption": [
  null,
  "Kryptering"
 ],
 "Encryption options": [
  null,
  "Krypteringsalternativ"
 ],
 "Encryption type": [
  null,
  "Krypteringstyp"
 ],
 "Erasing $target": [
  null,
  "Raderar $target"
 ],
 "Error": [
  null,
  "Fel"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Fel vid installation $0: PackageKit är inte installerat"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Exakt $0 fysiska volymer måste väljas"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Exakt $0 fysiska volymer måste väljas, en för varje remsa av den logiska volymen."
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Extended partition": [
  null,
  "Utökad partition"
 ],
 "Failed": [
  null,
  "Misslyckades"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Filesystem": [
  null,
  "Filsystem"
 ],
 "Filesystem is locked": [
  null,
  "Filsystem är låst"
 ],
 "Filesystem name": [
  null,
  "Filsystemsnamn"
 ],
 "Filesystem outside the target": [
  null,
  "Filsystem utanför mål"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Filsystem är redan monterade under denna monteringspunkt."
 ],
 "Firmware version": [
  null,
  "Version på fastprogramvara"
 ],
 "Fix NBDE support": [
  null,
  "Fixa NBDE-stöd"
 ],
 "Format": [
  null,
  "Formatera"
 ],
 "Format $0": [
  null,
  "Formatera $0"
 ],
 "Format and mount": [
  null,
  "Formatera och montera"
 ],
 "Format and start": [
  null,
  "Formatera och starta"
 ],
 "Format only": [
  null,
  "Formatera endast"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formatering raderar all data på en lagringsenhet."
 ],
 "Free space": [
  null,
  "Ledigt utrymme"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "Grow": [
  null,
  "Utöka"
 ],
 "Grow content": [
  null,
  "Utöka innehållet"
 ],
 "Grow logical size of $0": [
  null,
  "Utöka den logiska storleken av $0"
 ],
 "Grow logical volume": [
  null,
  "Utöka en logisk volym"
 ],
 "Grow partition": [
  null,
  "Väx partition"
 ],
 "Grow the pool to take all space": [
  null,
  "Växa poolen så att den tar all plats"
 ],
 "Grow to take all space": [
  null,
  "Utöka till att ta allt utrymme"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "Hard Disk Drive": [
  null,
  "Hårddiskenhet"
 ],
 "Hide confirmation password": [
  null,
  "Dölj bekräftelselösenord"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "Host key is incorrect": [
  null,
  "Värdnyckeln är felaktig"
 ],
 "How to check": [
  null,
  "Hur man kontrollerar"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Jag bekräftar att jag vill förlora denna data för alltid"
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "INTERNT FEL - Denna logiska volym är markerad som aktiv och bör ha en tillhörande blockenhet. Ingen sådan blockenhet kunde dock hittas."
 ],
 "Important data might be deleted:": [
  null,
  "Viktig data kan raderas:"
 ],
 "In a terminal, run: ": [
  null,
  "I en terminal, kör: "
 ],
 "In sync": [
  null,
  "I synk"
 ],
 "Inactive logical volume": [
  null,
  "Inaktiv logisk volym"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Felaktig monteringsinformation"
 ],
 "Index memory": [
  null,
  "Indexminne"
 ],
 "Initialize": [
  null,
  "Initierar"
 ],
 "Initialize disk $0": [
  null,
  "Initierar disk $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Initiering raderar all data på en disk."
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Install NFS support": [
  null,
  "Installera stöd för NFS"
 ],
 "Install Stratis support": [
  null,
  "Installera Stratis stöd"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Att installera $0 skulle ta bort $1."
 ],
 "Installing packages": [
  null,
  "Installerar paket"
 ],
 "Internal error": [
  null,
  "Internt fel"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "Invalid username or password": [
  null,
  "Felaktigt användarnamn eller lösenord"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Jobs": [
  null,
  "Jobb"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Nyckelfack med okända typer kan inte redigeras här"
 ],
 "Key source": [
  null,
  "Nyckelkälla"
 ],
 "Keys": [
  null,
  "Nycklar"
 ],
 "Keyserver": [
  null,
  "Nyckelserver"
 ],
 "Keyserver address": [
  null,
  "Nyckelserverns adress"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Att ta bort nyckelservern kan förhindra upplåsning av $0."
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO Pool"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 logisk volym"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 logiska volymer"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fysisk volym"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 fysiska volymer"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 Volymgrupp"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 Volymgrupp $0"
 ],
 "Label": [
  null,
  "Etikett"
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Last cannot be removed": [
  null,
  "Den sista kan inte tas bort"
 ],
 "Last disk can not be removed": [
  null,
  "Den senaste disken kan inte tas bort"
 ],
 "Last modified: $0": [
  null,
  "Senast ändrad: $0"
 ],
 "Layout": [
  null,
  "Layout"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Linear": [
  null,
  "Linjär"
 ],
 "Linux filesystem data": [
  null,
  "Linux filsystem data"
 ],
 "Linux swap space": [
  null,
  "Linux växlingsutrymme"
 ],
 "Loading system modifications...": [
  null,
  "Läser in anpassningar till systemet..."
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "Local mount point": [
  null,
  "Lokal monteringspunkt"
 ],
 "Local storage": [
  null,
  "Lokal lagring"
 ],
 "Location": [
  null,
  "Plats"
 ],
 "Lock": [
  null,
  "Lås"
 ],
 "Locked data": [
  null,
  "Låst data"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Låst krypterad enhet kan innehålla data"
 ],
 "Locking $target": [
  null,
  "Låser $target"
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "Logical": [
  null,
  "Logisk"
 ],
 "Logical Volume Manager partition": [
  null,
  "Logisk volymhanterare-partition"
 ],
 "Logical size": [
  null,
  "Logisk storlek"
 ],
 "Logical volume": [
  null,
  "Logisk volym"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logisk volym (ögonblicksbild)"
 ],
 "Logical volume of $0": [
  null,
  "Logisk volym av $0"
 ],
 "Login failed": [
  null,
  "Inloggningen misslyckades"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "MDRAID device": [
  null,
  "MDRAID-enhet"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID-enhet $0"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID-enhet återställs"
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID-enhet måste vara igång"
 ],
 "MDRAID disk": [
  null,
  "MDRAID disk"
 ],
 "MDRAID disks": [
  null,
  "MDRAID diskar"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Manage filesystem sizes": [
  null,
  "Hantera filsystemstorlekar"
 ],
 "Manage storage": [
  null,
  "Hantera lagring"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Marking $target as faulty": [
  null,
  "Markerar $target som felaktig"
 ],
 "Media drive": [
  null,
  "Media enhet"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Metadata used": [
  null,
  "Metadata använt"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Speglad (RAID 1)"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Modifying $target": [
  null,
  "Modifiera $target"
 ],
 "Mount": [
  null,
  "Montering"
 ],
 "Mount Point": [
  null,
  "Monteringspunkt"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Montera efter att nätverket blir tillgängligt, ignorera fel"
 ],
 "Mount also automatically on boot": [
  null,
  "Montera också automatiskt vid start"
 ],
 "Mount at boot": [
  null,
  "Montera vid uppstart"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montera automatiskt på $0 vid start"
 ],
 "Mount before services start": [
  null,
  "Montera innan tjänster startar"
 ],
 "Mount configuration": [
  null,
  "Inställningar för monteringspunkter"
 ],
 "Mount filesystem": [
  null,
  "Montera filsystem"
 ],
 "Mount now": [
  null,
  "Montera nu"
 ],
 "Mount on $0 now": [
  null,
  "Montera på $0 nu"
 ],
 "Mount options": [
  null,
  "Monteringsflaggor"
 ],
 "Mount point": [
  null,
  "Monteringspunkt"
 ],
 "Mount point cannot be empty": [
  null,
  "Monteringspunkten kan inte vara tom"
 ],
 "Mount point cannot be empty.": [
  null,
  "Monteringspunkten får inte vara tom."
 ],
 "Mount point is already used for $0": [
  null,
  "Monteringspunkten är redan i användning för $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Monteringspunkten måste börja med ”/”."
 ],
 "Mount read only": [
  null,
  "Montera skrivskyddat"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Montera utan att vänta, ignorera fel"
 ],
 "Mounting $target": [
  null,
  "Monterar $target"
 ],
 "Mounts before services start": [
  null,
  "Monteras innan tjänster startar"
 ],
 "Mounts in parallel with services": [
  null,
  "Monteras parallellt med tjänster"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Monteras parallellt med tjänster, men efter nätverk är tillgängligt"
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "Multipathed devices": [
  null,
  "Flervägsenheter"
 ],
 "NFS mount": [
  null,
  "NFS-montering"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Name can not be empty.": [
  null,
  "Namnet får inte vara tomt."
 ],
 "Name cannot be empty.": [
  null,
  "Namnet får inte vara tomt."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Namnet får inte vara längre än $0 byte"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Namnet får inte vara längre än $0 tecken"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Namnet får inte vara längre än 127 tecken."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Namnet får inte vara längre än 255 tecken."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Namnet får inte innehålla tecknet ”$0”."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Namnet får inte innehålla tecknet '/'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Namnet får inte innehålla blanktecken."
 ],
 "Need a spare disk": [
  null,
  "Behöver en reservdisk"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "Networked storage": [
  null,
  "Nätverkslagring"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "New NFS mount": [
  null,
  "Ny NFS-montering"
 ],
 "New passphrase": [
  null,
  "Ny lösenfras"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "Next": [
  null,
  "Nästa"
 ],
 "No available slots": [
  null,
  "Inga tillgängliga fack"
 ],
 "No block devices are available.": [
  null,
  "Inga block enheter är tillgängliga."
 ],
 "No block devices found": [
  null,
  "Ingen blockenhet hittades"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "No devices found": [
  null,
  "Inga enheter hittades"
 ],
 "No disks are available.": [
  null,
  "Inga diskar är tillgängliga."
 ],
 "No disks found": [
  null,
  "Inga diskar hittades"
 ],
 "No drives found": [
  null,
  "Inga diskar funna"
 ],
 "No encryption": [
  null,
  "Ingen kryptering"
 ],
 "No filesystem": [
  null,
  "Inget filsystem"
 ],
 "No filesystems": [
  null,
  "Inga filsystem"
 ],
 "No free key slots": [
  null,
  "Inga fria nyckelfack"
 ],
 "No free space": [
  null,
  "Inget ledigt utrymme"
 ],
 "No free space after this partition": [
  null,
  "Inget ledigt utrymme efter denna partition"
 ],
 "No keys added": [
  null,
  "Inga nycklar tillagda"
 ],
 "No logical volumes": [
  null,
  "Inga logiska volymer"
 ],
 "No media inserted": [
  null,
  "Inget medium isatt"
 ],
 "No partitioning": [
  null,
  "Ingen partitionering"
 ],
 "No partitions found": [
  null,
  "Inga partitioner hittades"
 ],
 "No physical volumes found": [
  null,
  "Inga fysiska volymer hittades"
 ],
 "No storage found": [
  null,
  "Ingen lagring hittades"
 ],
 "No subvolumes": [
  null,
  "Inga undervolymer"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "No system modifications": [
  null,
  "Inga systemändringar"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Not enough free space": [
  null,
  "Inte tillräckligt med fritt utrymme"
 ],
 "Not enough space": [
  null,
  "Inte tillräckligt med utrymme"
 ],
 "Not enough space to grow": [
  null,
  "Inte tillräckligt med utrymme för att växa"
 ],
 "Not found": [
  null,
  "Finns inte"
 ],
 "Not permitted to perform this action.": [
  null,
  "Inte tillåtet att utföra denna åtgärd."
 ],
 "Not running": [
  null,
  "Kör inte"
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Occurrences": [
  null,
  "Förekomster"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Gammal lösenfras"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "När Cockpit är installerat, aktivera det med ”systemctl enable --now cockpit.socket”."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Endast $0 av $1 används."
 ],
 "Operation '$operation' on $target": [
  null,
  "Åtgärden ”$operation” på $target"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Other": [
  null,
  "Annan"
 ],
 "Overwrite": [
  null,
  "Skriv över"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Skriv över befintlig data med nollor (långsammare)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "Partition": [
  null,
  "Partition"
 ],
 "Partition of $0": [
  null,
  "Partition av $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Partitionsstorlek är $0. Innehållsstorlek är $1."
 ],
 "Partitioning": [
  null,
  "Partitionering"
 ],
 "Partitions": [
  null,
  "Partitioner"
 ],
 "Passphrase": [
  null,
  "Lösenfras"
 ],
 "Passphrase can not be empty": [
  null,
  "Lösenfrasen kan inte vara tom"
 ],
 "Passphrase cannot be empty": [
  null,
  "Lösenfrasen får inte vara tom"
 ],
 "Passphrase from any other key slot": [
  null,
  "Lösenfrasen från vilket annat nyckelfack som helst"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Att ta bort lösenfrasen kan förhindra upplåsning av $0."
 ],
 "Passphrases do not match": [
  null,
  "Lösenfraserna stämmer inte överens"
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Paste error": [
  null,
  "Klistra in fel"
 ],
 "Path on server": [
  null,
  "Sökväg på servern"
 ],
 "Path on server cannot be empty.": [
  null,
  "Sökvägen på servern får inte vara tom."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Sökvägen på servern måste börja med ”/”."
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "Permanently delete $0?": [
  null,
  "Permanent ta bort $0?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Vill du permanent ta bort logisk volym $0/$1?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Vill du permanent ta bort undervolym $0?"
 ],
 "Physical": [
  null,
  "Fysiskt"
 ],
 "Physical Volumes": [
  null,
  "Fysiska volymer"
 ],
 "Physical volumes": [
  null,
  "Fysiska volymer"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Storleken på fysiska volymer kan inte ändras här"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Please unmount them first.": [
  null,
  "Vänligen avmontera dem först."
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool för tunna logiska volymer"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool för tunt underhållna LVM2 logiska volymer"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool för tunt underhållna volymer"
 ],
 "Pool passphrase": [
  null,
  "Pool lösenfras"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP uppstartspartition"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "Processes using the location": [
  null,
  "Processer som använder platsen"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Ange lösenordsfrasen för poolen på dessa blockenheter:"
 ],
 "Purpose": [
  null,
  "Syfte"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Strimlor)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Spegel)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Strimlor av speglar)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (dedikerad paritet)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (distribuerad paritet)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dubbel distribuerad paritet)"
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "RAID level": [
  null,
  "RAID-nivå"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 behöver ett jämnt antal fysiska volymer"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Reading": [
  null,
  "Läser"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Recovering": [
  null,
  "Återställer"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Återställer MDRAID-enhet $target"
 ],
 "Regenerating initrd": [
  null,
  "Regenererar initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Relaterade processer och tjänster kommer tvingas stoppa."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Relaterade processer kommer tvingas stoppa."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Relaterade tjänster kommer tvingas stoppa."
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Remove": [
  null,
  "Ta bort"
 ],
 "Remove $0?": [
  null,
  "Ta bort $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Ta bort Tang-nyckelserver?"
 ],
 "Remove device": [
  null,
  "Ta bort enhet"
 ],
 "Remove missing physical volumes?": [
  null,
  "Ta bort saknade fysiska volymer?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Ta bort lösenfrasen i nyckelfack $0?"
 ],
 "Remove passphrase?": [
  null,
  "Ta bort lösenfras?"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Tar bort $target från MDRAID-enheten"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Att ta bort en lösenfras utan bekräftelse av en annan lösenfras kan förhindra upplåsning eller nyckelhantering, om andra lösenfraser glöms bort eller går förlorade."
 ],
 "Removing physical volume from $target": [
  null,
  "Tar bort den fysiska volymen från $target"
 ],
 "Rename": [
  null,
  "Byt namn"
 ],
 "Rename Stratis pool": [
  null,
  "Byt namn på Stratis pool"
 ],
 "Rename filesystem": [
  null,
  "Byt namn på filsystem"
 ],
 "Rename logical volume": [
  null,
  "Byt namn på en logisk volym"
 ],
 "Rename volume group": [
  null,
  "Byt namn på en volymgrupp"
 ],
 "Renaming $target": [
  null,
  "Byter namn på $target"
 ],
 "Repair": [
  null,
  "Reparera"
 ],
 "Repair logical volume $0": [
  null,
  "Reparera logisk volym $0"
 ],
 "Repairing $target": [
  null,
  "Reparerar $target"
 ],
 "Repeat passphrase": [
  null,
  "Upprepa lösenfrasen"
 ],
 "Resizing $target": [
  null,
  "Ändrar storlek på $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Ändra storlek på ett krypterat filsystem kräver upplåsning av disken. Ange en aktuell disklösenfras."
 ],
 "Reuse existing encryption": [
  null,
  "Återanvänd befintlig kryptering"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Återanvänd befintlig kryptering ($0)"
 ],
 "Row expansion": [
  null,
  "Radexpansion"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Running": [
  null,
  "Kör"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART-självtest av $target"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Spara utrymme genom att komprimera enskilda block med LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Spara utrymme genom att lagra identiska datablock bara en gång"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Att spara en ny lösenfras kräver att disken låses upp. Ge en aktuell disklösenfras."
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Securely erasing $target": [
  null,
  "Raderar säkert $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Säkerhetsförbättrad Linux-konfiguration och felsökning"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At leat $0 are needed.": [
  null,
  "Välj de fysiska volymer som ska användas för att reparera den logiska volymen. Minst $0 behövs."
 ],
 "Serial number": [
  null,
  "Serienummer"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server address": [
  null,
  "Serveradress"
 ],
 "Server address cannot be empty.": [
  null,
  "Serveradressen får inte vara tom."
 ],
 "Server cannot be empty.": [
  null,
  "Servern får inte vara tom."
 ],
 "Server has closed the connection.": [
  null,
  "Servern har stängt förbindelsen."
 ],
 "Service": [
  null,
  "Tjänst"
 ],
 "Services using the location": [
  null,
  "Tjänster som använder platsen"
 ],
 "Set partition type of $0": [
  null,
  "Ställ in partitionstyp till $0"
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Setting up loop device $target": [
  null,
  "Sätter upp vändslingeenheten $target"
 ],
 "Shell script": [
  null,
  "Skalskript"
 ],
 "Shift+Insert": [
  null,
  "Skift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "Visa alla $0 rader"
 ],
 "Show confirmation password": [
  null,
  "Visa bekräftelselösenord"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Shrink": [
  null,
  "Krymp"
 ],
 "Shrink logical volume": [
  null,
  "Krymp en logisk volym"
 ],
 "Shrink partition": [
  null,
  "Krymp partition"
 ],
 "Shrink volume": [
  null,
  "Krymp volym"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "Size cannot be negative": [
  null,
  "Storleken kan inte vara negativ"
 ],
 "Size cannot be zero": [
  null,
  "Storleken kan inte vara noll"
 ],
 "Size is too large": [
  null,
  "Storleken är för stor"
 ],
 "Size must be a number": [
  null,
  "Storleken måste vara ett tal"
 ],
 "Size must be at least $0": [
  null,
  "Storleken måste vara åtminstone $0"
 ],
 "Slot $0": [
  null,
  "Plats $0"
 ],
 "Snapshot": [
  null,
  "Ögonblicksbild"
 ],
 "Solid State Drive": [
  null,
  "SSD-enhet"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Vissa blockenheter i denna pool har vuxit i storlek efter att poolen skapades. Poolen kan säkert växa för att använda det nyligen tillgängliga utrymmet."
 ],
 "Sorry": [
  null,
  "Förlåt"
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Spare": [
  null,
  "Reserv"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Start": [
  null,
  "Starta"
 ],
 "Start multipath": [
  null,
  "Starta multipath"
 ],
 "Started": [
  null,
  "Startad"
 ],
 "Starting MDRAID device $target": [
  null,
  "Startar MDRAID-enhet $target"
 ],
 "Starting swapspace $target": [
  null,
  "Starta växlingsutrymmet $target"
 ],
 "State": [
  null,
  "Tillstånd"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "Stop": [
  null,
  "Stoppa"
 ],
 "Stop and remove": [
  null,
  "Stoppa och ta bort"
 ],
 "Stop and unmount": [
  null,
  "Stoppa och avmontera"
 ],
 "Stop device": [
  null,
  "Stoppa enhet"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Stoppar MDRAID-enhet $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Stoppar växlingsutrymmet $target"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Lagring kan inte hanteras på detta system."
 ],
 "Storage logs": [
  null,
  "Lagringsloggar"
 ],
 "Store passphrase": [
  null,
  "Lagra lösenfrasen"
 ],
 "Stored passphrase": [
  null,
  "Lagrad lösenfras"
 ],
 "Stratis block device": [
  null,
  "Stratis blockenhet"
 ],
 "Stratis block devices": [
  null,
  "Stratis blockenheter"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockenheter kan inte göras mindre"
 ],
 "Stratis filesystem": [
  null,
  "Stratis filsystem"
 ],
 "Stratis filesystems": [
  null,
  "Stratis filsystem"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis filsystem pool"
 ],
 "Stratis pool": [
  null,
  "Stratis-pool"
 ],
 "Striped (RAID 0)": [
  null,
  "Remsa (Raid 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Remsad och speglad (Raid 10)"
 ],
 "Stripes": [
  null,
  "Remsor"
 ],
 "Strong password": [
  null,
  "Starkt lösenord"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Subvolume needs to be mounted": [
  null,
  "Undervolym måste monteras"
 ],
 "Subvolume needs to be mounted writable": [
  null,
  "Undervolym måste monteras skrivbar"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Kopierade till urklipp!"
 ],
 "Swap": [
  null,
  "Växlingsutrymme"
 ],
 "Swap can not be resized here": [
  null,
  "Det går inte att ändra storlek på swap här"
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synkroniserar MDRAID-enheten $target"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "Tang keyserver": [
  null,
  "Tang-nyckelserver"
 ],
 "Target": [
  null,
  "Mål"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 paket är inte tillgängligt från något förråd."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Paketet $0 måste installeras för att skapa Stratis-pooler."
 ],
 "The $0 package must be installed.": [
  null,
  "Paketet $0 måste vara installerat."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Paketet $0 kommer att installeras för att skapa VDO-enheter."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID-enheten är i ett degraderat tillstånd"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID-enheten måste vara igång"
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Skapandet av denna VDO-enhet avslutade inte och enheten kan inte användas."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Användaren som för närvarande är inloggad har inte tillstånd att se information om nycklar."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Disken måste låsas upp innan formatering. Ange en befintlig lösenfras."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Filsystemet har ingen tilldelad monteringspunkt."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Filsystemet har ingen permanent monteringspunkt."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Filsystemet är konfigurerat att monteras automatiskt vid uppstart men dess krypteringsbehållare kommer inte att låsas upp vid den tidpunkten."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Filsystemet är för närvarande monterat men kommer inte att monteras efter nästa uppstart."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Filsystemet är för närvarande monterat på $0 men kommer att monteras på $1 vid nästa uppstart."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Filsystemet är för närvarande monterat på $0 men kommer inte att monteras efter nästa uppstart."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Filsystemet är för närvarande inte monterat men kommer att monteras vid nästa uppstart."
 ],
 "The filesystem is not mounted.": [
  null,
  "Filsystemet är inte monterat."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Filsystemet kommer att låsas upp och monteras vid nästa uppstart. Detta kan kräva att du matar in en lösenfras."
 ],
 "The initrd must be regenerated.": [
  null,
  "Initrd måste återskapas."
 ],
 "The last key slot can not be removed": [
  null,
  "Det sista nyckelfacket kan inte tas bort"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "De listade processerna och tjänsterna kommer tvingas stoppa."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "De listade processerna kommer att tvingas stoppa."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "De listade tjänsterna kommer att tvingas stoppa."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den inloggade användaren har inte tillåtelse att se systemändringar"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Monteringspunkten $0 används av dessa processer:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Monteringspunkten $0 används av dessa tjänster:"
 ],
 "The passwords do not match.": [
  null,
  "Lösenorden stämmer inte överens."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Servern vägrade att autentisera med några stödda metoder."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Systemet stöder för närvarande inte upplåsning av ett filsystem med en Tang-nyckelserver under uppstart."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Systemet stöder för närvarande inte upplåsning av rotfilsystemet med en Tang-nyckelserver."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Det finns enheter med flera sökvägar på systemet, men multipath-tjänsten kör inte."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Det finns inte tillräckligt med utrymme som kan användas för reparation. Minst $0 behövs för fysiska volymer som inte redan används för denna logiska volym."
 ],
 "There is not enough space in the pool to make a snapshot of this filesystem. At least $0 are required but only $1 are available.": [
  null,
  "Det finns inte tillräckligt med utrymme i poolen för att ta en ögonblicksbild av detta filsystem. Minst $0 krävs men endast $1 är tillgängligt."
 ],
 "These additional steps are necessary:": [
  null,
  "Dessa ytterligare steg är nödvändiga:"
 ],
 "These changes will be made:": [
  null,
  "Dessa ändringar kommer att göras:"
 ],
 "Thin logical volume": [
  null,
  "Tunn logisk volym"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Tunt provisionerade LVM2 logiska volymer"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce sychronization times significantly.": [
  null,
  "Denna MDRAID-enhet har ingen bitmap för skrivavsikt. En sådan bitmap kan minska synkroniseringstiderna avsevärt."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Denna NFS-montering används och endast dess alternativ kan ändras."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Denna VDO-enhet använder inte alla sina underliggande enheter."
 ],
 "This device can not be used for the installation target.": [
  null,
  "Den här enheten kan inte användas för installationsmålet."
 ],
 "This device is currently in use.": [
  null,
  "Den här enheten används för närvarande."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Denna nyckelserver är det enda sättet att låsa upp pool och kan inte tas bort."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Denna logiska volym har förlorat några av sina fysiska volymer och kan inte längre användas. Du måste ta bort den och skapa en ny för att ta dess plats."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Denna logiska volym har förlorat några av sina fysiska volymer men har inte förlorat några data ännu. Du bör reparera den för att återställa den ursprungliga redundansen."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Denna logiska volym har förlorat några av sina fysiska volymer men kanske inte har förlorat någon data ännu. Du kanske kan reparera den."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Denna logiska volym används inte helt av innehållet."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Denna partition används inte helt av innehållet."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Denna lösenfras är det enda sättet att låsa upp pool och kan inte tas bort."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Den här poolen använder inte allt utrymme på sina blockenheter."
 ],
 "This pool is in a degraded state.": [
  null,
  "Denna pool är i ett degraderat tillstånd."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Det här verktyget konfigurerar SELinux-policyn och kan hjälpa till med att förstå och lösa policy överträdelser."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Det här verktyget konfigurerar systemet till att kunna skriva kärnkraschdumpar till disken."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Detta verktyg genererar ett arkiv med konfiguration och diagnostisk information från det körande systemet. Arkivet kan förvaras lokalt eller centralt för inspelning eller spårningsändamål eller kan skickas till tekniska supportrepresentanter, utvecklare eller systemadministratörer för att hjälpa till med teknisk felspårning och felsökning."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Detta verktyg hanterar lokal lagring, såsom filsystem, LVM2-volymgrupper och NFS-monteringar."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Detta verktyg hanterar nätverk som bindningar, broar, team, VLAN och brandväggar med NetworkManager och Firewalld. NetworkManager är inkompatibelt med Ubuntus standard systemd-networkd och Debians ifupdown skript."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Den här volymgruppen saknar några fysiska volymer."
 ],
 "Tier": [
  null,
  "Nivå"
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Too much data": [
  null,
  "För mycket data"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Trust key": [
  null,
  "Förtroendenyckel"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Typ kan bara innehålla tecknen 0 till 9, A till F och \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Typ måste ha formatet NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Typ måste innehålla exakt två hexadecimala tecken (0 till 9, A till F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Kan inte nå servern"
 ],
 "Unable to remove mount": [
  null,
  "Kan inte ta bort monteringen"
 ],
 "Unable to repair logical volume $0": [
  null,
  "Kunde inte reparera logisk volym $0"
 ],
 "Unable to unmount filesystem": [
  null,
  "Kan inte avmontera filsystem"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Oväntat PackageKit-fel under installation av $0: $1"
 ],
 "Unformatted data": [
  null,
  "Oformaterad data"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Unknown ($0)": [
  null,
  "Okänt ($0)"
 ],
 "Unknown host name": [
  null,
  "Okänt värdnamn"
 ],
 "Unknown type": [
  null,
  "Okänd typ"
 ],
 "Unlock": [
  null,
  "Lås upp"
 ],
 "Unlock automatically on boot": [
  null,
  "Lås upp automatiskt vid start"
 ],
 "Unlock before resizing": [
  null,
  "Lås upp innan du ändrar storlek"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Lås upp krypterad Stratis pool"
 ],
 "Unlocking $target": [
  null,
  "Lås upp $target"
 ],
 "Unlocking disk": [
  null,
  "Låser upp disk"
 ],
 "Unmount": [
  null,
  "Avmontera"
 ],
 "Unmount filesystem $0": [
  null,
  "Avmontera filsystem $0"
 ],
 "Unmount now": [
  null,
  "Avmontera nu"
 ],
 "Unmounting $target": [
  null,
  "Avmonterar $target"
 ],
 "Unrecognized data": [
  null,
  "Okända data"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Okända data får inte göras mindre här"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Okända data får inte göras mindre här."
 ],
 "Unsupported logical volume": [
  null,
  "Den logiska volymen stöds inte"
 ],
 "Untrusted host": [
  null,
  "Ej betrodd värd"
 ],
 "Usage": [
  null,
  "Användning"
 ],
 "Usage of $0": [
  null,
  "Användning av $0"
 ],
 "Use": [
  null,
  "Använd"
 ],
 "Use compression": [
  null,
  "Använd komprimering"
 ],
 "Use deduplication": [
  null,
  "Använd deduplicering"
 ],
 "Used": [
  null,
  "Använt"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Användbart för monteringar som är valfria eller behöver interaktion (som lösenfraser)"
 ],
 "User": [
  null,
  "Användare"
 ],
 "Username": [
  null,
  "Användarnamn"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-underlagsenheter kan inte göras mindre"
 ],
 "VDO device $0": [
  null,
  "VDO-enhet $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-filsystemvolym (komprimering/deduplicering)"
 ],
 "Vendor": [
  null,
  "Leverantör"
 ],
 "Verify key": [
  null,
  "Verifiera nyckel"
 ],
 "Very securely erasing $target": [
  null,
  "Raderar mycket säkert $target"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "View automation script": [
  null,
  "Visa automatiseringsskript"
 ],
 "View logs": [
  null,
  "Visa loggar"
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Volume group": [
  null,
  "Volymgrupp"
 ],
 "Volume group is missing physical volumes": [
  null,
  "Volymgruppen saknar fysiska volymer"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Volymstorlek är $0. Innehållsstorlek är $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder skall bli klara"
 ],
 "Weak password": [
  null,
  "Svagt lösenord"
 ],
 "Web Console for Linux servers": [
  null,
  "Webbkonsol för Linuxservrar"
 ],
 "When this option is checked, the new pool will not allow overprovisioning. You need to specify a maximum size for each filesystem that is created in the pool. Filesystems can not be made larger after creation. Snapshots are fully allocated on creation. The sum of all maximum sizes can not exceed the size of the pool. The advantage of this is that filesystems in this pool can not run out of space in a surprising way. The disadvantage is that you need to know the maximum size for each filesystem in advance and creation of snapshots is limited.": [
  null,
  "När det här alternativet är markerat kommer den nya poolen inte att tillåta överprovisionering. Du måste ange en maximal storlek för varje filsystem som skapas i poolen. Filsystem kan inte göras större efter att de skapats. Ögonblicksbilder tilldelas helt när de skapas. Summan av alla maximala storlekar får inte överstiga poolens storlek. Fördelen med detta är att filsystemen i denna pool inte kan få ont om utrymme på ett överraskande sätt. Nackdelen är att du behöver veta den maximala storleken för varje filsystem i förväg och skapande av ögonblicksbilder är begränsad."
 ],
 "World wide name": [
  null,
  "Världsomfattande namn"
 ],
 "Write-mostly": [
  null,
  "Skriv huvudsakligen"
 ],
 "Writing": [
  null,
  "Skriver"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Din webbläsare tillåter inte att klistra in från sammanhangsmenyn. Du kan använda Skift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Din session har avslutats."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Din session har gått ut. Logga in igen."
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "after network": [
  null,
  "efter nätverk"
 ],
 "backing device for VDO device": [
  null,
  "bakomliggande enhet för VDO-enheten"
 ],
 "btrfs device": [
  null,
  "btrfs enhet"
 ],
 "btrfs devices": [
  null,
  "btrfs enheter"
 ],
 "btrfs filesystem": [
  null,
  "btrfs filsystem"
 ],
 "btrfs subvolume": [
  null,
  "btrfs undervolym"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs undervolym $0 av $1"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs undervolymer"
 ],
 "btrfs volume": [
  null,
  "btrfs volym"
 ],
 "cache": [
  null,
  "cache"
 ],
 "data": [
  null,
  "data"
 ],
 "deactivate": [
  null,
  "avaktivera"
 ],
 "delete": [
  null,
  "ta bort"
 ],
 "device of btrfs volume": [
  null,
  "enhet av btrfs volym"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "encrypted": [
  null,
  "krypterad"
 ],
 "format": [
  null,
  "formatera"
 ],
 "grow": [
  null,
  "väx"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI-disk"
 ],
 "iSCSI drives": [
  null,
  "iSCSI-diskar"
 ],
 "iSCSI portal": [
  null,
  "iSCSI-portal"
 ],
 "ignore failure": [
  null,
  "ignorera fel"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "initialize": [
  null,
  "initierar"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "member of MDRAID device": [
  null,
  "medlem i MDRAID-enhet"
 ],
 "member of Stratis pool": [
  null,
  "medlem i Stratis pool"
 ],
 "mount": [
  null,
  "montering"
 ],
 "never mount at boot": [
  null,
  "Montera aldrig vid uppstart"
 ],
 "none": [
  null,
  "ingen"
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fysisk volym på LVM2 volymgrupp"
 ],
 "read only": [
  null,
  "läs endast"
 ],
 "remove from LVM2": [
  null,
  "ta bort från LVM2"
 ],
 "remove from MDRAID": [
  null,
  "tar bort från MDRAID"
 ],
 "remove from btrfs volume": [
  null,
  "ta bort från btrfs volym"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "shrink": [
  null,
  "krymp"
 ],
 "stop": [
  null,
  "stoppa"
 ],
 "stop boot on failure": [
  null,
  "Stoppa uppstart vid misslyckande"
 ],
 "stopped": [
  null,
  "stoppad"
 ],
 "unknown target": [
  null,
  "okänt mål"
 ],
 "unmount": [
  null,
  "avmontera"
 ],
 "unpartitioned space on $0": [
  null,
  "opartitionerat utrymmer på $0"
 ],
 "using key description $0": [
  null,
  "använder nyckelbeskrivning $0"
 ],
 "yes": [
  null,
  "ja"
 ],
 "format-bytes\u0004bytes": [
  null,
  "byte"
 ]
});
