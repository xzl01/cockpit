cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Managing LVMs": [
  null,
  "Správa LVM svazků"
 ],
 "Managing NFS mounts": [
  null,
  "Správa NFS připojení"
 ],
 "Managing RAIDs": [
  null,
  "Správa RAID polí"
 ],
 "Managing VDOs": [
  null,
  "Správa VDO optimalizátorů"
 ],
 "Managing partitions": [
  null,
  "Správa oddílů"
 ],
 "Managing physical drives": [
  null,
  "Správa fyzických disků"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Using LUKS encryption": [
  null,
  "S použitím LUKS šifrování"
 ],
 "Using Tang server": [
  null,
  "S použitím Tang serveru"
 ],
 "disk": [
  null,
  "disk"
 ],
 "drive": [
  null,
  "jednotka"
 ],
 "encryption": [
  null,
  "šifrování"
 ],
 "filesystem": [
  null,
  "souborový systém"
 ],
 "format": [
  null,
  "formátovat"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "mount"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "oddíl"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "odpojit (unmount)"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "svazek"
 ]
});
