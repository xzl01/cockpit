cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 není možné zvětšit"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 není možné zmenšit"
 ],
 "$0 can not be resized": [
  null,
  "$0 není možné změnit velikost"
 ],
 "$0 can not be resized here": [
  null,
  "$0 zde není možné změnit velikost"
 ],
 "$0 chunk size": [
  null,
  "$0 velikost bloku dat"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 režie využito z $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk chybí",
  "$0 disky chybí",
  "$0 disků chybí"
 ],
 "$0 disks": [
  null,
  "$0 disky"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "$0 filesystem": [
  null,
  "$0 souborový systém"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 is in use": [
  null,
  "$0 je používáno"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 key changed": [
  null,
  "$0 klíč změněn"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 partitions": [
  null,
  "$0 oddíly"
 ],
 "$0 slot remains": [
  null,
  "$0 slot zbývá",
  "$0 sloty zbývají",
  "$0 slotů zbývá"
 ],
 "$0 synchronized": [
  null,
  "$0 synchronizováno"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "použito $0 z $1 ($2 ušetřeno)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 použito, $1 celkem"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainstalováno."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "$name (from $host)": [
  null,
  "$name (z $host)"
 ],
 "(Not part of target)": [
  null,
  "(Není součástí cíle)"
 ],
 "(no assigned mount point)": [
  null,
  "(nepřiřazen žádný přípojný bod)"
 ],
 "(not mounted)": [
  null,
  "(nepřipojeno)"
 ],
 "(recommended)": [
  null,
  "(doporučeno)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 není nainstalovaná kompatibilní verze Cockpit."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Souborový systém s tímto názvem už v tomto fondu existuje."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vytvořen nový SSH klíč pro $1 na $2 a bude přidán do souboru $3 od $4 na $5."
 ],
 "A pool with this name exists already.": [
  null,
  "Fond s tímto názvem už existuje."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Skupinu svazků, ve které chybí fyzické svazky, není možné přejmenovat."
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Action": [
  null,
  "Akce"
 ],
 "Actions": [
  null,
  "Akce"
 ],
 "Activate": [
  null,
  "Aktivovat"
 ],
 "Activate before resizing": [
  null,
  "Aktivujte před změnou velikosti"
 ],
 "Activating $target": [
  null,
  "Aktivuje se $targetk"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Přidat šifrování disku vázané na síť"
 ],
 "Add Tang keyserver": [
  null,
  "Přidat Tang server s klíči"
 ],
 "Add a bitmap": [
  null,
  "Přidat bitovou mapu"
 ],
 "Add block devices": [
  null,
  "Přidat blokové zařízení"
 ],
 "Add disk": [
  null,
  "Přidat disk"
 ],
 "Add disks": [
  null,
  "Přidat disky"
 ],
 "Add iSCSI portal": [
  null,
  "Přidat iSCSI portál"
 ],
 "Add key": [
  null,
  "Přidat klíč"
 ],
 "Add keyserver": [
  null,
  "Přidat server s klíči"
 ],
 "Add passphrase": [
  null,
  "Přidat heslovou frázi"
 ],
 "Add physical volume": [
  null,
  "Přidat fyzický svazek"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Přidává se „$0“ do možností šifrování"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Přidává se „$0“ do možností souborového systému"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Přidání serveru s klíči vyžaduje odemknutí fondu. Zadejte stávající heslovou frázi k fondu."
 ],
 "Adding key": [
  null,
  "Přidává se klíč"
 ],
 "Adding physical volume to $target": [
  null,
  "Přidává se fyzický svazek do $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Přidává se rd.neednet=1 do parametrů zavádění jádra"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "Address cannot be empty": [
  null,
  "Adresu je třeba vyplnit"
 ],
 "Address is not a valid URL": [
  null,
  "Do adresy nebyla vyplněná platná URL"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Všech $0 vybraných fyzických svazků je třeba pro zvolené rozvržení."
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Allocated": [
  null,
  "Přiděleno"
 ],
 "Allow overprovisioning": [
  null,
  "Umožnit přidělování více prostředků, než je k dispozici"
 ],
 "An additional $0 must be selected": [
  null,
  "Je třeba vybrat další $0"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Příhodné pro kriticky důležité přípojné body, jako např. /var"
 ],
 "Assessment": [
  null,
  "Posouzení"
 ],
 "At boot": [
  null,
  "Při startu systému"
 ],
 "At least $0 disk is needed.": [
  null,
  "Je vyžadován alespoň $0 disk.",
  "Jsou vyžadovány alespoň $0 disky.",
  "Je vyžadováno alespoň $0 disků."
 ],
 "At least one block device is needed.": [
  null,
  "Je vyžadováno alespoň jedno blokové zařízení."
 ],
 "At least one disk is needed.": [
  null,
  "Je vyžadován alespoň jeden disk."
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Je třeba, aby byl připojený alespoň jeden dílčí svazek"
 ],
 "Authentication": [
  null,
  "Ověření se"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ],
 "Authentication required": [
  null,
  "Nutné ověření se"
 ],
 "Authorize SSH key": [
  null,
  "Pověřit SSH klíč"
 ],
 "Automatically using NTP": [
  null,
  "Automatické použití NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické použití dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatické použití uvedených NTP serverů"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "Available targets on $0": [
  null,
  "Cíle dostupné na $0"
 ],
 "BIOS boot partition": [
  null,
  "Oddíl pro BIOS zavádění"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Block device": [
  null,
  "Blokové zařízení"
 ],
 "Block device for filesystems": [
  null,
  "Blokové zařízení pro souborové systémy"
 ],
 "Block devices": [
  null,
  "Bloková zařízení"
 ],
 "Blocked": [
  null,
  "Blokované"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Pokud souborový systém nebude připojen, start operačního systému se nezdaří a nebude tak možný vzdálený přístup"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Start operačního systému se zdaří i když souborový systém nebude připojen"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "Cache": [
  null,
  "Mezipaměť"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "Capacity": [
  null,
  "Kapacita"
 ],
 "Category": [
  null,
  "Kategorie"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change iSCSI initiater name": [
  null,
  "Změnit název iSCSI iniciátoru"
 ],
 "Change iSCSI initiator name": [
  null,
  "Změnit název iSCSI iniciátoru"
 ],
 "Change label": [
  null,
  "Změnit štítek"
 ],
 "Change passphrase": [
  null,
  "Změnit heslovou frázi"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Změněné klíče jsou často výsledkem přeinstalace operačního systému. Nicméně, neočekávaná změna může značit pokus třetí strany o vložení se do vaší komunikace."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Změna typů oddílů může bránit nastartování systému."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Zkontrolujte, že se SHA-256 nebo SHA-1 otisk z příkazu shoduje s tímto dialogem."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Zkontrolovat otisk klíče vůči Tang serveru."
 ],
 "Checking $target": [
  null,
  "Kontroluje se $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Kontroluje se RAID zařízení $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Kontroluje a opravuje se MDRAID zařízení $target"
 ],
 "Checking filesystem usage": [
  null,
  "Zjišťování využití souborového systému"
 ],
 "Checking for $0 package": [
  null,
  "Zjišťování pro $0 balíček"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Zjišťování přítomnosti podpory NBDE v initrd"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Chunk size": [
  null,
  "Velikost bloku"
 ],
 "Cleaning up for $target": [
  null,
  "Čištění pro $target"
 ],
 "Cleartext device": [
  null,
  "Znakové zařízení"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je nástroj, který usnadňuje správu linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit není nainstalován"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce systémů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Je možné souběžně sledovat a spravovat několik serverů naráz. Stačí je jedním kliknutím přidat a vaše stroje se budou starat o své kamarády."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "Command": [
  null,
  "Příkaz"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibilní se všemi systémy a zařízeními (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibilní s moderním systémem a pevnými disky > 2TB (GPT)"
 ],
 "Compression": [
  null,
  "Komprese"
 ],
 "Confirm": [
  null,
  "Potvrdit"
 ],
 "Confirm deletion of $0": [
  null,
  "Potvrďte smazání $0"
 ],
 "Confirm key password": [
  null,
  "Potvrdit heslo ke klíči"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Potvrdit odebrání pomocí alternativní heslové fráze"
 ],
 "Confirm stopping of $0": [
  null,
  "Potvrďte zastavení $0"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copied": [
  null,
  "Zkopírováno"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Create LVM2 volume group": [
  null,
  "Vytvořit LVM2 skupinu svazků"
 ],
 "Create MDRAID device": [
  null,
  "Vytvořit MDRAID zařízení"
 ],
 "Create RAID device": [
  null,
  "Vytvořit RAID zařízení"
 ],
 "Create Stratis pool": [
  null,
  "Vytvořit Stratis fond úložiště"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvořit nový SSH klíč a pověřit ho"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Pořídit zachycený stav souborového systému $0"
 ],
 "Create and mount": [
  null,
  "Vytvořit a připojit"
 ],
 "Create and start": [
  null,
  "Vytvořit a spustit"
 ],
 "Create filesystem": [
  null,
  "Vytvořit souborový systém"
 ],
 "Create logical volume": [
  null,
  "Vytvořit logický svazek"
 ],
 "Create new filesystem": [
  null,
  "Vytvořit nový souborový systém"
 ],
 "Create new logical volume": [
  null,
  "Vytvořit nový logický svazek"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořte nový soubor s úlohou s tímto obsahem."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Vytvořit nový tence (thin) poskytovaný logický svazek"
 ],
 "Create only": [
  null,
  "Pouze vytvořit"
 ],
 "Create partition": [
  null,
  "Vytvořit oddíl"
 ],
 "Create partition on $0": [
  null,
  "Vytvořit oddíl na $0"
 ],
 "Create partition table": [
  null,
  "Vytvořit tabulku rozdělení na oddíly"
 ],
 "Create snapshot": [
  null,
  "Pořídit zachycený stav"
 ],
 "Create snapshot and mount": [
  null,
  "Pořídit zachycený stav a připojit ho"
 ],
 "Create snapshot only": [
  null,
  "Pouze pořídit zachycený stav"
 ],
 "Create storage device": [
  null,
  "Vytvořit zařízení úložiště"
 ],
 "Create subvolume": [
  null,
  "Vytvořit dílčí svazek"
 ],
 "Create thin volume": [
  null,
  "Vytvořit tence poskytovaný (thin provided) svazek"
 ],
 "Create volume group": [
  null,
  "Vytvořit skupinu svazků"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Vytváří se LVM2 skupina svazků $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "Vytváří se MDRAID zařízení $target"
 ],
 "Creating VDO device": [
  null,
  "Vytváří se VDO zařízení"
 ],
 "Creating filesystem on $target": [
  null,
  "Vytváří se souborový systém na $target"
 ],
 "Creating logical volume $target": [
  null,
  "Vytváří se logický svazek $target"
 ],
 "Creating partition $target": [
  null,
  "Vytváří se oddíl $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Pořizování zachyceného stavu $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Nepoužíváno"
 ],
 "Custom": [
  null,
  "Uživatelsky určené"
 ],
 "Custom mount options": [
  null,
  "Uživatelsky určené předvolby připojení"
 ],
 "Custom type": [
  null,
  "Uživatelsky určený typ"
 ],
 "Data": [
  null,
  "Data"
 ],
 "Data used": [
  null,
  "Využito dat"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Data budou ukládána jako dvě kopie a ty pak střídavě na označených fyzických svazcích, což zlepší jak spolehlivost, tak výkon. Je třeba vybrat alespoň 4 svazky."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Data budou ukládána jako dvě či více kopií na vybraných fyzických svazcích, což zlepší spolehlivost. Je třeba vybrat alespoň dva svazky."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích střídavě, což zlepší výkon. Je třeba vybrat alespoň dva svazky."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích tak, že bude možné jeden z nich ztratit, aniž by to postihlo data. Je třeba vybrat alespoň tři svazky."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích tak, že bude možné jeden z nich ztratit, aniž by to postihlo data. Bude také zlepšen výkon ukládáním dat střídavě. Je třeba vybrat alespoň tři svazky."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích tak, že bude možné ztratit až dva naráz, aniž by to postihlo data. Bude také zlepšen výkon ukládáním dat střídavě. Je třeba vybrat alespoň pět svazků."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích bez jakékoli dodatečné odolnosti či zlepšení výkonu."
 ],
 "Deactivate": [
  null,
  "Deaktivovat"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Deaktivovat logický svazek $0/$1?"
 ],
 "Deactivating $target": [
  null,
  "Deaktivuje se $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Vyhrazená parita (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Deduplikace"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Delete group": [
  null,
  "Smazat skupinu"
 ],
 "Delete pool": [
  null,
  "Smazat fond"
 ],
 "Deleting $target": [
  null,
  "Maže se $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Maže se LVM2 skupina svazků $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Smazání Stratis fondu vymaže veškerá data na něm."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Smazání souborového systému vymaže veškerá data na něm."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Smazání logického svazku vymaže veškerá data na něm."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Smazání oddílu vymaže veškerá data na něm."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Smazání vymaže veškerá data na MDRAID zařízení."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Smazání vymaže veškerá data na VDO zařízení."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Smazání vymaže veškerá data ve skupině svazků."
 ],
 "Deleting erases all data on this subvolume and all it's children.": [
  null,
  "Smazání vymaže veškerá data na tomto dílčím svazku a všech jemu podřízeným."
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "Device": [
  null,
  "Zařízení"
 ],
 "Device contains unrecognized data": [
  null,
  "Zařízení obsahuje nerozpoznaná data"
 ],
 "Device file": [
  null,
  "Soubor představující zařízení"
 ],
 "Device is read-only": [
  null,
  "Zařízení je pouze pro čtení"
 ],
 "Device number": [
  null,
  "Číslo zařízení"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Disconnect": [
  null,
  "Odpojit"
 ],
 "Disk is OK": [
  null,
  "Disk je OK"
 ],
 "Disk is failing": [
  null,
  "Disk selhává"
 ],
 "Disk passphrase": [
  null,
  "Heslová fráze k disku"
 ],
 "Disks": [
  null,
  "Disky"
 ],
 "Dismiss": [
  null,
  "Zahodit"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Distribuovaná parita (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Nepřipojovat"
 ],
 "Do not mount automatically on boot": [
  null,
  "Nepřipojovat automaticky při startu systému"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "Does not mount during boot": [
  null,
  "Nepřipojuje se při startu systému"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Dvojitá distribuovaná parita (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Drive": [
  null,
  "Jednotka"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "EFI system partition": [
  null,
  "Systémový oddíl EFI"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Edit Tang keyserver": [
  null,
  "Upravit Tang server s klíči"
 ],
 "Edit mount point": [
  null,
  "Upravit přípojný bod"
 ],
 "Editing a key requires a free slot": [
  null,
  "K upravení klíče je zapotřebí volného slotu"
 ],
 "Ejecting $target": [
  null,
  "Vysouvání $target"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Emptying $target": [
  null,
  "Vyprazdňuje se $target"
 ],
 "Enabling $0": [
  null,
  "Povoluje se $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Šifrovat data pomocí Tang serveru s klíči"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Šifrovat data pomocí heslové fráze"
 ],
 "Encrypted $0": [
  null,
  "Šifrované $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "Šifrovaný Stratis fond"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Šifrovaný logický svazek na $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Šifrovaný oddíl na $0"
 ],
 "Encryption": [
  null,
  "Šifrování"
 ],
 "Encryption options": [
  null,
  "Předvolby šifrování"
 ],
 "Encryption type": [
  null,
  "Typ šifrování"
 ],
 "Erasing $target": [
  null,
  "Vymazává se $target"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Chyba při instalování $0: PackageKit není nainstalovaný"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Je třeba vybrat přesně $0 fyzických svazků"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Je třeba vybrat přesně $0 fyzických svazků – jeden pro každý z proužků logického svazku."
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Extended partition": [
  null,
  "Rozšířený oddíl"
 ],
 "Failed": [
  null,
  "Neúspěšné"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Filesystem": [
  null,
  "Souborový systém"
 ],
 "Filesystem is locked": [
  null,
  "Souborový systém je uzamčen"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Souborový systém je připojen pouze pro čtení"
 ],
 "Filesystem name": [
  null,
  "Název souborového systému"
 ],
 "Filesystem outside the target": [
  null,
  "Souborový systém vně cíle"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Do tohoto přípojného bodu už jsou připojené souborové systémy."
 ],
 "Firmware version": [
  null,
  "Verze firmware"
 ],
 "Fix NBDE support": [
  null,
  "Opravit podporu pro NBDE"
 ],
 "Format": [
  null,
  "Formát"
 ],
 "Format $0": [
  null,
  "Naformátovat $0"
 ],
 "Format and mount": [
  null,
  "Naformátovat a připojit"
 ],
 "Format and start": [
  null,
  "Naformátovat a spustit"
 ],
 "Format only": [
  null,
  "Pouze naformátovat"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formátování vymaže všechna data na úložném zařízení."
 ],
 "Free space": [
  null,
  "Volné místo"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "Grow": [
  null,
  "Zvětšit"
 ],
 "Grow content": [
  null,
  "Zvětšit obsah"
 ],
 "Grow logical size of $0": [
  null,
  "Zvětšit logickou velikost $0"
 ],
 "Grow logical volume": [
  null,
  "Zvětšit logický svazek"
 ],
 "Grow partition": [
  null,
  "Zvětšit oddíl"
 ],
 "Grow the pool to take all space": [
  null,
  "Zvětšit fond tak, aby využil veškerý dostupný prostor"
 ],
 "Grow to take all space": [
  null,
  "Zvětšit tak, aby využilo veškerý dostupný prostor"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Hard Disk Drive": [
  null,
  "Jednotka pevného disku"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "How to check": [
  null,
  "Jak zkontrolovat"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Potvrzuji, že chci tato data natrvalo ztratit"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "VNITŘNÍ CHYBA – Tento logický svazek je označen jako aktivní a měl by mít přiřazené blokové zařízení. Žádné takové blokové zařízení však nebylo nalezeno."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Pokud se otisk shoduje, klikněte na „Důvěřovat a přidat stroj“. V opačném případě se nepřipojujte a obraťte se na správce."
 ],
 "Important data might be deleted:": [
  null,
  "Může se stát, že budou smazána důležitá data:"
 ],
 "In a terminal, run: ": [
  null,
  "V terminálu spusťte: "
 ],
 "In sync": [
  null,
  "Synchronní"
 ],
 "Inactive logical volume": [
  null,
  "Neaktivní logický svazek"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Nekonzistentní připojení souborového systému"
 ],
 "Index memory": [
  null,
  "Paměť indexu"
 ],
 "Initialize": [
  null,
  "inicializovat"
 ],
 "Initialize disk $0": [
  null,
  "Inicializovat disk $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Inicializace vymaže veškerá data na disku."
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install NFS support": [
  null,
  "Nainstalovat podporu pro NFS"
 ],
 "Install Stratis support": [
  null,
  "Nainstalovat podporu pro Stratis"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Instalace $0 by odebrala $1."
 ],
 "Installing packages": [
  null,
  "Instalují se balíčky"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná oprávnění k souboru"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "Invalid username or password": [
  null,
  "Neplatné uživatelské jméno a heslo"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Jobs": [
  null,
  "Úlohy"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Key password": [
  null,
  "Heslo ke klíči"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Sloty klíčů s neznámým typem zde není možné upravovat"
 ],
 "Key source": [
  null,
  "Zdroj klíče"
 ],
 "Keys": [
  null,
  "Klíče"
 ],
 "Keyserver": [
  null,
  "Server s klíči"
 ],
 "Keyserver address": [
  null,
  "Adresa serveru s klíči"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Odebrání serveru s klíči může zabránit odemčení $0."
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO fond"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 logický svazek"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 logické oddíly"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fyzický svazek"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 fyzické svazky"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 skupina svazků"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 skupina svazků $0"
 ],
 "Label": [
  null,
  "Štítek"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Last cannot be removed": [
  null,
  "Poslední zbývající není možné odebrat"
 ],
 "Last disk can not be removed": [
  null,
  "Poslední zbývající disk není možné odebrat"
 ],
 "Last modified: $0": [
  null,
  "Naposledy zkontrolováno: $0"
 ],
 "Layout": [
  null,
  "Rozvržení"
 ],
 "Learn more": [
  null,
  "Zjistit více"
 ],
 "Limit size": [
  null,
  "Omezit velikost"
 ],
 "Limit virtual filesystem size": [
  null,
  "Omezit virtuální velikost souborového systému"
 ],
 "Linear": [
  null,
  "Lineární"
 ],
 "Linux filesystem data": [
  null,
  "Data linuxového souborového systému"
 ],
 "Linux swap space": [
  null,
  "Odkládací prostor Linux"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "Local mount point": [
  null,
  "Místní přípojný bod"
 ],
 "Local storage": [
  null,
  "Lokální úložiště"
 ],
 "Location": [
  null,
  "Umístění"
 ],
 "Lock": [
  null,
  "Uzamknout"
 ],
 "Lock $0?": [
  null,
  "Uzamknout $0?"
 ],
 "Locked data": [
  null,
  "Uzamčená data"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Je možné, že uzamčené šifrované zařízení obsahuje data"
 ],
 "Locking $target": [
  null,
  "Uzamyká se $target"
 ],
 "Log in": [
  null,
  "Přihlásit se"
 ],
 "Log in to $0": [
  null,
  "Přihlásit se k $0"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "Logical": [
  null,
  "Logický"
 ],
 "Logical Volume Manager partition": [
  null,
  "Oddíl správy logických svazků"
 ],
 "Logical size": [
  null,
  "Logická velikost"
 ],
 "Logical volume": [
  null,
  "Logický svazek"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logický svazek (zachycený stav)"
 ],
 "Logical volume of $0": [
  null,
  "Logický svazek na $0"
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "MDRAID device": [
  null,
  "MDRAID zařízení"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID zařízení $0"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID zařízení se zotavuje"
 ],
 "MDRAID device must be running": [
  null,
  "Je třeba, aby MDRAID zařízení bylo spuštěné"
 ],
 "MDRAID disk": [
  null,
  "MDRAID disk"
 ],
 "MDRAID disks": [
  null,
  "MDRAID disky"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Marking $target as faulty": [
  null,
  "Označování $target jako vadný"
 ],
 "Media drive": [
  null,
  "Jednotka média"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Metadata used": [
  null,
  "Využito metadat"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Zrcadlené (RAID 1)"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Modifying $target": [
  null,
  "Upravuje se $target"
 ],
 "Mount": [
  null,
  "Připojit (mount)"
 ],
 "Mount Point": [
  null,
  "Přípojný bod"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Připojit až bude síť k dispozici, ignorovat nezdar"
 ],
 "Mount also automatically on boot": [
  null,
  "Připojovat také automaticky při startu systému"
 ],
 "Mount at boot": [
  null,
  "Připojit při startu"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Při startu systému automaticky připojit do $0"
 ],
 "Mount before services start": [
  null,
  "Připojit před spuštěním služeb"
 ],
 "Mount configuration": [
  null,
  "Nastavení připojení (mount)"
 ],
 "Mount filesystem": [
  null,
  "Připojit souborový systém"
 ],
 "Mount now": [
  null,
  "Připojit nyní"
 ],
 "Mount on $0 now": [
  null,
  "Připojit do $0 nyní"
 ],
 "Mount options": [
  null,
  "Předvolby připojení"
 ],
 "Mount point": [
  null,
  "Přípojný bod"
 ],
 "Mount point cannot be empty": [
  null,
  "Je třeba vyplnit přípojný bod"
 ],
 "Mount point cannot be empty.": [
  null,
  "Přípojný bod je třeba vyplnit."
 ],
 "Mount point is already used for $0": [
  null,
  "Přípojný bod už je používán pro $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Je třeba, aby popis přípojného bodu začínal na „/“."
 ],
 "Mount read only": [
  null,
  "Připojit pouze pro čtení"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Připojit bez čekání, ignorovat nezdar"
 ],
 "Mounting $target": [
  null,
  "Připojování $target"
 ],
 "Mounts before services start": [
  null,
  "Připojit před spuštěním služeb"
 ],
 "Mounts in parallel with services": [
  null,
  "Bude připojeno souběžně se službami"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Připojuje souběžně se službami, ale až poté, co je k dispozici síť"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "Multipathed devices": [
  null,
  "Zařízení s vícero cestami (multipath)"
 ],
 "NFS mount": [
  null,
  "NFS připojení"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Name can not be empty.": [
  null,
  "Název je třeba vyplnit."
 ],
 "Name cannot be empty.": [
  null,
  "Název je třeba vyplnit."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Název nemůže být delší než $0 bajtů"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Název nemůže být delší než $0 znaků"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Název nemůže být delší než 127 znaků."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Název nemůže být delší než 255 znaků."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Název nemůže obsahovat znak „$0“."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Název nemůže obsahovat znak „/“."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Název nemůže obsahovat prázdný znak."
 ],
 "Need a spare disk": [
  null,
  "Potřebujete rezervní disk"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Networked storage": [
  null,
  "Síťové úložiště"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "New NFS mount": [
  null,
  "Nové NFS připojení"
 ],
 "New passphrase": [
  null,
  "Nová heslová fráze"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "Next": [
  null,
  "Další"
 ],
 "No available slots": [
  null,
  "Nejsou k dispozici žádné sloty"
 ],
 "No block devices are available.": [
  null,
  "Nejsou k dispozici žádná bloková zařízení."
 ],
 "No block devices found": [
  null,
  "Nenalezena žádná bloková zařízení"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "No devices found": [
  null,
  "Nenalezena žádná zařízení"
 ],
 "No disks are available.": [
  null,
  "Nejsou k dispozici žádné disky."
 ],
 "No disks found": [
  null,
  "Nenalezeny žádné disky"
 ],
 "No drives found": [
  null,
  "Nenalezeny žádné jednotky"
 ],
 "No encryption": [
  null,
  "Bez šifrování"
 ],
 "No filesystem": [
  null,
  "Žádný souborový systém"
 ],
 "No filesystems": [
  null,
  "Žádné souborové systémy"
 ],
 "No free key slots": [
  null,
  "Žádné volné sloty klíčů"
 ],
 "No free space": [
  null,
  "Žádné volné místo"
 ],
 "No free space after this partition": [
  null,
  "Za tímto oddílem už není žádné volné místo"
 ],
 "No keys added": [
  null,
  "Nepřidány žádné klíče"
 ],
 "No logical volumes": [
  null,
  "Žádné logické svazky"
 ],
 "No media inserted": [
  null,
  "Není vloženo žádné médium"
 ],
 "No partitioning": [
  null,
  "Žádný oddíl"
 ],
 "No partitions found": [
  null,
  "Nenalezeny žádné oddíly"
 ],
 "No physical volumes found": [
  null,
  "Nenalezeny žádné fyzické svazky"
 ],
 "No results found": [
  null,
  "Nenalezeny žádné výsledky"
 ],
 "No snapshots found": [
  null,
  "Nenalezeny žádné zachycené stavy"
 ],
 "No storage found": [
  null,
  "Nenalezeno žádné úložiště"
 ],
 "No subvolumes": [
  null,
  "Žádné dílčí svazky"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Not enough free space": [
  null,
  "Nedostatek volného prostoru"
 ],
 "Not enough space": [
  null,
  "Nedostatek prostoru"
 ],
 "Not enough space to grow": [
  null,
  "Pro zvětšení není k dispozici dostatek prostoru"
 ],
 "Not found": [
  null,
  "Nenalezeno"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Not running": [
  null,
  "Není spuštěné"
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "Původní heslová fráze"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Je použito pouze $0 z $1."
 ],
 "Operation '$operation' on $target": [
  null,
  "Operace „$operation“ na $target"
 ],
 "Options": [
  null,
  "Přepínače"
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Overprovisioning": [
  null,
  "Přidělování více prostředků, než je k dispozici"
 ],
 "Overwrite": [
  null,
  "Přepsat"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Přepsat existující data nulami (pomalejší)"
 ],
 "PID": [
  null,
  "Identif. procesu"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Partition": [
  null,
  "Oddíl"
 ],
 "Partition of $0": [
  null,
  "Oddíl na $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Velikost oddílu je $0. Velikost obsahu na něm je $1."
 ],
 "Partitioning": [
  null,
  "Vytváření oddílů"
 ],
 "Partitions": [
  null,
  "Oddíly"
 ],
 "Passphrase": [
  null,
  "Heslová fráze"
 ],
 "Passphrase can not be empty": [
  null,
  "Heslovou frázi je třeba vyplnit"
 ],
 "Passphrase cannot be empty": [
  null,
  "Heslovou frázi je třeba vyplnit"
 ],
 "Passphrase from any other key slot": [
  null,
  "Heslová fráze z libovolného jiného slotu s klíčem"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Odebrání heslové fráze může bránit odemknutí $0."
 ],
 "Passphrases do not match": [
  null,
  "Zadání heslové fráze se neshodují"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nepřijato"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Path on server": [
  null,
  "Popis umístění na serveru"
 ],
 "Path on server cannot be empty.": [
  null,
  "Popis umístění na serveru je třeba vyplnit."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Je třeba, aby popis umístění na serveru začínal na „/“."
 ],
 "Path to file": [
  null,
  "Popis umístění souboru"
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "Permanently delete $0?": [
  null,
  "Nenávratně smazat $0?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Nenávratně smazat logický svazek $0/&1?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Nenávratně smazat dílčí svazek $0?"
 ],
 "Physical": [
  null,
  "Fyzické"
 ],
 "Physical Volumes": [
  null,
  "Fyzické svazky"
 ],
 "Physical volumes": [
  null,
  "Fyzické svazky"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Zde není možné měnit velikost fyzických svazků"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Please unmount them first.": [
  null,
  "Prosím nejprve je odpojte."
 ],
 "Pool for thin logical volumes": [
  null,
  "Fond pro thin logické svazky"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Fond pro tence poskytované LVM2 logické svazky"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Fond pro tence poskytované svazky"
 ],
 "Pool passphrase": [
  null,
  "Heslová fráze k fondu"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Zaváděcí oddíl PReP architektury PowerPC"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Processes using the location": [
  null,
  "Procesy využívající toto umístění"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Zadejte heslovou frázi pro fond na těchto blokových zařízeních:"
 ],
 "Purpose": [
  null,
  "Účel"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (proužkování)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (zrcadlení)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (proužkování zrcadel)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (vyhrazená parita)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (distribuovaná parita)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dvojitá distribuovaná parita)"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "RAID level": [
  null,
  "RAID úroveň"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "Pro RAID 10 je třeba sudý počet fyzických svazků"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Reading": [
  null,
  "Čtení"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Recovering": [
  null,
  "Zotavování"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Zotavování MDRAID zařízení $target"
 ],
 "Regenerating initrd": [
  null,
  "Znovuvytváření initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Související procesy a služby budou vynuceně zastaveny."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Související procesy budou vynuceně zastaveny."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Související služby budou vynuceně zastaveny."
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "Remove $0?": [
  null,
  "Odebrat $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Odebrat Tang server s klíči?"
 ],
 "Remove device": [
  null,
  "Odebrat zařízení"
 ],
 "Remove missing physical volumes?": [
  null,
  "Odebrat chybějící fyzické svazky?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Odebrat heslovou frázi v slotu na klíč $0?"
 ],
 "Remove passphrase?": [
  null,
  "Odebrat heslovou frázi?"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Odebírání $target z MDRAID zařízení"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Odebrání heslové fráze bez potvrzení jiné heslové fráze může bránit v odemknutí nebo správě klíčů, pokud jsou ostatní heslové fráze zapomenuty nebo ztraceny."
 ],
 "Removing physical volume from $target": [
  null,
  "Odebírání fyzického svazku z $target"
 ],
 "Rename": [
  null,
  "Přejmenovat"
 ],
 "Rename Stratis pool": [
  null,
  "Přejmenovat Stratis fond"
 ],
 "Rename filesystem": [
  null,
  "Přejmenovat souborový systém"
 ],
 "Rename logical volume": [
  null,
  "Přejmenovat logický svazek"
 ],
 "Rename volume group": [
  null,
  "Přejmenovat skupinu svazků"
 ],
 "Renaming $target": [
  null,
  "Přejmenovává se $target"
 ],
 "Repair": [
  null,
  "Opravit"
 ],
 "Repair logical volume $0": [
  null,
  "Opravit logický svazek $0"
 ],
 "Repairing $target": [
  null,
  "Opravuje se $target"
 ],
 "Repeat passphrase": [
  null,
  "Zopakovat heslovou frázi"
 ],
 "Resizing $target": [
  null,
  "Mění se velikost $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Změna velikost šifrovaného souborového systému vyžaduje jeho odemčení. Zadejte heslovou frázi."
 ],
 "Reuse existing encryption": [
  null,
  "Použít stávající šifrování"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Použít stávající šifrování ($0)"
 ],
 "Row expansion": [
  null,
  "Rozbalení řádku"
 ],
 "Row select": [
  null,
  "Výběr řádku"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdáleném stroji spusťte – přes důvěryhodnou síť nebo fyzicky přímo na něm – tento příkaz:"
 ],
 "Running": [
  null,
  "Spuštěné"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART samotest $target"
 ],
 "SSH key": [
  null,
  "SSH klíč"
 ],
 "SSH key login": [
  null,
  "Přihlášení SSH klíčem"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Šetřit prostorem komprimováním jednotlivých bloků pomocí LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Šetřit prostorem tím, že stejné bloky dat budou ukládány pouze jednou"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Uložení nové heslové fráze vyžaduje odemknutí disku. Zadejte stávající heslovou frázi k disku."
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Securely erasing $target": [
  null,
  "Zaručené vymazávání $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Vyberte fyzické svazky, které mají být použity pro opravu logického svazku. Je zapotřebí alespoň $0."
 ],
 "Serial number": [
  null,
  "Sériové číslo"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server address": [
  null,
  "Adresa serveru"
 ],
 "Server address cannot be empty.": [
  null,
  "Adresu serveru je třeba vyplnit."
 ],
 "Server cannot be empty.": [
  null,
  "Server je třeba vyplnit."
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Services using the location": [
  null,
  "Služby využívající toto umístění"
 ],
 "Set": [
  null,
  "Nastavit"
 ],
 "Set initial size": [
  null,
  "Nastavit počáteční velikost"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Nastavit omezení virtuální velikosti souborového systému"
 ],
 "Set partition type of $0": [
  null,
  "Nastavit typ oddílu na $0"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Setting up loop device $target": [
  null,
  "Nastavování zařízení zpětné smyčky $target"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "Zobrazit všech $0 řádků"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Shrink": [
  null,
  "Zmenšit"
 ],
 "Shrink logical volume": [
  null,
  "Zmenšit logický svazek"
 ],
 "Shrink partition": [
  null,
  "Zmenšit oddíl"
 ],
 "Shrink volume": [
  null,
  "Zmenšit oddíl"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "Size cannot be negative": [
  null,
  "Velikost nemůže být záporná"
 ],
 "Size cannot be zero": [
  null,
  "Velikost nemůže být nula"
 ],
 "Size is too large": [
  null,
  "Příliš velké"
 ],
 "Size must be a number": [
  null,
  "Je třeba, aby velikost byla číslo"
 ],
 "Size must be at least $0": [
  null,
  "Je třeba, aby velikost byla alespoň $0"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Snapshot": [
  null,
  "Zachycený stav"
 ],
 "Snapshot origin": [
  null,
  "Původ zachyceného stavu"
 ],
 "Snapshots": [
  null,
  "Zachycené stavy"
 ],
 "Solid State Drive": [
  null,
  "Jednotka bez pohyblivých částí"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Velikost některých blokových zařízení byla po vytvoření fondu zvětšena. Fond je možné bezpečně zvětšit a využít tak nově dostupné místo."
 ],
 "Sorry": [
  null,
  "Promiňte"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Spare": [
  null,
  "Náhradní"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Start": [
  null,
  "Spustit"
 ],
 "Start multipath": [
  null,
  "Spustit multipath"
 ],
 "Started": [
  null,
  "Spuštěno"
 ],
 "Starting MDRAID device $target": [
  null,
  "Spouštění MDRAID zařízení $target"
 ],
 "Starting swapspace $target": [
  null,
  "Spouštění odkládacího prostoru $target"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "Stop": [
  null,
  "Zastavit"
 ],
 "Stop and remove": [
  null,
  "Zastavit a odebrat"
 ],
 "Stop and unmount": [
  null,
  "Zastavit a odpojit"
 ],
 "Stop device": [
  null,
  "Zastavit zařízení"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Zastavování MDRAID zařízení $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Zastavování odkládacího prostoru $target"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Úložiště není na tomto systému možné spravovat."
 ],
 "Storage logs": [
  null,
  "Záznamy událostí úložiště"
 ],
 "Store passphrase": [
  null,
  "Uložit heslovou frázi"
 ],
 "Stored passphrase": [
  null,
  "Uložená heslová fráze"
 ],
 "Stratis block device": [
  null,
  "Stratis blokové zařízení"
 ],
 "Stratis block devices": [
  null,
  "Stratis bloková zařízení"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Bloková zařízení Stratis není možné zmenšovat"
 ],
 "Stratis filesystem": [
  null,
  "Stratis souborový systém"
 ],
 "Stratis filesystems": [
  null,
  "Stratis souborové systémy"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis fond souborových systémů"
 ],
 "Stratis pool": [
  null,
  "Stratis fond"
 ],
 "Striped (RAID 0)": [
  null,
  "Proužkované (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Proužkované a zrcadlené (RAID 10)"
 ],
 "Stripes": [
  null,
  "Proužky"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Úspěšně zkopírováno do schránky!"
 ],
 "Swap": [
  null,
  "Odkládací oddíl"
 ],
 "Swap can not be resized here": [
  null,
  "Velikost odkládacího prostoru nelze změnit zde"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synchronizuje se MDRAID zařízení $target"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Tang keyserver": [
  null,
  "Tang server s klíči"
 ],
 "Target": [
  null,
  "Cíl"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Balíček $0 není k dispozici v žádném z repozitářů."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Pro vytváření Stratis fondu je třeba, aby byl nainstalovaný balíček $0."
 ],
 "The $0 package must be installed.": [
  null,
  "Je třeba, aby byl nainstalovaný balíček $0."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Pro vytváření VDO zařízení bude nainstalován balíček $0."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID zařízení je v degradovaném stavu"
 ],
 "The MDRAID device must be running": [
  null,
  "Je třeba, aby MDRAID zařízení bylo spuštěné"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH klíč $0 uživatele $1 na $2 bude přidán do souboru $3 uživatele $4 na $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH klíč $0 bude zpřístupněn po celou relaci a bude k dispozici také pro přihlašování se k ostatním strojům."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Vytváření tohoto VDO zařízení není dokončeno a proto ho nelze použít."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Stávající uživatel není oprávněn zobrazovat informace o klíčích."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Aby ho bylo možné naformátovat, disk je třeba odemknout. Zadejte stávající heslovou frázi."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Souborový systém nemá přiřazen přípojný bod."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Souborový systém nemá trvalý přípojný bod."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Souborový systém je nastavený tak, aby byl automaticky připojován při startu systému, ale šifrovaný kontejner, ve kterém se nachází, nebude v tu dobu odemčený."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Souborový systém je nyní připojený, ale po příštím startu systému už nebude."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Souborový systém je nyní připojený v $0, ale po příštím startu systému bude připojený v $1."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Souborový systém je nyní připojený v $0, ale po příštím startu systému už nebude připojený vůbec."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Souborový systém nyní není připojený, ale po příštím startu systému už bude."
 ],
 "The filesystem is not mounted.": [
  null,
  "Souborový systém není připojený."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Souborový systém bude odemčen při příštím startu systému. To může vyžadovat zadání heslové fráze."
 ],
 "The fingerprint should match:": [
  null,
  "Otisk by se měl shodovat:"
 ],
 "The initrd must be regenerated.": [
  null,
  "Je třeba znovu vytvořit initrd."
 ],
 "The key password can not be empty": [
  null,
  "Heslo ke klíči je třeba vyplnit"
 ],
 "The key passwords do not match": [
  null,
  "Zadání hesla ke klíči se neshodují"
 ],
 "The last key slot can not be removed": [
  null,
  "Poslední zbývající slot klíče není možné odebrat"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Poslední zbývající připojený dílčí svazek možné smazat"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Uvedené procesy a služby budou vynuceně zastaveny."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Uvedené procesy budou vynuceně zastaveny."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Uvedené služby budou vynuceně zastaveny."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Přípojný bod $0 je používán následujícími procesy:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Přípojný bod $0 je používán následujícími službami:"
 ],
 "The password can not be empty": [
  null,
  "Heslo je třeba vyplnit"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný otisk je možné sdílet veřejnými způsoby, včetně e-mailu."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný otisk je možné bez problémů sdílet prostřednictvím veřejných metod, včetně e-mailu. Pokud někoho jiného požádáte, aby pro vás ověřil, může výsledky poslat libovolnou metodou."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Systém v tuto chvíli nepodporuje odemykání souborového systému pomocí Tang serveru s klíči v průběhu zavádění systému."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Systém v tuto chvíli nepodporuje odemykání kořenového souborového systému pomocí Tang serveru s klíči."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "V systému jsou zařízení s vícero cestami, ale služba multipath není spuštěná."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Není k dispozici dostatek prostoru, který by bylo možné použít pro opravu. Na fyzických svazcích je zapotřebí přinejmenším $0, které ještě nejsou použity pro logický svazek."
 ],
 "These additional steps are necessary:": [
  null,
  "Jsou nezbytné tyto další kroky:"
 ],
 "These changes will be made:": [
  null,
  "Budou učiněny tyto změny:"
 ],
 "Thin logical volume": [
  null,
  "Tenký logický svazek"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Tence poskytované LVM2 logické svazky"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Toto MDRAID zařízení nemá bitovou mapu pro write-intent. Taková mapa může významně zkrátit časy potřebné k synchronizaci."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Toto NFS připojení je používáno a měnit je možné jen jeho předvolby."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Toto VDO zařízení nepoužívá ze svého podkladového zařízení vše."
 ],
 "This device can not be used for the installation target.": [
  null,
  "Toto zařízení nelze využít pro cíl instalace."
 ],
 "This device is currently in use.": [
  null,
  "Toto zařízení je v tuto chvíli používáno."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Tento server s klíči je jediný způsob jak fond odemknout a není ho proto možné odebrat."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Tento logický svazek ztratil některé své fyzické svazky a už ho není možné používat. Je třeba ho smazat a vytvořit nový na jeho místě."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Tento logický svazek ztratil některé své fyzické svazky, ale zatím ještě nedošlo ke ztrátě žádných dat. Měli byste ho opravit a obnovit tak jeho původní odolnost."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Tento logický svazek ztratil některé své fyzické svazky, ale nejspíš ještě neztratil žádná data. Měli byste být schopní ho opravit."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Tento logický svazek není zcela využíván obsahem, který se na něm nachází."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Tento oddíl není zcela využíván obsahem, který se na něm nachází."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Tato heslová fráze je jediným způsobem jak fond odemknout a proto jí není možné odebrat."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Tento fond nevyužívá ze svých podkladových zařízení všechen prostor."
 ],
 "This pool is in a degraded state.": [
  null,
  "Tento fond se nachází v degradovaném stavu."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje zásady pro SELinux a může pomoci s porozuměním a řešením jejich porušení."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tento nástroj nastavuje systém tak, aby byly zapisovány výpisy pádů jádra. Podporuje cíle výstupu „local“ (disk), „ssh“ a „nfs“."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení linek (typu bond i tým), mosty, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s výchozím stavem v Ubuntu (to používá systemd-networkd) a skripty ifupdown v distribuci Debian."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Této skupině svazků chybí některé fyzické svazky."
 ],
 "Tier": [
  null,
  "Tier"
 ],
 "Time zone": [
  null,
  "Časové pásmo"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Abyste zajistili, že do vašeho připojení není zasahováno záškodnickou třetí stranou, ověřte otisk klíče hostitele:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pokud chcete otisk ověřit, spusťte následující na $0 když jste fyzicky u stroje nebo prostřednictvím důvěryhodné sítě:"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Trust and add host": [
  null,
  "Důvěřovat a přidat hostitele"
 ],
 "Trust key": [
  null,
  "Důvěryhodný klíč"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Typ může obsahovat pouze znaky 0 až 9, A až F, a „-“ (mínus, spojovník)."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Je třeba, aby typ měl podobu NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Je třeba, aby typ obsahoval právě dva šestnáctkové znaky (0 až 9, A až F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nepodařilo se přihlásit k $0 pomocí ověření se SSH klíčem. Prosím zadejte heslo."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedaří se přihlásit k $0. Hostitel nepřijímá přihlášení heslem nebo žádný z vašich SSH klíčů."
 ],
 "Unable to reach server": [
  null,
  "Server se nedaří dosáhnout"
 ],
 "Unable to remove mount": [
  null,
  "Účet se nedaří odebrat"
 ],
 "Unable to repair logical volume $0": [
  null,
  "Nepodařilo se opravit logický svazek $0"
 ],
 "Unable to unmount filesystem": [
  null,
  "Nedaří se odpojit souborový systém"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Neočekávaná chyba PackageKit v průběhu instalace $0: $1"
 ],
 "Unformatted data": [
  null,
  "Neformátovaná data"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Unknown ($0)": [
  null,
  "Neznámé ($0)"
 ],
 "Unknown host name": [
  null,
  "Neznámý název stroje"
 ],
 "Unknown host: $0": [
  null,
  "Neznámý hostitel: $0"
 ],
 "Unknown type": [
  null,
  "Neznámý typ"
 ],
 "Unlock": [
  null,
  "Odemknout"
 ],
 "Unlock automatically on boot": [
  null,
  "Automaticky odemknout při startu systému"
 ],
 "Unlock before resizing": [
  null,
  "Odemknout před změnou velikosti"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Odemknout šifrovaný Stratis fond"
 ],
 "Unlocking $target": [
  null,
  "Odemyká se $target"
 ],
 "Unlocking disk": [
  null,
  "Odemykání disku"
 ],
 "Unmount": [
  null,
  "Odpojit"
 ],
 "Unmount filesystem $0": [
  null,
  "Odpojit souborový systém $0"
 ],
 "Unmount now": [
  null,
  "Odpojit nyní"
 ],
 "Unmounting $target": [
  null,
  "Odpojování $target"
 ],
 "Unrecognized data": [
  null,
  "Nerozpoznaná data"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Nerozpoznaná data zde nelze zmenšit"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Nerozpoznaná data zde nelze zmenšit."
 ],
 "Unsupported logical volume": [
  null,
  "Nepodporovaný logický svazek"
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "Usage": [
  null,
  "Využití"
 ],
 "Usage of $0": [
  null,
  "Využití $0"
 ],
 "Use": [
  null,
  "Použít"
 ],
 "Use compression": [
  null,
  "Komprimovat"
 ],
 "Use deduplication": [
  null,
  "Deduplikovat"
 ],
 "Used": [
  null,
  "Využito"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Užitečné pro připojení která jsou volitelná nebo vyžadují interakci (jako např. heslovou frázi)"
 ],
 "User": [
  null,
  "Uživatel"
 ],
 "Username": [
  null,
  "Uživatelské jméno"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Zařízení, která jsou podkladem pro VDO, není možné zmenšovat"
 ],
 "VDO device $0": [
  null,
  "VDO zařízení $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Svazek VDO souborového systému (komprese/deduplikace)"
 ],
 "Vendor": [
  null,
  "Výrobce"
 ],
 "Verify fingerprint": [
  null,
  "Ověřit otisk"
 ],
 "Verify key": [
  null,
  "Ověřit klíč"
 ],
 "Very securely erasing $target": [
  null,
  "Velmi zaručené vymazávání $target"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "View logs": [
  null,
  "Zobrazit záznamy událostí"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Virtuální velikosti souborových systémů jsou větší než fond. Přidělování více prostředků, než je k dispozici proto není možné vypnout."
 ],
 "Virtual size": [
  null,
  "Virtuální velikost"
 ],
 "Virtual size limit": [
  null,
  "Omezení virtuální velikosti"
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Volume group": [
  null,
  "Skupina oddílů"
 ],
 "Volume group is missing physical volumes": [
  null,
  "Skupině svazků chybí fyzické svazky"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Velikost svazku je $0. Velikost obsahu na něm je $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "Write-mostly": [
  null,
  "Převážně zápis"
 ],
 "Writing": [
  null,
  "Zapisování"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 se připojujete poprvé."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "after network": [
  null,
  "po síti"
 ],
 "backing device for VDO device": [
  null,
  "zařízení, na kterém je VDO zařízení založeno"
 ],
 "btrfs device": [
  null,
  "btrfs zařízení"
 ],
 "btrfs devices": [
  null,
  "btrfs zařízení"
 ],
 "btrfs filesystem": [
  null,
  "souborový systém btrfs"
 ],
 "btrfs subvolume": [
  null,
  "btrfs dílčí svazek"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs dílčí svazke $0 z $1"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs dílčí svazky"
 ],
 "btrfs volume": [
  null,
  "btrfs svazek"
 ],
 "cache": [
  null,
  "mezipaměť"
 ],
 "data": [
  null,
  "data"
 ],
 "deactivate": [
  null,
  "deaktivovat"
 ],
 "delete": [
  null,
  "smazat"
 ],
 "device of btrfs volume": [
  null,
  "zařízení btrfs svazku"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "encrypted": [
  null,
  "šifrováno"
 ],
 "format": [
  null,
  "formátovat"
 ],
 "grow": [
  null,
  "zvětšit"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI jednotka"
 ],
 "iSCSI drives": [
  null,
  "iSCSI jednotky"
 ],
 "iSCSI portal": [
  null,
  "iSCSI portál"
 ],
 "ignore failure": [
  null,
  "ignorovat nezdar"
 ],
 "in less than a minute": [
  null,
  "za méně než minutu"
 ],
 "initialize": [
  null,
  "inicializovat"
 ],
 "less than a minute ago": [
  null,
  "před méně než minutou"
 ],
 "lock": [
  null,
  "zamknout"
 ],
 "member of MDRAID device": [
  null,
  "člen MDRAID zařízení"
 ],
 "member of Stratis pool": [
  null,
  "člen Stratis fondu"
 ],
 "mount": [
  null,
  "mount"
 ],
 "never mount at boot": [
  null,
  "nikdy nepřipojovat při startu systému"
 ],
 "none": [
  null,
  "nic"
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fyzický svazek LVM2 skupiny svazků"
 ],
 "read only": [
  null,
  "pouze pro čtení"
 ],
 "remove from LVM2": [
  null,
  "odebrat z LVM2"
 ],
 "remove from MDRAID": [
  null,
  "odebrat z MDRAID"
 ],
 "remove from btrfs volume": [
  null,
  "odebrat z btrfs svazku"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "shrink": [
  null,
  "zmenšit"
 ],
 "snapshot": [
  null,
  "zachycený stav"
 ],
 "stop": [
  null,
  "zastavit"
 ],
 "stop boot on failure": [
  null,
  "při nezdaru zastavit start systému"
 ],
 "stopped": [
  null,
  "zastaveno"
 ],
 "unknown target": [
  null,
  "neznámý cíl"
 ],
 "unmount": [
  null,
  "odpojit (unmount)"
 ],
 "unpartitioned space on $0": [
  null,
  "nerozdělené místo na $0"
 ],
 "using key description $0": [
  null,
  "s použitím popisu klíče $0"
 ],
 "yes": [
  null,
  "ano"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bajtů"
 ]
});
