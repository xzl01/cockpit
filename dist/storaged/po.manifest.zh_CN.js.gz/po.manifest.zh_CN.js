cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Managing LVMs": [
  null,
  "管理 LVM"
 ],
 "Managing NFS mounts": [
  null,
  "管理 NFS 挂载"
 ],
 "Managing RAIDs": [
  null,
  "管理 RAID"
 ],
 "Managing VDOs": [
  null,
  "管理 VDO"
 ],
 "Managing partitions": [
  null,
  "管理分区"
 ],
 "Managing physical drives": [
  null,
  "管理物理驱动"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Using LUKS encryption": [
  null,
  "使用 LUKS 加密"
 ],
 "Using Tang server": [
  null,
  "使用 Tang 服务器"
 ],
 "disk": [
  null,
  "磁盘"
 ],
 "drive": [
  null,
  "驱动"
 ],
 "encryption": [
  null,
  "加密"
 ],
 "filesystem": [
  null,
  "文件系统"
 ],
 "format": [
  null,
  "格式"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "挂载"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "分区"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "卸载"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "卷"
 ]
});
