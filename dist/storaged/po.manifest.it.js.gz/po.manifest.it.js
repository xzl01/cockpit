cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Managing LVMs": [
  null,
  "Gestione dei LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Gestione dei montaggi NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestione RAID"
 ],
 "Managing VDOs": [
  null,
  "Gestione VDO"
 ],
 "Managing partitions": [
  null,
  "Gestione delle partizioni"
 ],
 "Managing physical drives": [
  null,
  "Gestione dei drive fisici"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "disk": [
  null,
  "disco"
 ],
 "drive": [
  null,
  "disco"
 ],
 "encryption": [
  null,
  "crittografia"
 ],
 "filesystem": [
  null,
  "file system"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "mount"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "partizione"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "smonta"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volume"
 ]
});
