cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "无法扩容 $0"
 ],
 "$0 can not be made smaller": [
  null,
  "无法缩小 $0"
 ],
 "$0 can not be resized": [
  null,
  "无法改变 $0 的大小"
 ],
 "$0 can not be resized here": [
  null,
  "无法在此改变 $0 的大小"
 ],
 "$0 chunk size": [
  null,
  "$0 块大小"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "已使用 $0 数据 + $1 额外开销，共 $2（$3）"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 disk is missing": [
  null,
  "找不到 $0 个磁盘"
 ],
 "$0 disks": [
  null,
  "$0 个磁盘"
 ],
 "$0 exited with code $1": [
  null,
  "进程 $0 已退出，返回码为 $1"
 ],
 "$0 failed": [
  null,
  "进程 $0 运行时出错"
 ],
 "$0 filesystem": [
  null,
  "$0 文件系统"
 ],
 "$0 hour": [
  null,
  "$0 小时"
 ],
 "$0 is in use": [
  null,
  "$0 正在使用"
 ],
 "$0 is not available from any repository.": [
  null,
  "没有提供 $0 组件的仓库。"
 ],
 "$0 killed with signal $1": [
  null,
  "进程 $0 被信号 $1 终止"
 ],
 "$0 minute": [
  null,
  "$0 分钟"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 partitions": [
  null,
  "$0 分区"
 ],
 "$0 slot remains": [
  null,
  "$0 个剩余插槽"
 ],
 "$0 synchronized": [
  null,
  "$0 同步"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "已使用 $0，共 $1（已保存 $2）"
 ],
 "$0 week": [
  null,
  "$0 周"
 ],
 "$0 will be installed.": [
  null,
  "即将安装 $0。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$name (from $host)": [
  null,
  "$name（位于 $host）"
 ],
 "(Not part of target)": [
  null,
  "（不是目标的一部分）"
 ],
 "(no assigned mount point)": [
  null,
  "（没有分配的挂载点）"
 ],
 "(not mounted)": [
  null,
  "（未挂载）"
 ],
 "(recommended)": [
  null,
  "（推荐）"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 hour": [
  null,
  "1 小时"
 ],
 "1 minute": [
  null,
  "1 分钟"
 ],
 "1 week": [
  null,
  "1 周"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 分钟"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 分钟"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 小时"
 ],
 "60 minutes": [
  null,
  "60 分钟"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "存储池中存在重名文件系统。"
 ],
 "A pool with this name exists already.": [
  null,
  "已有重名存储池。"
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "无法重命名物理卷丢失的卷组。"
 ],
 "Absent": [
  null,
  "空缺"
 ],
 "Acceptable password": [
  null,
  "可行的密码"
 ],
 "Action": [
  null,
  "操作"
 ],
 "Actions": [
  null,
  "操作"
 ],
 "Activate": [
  null,
  "启用逻辑卷"
 ],
 "Activate before resizing": [
  null,
  "调整大小前激活"
 ],
 "Activating $target": [
  null,
  "正在启用逻辑卷 $target"
 ],
 "Add": [
  null,
  "添加"
 ],
 "Add $0": [
  null,
  "添加 $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "添加网络绑定磁盘加密"
 ],
 "Add Tang keyserver": [
  null,
  "添加 Tang 密钥服务器"
 ],
 "Add a bitmap": [
  null,
  "添加位图"
 ],
 "Add block devices": [
  null,
  "添加块设备"
 ],
 "Add disk": [
  null,
  "添加磁盘"
 ],
 "Add disks": [
  null,
  "添加磁盘"
 ],
 "Add iSCSI portal": [
  null,
  "添加 iSCSI 门户"
 ],
 "Add key": [
  null,
  "添加密钥"
 ],
 "Add keyserver": [
  null,
  "添加密钥服务器"
 ],
 "Add passphrase": [
  null,
  "添加密码"
 ],
 "Add physical volume": [
  null,
  "添加物理卷"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "将 \"$0\" 添加到加密选项"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "将 \"$0\" 添加到文件系统选项"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "添加密钥服务器需要解锁池。 请提供现有的池密码。"
 ],
 "Adding key": [
  null,
  "添加密钥"
 ],
 "Adding physical volume to $target": [
  null,
  "添加物理卷至 $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "在内核命令行中添加 rd.neednet=1"
 ],
 "Additional packages:": [
  null,
  "额外软件包："
 ],
 "Address": [
  null,
  "IP 地址"
 ],
 "Address cannot be empty": [
  null,
  "地址不能为空"
 ],
 "Address is not a valid URL": [
  null,
  "该地址为无效 URL"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 网页控制台管理系统"
 ],
 "Advanced TCA": [
  null,
  "高级 TCA"
 ],
 "All $0 selected physical volumes are needed for the choosen layout.": [
  null,
  "所选布局需要所有选定的 $0 物理卷。"
 ],
 "All-in-one": [
  null,
  "一体机"
 ],
 "An additional $0 must be selected": [
  null,
  "必须额外选择 $0"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文档"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "适用于关键挂载，如 /var"
 ],
 "Assessment": [
  null,
  "评估报告"
 ],
 "At boot": [
  null,
  "在引导时"
 ],
 "At least $0 disk is needed.": [
  null,
  "至少需要 $0 块磁盘。"
 ],
 "At least one block device is needed.": [
  null,
  "至少需要 1 个块设备。"
 ],
 "At least one disk is needed.": [
  null,
  "至少需要 1 块磁盘。"
 ],
 "At least one parent needs to be mounted writable": [
  null,
  "最少有一个父设备需要以可写模式挂载"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "通过Cockpit Web Console进行验证后才能执行特权操作"
 ],
 "Authentication required": [
  null,
  "需要验证"
 ],
 "Automatically using NTP": [
  null,
  "自动使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自动使用额外的 NTP 服务器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自动使用指定的 NTP 服务器"
 ],
 "Automation script": [
  null,
  "自动化脚本"
 ],
 "Available targets on $0": [
  null,
  "$0 上可用的目标"
 ],
 "BIOS boot partition": [
  null,
  "BIOS 引导分区"
 ],
 "Blade": [
  null,
  "刀片"
 ],
 "Blade enclosure": [
  null,
  "刀片机箱"
 ],
 "Block device": [
  null,
  "块设备"
 ],
 "Block device for filesystems": [
  null,
  "文件系统的块设备"
 ],
 "Block devices": [
  null,
  "块设备"
 ],
 "Blocked": [
  null,
  "受阻"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "如果文件系统没有挂载，引导会失败，防止远程访问"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "当文件系统没有挂载时，引导仍然成功"
 ],
 "Btrfs volume is mounted": [
  null,
  "Btrfs 卷已被挂载"
 ],
 "Bus expansion chassis": [
  null,
  "总线扩展机箱"
 ],
 "Cache": [
  null,
  "缓存"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cannot forward login credentials": [
  null,
  "无法转发登录凭证"
 ],
 "Cannot schedule event in the past": [
  null,
  "无法调度以前的事件"
 ],
 "Capacity": [
  null,
  "容量"
 ],
 "Category": [
  null,
  ""
 ],
 "Change": [
  null,
  "变更"
 ],
 "Change iSCSI initiater name": [
  null,
  "变更 iSCSI Initiater 名称"
 ],
 "Change iSCSI initiator name": [
  null,
  "变更 iSCSI Initiator 名称"
 ],
 "Change label": [
  null,
  "更改标签"
 ],
 "Change passphrase": [
  null,
  "修改密码"
 ],
 "Change system time": [
  null,
  "修改系统时间"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "更改分区类型可能会阻止系统引导。"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "检查命令中的 SHA-256 或 SHA-1 哈希值是否与此对话框匹配。"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "使用 Tang 服务器检查密钥哈希。"
 ],
 "Checking $target": [
  null,
  "检查 $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "检查 MDRAID 设备 $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "检查并修复 MDRAID 设备 $target"
 ],
 "Checking for $0 package": [
  null,
  "检查 $0 软件包"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "在 initrd 中检查 NBDE 支持"
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "Chunk size": [
  null,
  "区块大小"
 ],
 "Cleaning up for $target": [
  null,
  "清理 $target"
 ],
 "Cleartext device": [
  null,
  "明文设备"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 的 Cockpit 配置和防火墙"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 无法联系指定的主机。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一个服务器管理工具，可以方便地通过浏览器来管理您的 Linux 服务器。在终端和 web 工具间自由切换将不是问题。通过 Cockpit 启动的服务可以通过终端停止。同样，如果在终端中发生错误, 也可以在 Cockpit 的日志接口中看到。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 与系统上的软件不兼容。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安装在系统上。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 是完美的系统管理员工具，它可以轻松完成简单的任务, 如存储管理, 检查日志信息，以及启动/停止服务。 您可以同时监控和管理多个服务器。点一键就可以添加服务器，并开始进行管理。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集并打包诊断和支持数据"
 ],
 "Collect kernel crash dumps": [
  null,
  "收集内核崩溃转储"
 ],
 "Command": [
  null,
  "命令"
 ],
 "Compact PCI": [
  null,
  "紧凑型 PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "兼容所有系统和设备 (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "兼容现代系统，且硬盘空间大于 2TB (GPT)"
 ],
 "Compression": [
  null,
  "压缩"
 ],
 "Confirm": [
  null,
  "确认"
 ],
 "Confirm deletion of $0": [
  null,
  "确认删除 $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "使用一个备用密码短语确认删除"
 ],
 "Confirm stopping of $0": [
  null,
  "确认停止 $0"
 ],
 "Connection has timed out.": [
  null,
  "连接超时。"
 ],
 "Convertible": [
  null,
  "可转换"
 ],
 "Copy": [
  null,
  "复制"
 ],
 "Copy to clipboard": [
  null,
  "复制到剪贴板"
 ],
 "Create": [
  null,
  "创建"
 ],
 "Create LVM2 volume group": [
  null,
  "创建 LVM2 卷组"
 ],
 "Create MDRAID device": [
  null,
  "创建 MDRAID 设备"
 ],
 "Create RAID device": [
  null,
  "创建 RAID 设备"
 ],
 "Create Stratis pool": [
  null,
  "创建 Stratis 池"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "创建文件系统 $0 的快照"
 ],
 "Create and mount": [
  null,
  "创建并挂载"
 ],
 "Create and start": [
  null,
  "创建并启动"
 ],
 "Create filesystem": [
  null,
  "创建文件系统"
 ],
 "Create logical volume": [
  null,
  "创建逻辑卷"
 ],
 "Create new filesystem": [
  null,
  "创建新文件系统"
 ],
 "Create new logical volume": [
  null,
  "创建新逻辑卷"
 ],
 "Create new task file with this content.": [
  null,
  "使用此内容创建新的任务文件。"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "创建新的精简配置逻辑卷"
 ],
 "Create only": [
  null,
  "仅创建"
 ],
 "Create partition": [
  null,
  "创建分区"
 ],
 "Create partition on $0": [
  null,
  "在$0上创建分区"
 ],
 "Create partition table": [
  null,
  "创建分区表"
 ],
 "Create snapshot": [
  null,
  "创建快照"
 ],
 "Create snapshot and mount": [
  null,
  "创建快照和挂载"
 ],
 "Create snapshot only": [
  null,
  "仅创建快照"
 ],
 "Create storage device": [
  null,
  "创建存储设备"
 ],
 "Create subvolume": [
  null,
  "创建子卷"
 ],
 "Create thin volume": [
  null,
  "创建Thin卷"
 ],
 "Create volume group": [
  null,
  "创建卷组"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "创建 LVM2 卷组 $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "创建 MDRAID 设备 $target"
 ],
 "Creating VDO device": [
  null,
  "创建 VDO 设备"
 ],
 "Creating filesystem on $target": [
  null,
  "在 $target 中创建文件系统"
 ],
 "Creating logical volume $target": [
  null,
  "创建逻辑卷 $target"
 ],
 "Creating partition $target": [
  null,
  "创建分区 $target"
 ],
 "Creating snapshot of $target": [
  null,
  "创建 $target 的快照"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "当前在用"
 ],
 "Custom": [
  null,
  "自定义"
 ],
 "Custom mount options": [
  null,
  "自定义挂载选项"
 ],
 "Custom type": [
  null,
  "自定义类型"
 ],
 "Data": [
  null,
  "数据"
 ],
 "Data used": [
  null,
  "使用的数据"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "数据将存储为两份副本，并交替存储在选定的物理卷上，以提高可靠性和性能。至少需要选择四个卷。"
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "数据将以两个或多个副本的形式存储在所选物理卷上，以提高可靠性。至少需要选择两个卷。"
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "数据将交替存储在选定的物理卷上以提高性能。至少需要选择两个卷。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "数据将存储在选定的物理卷上，这样其中一个卷丢失也不会影响数据。至少需要选择三个卷。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "数据将存储在所选物理卷上，以便在其中一个出现故障时不会影响数据。数据也会以交替的方式使用以提高性能。至少需要选择三个卷。"
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "数据将存储在所选物理卷上，以便在其中最多两个同时出现故障时不会影响数据。数据也会以交替的方式使用以提高性能。至少需要选择五个卷。"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "数据将存储在所选物理卷上，它们没有额外的冗余功能或性能改进。"
 ],
 "Deactivate": [
  null,
  "取消激活"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "取消激活逻辑卷 $0/$1？"
 ],
 "Deactivating $target": [
  null,
  "取消激活 $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "专用奇偶校验 (RAID 4)"
 ],
 "Deduplication": [
  null,
  "复制"
 ],
 "Delay": [
  null,
  "延时"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Delete group": [
  null,
  "删除用户组"
 ],
 "Delete pool": [
  null,
  "删除池"
 ],
 "Deleting $target": [
  null,
  "删除 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "删除 LVM2 卷组 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "删除 Stratis 池将会清除其包含的所有数据。"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "删除文件系统将会删除其中的所有数据。"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "删除逻辑卷将擦除其中的所有数据。"
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "删除分区将删除其中的所有数据。"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "删除将清除 MDRAID 设备中的所有数据。"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "删除会擦除 VDO 设备上的所有数据."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "删除会擦除卷组上的所有数据."
 ],
 "Deleting erases all data on this subvolume and all it's children.": [
  null,
  "删除会擦除这个子卷组上的所有数据，以及它的子卷中的所有数据。"
 ],
 "Description": [
  null,
  "描述"
 ],
 "Desktop": [
  null,
  "桌面"
 ],
 "Detachable": [
  null,
  "可拆开"
 ],
 "Device": [
  null,
  "设备"
 ],
 "Device file": [
  null,
  "设备文件"
 ],
 "Device is read-only": [
  null,
  "设备只读"
 ],
 "Device number": [
  null,
  "设备号"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Disconnect": [
  null,
  "断开"
 ],
 "Disk is OK": [
  null,
  "磁盘良好"
 ],
 "Disk is failing": [
  null,
  "磁盘失败"
 ],
 "Disk passphrase": [
  null,
  "磁盘密码"
 ],
 "Disks": [
  null,
  "磁盘"
 ],
 "Dismiss": [
  null,
  "清除"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "分布式奇偶校验 (RAID 5)"
 ],
 "Do not mount": [
  null,
  "不要挂载"
 ],
 "Do not mount automatically on boot": [
  null,
  "不要在启动时自动安装"
 ],
 "Docking station": [
  null,
  "扩展坞"
 ],
 "Does not mount during boot": [
  null,
  "在引导过程中不挂载"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "双重分布式奇偶校验 (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Drive": [
  null,
  "驱动"
 ],
 "Dual rank": [
  null,
  "双通道"
 ],
 "EFI system partition": [
  null,
  "EFI 系统分区"
 ],
 "Edit": [
  null,
  "编辑"
 ],
 "Edit Tang keyserver": [
  null,
  "编辑Tang keyserver"
 ],
 "Edit mount point": [
  null,
  "编辑挂载点"
 ],
 "Editing a key requires a free slot": [
  null,
  "编辑密钥需要一个空闲插槽"
 ],
 "Ejecting $target": [
  null,
  "弹出 $target"
 ],
 "Embedded PC": [
  null,
  "嵌入式 PC"
 ],
 "Emptying $target": [
  null,
  "清空 $target"
 ],
 "Enabling $0": [
  null,
  "启用 $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "使用 Tang 密钥服务器加密数据"
 ],
 "Encrypt data with a passphrase": [
  null,
  "使用密码加密数据"
 ],
 "Encrypted $0": [
  null,
  "已加密 $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "加密的 Stratis 池"
 ],
 "Encrypted logical volume of $0": [
  null,
  "$0 的已加密逻辑卷"
 ],
 "Encrypted partition of $0": [
  null,
  "$0 的已加密分区"
 ],
 "Encryption": [
  null,
  "加密"
 ],
 "Encryption options": [
  null,
  "加密选项"
 ],
 "Encryption type": [
  null,
  "加密类型"
 ],
 "Erasing $target": [
  null,
  "擦除 $target"
 ],
 "Error": [
  null,
  "错误"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "安装错误 $0: PackageKit 没有安装"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "必须选择 $0 个物理卷"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "必须选择 $0 个物理卷，每个逻辑卷条带使用一个。"
 ],
 "Excellent password": [
  null,
  "密码强度良好"
 ],
 "Expansion chassis": [
  null,
  "扩展机箱"
 ],
 "Extended partition": [
  null,
  "扩展分区"
 ],
 "Failed": [
  null,
  "已失败"
 ],
 "Failed to change password": [
  null,
  "修改密码失败"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "在 firewalld 中启用 $0 失败"
 ],
 "Filesystem": [
  null,
  "文件系统"
 ],
 "Filesystem is locked": [
  null,
  "文件系统被锁住"
 ],
 "Filesystem name": [
  null,
  "文件系统名称"
 ],
 "Filesystem outside the target": [
  null,
  "目标之外的文件系统"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "文件系统已在此挂载点下挂载。"
 ],
 "Firmware version": [
  null,
  "固件版本"
 ],
 "Fix NBDE support": [
  null,
  "修复 NBDE 支持"
 ],
 "Format": [
  null,
  "格式化"
 ],
 "Format $0": [
  null,
  "格式化 $0"
 ],
 "Format and mount": [
  null,
  "格式和挂载"
 ],
 "Format and start": [
  null,
  "格式和启动"
 ],
 "Format only": [
  null,
  "仅格式"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "格式化会擦除存储设备上的所有数据。"
 ],
 "Free space": [
  null,
  "空闲空间"
 ],
 "Go to now": [
  null,
  "转到现在"
 ],
 "Grow": [
  null,
  "增长"
 ],
 "Grow content": [
  null,
  "增长内容"
 ],
 "Grow logical size of $0": [
  null,
  "增长 $0 的逻辑大小"
 ],
 "Grow logical volume": [
  null,
  "稀疏逻辑卷增长"
 ],
 "Grow partition": [
  null,
  "增加分区"
 ],
 "Grow the pool to take all space": [
  null,
  "扩展池以占据所有空间"
 ],
 "Grow to take all space": [
  null,
  "增长到占据所有空间"
 ],
 "Handheld": [
  null,
  "手持式"
 ],
 "Hard Disk Drive": [
  null,
  "硬盘设备"
 ],
 "Hide confirmation password": [
  null,
  "隐藏确认密码"
 ],
 "Hide password": [
  null,
  "隐藏密码"
 ],
 "Host key is incorrect": [
  null,
  "主机密钥不正确"
 ],
 "How to check": [
  null,
  "如何检查"
 ],
 "I confirm I want to lose this data forever": [
  null,
  ""
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "内部错误 - 此逻辑卷被标记为 active，应该有一个关联的块设备。但是，无法找到这样的块设备。"
 ],
 "Important data might be deleted:": [
  null,
  ""
 ],
 "In a terminal, run: ": [
  null,
  "在终端中，运行： "
 ],
 "In sync": [
  null,
  "同步中"
 ],
 "Inactive logical volume": [
  null,
  "不活跃的逻辑卷"
 ],
 "Inconsistent filesystem mount": [
  null,
  "不一致的文件系统挂载"
 ],
 "Index memory": [
  null,
  "索引内存"
 ],
 "Initialize": [
  null,
  "初始化"
 ],
 "Initialize disk $0": [
  null,
  "初始化磁盘 $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "初始化会擦除磁盘上的所有数据。"
 ],
 "Install": [
  null,
  "安装"
 ],
 "Install NFS support": [
  null,
  "安装 NFS 支持"
 ],
 "Install Stratis support": [
  null,
  "安装 Stratis 支持"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "安装 $0 将删除 $1 。"
 ],
 "Installing packages": [
  null,
  "安装软件包"
 ],
 "Internal error": [
  null,
  "内部错误"
 ],
 "Invalid date format": [
  null,
  "无效的日期格式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "无效的日期格式和时间格式"
 ],
 "Invalid file permissions": [
  null,
  "无效的文件权限"
 ],
 "Invalid time format": [
  null,
  "无效的时间格式"
 ],
 "Invalid timezone": [
  null,
  "无效的时区"
 ],
 "Invalid username or password": [
  null,
  "无效的用户名或密码"
 ],
 "IoT gateway": [
  null,
  "IoT 网关"
 ],
 "Jobs": [
  null,
  "任务"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "这里无法编辑未知类型的密钥 slot"
 ],
 "Key source": [
  null,
  "密钥源"
 ],
 "Keys": [
  null,
  "密钥"
 ],
 "Keyserver": [
  null,
  "密钥服务器"
 ],
 "Keyserver address": [
  null,
  "Keyserver 地址"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "删除 keyserver 可能会阻止解锁 $0。"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO 池"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 逻辑卷"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 逻辑卷"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2物理卷"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 物理卷"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 卷组"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 卷组 $0"
 ],
 "Label": [
  null,
  "标签"
 ],
 "Laptop": [
  null,
  "笔记本电脑"
 ],
 "Last cannot be removed": [
  null,
  "最后一个无法删除"
 ],
 "Last disk can not be removed": [
  null,
  "不能删除最后一个磁盘"
 ],
 "Last modified: $0": [
  null,
  "最后修改于： $0"
 ],
 "Layout": [
  null,
  "布局"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Linear": [
  null,
  "线性"
 ],
 "Linux filesystem data": [
  null,
  "Linux 文件系统数据"
 ],
 "Linux swap space": [
  null,
  "Linux 交换空间"
 ],
 "Loading system modifications...": [
  null,
  "加载系统改变..."
 ],
 "Loading...": [
  null,
  "载入中..."
 ],
 "Local mount point": [
  null,
  "挂载点"
 ],
 "Local storage": [
  null,
  "本地存储"
 ],
 "Location": [
  null,
  "位置"
 ],
 "Lock": [
  null,
  "锁定"
 ],
 "Locked data": [
  null,
  "锁定的数据"
 ],
 "Locking $target": [
  null,
  "锁定 $target"
 ],
 "Log messages": [
  null,
  "日志消息"
 ],
 "Logical": [
  null,
  "逻辑"
 ],
 "Logical Volume Manager partition": [
  null,
  "逻辑卷管理器分区"
 ],
 "Logical size": [
  null,
  "逻辑大小"
 ],
 "Logical volume": [
  null,
  "逻辑卷"
 ],
 "Logical volume (snapshot)": [
  null,
  "逻辑卷 (快照)"
 ],
 "Logical volume of $0": [
  null,
  "$0 的逻辑卷"
 ],
 "Login failed": [
  null,
  "登录失败"
 ],
 "Low profile desktop": [
  null,
  "低调桌面"
 ],
 "Lunch box": [
  null,
  "主机类型"
 ],
 "MDRAID device": [
  null,
  "MDRAID 设备"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID 设备 $0"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID 设备正在恢复"
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID 设备必须正在运行"
 ],
 "MDRAID disk": [
  null,
  "MDRAID 磁盘"
 ],
 "MDRAID disks": [
  null,
  "MDRAID 磁盘"
 ],
 "Main server chassis": [
  null,
  "主服务器机箱"
 ],
 "Manage filesystem sizes": [
  null,
  "管理文件系统大小"
 ],
 "Manage storage": [
  null,
  "管理存储"
 ],
 "Manually": [
  null,
  "手动的"
 ],
 "Marking $target as faulty": [
  null,
  "标记 $target 为故障"
 ],
 "Media drive": [
  null,
  "介质驱动器"
 ],
 "Message to logged in users": [
  null,
  "发送给已登录用户的信息"
 ],
 "Metadata used": [
  null,
  "已使用的元数据"
 ],
 "Mini PC": [
  null,
  "迷你电脑"
 ],
 "Mini tower": [
  null,
  "迷你塔式主机"
 ],
 "Mirrored (RAID 1)": [
  null,
  "镜像 (RAID 1)"
 ],
 "Model": [
  null,
  "型号"
 ],
 "Modifying $target": [
  null,
  "修改 $target"
 ],
 "Mount": [
  null,
  "挂载"
 ],
 "Mount Point": [
  null,
  "挂载点"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "网络可用后挂载，忽略失败"
 ],
 "Mount also automatically on boot": [
  null,
  "在引导时也自动挂载"
 ],
 "Mount at boot": [
  null,
  "引导时挂载"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "在引导时在 $0 自动挂载"
 ],
 "Mount before services start": [
  null,
  "服务启动前挂载"
 ],
 "Mount configuration": [
  null,
  "挂载配置"
 ],
 "Mount filesystem": [
  null,
  "挂载文件系统"
 ],
 "Mount now": [
  null,
  "现在挂载"
 ],
 "Mount on $0 now": [
  null,
  "现在在 $0 挂载"
 ],
 "Mount options": [
  null,
  "挂载选项"
 ],
 "Mount point": [
  null,
  "挂载点"
 ],
 "Mount point cannot be empty": [
  null,
  "挂载点不能为空"
 ],
 "Mount point cannot be empty.": [
  null,
  "挂载点不能为空。"
 ],
 "Mount point is already used for $0": [
  null,
  "挂载点已用于 $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "挂载点必须以“/”开头。"
 ],
 "Mount read only": [
  null,
  "只读挂载"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "无需等待即可挂载，忽略失败"
 ],
 "Mounting $target": [
  null,
  "挂载 $target"
 ],
 "Mounts before services start": [
  null,
  "服务启动前挂载"
 ],
 "Mounts in parallel with services": [
  null,
  "与服务并行挂载"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "与服务并行挂载，但是在网络可用后"
 ],
 "Multi-system chassis": [
  null,
  "多系统机箱"
 ],
 "Multipathed devices": [
  null,
  "多路径设备"
 ],
 "NFS mount": [
  null,
  "NFS 挂载"
 ],
 "NTP server": [
  null,
  "NTP 服务器"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Name can not be empty.": [
  null,
  "名称不能为空."
 ],
 "Name cannot be empty.": [
  null,
  "名称不能为空。"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "名称不能长于 $0 字节"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "名称不能长于 $0 个字符"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "名称不能长于127个字符。"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "名称不能超过 255 个字符。"
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "名称不能包含字符 '$0'。"
 ],
 "Name cannot contain the character '/'.": [
  null,
  "名称不能包含字符 '/'。"
 ],
 "Name cannot contain whitespace.": [
  null,
  "名称不能包含空格。"
 ],
 "Need a spare disk": [
  null,
  "需要一个备用磁盘"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一个 NTP 服务器"
 ],
 "Networked storage": [
  null,
  "网络存储"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "New NFS mount": [
  null,
  "新的 NFS 挂载"
 ],
 "New passphrase": [
  null,
  "新密码"
 ],
 "New password was not accepted": [
  null,
  "新密码不被接受"
 ],
 "Next": [
  null,
  "下一步"
 ],
 "No available slots": [
  null,
  "没有可用的插槽"
 ],
 "No block devices are available.": [
  null,
  "没有可用的块设备。"
 ],
 "No block devices found": [
  null,
  "没有找到块设备"
 ],
 "No delay": [
  null,
  "无延时"
 ],
 "No devices found": [
  null,
  "没有找到设备"
 ],
 "No disks are available.": [
  null,
  "没有可用的磁盘。"
 ],
 "No disks found": [
  null,
  "没有找到磁盘"
 ],
 "No drives found": [
  null,
  "没有找到驱动器"
 ],
 "No encryption": [
  null,
  "无加密"
 ],
 "No filesystem": [
  null,
  "无文件系统"
 ],
 "No filesystems": [
  null,
  "无文件系统"
 ],
 "No free key slots": [
  null,
  "没有空闲的密钥 slot"
 ],
 "No free space": [
  null,
  "没有剩余空间"
 ],
 "No free space after this partition": [
  null,
  "这个分区后没有可用空间"
 ],
 "No keys added": [
  null,
  "没有添加密钥"
 ],
 "No logical volumes": [
  null,
  "没有逻辑卷"
 ],
 "No media inserted": [
  null,
  "没有插入介质"
 ],
 "No partitioning": [
  null,
  "无分区"
 ],
 "No partitions found": [
  null,
  "没有找到分区"
 ],
 "No physical volumes found": [
  null,
  "没有找到物理卷"
 ],
 "No storage found": [
  null,
  "没有找到存储"
 ],
 "No subvolumes": [
  null,
  "没有子卷"
 ],
 "No such file or directory": [
  null,
  "没有该文件或目录"
 ],
 "No system modifications": [
  null,
  "没有系统改变"
 ],
 "Not a valid private key": [
  null,
  "无效的私钥"
 ],
 "Not enough free space": [
  null,
  "没有足够的可用空间"
 ],
 "Not enough space": [
  null,
  "没有足够空间"
 ],
 "Not enough space to grow": [
  null,
  "没有足够的空间来增长"
 ],
 "Not found": [
  null,
  "未找到"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允许执行该操作。"
 ],
 "Not running": [
  null,
  "未运行"
 ],
 "Not synchronized": [
  null,
  "未同步"
 ],
 "Notebook": [
  null,
  "笔记本"
 ],
 "Occurrences": [
  null,
  "发生"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Old passphrase": [
  null,
  "旧密码"
 ],
 "Old password not accepted": [
  null,
  "旧密码不被接受"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "在安装 Cockpit 后，使用 \"systemctl enable --now cockpit.socket\" 启用它。"
 ],
 "Only $0 of $1 are used.": [
  null,
  "仅使用 $1 的 $0。"
 ],
 "Operation '$operation' on $target": [
  null,
  "$target 上的操作 '$operation'"
 ],
 "Options": [
  null,
  "选项"
 ],
 "Other": [
  null,
  "其他"
 ],
 "Overwrite": [
  null,
  "覆盖"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "用 0 覆盖现有数据（较慢）"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "Partition": [
  null,
  "分区"
 ],
 "Partition of $0": [
  null,
  "$0 的分区"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "分区大小是 $0。内容大小为 $1。"
 ],
 "Partitioning": [
  null,
  "分区"
 ],
 "Partitions": [
  null,
  "分区"
 ],
 "Passphrase": [
  null,
  "密码"
 ],
 "Passphrase can not be empty": [
  null,
  "密码不能为空"
 ],
 "Passphrase cannot be empty": [
  null,
  "密码不能为空"
 ],
 "Passphrase from any other key slot": [
  null,
  "来自其他密钥插槽的密码短语"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "删除密码可能会阻止解锁 $0。"
 ],
 "Passphrases do not match": [
  null,
  "密码不匹配"
 ],
 "Password": [
  null,
  "密码"
 ],
 "Password is not acceptable": [
  null,
  "不接受该密码"
 ],
 "Password is too weak": [
  null,
  "密码太弱"
 ],
 "Password not accepted": [
  null,
  "密码未接受"
 ],
 "Paste": [
  null,
  "粘贴"
 ],
 "Paste error": [
  null,
  "粘贴错误"
 ],
 "Path on server": [
  null,
  "服务器上的路径"
 ],
 "Path on server cannot be empty.": [
  null,
  "服务器上的路径不能为空。"
 ],
 "Path on server must start with \"/\".": [
  null,
  "服务器上的路径必须以“/”开头。"
 ],
 "Path to file": [
  null,
  "文件路径"
 ],
 "Peripheral chassis": [
  null,
  "外设机箱"
 ],
 "Permanently delete $0?": [
  null,
  "永久删除 $0？"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "永久删除逻辑卷 $0/$1？"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "永久删除子卷 $0？"
 ],
 "Physical": [
  null,
  "物理"
 ],
 "Physical Volumes": [
  null,
  "物理卷"
 ],
 "Physical volumes": [
  null,
  "物理卷"
 ],
 "Physical volumes can not be resized here": [
  null,
  "此处无法调整物理卷的大小"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Pizza box": [
  null,
  "披萨盒"
 ],
 "Please unmount them first.": [
  null,
  "请首先卸载它们。"
 ],
 "Pool for thin logical volumes": [
  null,
  "瘦逻辑卷池"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "用于精简置备的 LVM2 逻辑卷的池"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "瘦分配配置卷的池"
 ],
 "Pool passphrase": [
  null,
  "矿池密码"
 ],
 "Port": [
  null,
  "端口"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP 引导分区"
 ],
 "Present": [
  null,
  "当前"
 ],
 "Processes using the location": [
  null,
  "使用位置的进程"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "通过 ssh-add 提示超时"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "通过 ssh-keygen 提示超时"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "为这些块设备上的池提供密码短语："
 ],
 "Purpose": [
  null,
  "目的"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (条带)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (镜像)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (条带镜像)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (奇偶校验)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (奇偶校验)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (双倍奇偶校验)"
 ],
 "RAID chassis": [
  null,
  "RAID 机箱"
 ],
 "RAID level": [
  null,
  "RAID 级别"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 需要有偶数数量的物理卷"
 ],
 "Rack mount chassis": [
  null,
  "机架式机箱"
 ],
 "Reading": [
  null,
  "读取中"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Recovering": [
  null,
  "恢复"
 ],
 "Recovering MDRAID device $target": [
  null,
  "恢复 MDRAID 设备 $target"
 ],
 "Regenerating initrd": [
  null,
  "重新生成 initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "相关进程和服务将被强制停止。"
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "相关进程将被强制停止。"
 ],
 "Related services will be forcefully stopped.": [
  null,
  "相关服务将被强制停止。"
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Remove": [
  null,
  "删除"
 ],
 "Remove $0?": [
  null,
  "移除 $0？"
 ],
 "Remove Tang keyserver?": [
  null,
  "删除 Tang keyserver？"
 ],
 "Remove device": [
  null,
  "删除设备"
 ],
 "Remove missing physical volumes?": [
  null,
  "删除缺少的物理卷？"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "删除密钥插槽 $0 中的密码短语？"
 ],
 "Remove passphrase?": [
  null,
  "删除密码?"
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "从 MDRAID 设备中删除 $target"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "当删除密码短语而没有确认另外一个密码短语时，如果忘记或丢失了其他密码短语，则可能无法取消锁定或进行密钥管理。"
 ],
 "Removing physical volume from $target": [
  null,
  "从 $target 删除物理卷"
 ],
 "Rename": [
  null,
  "重命名"
 ],
 "Rename Stratis pool": [
  null,
  "重命名 Stratis 池"
 ],
 "Rename filesystem": [
  null,
  "重命名文件系统"
 ],
 "Rename logical volume": [
  null,
  "重命名逻辑卷"
 ],
 "Rename volume group": [
  null,
  "重命名卷组"
 ],
 "Renaming $target": [
  null,
  "重命名 $target"
 ],
 "Repair": [
  null,
  "修复"
 ],
 "Repair logical volume $0": [
  null,
  "修复逻辑卷 $0"
 ],
 "Repairing $target": [
  null,
  "正在修复 $target"
 ],
 "Repeat passphrase": [
  null,
  "重复密码"
 ],
 "Resizing $target": [
  null,
  "调整大小 $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "对一个加密的文件系统调整大小需要解锁磁盘。请提供磁盘的密码。"
 ],
 "Reuse existing encryption": [
  null,
  "重用现有的加密"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "重用现有的加密($0)"
 ],
 "Running": [
  null,
  "运行中"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "$target SMART 自检"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "使用 LZ4 压缩独立块以节省空间"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "通过对相同数据块只保存一次来节省空间"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "保存新密码需要解锁磁盘。请提供当前的磁盘密码。"
 ],
 "Sealed-case PC": [
  null,
  "密封式 PC"
 ],
 "Securely erasing $target": [
  null,
  "安全擦除 $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 配置和故障排除"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At leat $0 are needed.": [
  null,
  "选择应该用来修复逻辑卷的物理卷。最少需要 $0。"
 ],
 "Serial number": [
  null,
  "序列号"
 ],
 "Server": [
  null,
  "服务器"
 ],
 "Server address": [
  null,
  "服务器地址"
 ],
 "Server address cannot be empty.": [
  null,
  "服务器地址不能为空。"
 ],
 "Server cannot be empty.": [
  null,
  "名称不能为空。"
 ],
 "Server has closed the connection.": [
  null,
  "服务器关闭了连接。"
 ],
 "Service": [
  null,
  "服务"
 ],
 "Services using the location": [
  null,
  "使用位置的服务"
 ],
 "Set partition type of $0": [
  null,
  "设置分区类型 $0"
 ],
 "Set time": [
  null,
  "设置时间"
 ],
 "Setting up loop device $target": [
  null,
  "创建 loop 设备 $target"
 ],
 "Shell script": [
  null,
  "Shell 脚本"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "显示所有 $0 行"
 ],
 "Show confirmation password": [
  null,
  "显示确认密码"
 ],
 "Show password": [
  null,
  "显示密码"
 ],
 "Shrink": [
  null,
  "缩小"
 ],
 "Shrink logical volume": [
  null,
  "缩小逻辑卷"
 ],
 "Shrink partition": [
  null,
  "缩小分区"
 ],
 "Shrink volume": [
  null,
  "缩小卷"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Single rank": [
  null,
  "单 rank"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Size cannot be negative": [
  null,
  "大小不能为负数"
 ],
 "Size cannot be zero": [
  null,
  "大小不能为零"
 ],
 "Size is too large": [
  null,
  "大小太大"
 ],
 "Size must be a number": [
  null,
  "大小必须是一个数字"
 ],
 "Size must be at least $0": [
  null,
  "大小必须最小为 $0"
 ],
 "Slot $0": [
  null,
  "插槽 $0"
 ],
 "Snapshot": [
  null,
  "快照"
 ],
 "Solid State Drive": [
  null,
  "固态驱动器"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "创建池后，该池的某些块设备的大小已增大。 可以安全地扩大池以使用新的可用空间。"
 ],
 "Sorry": [
  null,
  "抱歉"
 ],
 "Space-saving computer": [
  null,
  "节省空间的计算机"
 ],
 "Spare": [
  null,
  "备用"
 ],
 "Specific time": [
  null,
  "指定时间"
 ],
 "Start": [
  null,
  "启动"
 ],
 "Start multipath": [
  null,
  "启用多路径"
 ],
 "Started": [
  null,
  "启动"
 ],
 "Starting MDRAID device $target": [
  null,
  "启动 MDRAID 设备 $target"
 ],
 "Starting swapspace $target": [
  null,
  "启动交换空间 $target"
 ],
 "State": [
  null,
  "状态"
 ],
 "Stick PC": [
  null,
  "PC 棒"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stop and remove": [
  null,
  "停止并删除"
 ],
 "Stop and unmount": [
  null,
  "停止并卸载"
 ],
 "Stop device": [
  null,
  "停止设备"
 ],
 "Stopping MDRAID device $target": [
  null,
  "停止 MDRAID 设备 $target"
 ],
 "Stopping swapspace $target": [
  null,
  "停止启动交换空间 $target"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Storage can not be managed on this system.": [
  null,
  "存储不能在这个系统上管理。"
 ],
 "Storage logs": [
  null,
  "存储日志"
 ],
 "Store passphrase": [
  null,
  "存储密码"
 ],
 "Stored passphrase": [
  null,
  "保存的密码"
 ],
 "Stratis block device": [
  null,
  "Stratis 块设备"
 ],
 "Stratis block devices": [
  null,
  "Stratis 块设备"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdevs 无法变得更小"
 ],
 "Stratis filesystem": [
  null,
  "Stratis 文件系统"
 ],
 "Stratis filesystems": [
  null,
  "Stratis 文件系统"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis 文件系统池"
 ],
 "Stratis pool": [
  null,
  "Stratis 池"
 ],
 "Striped (RAID 0)": [
  null,
  "条带 (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "条带和镜像 (RAID 10)"
 ],
 "Stripes": [
  null,
  "条带"
 ],
 "Strong password": [
  null,
  "强密码"
 ],
 "Sub-Chassis": [
  null,
  "子机箱"
 ],
 "Sub-Notebook": [
  null,
  "子笔记本"
 ],
 "Subvolume needs to be mounted": [
  null,
  "需要挂载的子卷"
 ],
 "Subvolume needs to be mounted writable": [
  null,
  "子卷需要挂载为可写模式"
 ],
 "Successfully copied to clipboard!": [
  null,
  "成功复制到剪贴板！"
 ],
 "Swap": [
  null,
  "交换空间"
 ],
 "Swap can not be resized here": [
  null,
  "无法在此处调整交换空间的大小"
 ],
 "Synchronized": [
  null,
  "已同步"
 ],
 "Synchronized with $0": [
  null,
  "与 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "同步 MDRAID 设备 $target"
 ],
 "Tablet": [
  null,
  "平板"
 ],
 "Tang keyserver": [
  null,
  "Tang 密钥服务器"
 ],
 "Target": [
  null,
  "目标"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "所有仓库都不提供 $0。"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "$0 软件包必须安装才能创建 Stratis 池。"
 ],
 "The $0 package must be installed.": [
  null,
  "必须安装 $0 软件包。"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "$0 软件包必须安装才能创建 VDO 设备。"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID 设备处于降级状态"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID 设备必须正在运行"
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "此 VDO 设备的创建未完成，无法使用该设备。"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "当前登录的用户不允许查看有关密钥的信息。"
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "在格式化之前需要解锁磁盘。请提供现有的密码短语。"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "文件系统没有分配挂载点。"
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "文件系统没有永久的挂载点。"
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "文件系统被配置为在引导时自动挂载，但它的加密容器不会被解锁。"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "该文件系统当前已被加载，但在下次引导后将不再被挂载。"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "该文件系统当前已被加载于 $0，但在下次引导后将被挂载到 $1。"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "该文件系统当前已被加载于 $0，但在下次引导后将不再被挂载。"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "该文件系统当前没有被加载，但在下次引导后将被挂载。"
 ],
 "The filesystem is not mounted.": [
  null,
  "文件系统未挂载。"
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "文件系统将被解锁，并在下次引导时被挂载。这可能需要输入密码短语。"
 ],
 "The initrd must be regenerated.": [
  null,
  "必须重新生成 initrd。"
 ],
 "The last key slot can not be removed": [
  null,
  "无法删除最后一个密钥槽"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "列出的进程和服务将被强制停止。"
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "列出的进程将被强制停止。"
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "列出的服务将被强制重启。"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "登陆的用户没有权限查看系统改变"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "挂载点 $0 正在被这些进程使用："
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "挂载点 $0 正在被这些服务使用："
 ],
 "The passwords do not match.": [
  null,
  "密码不匹配。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "服务器拒绝使用任何支持的方式来验证。"
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "系统目前不支持在引导过程中解锁具有 Tang keyserver 的文件系统。"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "系统目前不支持解锁具有 Tang keyserver 的根文件系统。"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "该系统上有带有多路径的设备，但是多路径服务未运行。"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "无法进行修复所需的足够的可用空间。在物理卷上至少需要有还没有被这个逻辑卷使用的 $0 可用空间。"
 ],
 "There is not enough space in the pool to make a snapshot of this filesystem. At least $0 are required but only $1 are available.": [
  null,
  "池中没有足够的空间来创建该文件系统的快照。 至少需要 $0，但只有 $1 可用。"
 ],
 "These additional steps are necessary:": [
  null,
  "这些额外步骤是必需的："
 ],
 "These changes will be made:": [
  null,
  "将做出这些更改："
 ],
 "Thin logical volume": [
  null,
  "稀疏逻辑卷"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "精简置备的 LVM2 逻辑卷"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce sychronization times significantly.": [
  null,
  "这个 MDRAID 设备没有 write-intent 位图。这个位图可以显著减少同步时间。"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "此 NFS 挂载正在使用中，只能更改其选项。"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "此 VDO 设备不使用其所有后台设备。"
 ],
 "This device can not be used for the installation target.": [
  null,
  "这个设备不能用于安装目标。"
 ],
 "This device is currently in use.": [
  null,
  "该设备正在被使用。"
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "该密钥服务器是解锁池的唯一方法并且无法删除。"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "这个逻辑卷已丢失其部分物理卷，无法再被使用。您需要删除它并创建一个新卷来代替它。"
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "这个逻辑卷已丢失其部分物理卷，但还没有丢失任何数据。您应该修复它来恢复其原始的冗余功能。"
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "这个逻辑卷已丢失其部分物理卷，但可能还没有丢失任何数据。您可能可以修复它。"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "这个逻辑卷没有被它的内容完全使用。"
 ],
 "This partition is not completely used by its content.": [
  null,
  "此分区不会被其内容完全使用。"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "此密码是解锁矿池的唯一方法，无法删除。"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "该池不使用其块设备上的所有空间。"
 ],
 "This pool is in a degraded state.": [
  null,
  "这个池处于降级状态。"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "这个工具配置 SELinux 策略，帮助理解和解决策略违规。"
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "这个工具配置系统，以将内核崩溃转储写入磁盘。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具从正在运行的系统中生成配置和诊断信息的存档。出于记录或跟踪目的，存档可能被存储在本地或集中存储，或者被发送到技术支持代表、开发人员或系统管理员，以帮助技术故障查找和调试。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本地存储，如文件系统、LVM2 卷组和 NFS 挂载。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 和 Firewalld 管理网络，如绑定、网桥、团队、VLAN 和防火墙等。NetworkManager 与 Ubuntu 的默认 systemd-networkd 和 Debian 的 ifupdown 脚本不兼容。"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "这个卷组缺少一些物理卷。"
 ],
 "Tier": [
  null,
  "层"
 ],
 "Time zone": [
  null,
  "时区"
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Too much data": [
  null,
  "太多数据"
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust key": [
  null,
  "信任密钥"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在尝试与 $0 同步"
 ],
 "Type": [
  null,
  "类型"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "类型只能包含字符 0 到 9，A 到 F，和 \"-\"。"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "类型的格式为 NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN。"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "类型必须正好包含两个十六进制字符 (0 到 9，A 到 F)。"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "无法到达服务器"
 ],
 "Unable to remove mount": [
  null,
  "无法删除挂载"
 ],
 "Unable to repair logical volume $0": [
  null,
  "无法修复逻辑卷 $0"
 ],
 "Unable to unmount filesystem": [
  null,
  "无法卸载文件系统"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "安装 $0 过程中出现意外的 PackageKit 错误：$1"
 ],
 "Unformatted data": [
  null,
  "未格式化的数据"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Unknown ($0)": [
  null,
  "未知 ($0)"
 ],
 "Unknown host name": [
  null,
  "未知主机名"
 ],
 "Unknown type": [
  null,
  "未知类型"
 ],
 "Unlock": [
  null,
  "解锁"
 ],
 "Unlock automatically on boot": [
  null,
  "在引导时自动解锁"
 ],
 "Unlock before resizing": [
  null,
  "在调整大小前解锁"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "解锁加密的 Stratis 池"
 ],
 "Unlocking $target": [
  null,
  "解锁 $target"
 ],
 "Unlocking disk": [
  null,
  "解锁磁盘"
 ],
 "Unmount": [
  null,
  "卸载"
 ],
 "Unmount filesystem $0": [
  null,
  "卸载文件系统 $0"
 ],
 "Unmount now": [
  null,
  "现在卸载"
 ],
 "Unmounting $target": [
  null,
  "卸载 $target"
 ],
 "Unrecognized data": [
  null,
  "无法识别的数据"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "未识别的数据无法在此处变得更小"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "这里不能把无法识别的数据变小。"
 ],
 "Unsupported logical volume": [
  null,
  "不支持的逻辑卷"
 ],
 "Untrusted host": [
  null,
  "不可信的主机"
 ],
 "Usage": [
  null,
  "用法"
 ],
 "Usage of $0": [
  null,
  "$0 的用法"
 ],
 "Use": [
  null,
  "使用"
 ],
 "Use compression": [
  null,
  "使用压缩"
 ],
 "Use deduplication": [
  null,
  "使用 deduplication"
 ],
 "Used": [
  null,
  "已使用"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "对于可选或需要交互的挂载（如密码短语）很有用"
 ],
 "User": [
  null,
  "用户"
 ],
 "Username": [
  null,
  "用户名"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO 后台设备不能更小"
 ],
 "VDO device $0": [
  null,
  "VDO 设备 $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO 文件系统卷（压缩/去除重复）"
 ],
 "Vendor": [
  null,
  "厂商"
 ],
 "Verify key": [
  null,
  "验证密钥"
 ],
 "Very securely erasing $target": [
  null,
  "非常安全地擦除 $target"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "View automation script": [
  null,
  "查看自动化脚本"
 ],
 "View logs": [
  null,
  "查看日志"
 ],
 "Visit firewall": [
  null,
  "访问防火墙"
 ],
 "Volume group": [
  null,
  "卷组"
 ],
 "Volume group is missing physical volumes": [
  null,
  "卷组缺少物理卷"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "卷大小为 $0。内容大小为 $1。"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Weak password": [
  null,
  "弱密码"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux 服务器的 Web 控制台"
 ],
 "When this option is checked, the new pool will not allow overprovisioning. You need to specify a maximum size for each filesystem that is created in the pool. Filesystems can not be made larger after creation. Snapshots are fully allocated on creation. The sum of all maximum sizes can not exceed the size of the pool. The advantage of this is that filesystems in this pool can not run out of space in a surprising way. The disadvantage is that you need to know the maximum size for each filesystem in advance and creation of snapshots is limited.": [
  null,
  "选中此选项后，新池将不允许过度配置。 您需要为池中创建的每个文件系统指定最大大小。 文件系统创建后无法扩大。 快照在创建时已完全分配。 所有最大大小的总和不能超过池的大小。 这样做的优点是该池中的文件系统不会以令人惊讶的方式耗尽空间。 缺点是您需要提前知道每个文件系统的最大大小，并且快照的创建受到限制。"
 ],
 "World wide name": [
  null,
  "全局范围名称"
 ],
 "Write-mostly": [
  null,
  "主要写"
 ],
 "Writing": [
  null,
  "写入中"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的浏览器不允许从上下文菜单中进行粘贴，您可以使用 Shift+Insert。"
 ],
 "Your session has been terminated.": [
  null,
  "会话被终止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "会话超时。请重新登录。"
 ],
 "Zone": [
  null,
  "区域"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "after network": [
  null,
  "网络后"
 ],
 "backing device for VDO device": [
  null,
  "VDO 设备的备份设备"
 ],
 "btrfs device": [
  null,
  "btrfs 设备"
 ],
 "btrfs devices": [
  null,
  "btrfs 设备"
 ],
 "btrfs filesystem": [
  null,
  "btrfs 文件系统"
 ],
 "btrfs subvolume": [
  null,
  "btrfs 子卷"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs 子卷 $0（共 $1）"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs 子卷"
 ],
 "btrfs volume": [
  null,
  "btrfs 卷"
 ],
 "cache": [
  null,
  "缓存"
 ],
 "data": [
  null,
  "数据"
 ],
 "deactivate": [
  null,
  "取消激活"
 ],
 "delete": [
  null,
  "删除"
 ],
 "device of btrfs volume": [
  null,
  "btrfs 卷的设备"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "encrypted": [
  null,
  "已加密"
 ],
 "format": [
  null,
  "格式"
 ],
 "grow": [
  null,
  "增长"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI 驱动器"
 ],
 "iSCSI drives": [
  null,
  "iSCSI 驱动器"
 ],
 "iSCSI portal": [
  null,
  "iSCSI 门户"
 ],
 "ignore failure": [
  null,
  "忽略失败"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "initialize": [
  null,
  "初始化"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "member of MDRAID device": [
  null,
  "MDRAID 设备的成员"
 ],
 "member of Stratis pool": [
  null,
  "Stratis 池的成员"
 ],
 "mount": [
  null,
  "挂载"
 ],
 "never mount at boot": [
  null,
  "永远不会在引导时挂载"
 ],
 "none": [
  null,
  "空"
 ],
 "password quality": [
  null,
  "密码质量"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 卷组的物理卷"
 ],
 "read only": [
  null,
  "只读"
 ],
 "remove from LVM2": [
  null,
  "从 LVM2 中删除"
 ],
 "remove from MDRAID": [
  null,
  "从 MDRAID 中删除"
 ],
 "remove from btrfs volume": [
  null,
  "从 btrfs 卷中删除"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "shrink": [
  null,
  "缩小"
 ],
 "stop": [
  null,
  "停止"
 ],
 "stop boot on failure": [
  null,
  "在失败时停止引导"
 ],
 "stopped": [
  null,
  "停止"
 ],
 "unknown target": [
  null,
  "未知目标"
 ],
 "unmount": [
  null,
  "卸载"
 ],
 "unpartitioned space on $0": [
  null,
  "$0 上未分区的空间"
 ],
 "using key description $0": [
  null,
  "使用密钥描述 $0"
 ],
 "yes": [
  null,
  "是"
 ],
 "format-bytes\u0004bytes": [
  null,
  "字节"
 ]
});
