cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Managing LVMs": [
  null,
  "ניהול LVMים"
 ],
 "Managing NFS mounts": [
  null,
  "ניהול עיגוני NFS"
 ],
 "Managing RAIDs": [
  null,
  "ניהול RAIDים"
 ],
 "Managing VDOs": [
  null,
  "ניהול VDOים"
 ],
 "Managing partitions": [
  null,
  "ניהול מחיצות"
 ],
 "Managing physical drives": [
  null,
  "ניהול כוננים פיזיים"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Using LUKS encryption": [
  null,
  "באמצעות הצפנת LUKS"
 ],
 "Using Tang server": [
  null,
  "באמצעות שרת Tang"
 ],
 "disk": [
  null,
  "כונן"
 ],
 "drive": [
  null,
  "כונן"
 ],
 "encryption": [
  null,
  "הצפנה"
 ],
 "filesystem": [
  null,
  "מערכת קבצים"
 ],
 "format": [
  null,
  "פרמוט"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "עיגון"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "מחיצה"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "ניתוק"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "כרך"
 ]
});
