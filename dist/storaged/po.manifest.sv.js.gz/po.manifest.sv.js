cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Managing LVMs": [
  null,
  "Hantera LVM:er"
 ],
 "Managing NFS mounts": [
  null,
  "Hantera NFS-monteringar"
 ],
 "Managing RAIDs": [
  null,
  "Hantera RAID:ar"
 ],
 "Managing VDOs": [
  null,
  "Hantera VDO:er"
 ],
 "Managing partitions": [
  null,
  "Hantera partitioner"
 ],
 "Managing physical drives": [
  null,
  "Hantera fysiska diskar"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Using LUKS encryption": [
  null,
  "Använder LUKS-kryptering"
 ],
 "Using Tang server": [
  null,
  "Använder Tang-server"
 ],
 "disk": [
  null,
  "disk"
 ],
 "drive": [
  null,
  "disk"
 ],
 "encryption": [
  null,
  "kryptering"
 ],
 "filesystem": [
  null,
  "filsystem"
 ],
 "format": [
  null,
  "formatera"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "montering"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "partition"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "avmontera"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volym"
 ]
});
