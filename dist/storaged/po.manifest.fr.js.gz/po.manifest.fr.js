cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Managing LVMs": [
  null,
  "Gestion des LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Gérer les montages NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestion des RAID"
 ],
 "Managing VDOs": [
  null,
  "Gestion des ODV"
 ],
 "Managing partitions": [
  null,
  "Gestion des partitions"
 ],
 "Managing physical drives": [
  null,
  "Gestion des lecteurs physiques"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Using LUKS encryption": [
  null,
  "Utilisation du chiffrement LUKS"
 ],
 "Using Tang server": [
  null,
  "Utilisation du serveur Tang"
 ],
 "disk": [
  null,
  "disque"
 ],
 "drive": [
  null,
  "disque"
 ],
 "encryption": [
  null,
  "chiffrement"
 ],
 "filesystem": [
  null,
  "système de fichiers"
 ],
 "format": [
  null,
  "formater"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "monter"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "partition"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "Démonter"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volume"
 ]
});
