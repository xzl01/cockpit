cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do Kernel"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Using LUKS encryption": [
  null,
  ""
 ],
 "disk": [
  null,
  "disco"
 ],
 "drive": [
  null,
  ""
 ],
 "encryption": [
  null,
  "criptografia"
 ],
 "filesystem": [
  null,
  "sistema de arquivos"
 ],
 "format": [
  null,
  ""
 ],
 "mount": [
  null,
  ""
 ],
 "nbde": [
  null,
  ""
 ],
 "partition": [
  null,
  "partição"
 ],
 "tang": [
  null,
  ""
 ]
});
