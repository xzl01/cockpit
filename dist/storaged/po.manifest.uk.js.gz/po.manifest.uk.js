cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Managing LVMs": [
  null,
  "Керування LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Керування монтуванням NFS"
 ],
 "Managing RAIDs": [
  null,
  "Керування RAID"
 ],
 "Managing VDOs": [
  null,
  "Керування VDO"
 ],
 "Managing partitions": [
  null,
  "Керування розділами диска"
 ],
 "Managing physical drives": [
  null,
  "Керування фізичними дисками"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Using LUKS encryption": [
  null,
  "З використанням шифрування LUKS"
 ],
 "Using Tang server": [
  null,
  "З використанням сервера Tang"
 ],
 "disk": [
  null,
  "диск"
 ],
 "drive": [
  null,
  "диск"
 ],
 "encryption": [
  null,
  "шифрування"
 ],
 "filesystem": [
  null,
  "файлова система"
 ],
 "format": [
  null,
  "формат"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "монтування"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "розділ"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "демонтувати"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "том"
 ]
});
