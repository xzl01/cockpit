cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Managing LVMs": [
  null,
  "LVM 관리"
 ],
 "Managing NFS mounts": [
  null,
  "NFS 적재 관리하기"
 ],
 "Managing RAIDs": [
  null,
  "레이드 관리"
 ],
 "Managing VDOs": [
  null,
  "VDO 관리"
 ],
 "Managing partitions": [
  null,
  "파티션 관리"
 ],
 "Managing physical drives": [
  null,
  "물리적 드라이브 관리"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS 암호화 사용 중"
 ],
 "Using Tang server": [
  null,
  "Tang 서버 사용 중"
 ],
 "disk": [
  null,
  "디스크"
 ],
 "drive": [
  null,
  "드라이브"
 ],
 "encryption": [
  null,
  "암호화"
 ],
 "filesystem": [
  null,
  "파일 시스템"
 ],
 "format": [
  null,
  "포맷"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "LUKS"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "적재"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "파티션"
 ],
 "raid": [
  null,
  "레이드"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "적재 해제"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "볼륨"
 ]
});
