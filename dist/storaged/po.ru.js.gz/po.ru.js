cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "$0 can not be made larger": [
  null,
  "$0 невозможно увеличить."
 ],
 "$0 can not be made smaller": [
  null,
  "$0 невозможно уменьшить."
 ],
 "$0 can not be resized": [
  null,
  "Размер $0 невозможно изменить."
 ],
 "$0 can not be resized here": [
  null,
  "Здесь невозможно изменить размер $0."
 ],
 "$0 chunk size": [
  null,
  "размер блока: $0"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 данных + $1 служебной информации использовано из $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 disk is missing": [
  null,
  "$0 диск отсутствует",
  "$0 диска отсутствуют",
  "$0 дисков отсутствуют"
 ],
 "$0 disks": [
  null,
  "дисков: $0"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "$0 filesystem": [
  null,
  "Файловая система $0"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 is in use": [
  null,
  "$0 используется"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 partitions": [
  null,
  "разделов: $0"
 ],
 "$0 slot remains": [
  null,
  "Остался $0 слот",
  "Осталось $0 слота",
  "Осталось $0 слотов"
 ],
 "$0 synchronized": [
  null,
  "$0 синхронизировано"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 использовано из $1 ($2 сэкономлено)"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "$name (from $host)": [
  null,
  "$name (от $host)"
 ],
 "(Not part of target)": [
  null,
  "(не является частью цели)"
 ],
 "(no assigned mount point)": [
  null,
  "(нет назначенной точки монтирования)"
 ],
 "(not mounted)": [
  null,
  "(не смонтировано)"
 ],
 "(recommended)": [
  null,
  "(рекомендовано)"
 ],
 "1 MiB": [
  null,
  "1 МиБ"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "128 KiB": [
  null,
  "128 КиБ"
 ],
 "16 KiB": [
  null,
  "16 КиБ"
 ],
 "2 MiB": [
  null,
  "2 МиБ"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "32 KiB": [
  null,
  "32 КиБ"
 ],
 "4 KiB": [
  null,
  "4 КиБ"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "512 KiB": [
  null,
  "512 КиБ"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "64 KiB": [
  null,
  "64 КиБ"
 ],
 "8 KiB": [
  null,
  "8 КиБ"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Файловая система с таким именем уже существует в этом пуле."
 ],
 "A pool with this name exists already.": [
  null,
  "Пул с таким названием уже существует."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Невозможно переименовать группу томов с отсутствующими физическими томами."
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Action": [
  null,
  "Действие"
 ],
 "Actions": [
  null,
  "Действия"
 ],
 "Activate": [
  null,
  "Включить"
 ],
 "Activate before resizing": [
  null,
  "Активировать перед изменением размера"
 ],
 "Activating $target": [
  null,
  "Включение $target"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Добавить шифрование диска с сетевой привязкой"
 ],
 "Add Tang keyserver": [
  null,
  "Добавить сервер ключей Tang"
 ],
 "Add a bitmap": [
  null,
  "Добавить битовую карту"
 ],
 "Add block devices": [
  null,
  "Добавить блочные устройства"
 ],
 "Add disk": [
  null,
  "Добавить диск"
 ],
 "Add disks": [
  null,
  "Добавление дисков"
 ],
 "Add iSCSI portal": [
  null,
  "Добавить портал iSCSI"
 ],
 "Add key": [
  null,
  "Добавить ключ"
 ],
 "Add keyserver": [
  null,
  "Добавить сервер ключей"
 ],
 "Add passphrase": [
  null,
  "Добавить парольную фразу"
 ],
 "Add physical volume": [
  null,
  "Добавить физический том"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Добавление «$0» в параметры шифрования"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Добавление «$0» в параметры файловой системы"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Добавление сервера ключей требует разблокировки буфера. Укажите существующую парольную фразу буфера"
 ],
 "Adding key": [
  null,
  "Добавление ключа"
 ],
 "Adding physical volume to $target": [
  null,
  "Добавление физического тома в $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Добавление rd.neednet=1 в командную строку ядра"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Address": [
  null,
  "Адрес"
 ],
 "Address cannot be empty": [
  null,
  "Адрес не может быть пустым"
 ],
 "Address is not a valid URL": [
  null,
  "Недопустимое значение URL-адреса"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "All $0 selected physical volumes are needed for the choosen layout.": [
  null,
  "Для выбранного макета необходимы все выбранные физические тома $0."
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "An additional $0 must be selected": [
  null,
  "Необходимо выбрать дополнительный $0"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Подходит для критических монтирований, таких как /var"
 ],
 "Assessment": [
  null,
  "Оценка"
 ],
 "At boot": [
  null,
  "При загрузке"
 ],
 "At least $0 disk is needed.": [
  null,
  "Необходим хотя бы $0 диск.",
  "Необходимо хотя бы $0 диска.",
  "Необходимо хотя бы $0 дисков."
 ],
 "At least one block device is needed.": [
  null,
  "Необходимо хотя бы одно блочное устройство."
 ],
 "At least one disk is needed.": [
  null,
  "Необходим хотя бы один диск."
 ],
 "At least one parent needs to be mounted writable": [
  null,
  "По крайней мере один родительский элемент должен быть смонтирован для записи"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ],
 "Authentication required": [
  null,
  "Необходима проверка подлинности"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "Available targets on $0": [
  null,
  "Доступные цели на $0"
 ],
 "BIOS boot partition": [
  null,
  "Загрузочный раздел BIOS"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Block device": [
  null,
  "Блочное устройство"
 ],
 "Block device for filesystems": [
  null,
  "Устройство блочного ввода-вывода для файловых систем"
 ],
 "Block devices": [
  null,
  "Блочные устройства"
 ],
 "Blocked": [
  null,
  "Заблокировано"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Загрузка завершится с ошибкой, если файловая система не монтируется, что препятствует удалённому доступу"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Загрузка всё равно завершится успешно, если файловая система не монтируется"
 ],
 "Btrfs volume is mounted": [
  null,
  "Том Btrfs смонтирован"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "Cache": [
  null,
  "Кэш"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "Capacity": [
  null,
  "Ёмкость"
 ],
 "Category": [
  null,
  "Категория"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change iSCSI initiater name": [
  null,
  "Изменить имя инициатора iSCSI"
 ],
 "Change iSCSI initiator name": [
  null,
  "Изменить имя инициатора iSCSI"
 ],
 "Change label": [
  null,
  "Изменить метку"
 ],
 "Change passphrase": [
  null,
  "Изменить парольную фразу"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Изменение типов разделов может помешать загрузке системы."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Проверьте, совпадает ли хэш SHA-256 или SHA-1, полученный с помощью команды, с приведённым в этом окне."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Проверьте хэш ключа с помощью сервера Tang."
 ],
 "Checking $target": [
  null,
  "Проверка $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Проверка устройства MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Проверка и восстановление устройства MDRAID $target"
 ],
 "Checking for $0 package": [
  null,
  "Проверка наличия пакета $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Проверка наличия поддержки NBDE в initrd"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Chunk size": [
  null,
  "Размер блока"
 ],
 "Cleaning up for $target": [
  null,
  "Очистка данных $target"
 ],
 "Cleartext device": [
  null,
  "Устройство с открытым текстом"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Совместимость со всеми системами и устройствами (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Совместимость с современными системами и жёсткими дисками объёмом более 2 ТБ (GPT)"
 ],
 "Compression": [
  null,
  "Сжатие"
 ],
 "Confirm": [
  null,
  "Подтверждение"
 ],
 "Confirm deletion of $0": [
  null,
  "Подтвердите удаление $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Подтвердите удаление с помощью альтернативной кодовой фразы"
 ],
 "Confirm stopping of $0": [
  null,
  "Подтвердите остановку $0"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Create": [
  null,
  "Создать"
 ],
 "Create LVM2 volume group": [
  null,
  "Создать группу томов LVM2"
 ],
 "Create MDRAID device": [
  null,
  "Создать устройство MDRAID"
 ],
 "Create RAID device": [
  null,
  "Создание RAID-устройства"
 ],
 "Create Stratis pool": [
  null,
  "Создать буфер Stratis"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Создать снимок файловой системы $0"
 ],
 "Create and mount": [
  null,
  "Создать и смонтировать"
 ],
 "Create and start": [
  null,
  "Создать и запустить"
 ],
 "Create filesystem": [
  null,
  "Создать файловую систему"
 ],
 "Create logical volume": [
  null,
  "Создание логического тома"
 ],
 "Create new filesystem": [
  null,
  "Создать новую файловую систему"
 ],
 "Create new logical volume": [
  null,
  "Создать новый логический том"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Создать новый тонко резервируемый логический том"
 ],
 "Create only": [
  null,
  "Только для создания"
 ],
 "Create partition": [
  null,
  "Создать раздел"
 ],
 "Create partition on $0": [
  null,
  "Создание раздела на $0"
 ],
 "Create partition table": [
  null,
  "Создать таблицу разделов"
 ],
 "Create snapshot": [
  null,
  "Создание моментального снимка"
 ],
 "Create snapshot and mount": [
  null,
  "Создать снимок и смонтировать"
 ],
 "Create snapshot only": [
  null,
  "Создать только снимок"
 ],
 "Create storage device": [
  null,
  "Создать устройство хранения данных"
 ],
 "Create subvolume": [
  null,
  "Создать подтом"
 ],
 "Create thin volume": [
  null,
  "Создать тонкий том"
 ],
 "Create volume group": [
  null,
  "Создать группу томов"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Создание группы томов LVM2 $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "Создание устройства MDRAID $target"
 ],
 "Creating VDO device": [
  null,
  "Создание устройства VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "Создание файловой системы на $target"
 ],
 "Creating logical volume $target": [
  null,
  "Создание логического тома $target"
 ],
 "Creating partition $target": [
  null,
  "Создание раздела $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Создание моментального снимка $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Используется в данный момент"
 ],
 "Custom": [
  null,
  "Другой"
 ],
 "Custom mount options": [
  null,
  "Пользовательские параметры монтирования"
 ],
 "Custom type": [
  null,
  "Нестандартный тип"
 ],
 "Data": [
  null,
  "Данные"
 ],
 "Data used": [
  null,
  "Использованные данные"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Данные будут храниться в виде двух копий, а также поочерёдно на выбранных физических томах, чтобы повысить надёжность и производительность. Необходимо выбрать не менее четырёх томов."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Данные будут храниться в виде двух или более копий на выбранных физических томах для повышения надёжности. Необходимо выбрать как минимум два тома."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Данные будут храниться на выбранных физических томах поочерёдно для повышения производительности. Необходимо выбрать как минимум два тома."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Данные будут храниться на выбранных физических томах таким образом, что один из них может быть потерян без ущерба для данных. Необходимо выбрать не менее трёх томов."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Данные будут храниться на выбранных физических томах таким образом, что один из них может быть потерян без ущерба для данных. Данные также хранятся поочерёдно для повышения производительности. Необходимо выбрать не менее трёх томов."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Данные будут храниться на выбранных физических томах, так что до двух из них могут быть потеряны одновременно без ущерба для данных. Данные также хранятся поочерёдно для повышения производительности. Необходимо выбрать не менее пяти томов."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Данные будут храниться на выбранных физических томах без какого-либо дополнительного резервирования или повышения производительности."
 ],
 "Deactivate": [
  null,
  "Отключить"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Деактивировать логический том $0/$1?"
 ],
 "Deactivating $target": [
  null,
  "Отключение $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Выделенная чётность (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Дедупликация"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Delete group": [
  null,
  "Удалить группу"
 ],
 "Delete pool": [
  null,
  "Удалить буфер"
 ],
 "Deleting $target": [
  null,
  "Удаление $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Удаление группы томов LVM2 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Удаление пула Stratis приведёт к уничтожению всех содержащихся в нём данных."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Удаление файловой системы приведёт к уничтожению всех содержащихся в ней данных."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Удаление логического тома приведёт к удалению всех данных в нём."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Удаление раздела приведёт к удалению всех данных в нём."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Удаление приведёт к уничтожению всех данных на устройстве MDRAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Удаление приведёт к уничтожению всех данных на устройстве VDO."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Удаление приведёт к уничтожению всех данных, содержащихся в группе томов."
 ],
 "Deleting erases all data on this subvolume and all it's children.": [
  null,
  "Удаление приведёт к уничтожению всех данных в подтоме и всех его дочерних объектах."
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "Device": [
  null,
  "Устройство"
 ],
 "Device file": [
  null,
  "Файл устройства"
 ],
 "Device is read-only": [
  null,
  "Устройство доступно только для чтения"
 ],
 "Device number": [
  null,
  "Номер устройства"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Disconnect": [
  null,
  "Отключиться"
 ],
 "Disk is OK": [
  null,
  "Диск в порядке"
 ],
 "Disk is failing": [
  null,
  "Сбой диска"
 ],
 "Disk passphrase": [
  null,
  "Парольная фраза диска"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "Dismiss": [
  null,
  "Закрыть"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Распределённая чётность (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Не монтировать"
 ],
 "Do not mount automatically on boot": [
  null,
  "Не монтировать автоматически при загрузке"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "Does not mount during boot": [
  null,
  "Не монтировать при загрузке"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Двойная распределённая чётность (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Drive": [
  null,
  "Устройство"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "EFI system partition": [
  null,
  "Системный раздел"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Edit Tang keyserver": [
  null,
  "Изменение сервера криптографических ключей Tang"
 ],
 "Edit mount point": [
  null,
  "Изменить точку монтирования"
 ],
 "Editing a key requires a free slot": [
  null,
  "Для редактирования ключа необходим свободный слот"
 ],
 "Ejecting $target": [
  null,
  "Извлечение $target"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Emptying $target": [
  null,
  "Очистка $target"
 ],
 "Enabling $0": [
  null,
  "Включение $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Шифрование данных с помощью сервера ключей Tang"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Шифрование данных с помощью парольной фразы"
 ],
 "Encrypted $0": [
  null,
  "Зашифрованный $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "Зашифрованный буфер Stratis"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Зашифрованный логический том $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Зашифрованный раздел $0"
 ],
 "Encryption": [
  null,
  "Шифрование"
 ],
 "Encryption options": [
  null,
  "Параметры шифрования"
 ],
 "Encryption type": [
  null,
  "Тип шифрования"
 ],
 "Erasing $target": [
  null,
  "Стирание $target"
 ],
 "Error": [
  null,
  "Ошибка"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Ошибка установки $0: PackageKit не установлен"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Необходимо выбрать физических томов: $0"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Необходимо выбрать физических томов: ровно $0, по одному для каждой полосы логического тома."
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Extended partition": [
  null,
  "Дополнительный раздел"
 ],
 "Failed": [
  null,
  "Сбой"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Filesystem": [
  null,
  "Файловая система"
 ],
 "Filesystem is locked": [
  null,
  "Файловая система заблокирована"
 ],
 "Filesystem name": [
  null,
  "Имя файловой системы"
 ],
 "Filesystem outside the target": [
  null,
  "Файловая система за пределами цели"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Файловые системы уже смонтированы под этой точкой монтирования."
 ],
 "Firmware version": [
  null,
  "Версия микропрограммы"
 ],
 "Fix NBDE support": [
  null,
  "Исправить поддержку NBDE"
 ],
 "Format": [
  null,
  "Форматировать"
 ],
 "Format $0": [
  null,
  "Форматирование $0"
 ],
 "Format and mount": [
  null,
  "Форматировать и монтировать"
 ],
 "Format and start": [
  null,
  "Форматировать и запустить"
 ],
 "Format only": [
  null,
  "Только форматировать"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "При форматировании устройства хранения все данные на нём удаляются."
 ],
 "Free space": [
  null,
  "свободного места"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "Grow": [
  null,
  "Расширить"
 ],
 "Grow content": [
  null,
  "Расширить содержимое"
 ],
 "Grow logical size of $0": [
  null,
  "Расширение логического размера $0"
 ],
 "Grow logical volume": [
  null,
  "Расширение логического тома"
 ],
 "Grow partition": [
  null,
  "Расширение раздела"
 ],
 "Grow the pool to take all space": [
  null,
  "Расширить буфер на всё пространство"
 ],
 "Grow to take all space": [
  null,
  "Расширить на всё пространство"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Hard Disk Drive": [
  null,
  "Жёсткий диск"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "How to check": [
  null,
  "Как проверить"
 ],
 "I confirm I want to lose this data forever": [
  null,
  ""
 ],
 "ID": [
  null,
  "Идентификатор"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ВНУТРЕННЯЯ ОШИБКА — этот логический том отмечен как активный и должен иметь соответствующее блочное устройство. Однако такого блочного устройства найти не удалось."
 ],
 "Important data might be deleted:": [
  null,
  ""
 ],
 "In a terminal, run: ": [
  null,
  "В терминале введите команду: "
 ],
 "In sync": [
  null,
  "Синхронизировано"
 ],
 "Inactive logical volume": [
  null,
  "Неактивный логический том"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Неправильное монтирование файловой системы"
 ],
 "Index memory": [
  null,
  "Память индексов"
 ],
 "Initialize": [
  null,
  "Инициализировать"
 ],
 "Initialize disk $0": [
  null,
  "Инициализировать диск $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "При инициализации все данные на диске уничтожаются."
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install NFS support": [
  null,
  "Установка поддержки NFS"
 ],
 "Install Stratis support": [
  null,
  "Установка поддержки Stratis"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Установка $0 приведёт к удалению $1."
 ],
 "Installing packages": [
  null,
  "Установка пакетов"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "Invalid username or password": [
  null,
  "Недопустимое имя пользователя или пароль"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Jobs": [
  null,
  "Задания"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Слоты для ключей с неизвестными типами нельзя изменить здесь"
 ],
 "Key source": [
  null,
  "Источник ключа"
 ],
 "Keys": [
  null,
  "Ключи"
 ],
 "Keyserver": [
  null,
  "Сервер криптографических ключей"
 ],
 "Keyserver address": [
  null,
  "Адрес сервера криптографических ключей"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Удаление сервера криптографических ключей может помешать разблокировке $0."
 ],
 "LVM2 VDO pool": [
  null,
  "Буфер VDO LVM2"
 ],
 "LVM2 logical volume": [
  null,
  "Логический том LVM2"
 ],
 "LVM2 logical volumes": [
  null,
  "Логические тома LVM2"
 ],
 "LVM2 physical volume": [
  null,
  "Физический том LVM2"
 ],
 "LVM2 physical volumes": [
  null,
  "Физические тома LVM2"
 ],
 "LVM2 volume group": [
  null,
  "Группа томов LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "Группа томов LVM2 $0"
 ],
 "Label": [
  null,
  "Метка"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Last cannot be removed": [
  null,
  "Последний не может быть удалён"
 ],
 "Last disk can not be removed": [
  null,
  "Последний диск не может быть удалён"
 ],
 "Last modified: $0": [
  null,
  "Время последнего изменения: $0"
 ],
 "Layout": [
  null,
  "Макет"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "Linear": [
  null,
  "Линейный"
 ],
 "Linux filesystem data": [
  null,
  "Данные файловой системы Linux"
 ],
 "Linux swap space": [
  null,
  "Резервная память Linux"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "Loading...": [
  null,
  "Загрузка…"
 ],
 "Local mount point": [
  null,
  "Локальная точка подключения"
 ],
 "Local storage": [
  null,
  "Локальное хранилище"
 ],
 "Location": [
  null,
  "Расположение"
 ],
 "Lock": [
  null,
  "Заблокировать"
 ],
 "Locked data": [
  null,
  "Заблокированные данные"
 ],
 "Locking $target": [
  null,
  "Блокировка $target"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "Logical": [
  null,
  "Логический размер"
 ],
 "Logical Volume Manager partition": [
  null,
  "Раздел средства управления логическими томами"
 ],
 "Logical size": [
  null,
  "Логический размер"
 ],
 "Logical volume": [
  null,
  "Логический том"
 ],
 "Logical volume (snapshot)": [
  null,
  "Логический том (моментальный снимок)"
 ],
 "Logical volume of $0": [
  null,
  "Логический том $0"
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "MDRAID device": [
  null,
  "Устройство MDRAID"
 ],
 "MDRAID device $0": [
  null,
  "Устройство MDRAID $0"
 ],
 "MDRAID device is recovering": [
  null,
  "Восстановление устройства MDRAID"
 ],
 "MDRAID device must be running": [
  null,
  "Устройство MDRAID должно быть запущено"
 ],
 "MDRAID disk": [
  null,
  "Диск MDRAID"
 ],
 "MDRAID disks": [
  null,
  "Диски MDRAID"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Manage filesystem sizes": [
  null,
  "Управление размерами файловой системы"
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Marking $target as faulty": [
  null,
  "Маркировка $target как неисправного"
 ],
 "Media drive": [
  null,
  "Медиа-носитель"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Metadata used": [
  null,
  "Используемые метаданные"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Зеркальный (RAID 1)"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Modifying $target": [
  null,
  "Изменение $target"
 ],
 "Mount": [
  null,
  "Подключение"
 ],
 "Mount Point": [
  null,
  "Точка монтирования"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Монтировать после того, как сеть станет доступной, игнорировать ошибки"
 ],
 "Mount also automatically on boot": [
  null,
  "Монтировать также автоматически при загрузке"
 ],
 "Mount at boot": [
  null,
  "Подключение при загрузке"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Монтировать автоматически на $0 при загрузке"
 ],
 "Mount before services start": [
  null,
  "Монтировать перед запуском служб"
 ],
 "Mount configuration": [
  null,
  "Настройки монтирования"
 ],
 "Mount filesystem": [
  null,
  "Монтировать файловую систему"
 ],
 "Mount now": [
  null,
  "Монтировать сейчас"
 ],
 "Mount on $0 now": [
  null,
  "Монтировать на $0 сейчас"
 ],
 "Mount options": [
  null,
  "Параметры подключения"
 ],
 "Mount point": [
  null,
  "Точка подключения"
 ],
 "Mount point cannot be empty": [
  null,
  "Точка монтирования не может быть пустой"
 ],
 "Mount point cannot be empty.": [
  null,
  "Точка подключения не может быть пуста."
 ],
 "Mount point is already used for $0": [
  null,
  "Точка монтирования уже используется для $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Точка подключения должна начинаться с символа «/»."
 ],
 "Mount read only": [
  null,
  "Подключение только для чтения"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Монтировать без ожидания, игнорировать ошибки"
 ],
 "Mounting $target": [
  null,
  "Подключение $target"
 ],
 "Mounts before services start": [
  null,
  "Монтируется перед запуском служб"
 ],
 "Mounts in parallel with services": [
  null,
  "Монтируется параллельно со службами"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Монтируется параллельно со службами, но после того, как сеть станет доступной"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "Multipathed devices": [
  null,
  "Многоканальные устройства"
 ],
 "NFS mount": [
  null,
  "Подключение по NFS"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Name can not be empty.": [
  null,
  "Имя не должно быть пустым."
 ],
 "Name cannot be empty.": [
  null,
  "Имя не должно быть пустым."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Длина имени в байтах не должна превышать $0"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Длина имени в символах не должна превышать $0"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Длина имени должна составлять не более 127 символов."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Длина имени не должна превышать 255 символов."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Имя не должно содержать знак «$0»."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Имя не должно содержать символ «/»."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Имя не должно содержать пробелы."
 ],
 "Need a spare disk": [
  null,
  "Требуется резервный диск"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Networked storage": [
  null,
  "Сетевое хранилище"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "New NFS mount": [
  null,
  "Новое подключение по NFS"
 ],
 "New passphrase": [
  null,
  "Новая парольная фраза"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "Next": [
  null,
  "Далее"
 ],
 "No available slots": [
  null,
  "Нет доступных слотов"
 ],
 "No block devices are available.": [
  null,
  "Нет доступных блочных устройств."
 ],
 "No block devices found": [
  null,
  "Блочные устройства не найдены"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "No devices found": [
  null,
  "Устройства не найдены"
 ],
 "No disks are available.": [
  null,
  "Нет доступных дисков."
 ],
 "No disks found": [
  null,
  "Диски не найдены"
 ],
 "No drives found": [
  null,
  "Накопители не найдены"
 ],
 "No encryption": [
  null,
  "Без шифрования"
 ],
 "No filesystem": [
  null,
  "Нет файловой системы"
 ],
 "No filesystems": [
  null,
  "Нет файловых систем"
 ],
 "No free key slots": [
  null,
  "Нет свободных слотов для ключей"
 ],
 "No free space": [
  null,
  "Нет свободного места"
 ],
 "No free space after this partition": [
  null,
  "После этого раздела нет свободного места"
 ],
 "No keys added": [
  null,
  "Нет добавленных ключей"
 ],
 "No logical volumes": [
  null,
  "Нет логических томов"
 ],
 "No media inserted": [
  null,
  "Носитель не вставлен"
 ],
 "No partitioning": [
  null,
  "Без разбиения"
 ],
 "No partitions found": [
  null,
  "Разделы не найдены"
 ],
 "No physical volumes found": [
  null,
  "Физические тома не найдены"
 ],
 "No storage found": [
  null,
  "Хранилище не найдено"
 ],
 "No subvolumes": [
  null,
  "Нет подтомов"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Not enough free space": [
  null,
  "Недостаточно свободного места"
 ],
 "Not enough space": [
  null,
  "Недостаточно места"
 ],
 "Not enough space to grow": [
  null,
  "Недостаточно места для увеличения"
 ],
 "Not found": [
  null,
  "Не найдено"
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Not running": [
  null,
  "Не работает"
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "Старая парольная фраза"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Используется только $0 из $1."
 ],
 "Operation '$operation' on $target": [
  null,
  "Операция «$operation» над $target"
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Overwrite": [
  null,
  "Перезаписать"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Заменить существующие данные нулями (медленно)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Partition": [
  null,
  "Раздел"
 ],
 "Partition of $0": [
  null,
  "Раздел $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Размер раздела составляет $0. Содержимое занимает $1."
 ],
 "Partitioning": [
  null,
  "Разбиение"
 ],
 "Partitions": [
  null,
  "Разделы"
 ],
 "Passphrase": [
  null,
  "Парольная фраза"
 ],
 "Passphrase can not be empty": [
  null,
  "Парольная фраза не может быть пустой"
 ],
 "Passphrase cannot be empty": [
  null,
  "Парольная фраза не может быть пустой"
 ],
 "Passphrase from any other key slot": [
  null,
  "Парольная фраза из любого другого слота для ключа"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Удаление парольной фразы может помешать разблокировке $0."
 ],
 "Passphrases do not match": [
  null,
  "Парольные фразы не совпадают"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Path on server": [
  null,
  "Путь на сервере"
 ],
 "Path on server cannot be empty.": [
  null,
  "Путь на сервере не может быть пустым."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Путь на сервере должен начинаться с символа «/»."
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "Permanently delete $0?": [
  null,
  "Окончательно удалить $0?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Окончательно удалить логический том $0/$1?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Окончательно удалить подтом $0?"
 ],
 "Physical": [
  null,
  "Физический размер"
 ],
 "Physical Volumes": [
  null,
  "Физические тома"
 ],
 "Physical volumes": [
  null,
  "Физические тома"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Здесь невозможно изменить размер физических томов"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Please unmount them first.": [
  null,
  "Сначала размонтируйте их."
 ],
 "Pool for thin logical volumes": [
  null,
  "Буфер для тонких логических томов"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Буфер для «тонко» резервируемых логических томов LVM2"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Буфер для «тонко» резервируемых томов"
 ],
 "Pool passphrase": [
  null,
  "Парольная фраза буфера"
 ],
 "Port": [
  null,
  "Порт"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Раздел загрузки PowerPC PReP"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Processes using the location": [
  null,
  "Процессы, использующие это расположение"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Введите парольную фразу для пула этих блоковых устройств:"
 ],
 "Purpose": [
  null,
  "Назначение"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (чередование)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (зеркалирование)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (чередование зеркалирования)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (выделенная чётность)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (распределённая чётность)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (двойная распределённая чётность)"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "RAID level": [
  null,
  "Уровень RAID"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 требуется чётное число физических томов"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Reading": [
  null,
  "Чтение"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Recovering": [
  null,
  "Восстановливается"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Восстановление устройства MDRAID $target"
 ],
 "Regenerating initrd": [
  null,
  "Повторное создание initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Связанные процессы и службы будут принудительно остановлены."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Связанные процессы будут принудительно остановлены."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Связанные службы будут принудительно остановлены."
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Remove $0?": [
  null,
  "Удалить $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Удалить сервер криптографических ключей Tang?"
 ],
 "Remove device": [
  null,
  "Удалить устройство"
 ],
 "Remove missing physical volumes?": [
  null,
  "Удалить отсутствующие физические тома?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Удалить парольную фразу в слоте ключа $0?"
 ],
 "Remove passphrase?": [
  null,
  "Удалить парольную фразу?"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Удаление $target с устройства MDRAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Удаление парольной фразы без подтверждения другой парольной фразой может привести к невозможности разблокировки или запрету управления ключами, если другие парольные фразы забыты или утеряны."
 ],
 "Removing physical volume from $target": [
  null,
  "Удаление физического тома из $target"
 ],
 "Rename": [
  null,
  "Переименовать"
 ],
 "Rename Stratis pool": [
  null,
  "Переименование пула Stratis"
 ],
 "Rename filesystem": [
  null,
  "Переименование файловой системы"
 ],
 "Rename logical volume": [
  null,
  "Переименование логического тома"
 ],
 "Rename volume group": [
  null,
  "Переименование группы томов"
 ],
 "Renaming $target": [
  null,
  "Переименование $target"
 ],
 "Repair": [
  null,
  "Исправить"
 ],
 "Repair logical volume $0": [
  null,
  "Исправить логический том $0"
 ],
 "Repairing $target": [
  null,
  "Восстановление $target"
 ],
 "Repeat passphrase": [
  null,
  "Подтверждение парольной фразы"
 ],
 "Resizing $target": [
  null,
  "Изменение размера $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Для изменения размера зашифрованной файловой системы необходимо разблокировать диск. Введите парольную фразу текущего диска."
 ],
 "Reuse existing encryption": [
  null,
  "Повторное использование существующего шифрования"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Повторное использование существующего шифрования ($0)"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "Running": [
  null,
  "Работает"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART самопроверка $target"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Экономьте место, сжимая отдельные блоки по алгоритму LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Экономьте место, сохраняя блоки идентичных данных лишь один раз"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Для сохранения новой парольной фразы требуется снятие блокировки диска. Укажите действующую парольную фразу диска."
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Securely erasing $target": [
  null,
  "Надёжное стирание $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At leat $0 are needed.": [
  null,
  "Выберите физические тома, которые следует использовать для восстановления логического тома. Необходимо как минимум $0."
 ],
 "Serial number": [
  null,
  "Серийный номер"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server address": [
  null,
  "Адрес сервера"
 ],
 "Server address cannot be empty.": [
  null,
  "Адрес сервера не может быть пустым."
 ],
 "Server cannot be empty.": [
  null,
  "Сервер не может быть пустым."
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Services using the location": [
  null,
  "Службы, использующие это расположение"
 ],
 "Set partition type of $0": [
  null,
  "Установить тип раздела $0"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Setting up loop device $target": [
  null,
  "Настройка петлевого устройства $target"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "Показать все строки ($0)"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Shrink": [
  null,
  "Сжать"
 ],
 "Shrink logical volume": [
  null,
  "Сжатие логического тома"
 ],
 "Shrink partition": [
  null,
  "Сжать раздел"
 ],
 "Shrink volume": [
  null,
  "Сжать том"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Size": [
  null,
  "Размер"
 ],
 "Size cannot be negative": [
  null,
  "Размер не может быть отрицательным"
 ],
 "Size cannot be zero": [
  null,
  "Размер не может быть равен нулю"
 ],
 "Size is too large": [
  null,
  "Слишком большой размер"
 ],
 "Size must be a number": [
  null,
  "Размер должен быть числом"
 ],
 "Size must be at least $0": [
  null,
  "Размер должен быть не менее $0"
 ],
 "Slot $0": [
  null,
  "Слот $0"
 ],
 "Snapshot": [
  null,
  "Моментальный снимок"
 ],
 "Solid State Drive": [
  null,
  "Твёрдотельный накопитель"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Некоторые блочные устройства этого буфера увеличились в размере после создания буфера. Буфер можно безопасно увеличить, чтобы использовать вновь освободившееся пространство."
 ],
 "Sorry": [
  null,
  "Ошибка"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Spare": [
  null,
  "В запасе"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Start": [
  null,
  "Запустить"
 ],
 "Start multipath": [
  null,
  "Запустить multipath"
 ],
 "Started": [
  null,
  "Начало"
 ],
 "Starting MDRAID device $target": [
  null,
  "Запуск устройства MDRAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "Запуск области подкачки $target"
 ],
 "State": [
  null,
  "Состояние"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "Stop": [
  null,
  "Остановить"
 ],
 "Stop and remove": [
  null,
  "Остановить и удалить"
 ],
 "Stop and unmount": [
  null,
  "Остановить и отключить"
 ],
 "Stop device": [
  null,
  "Остановить устройство"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Остановка устройства MDRAID $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Остановка области подкачки $target"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Управление хранилищем недоступно в данной системе."
 ],
 "Storage logs": [
  null,
  "Журналы хранения"
 ],
 "Store passphrase": [
  null,
  "Хранить парольную фразу"
 ],
 "Stored passphrase": [
  null,
  "Сохранённая парольная фраза"
 ],
 "Stratis block device": [
  null,
  "Блочное устройство Stratis"
 ],
 "Stratis block devices": [
  null,
  "Блочные устройства Stratis"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Блочные устройства Stratis не могут быть уменьшены"
 ],
 "Stratis filesystem": [
  null,
  "Файловая система Stratis"
 ],
 "Stratis filesystems": [
  null,
  "Файловые системы Stratis"
 ],
 "Stratis filesystems pool": [
  null,
  "Буфер файловых систем Stratis"
 ],
 "Stratis pool": [
  null,
  "Пул Stratis"
 ],
 "Striped (RAID 0)": [
  null,
  "Полосатый (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Полосатый и зеркальный (RAID 10)"
 ],
 "Stripes": [
  null,
  "Полосы"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Subvolume needs to be mounted": [
  null,
  "Подтом должен быть смонтирован"
 ],
 "Subvolume needs to be mounted writable": [
  null,
  "Подтом должен быть смонтирован для записи"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Успешно скопировано в буфер обмена!"
 ],
 "Swap": [
  null,
  "Подкачка"
 ],
 "Swap can not be resized here": [
  null,
  "Здесь невозможно изменить размер резервной памяти"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Синхронизация устройства MDRAID $target"
 ],
 "Tablet": [
  null,
  "Планшетный ПК"
 ],
 "Tang keyserver": [
  null,
  "Сервер криптографических ключей Tang"
 ],
 "Target": [
  null,
  "Цель"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Пакет $0 недоступен в репозиториях."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Для создания пулов Stratis должен быть установлен пакет $0."
 ],
 "The $0 package must be installed.": [
  null,
  "Требуется установить пакет $0."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Для создания устройств VDO будет установлен пакет $0."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Устройство MDRAID находится в состоянии сбоя"
 ],
 "The MDRAID device must be running": [
  null,
  "Устройство MDRAID должно быть запущено"
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Создание данного устройства VDO не завершилось, поэтому устройство не может быть использовано."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Текущему пользователю не разрешено просматривать сведения о ключах."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Перед форматированием диск необходимо разблокировать. Введите соответствующую парольную фразу."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "У этой файловой системы нет назначенной точки монтирования."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "У этой файловой системы нет постоянной точки монтирования."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Настройка файловой системы обеспечивает автоматическое монтирование при загрузке, но к моменту монтирования контейнер шифрования не будет разблокирован."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Файловая система сейчас смонтирована, после следующей загрузки не будет смонтирована."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Файловая система сейчас смонтирована на $0, но при следующей загрузке будет монтироваться на $1."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Файловая система сейчас смонтирована на $0, но не будет монтироваться при следующей загрузке."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Файловая система сейчас не смонтирована, но будет монтироваться при следующей загрузке."
 ],
 "The filesystem is not mounted.": [
  null,
  "Файловая система не смонтирована."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Файловая система будет разблокирована и смонтирована при следующей загрузке. При этом может потребоваться ввод парольной фразы."
 ],
 "The initrd must be regenerated.": [
  null,
  "initrd должен быть создан повторно."
 ],
 "The last key slot can not be removed": [
  null,
  "Последний слот для ключа не может быть удалён"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Перечисленные процессы и службы будут принудительно остановлены."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Перечисленные процессы будут принудительно остановлены."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Перечисленные службы будут принудительно остановлены."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Точка монтирования $0 используется следующими процессами:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Точка монтирования $0 используется следующими службами:"
 ],
 "The passwords do not match.": [
  null,
  "Пароли не совпадают."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "В настоящее время система не поддерживает разблокировку файловой системы с сервером ключей Tang во время загрузки."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "В настоящее время система не поддерживает разблокировку корневой файловой системы с помощью сервера ключей Tang."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "В системе есть устройства, использующие несколько путей, но служба multipath не работает."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Здесь не хватает места, которое можно было бы использовать для восстановления. Требуется не менее $0 на физических томах, которые ещё не используются для этого логического тома."
 ],
 "There is not enough space in the pool to make a snapshot of this filesystem. At least $0 are required but only $1 are available.": [
  null,
  "В буфере недостаточно места для создания моментального снимка этой файловой системы. Требуется не менее $0, но доступно только $1."
 ],
 "These additional steps are necessary:": [
  null,
  "Необходимы дополнительные шаги:"
 ],
 "These changes will be made:": [
  null,
  "Будут внесены следующие изменения:"
 ],
 "Thin logical volume": [
  null,
  "Тонкий логический том"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Тонко резервируемые логические тома LVM2"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce sychronization times significantly.": [
  null,
  "Это устройство MDRAID не имеет битовой карты, ориентированной на запись. Наличие такой битовой карты может значительно сократить время синхронизации."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Данное подключение по NFS используется. Возможно только изменение его параметров."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Данное устройство VDO не полностью использует резервное устройство."
 ],
 "This device can not be used for the installation target.": [
  null,
  "Это устройство не может быть использовано для целей установки."
 ],
 "This device is currently in use.": [
  null,
  "Это устройство в данный момент используется."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Этот сервер ключей является единственным способом разблокировать буфер и не может быть удалён."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Этот логический том потерял часть своих физических томов и больше не может использоваться. Необходимо удалить его и создать новый, чтобы занять его место."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Этот логический том потерял часть своих физических томов, но не потерял данные. Его следует восстановить, чтобы вернуть первоначальное резервирование."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Этот логический том потерял часть своих физических томов, но, возможно, данные ещё не потеряны. Возможно, его удастся восстановить."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Логический том используется содержимым не до конца."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Этот раздел используется не полностью."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Эта парольная фраза является единственным способом разблокировать буфер и не может быть удалена."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Этот буфер не использует всё пространство на своих блочных устройствах."
 ],
 "This pool is in a degraded state.": [
  null,
  "Этот буфер находится в состоянии сбоя"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Этот инструмент настраивает систему для записи аварийных дампов ядра на диск."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "В этой группе томов отсутствуют некоторые физические тома."
 ],
 "Tier": [
  null,
  "Уровень"
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Trust key": [
  null,
  "Ключ доверия"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Тип может содержать только символы от 0 до 9, от A до F и «-»."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Тип должен иметь форму NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Тип должен содержать два шестнадцатеричных символа (от 0 до 9, от А до F)"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Не удаётся связаться с сервером"
 ],
 "Unable to remove mount": [
  null,
  "Не удаётся удалить подключение"
 ],
 "Unable to repair logical volume $0": [
  null,
  "Не удалось восстановить логический том $0"
 ],
 "Unable to unmount filesystem": [
  null,
  "Не удаётся отключить файловую систему"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Неожиданная ошибка PackageKit во время установки $0: $1"
 ],
 "Unformatted data": [
  null,
  "Неформатированные данные"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Unknown ($0)": [
  null,
  "Неизвестно ($0)"
 ],
 "Unknown host name": [
  null,
  "Неизвестное имя узла"
 ],
 "Unknown type": [
  null,
  "Неизвестный тип"
 ],
 "Unlock": [
  null,
  "Разблокировать"
 ],
 "Unlock automatically on boot": [
  null,
  "Автоматически снимать блокировку при загрузке"
 ],
 "Unlock before resizing": [
  null,
  "Разблокировать перед изменением размера"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Снятие блокировки зашифрованного пула Stratis"
 ],
 "Unlocking $target": [
  null,
  "Снятие блокировки $target"
 ],
 "Unlocking disk": [
  null,
  "Снятие блокировки диска"
 ],
 "Unmount": [
  null,
  "Отключить"
 ],
 "Unmount filesystem $0": [
  null,
  "Размонтирование файловой системы $0"
 ],
 "Unmount now": [
  null,
  "Размонтировать сейчас"
 ],
 "Unmounting $target": [
  null,
  "Отключение $target"
 ],
 "Unrecognized data": [
  null,
  "Нераспознанные данные"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Нераспознанные данные не могут быть уменьшены здесь"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Нераспознанные данные не могут быть уменьшены здесь."
 ],
 "Unsupported logical volume": [
  null,
  "Неподдерживаемый логический том"
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "Usage": [
  null,
  "Использование"
 ],
 "Usage of $0": [
  null,
  "Использование $0"
 ],
 "Use": [
  null,
  "Использование"
 ],
 "Use compression": [
  null,
  "Использовать сжатие"
 ],
 "Use deduplication": [
  null,
  "Использовать дедупликацию"
 ],
 "Used": [
  null,
  "Использовано"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Полезно для монтирований, которые являются необязательными или требуют взаимодействия (например, парольные фразы)"
 ],
 "User": [
  null,
  "Пользователь"
 ],
 "Username": [
  null,
  "Имя пользователя"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Устройства резервирования VDO не могут быть уменьшены"
 ],
 "VDO device $0": [
  null,
  "Устройство VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Том файловой системы VDO (сжатие/дедупликация)"
 ],
 "Vendor": [
  null,
  "Производитель"
 ],
 "Verify key": [
  null,
  "Проверка ключа"
 ],
 "Very securely erasing $target": [
  null,
  "Крайне надёжное стирание $target"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "View logs": [
  null,
  "Смотреть журналы"
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Volume group": [
  null,
  "Группа томов"
 ],
 "Volume group is missing physical volumes": [
  null,
  "В группе томов отсутствуют физические тома"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Размер тома составляет $0. Содержимое занимает $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "When this option is checked, the new pool will not allow overprovisioning. You need to specify a maximum size for each filesystem that is created in the pool. Filesystems can not be made larger after creation. Snapshots are fully allocated on creation. The sum of all maximum sizes can not exceed the size of the pool. The advantage of this is that filesystems in this pool can not run out of space in a surprising way. The disadvantage is that you need to know the maximum size for each filesystem in advance and creation of snapshots is limited.": [
  null,
  "Если установлен этот флажок, новый буфер не будет допускать избыточного резервирования. Необходимо указать максимальный размер для каждой файловой системы, создаваемой в буфере. Файловые системы невозможно увеличить после создания. Мгновенные снимки полностью распределяются при создании. Сумма всех максимальных размеров не может превышать размера буфера. Преимуществом этого варианта является то, что в файловые системы в этом буфере не может неожиданно закончиться место. Недостаток заключается в том, что вам необходимо заранее знать максимальный размер для каждой файловой системы, а создание моментальных снимков ограничено."
 ],
 "World wide name": [
  null,
  "WWN-имя"
 ],
 "Write-mostly": [
  null,
  "В основном запись"
 ],
 "Writing": [
  null,
  "Запись"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "after network": [
  null,
  "после сети"
 ],
 "backing device for VDO device": [
  null,
  "устройство резервного копирования для устройства VDO"
 ],
 "btrfs device": [
  null,
  "Устройство BTRFS"
 ],
 "btrfs devices": [
  null,
  "Устройства BTRFS"
 ],
 "btrfs filesystem": [
  null,
  "Файловая система BTRFS"
 ],
 "btrfs subvolume": [
  null,
  "Подтом BTRFS"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "Подтом BTRFS $0 из $1"
 ],
 "btrfs subvolumes": [
  null,
  "Подтома BTRFS"
 ],
 "btrfs volume": [
  null,
  "Том BTRFS"
 ],
 "cache": [
  null,
  "кэш"
 ],
 "data": [
  null,
  "данные"
 ],
 "deactivate": [
  null,
  "отключить"
 ],
 "delete": [
  null,
  "удалить"
 ],
 "device of btrfs volume": [
  null,
  "устройство тома BTRFS"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "encrypted": [
  null,
  "зашифрованный"
 ],
 "format": [
  null,
  "форматировать"
 ],
 "grow": [
  null,
  "расширить"
 ],
 "iSCSI Drive": [
  null,
  "Накопитель iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Накопители iSCSI"
 ],
 "iSCSI portal": [
  null,
  "Портал iSCSI"
 ],
 "ignore failure": [
  null,
  "игнорировать ошибки"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "initialize": [
  null,
  "инициализировать"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "member of MDRAID device": [
  null,
  "элемент устройства MDRAID"
 ],
 "member of Stratis pool": [
  null,
  "участник пула Stratis"
 ],
 "mount": [
  null,
  "монтировать"
 ],
 "never mount at boot": [
  null,
  "никогда не монтировать при загрузке"
 ],
 "none": [
  null,
  "нет"
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "физический том группы томов LVM2"
 ],
 "read only": [
  null,
  "только для чтения"
 ],
 "remove from LVM2": [
  null,
  "удалить из LVM2"
 ],
 "remove from MDRAID": [
  null,
  "удалить из MDRAID"
 ],
 "remove from btrfs volume": [
  null,
  "удалить из тома BTRFS"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "shrink": [
  null,
  "сжать"
 ],
 "stop": [
  null,
  "остановить"
 ],
 "stop boot on failure": [
  null,
  "прекратить загрузку при ошибке"
 ],
 "stopped": [
  null,
  "остановлено"
 ],
 "unknown target": [
  null,
  "неизвестная цель"
 ],
 "unmount": [
  null,
  "размонтировать"
 ],
 "unpartitioned space on $0": [
  null,
  "неразмеченная область диска на $0"
 ],
 "using key description $0": [
  null,
  "с использованием описания ключа $0"
 ],
 "yes": [
  null,
  "да"
 ],
 "format-bytes\u0004bytes": [
  null,
  "байтов"
 ]
});
