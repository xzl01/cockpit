cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "$0 can not be made larger": [
  null,
  "$0 მეტად ვეღარ გაიზრდება"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 მეტად ვეღარ დაპატარავდება"
 ],
 "$0 can not be resized": [
  null,
  "$0 ზომას ვერ შეცვლით"
 ],
 "$0 can not be resized here": [
  null,
  "$0-ის ზომას აქ ვერ შეცვლით"
 ],
 "$0 chunk size": [
  null,
  "ნაგლეჯის ზომა $0"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 მონაცემები + $1 დამატებით გამოყენებული $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 disk is missing": [
  null,
  "$0 დისკი აკლია",
  "$0 ცალი დისკი აკლია"
 ],
 "$0 disks": [
  null,
  "$0 დისკი"
 ],
 "$0 exited with code $1": [
  null,
  "$0-ის გამოსვლის კოდია $1"
 ],
 "$0 failed": [
  null,
  "$0 წარუმატებელია"
 ],
 "$0 filesystem": [
  null,
  "ფაილური სისტემა $0"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 is in use": [
  null,
  "$0 გამოიყენება"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 მოკვდა სიგნალით $1"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 partitions": [
  null,
  "$0 დანაყოფი"
 ],
 "$0 slot remains": [
  null,
  "დარჩენილია $0 სლოტი",
  "დარჩენილი სლოტების რაოდენობა $0"
 ],
 "$0 synchronized": [
  null,
  "$0 სინქრონიზებულია"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "გამოყენებულია $0 $1-დან (შენახულია $2)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 გამოყენებული, ჯამში $1"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "$name (from $host)": [
  null,
  "$name ($host-დან)"
 ],
 "(Not part of target)": [
  null,
  "(სამიზნის ნაწილი არაა)"
 ],
 "(no assigned mount point)": [
  null,
  "(მინიჭებული მიმაგრების წერტილის გარეშე)"
 ],
 "(not mounted)": [
  null,
  "(მიმაგრებული არაა)"
 ],
 "(recommended)": [
  null,
  "(რეკომენდებულია)"
 ],
 "1 MiB": [
  null,
  "1 მიბ"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "128 KiB": [
  null,
  "128 კიბ"
 ],
 "16 KiB": [
  null,
  "16 კიბ"
 ],
 "2 MiB": [
  null,
  "2 მიბ"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "32 KiB": [
  null,
  "32 კიბ"
 ],
 "4 KiB": [
  null,
  "4 კიბ"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "512 KiB": [
  null,
  "512 კიბ"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "64 KiB": [
  null,
  "64 კიბ"
 ],
 "8 KiB": [
  null,
  "8 კიბ"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "ფაილური სისტემა ამ სახელით მითითებულ პულში უკვე არსებობს."
 ],
 "A pool with this name exists already.": [
  null,
  "პული ამ სახელით უკვე არსებობს."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "ტომების ჯგუფს, რომელსაც ფიზიკური ტომები აკლია, სახელს ვერ გადაარქმევთ."
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Acceptable password": [
  null,
  "მისაღები პაროლი"
 ],
 "Action": [
  null,
  "ქმედება"
 ],
 "Actions": [
  null,
  "ქმედებები"
 ],
 "Activate": [
  null,
  "აქტივაცია"
 ],
 "Activate before resizing": [
  null,
  "აქტივაცია ზომის შეცვლამდე"
 ],
 "Activating $target": [
  null,
  "$target-ის აქტივაცია"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "ქსელზე მიბმული დისკის დაშიფვრის დამატება"
 ],
 "Add Tang keyserver": [
  null,
  "Tang გასაღებების სერვერის დამატება"
 ],
 "Add a bitmap": [
  null,
  "ბიტური რუკის დამატება"
 ],
 "Add block devices": [
  null,
  "ბლოკური მოწყობილობების დამატება"
 ],
 "Add disk": [
  null,
  "დისკის დამატება"
 ],
 "Add disks": [
  null,
  "დისკების დამატება"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI პორტალის დამატება"
 ],
 "Add key": [
  null,
  "გასაღების დამატება"
 ],
 "Add keyserver": [
  null,
  "გასაღებების სერვერის დამატება"
 ],
 "Add passphrase": [
  null,
  "საკვანძო ფრაზის დამატება"
 ],
 "Add physical volume": [
  null,
  "ფიზიკური ტომის დამატება"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "\"$0\"-ის დამატება დაშიფვრის პარამეტრებში"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "\"$0\"-ის დამატება ფაილური სისტემის პარამეტრებში"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "ახალი გასარებების სერვერის დასამატებლად საჭიროა პულის განბლოკვა. შეიყვანეთ არსებული პულის საკვანძო ფრაზა."
 ],
 "Adding key": [
  null,
  "გასაღების დამატება"
 ],
 "Adding physical volume to $target": [
  null,
  "$target-ზე ფიზიკური მოცულობების დამატება"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "ბირთვის ბრძანების სტრიქონში rd.neednet=1 -ის დამატება"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Address": [
  null,
  "მისამართი"
 ],
 "Address cannot be empty": [
  null,
  "მისამართი არ შეიძლება ცარიელი იყოს"
 ],
 "Address is not a valid URL": [
  null,
  "მისამართი არ წარმოადგენს სწორ URL-ს"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockput ვებ კონსოლით ადმინისტრირება"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "All $0 selected physical volumes are needed for the choosen layout.": [
  null,
  "ყველა $0 მონიშნული ფიზიკური ტომია საჭირო არჩეული განლაგებისთვის."
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "An additional $0 must be selected": [
  null,
  "საჭიროა დამატებით $0-ის მონიშვნა"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-ის როლების დოკუმენტაცია"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "სათანადოა კრიტიკული მიმაგრების წერტილებისთვის, როგორიცაა /var"
 ],
 "Assessment": [
  null,
  "შეფასება"
 ],
 "At boot": [
  null,
  "ჩატვირთვისას"
 ],
 "At least $0 disk is needed.": [
  null,
  "საჭიროა $0 დისკი მაინც.",
  "საჭიროა $0 ცალი დისკი მაინც."
 ],
 "At least one block device is needed.": [
  null,
  "საჭიროა ერთი ბლოკური ტიპის მოწყობილობა მაინც."
 ],
 "At least one disk is needed.": [
  null,
  "საჭიროა ერთი დისკი მაინც."
 ],
 "At least one parent needs to be mounted writable": [
  null,
  "აუცილებელია, სულ ცოტა, ერთი მშობელი ჩაწერადად იყოს მიმაგრებული"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit ვებ კონსოლში პრივილეგირებული ამოცანების შესასრულებლად საჭიროა ავთენტიკაცია"
 ],
 "Authentication required": [
  null,
  "საჭიროა ავთენტიკაცია"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using additional NTP servers": [
  null,
  "დამატებითი NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automation script": [
  null,
  "ავტომატიზაციის სკრიპტი"
 ],
 "Available targets on $0": [
  null,
  "ხელმისაწვდომი სამიზნე $0-ზე"
 ],
 "BIOS boot partition": [
  null,
  "BIOS ჩატვირთვის დანაყოფი"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Block device": [
  null,
  "ბლოკური მოწყობილობა"
 ],
 "Block device for filesystems": [
  null,
  "ბლოკური მოწყობილობები ფაილური სისტემებისთვის"
 ],
 "Block devices": [
  null,
  "ბლოკური მოწყობილობები"
 ],
 "Blocked": [
  null,
  "დაბლოკილია"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "ჩატვირთვა ავარიულია, თუ ფაილური სისტემა მიმაგრებული არ იქნება, რის შედეგადაც დაშორებული წვდომა არ გექნებათ"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "ჩატვირთვა გაგრძელდება, თუ ფაილური სისტემა მიმაგრებული არაა"
 ],
 "Btrfs volume is mounted": [
  null,
  "Btrfs ტომი მიმაგრებულია"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "Cache": [
  null,
  "ქეში"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Cannot forward login credentials": [
  null,
  "მომხმარებლისადაპაროლის გადაგზავნის შეცდომა"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "Capacity": [
  null,
  "მოცულობა"
 ],
 "Category": [
  null,
  "კატეგორია"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change iSCSI initiater name": [
  null,
  "iSCSI ინიციატორის სახელის შეცვლა"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI ინიციატორის სახელის შეცვლა"
 ],
 "Change label": [
  null,
  "ჭდის შეცვლა"
 ],
 "Change passphrase": [
  null,
  "საკვანძო ფრაზის შეცვლა"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "დანაყოფის ტიპების შეცვლამ, შეიძლება, სისტემის ჩატვირთვას ხელი შეუშალოს."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "შემწმება, ბრძანების სტრიქონიდან მოსული SHA-256 ან SHA-1 ჰეში ფანჯრისას თუ ემთხვევა."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "გასაღების ჰეშის Tang სერვერთან შემოწმება."
 ],
 "Checking $target": [
  null,
  "$target-ის შემოწმება"
 ],
 "Checking MDRAID device $target": [
  null,
  "MDRAID მოწყობილობის, $target-ის შემოწმება"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის შემოწმება და შეკეთება"
 ],
 "Checking filesystem usage": [
  null,
  "ფაილური სისტემის გამოყენების შემოწმება"
 ],
 "Checking for $0 package": [
  null,
  "$0 პაკეტის შემოწმება"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Initrd-ში NBDE-ის მხარდაჭერის შემოწმება"
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "Chunk size": [
  null,
  "ბლოკის ზომა"
 ],
 "Cleaning up for $target": [
  null,
  "$target-ის გასუფთავება"
 ],
 "Cleartext device": [
  null,
  "მოწყობილობის შექმნა"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager-ის და Firewalld-ის მორგება Cockpit-ით"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit-ს მითითებულ ჰოსტთან დაკავშირება არ შეუძლია ."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit წარმოადგენს სერვერის მმართველს, რომლითაც Linux სერვერების ადმინისტრირება ბრაუზერითაც შეგიძლიათ. ტერმინალსა და ვებ ხელსაწყოს შორის გადართვა პრობლემა არაა. Cockpit-ით გაშვებული სერვისი შეგიძლიათ გააჩეროთ ტერმინალთაც. ასევე, თუ შეცდომა დაფიქსირდება ტერმინალში, მისი ნახვა Cockpit-ის საშუალებითაც შეგიძლიათ."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit-ი შეუთავსებელია თქვენს სერვერზე დაყენებულ პროგრამულ უზრუნველყოფასთან."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit-ი ამ სისტემაზე დაყენებული არაა."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit შესანიშნავია ახალი სისტემური ადმინისტრატორებისთვის. ის მათ საშუალებას აძლევს ადვილად შეასრულონ ისეთი მარტივი ამოცანები, როგორიცაა შენახვის ადმინისტრირება, ჟურნალების შემოწმება და სერვისების დაწყება და გაჩერება. შეგიძლიათ ერთდროულად რამდენიმე სერვერის მონიტორინგი და ადმინისტრირება. უბრალოდ დაამატეთ ისინი ერთი დაწკაპუნებით და თქვენი მანქანები იზრუნებს მის მეგობრებზე."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "მოაგროვეთ დიაგნოსტიკური და მხარდაჭერის მონაცემები"
 ],
 "Collect kernel crash dumps": [
  null,
  "ოპერაციული სისტემის ბირთვის ავარიის დამპები"
 ],
 "Command": [
  null,
  "ბრძანება"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "თავსებადია ყველა სისტემასა და მოწყობილობასთან (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "თავსებადია თანამედროვე სისტემებთან და >2TB დისკებთან (GPT)"
 ],
 "Compression": [
  null,
  "შეკუმშვა"
 ],
 "Confirm": [
  null,
  "დასტური"
 ],
 "Confirm deletion of $0": [
  null,
  "დაადასტურეთ $0-ის წაშლა"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "არასავალდებულო საკვნძო ფრაზის წაშლის დადასტურება"
 ],
 "Confirm stopping of $0": [
  null,
  "დაადასტურეთ $0-ის გაჩერება"
 ],
 "Connection has timed out.": [
  null,
  "კავშირის დრო გავიდა."
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Copy to clipboard": [
  null,
  "ბაფერში კოპირება"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 საცავის ჯგუფის შექმნა"
 ],
 "Create MDRAID device": [
  null,
  "MDRAID მოწყობილობის შექმნა"
 ],
 "Create RAID device": [
  null,
  "RAID მოწყობილობის შექმნა"
 ],
 "Create Stratis pool": [
  null,
  "Stratis-ის პულის შექმნა"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "ფაილური სისტემა $0-ის მყისიერი ასლის გადაღება"
 ],
 "Create and mount": [
  null,
  "შექმნა და მიმაგრება"
 ],
 "Create and start": [
  null,
  "შექმნა და გაშვება"
 ],
 "Create filesystem": [
  null,
  "ფაილური სისტემის შექმნა"
 ],
 "Create logical volume": [
  null,
  "ლოგიკური ტომის შექმნა"
 ],
 "Create new filesystem": [
  null,
  "ახალი ფაილური სისტემის შექმნა"
 ],
 "Create new logical volume": [
  null,
  "ახალი ლოგიკური ტომის შექმნა"
 ],
 "Create new task file with this content.": [
  null,
  "ახალი ამოცანის ამ შემცველობით შექმნა."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "ახალი თხლად გამოყოფილი ლოგიკური ტომის შექმნა"
 ],
 "Create only": [
  null,
  "მხოლოდ შექმნა"
 ],
 "Create partition": [
  null,
  "განაყოფის შექმნა"
 ],
 "Create partition on $0": [
  null,
  "$0-ზე სექციის შექმნა"
 ],
 "Create partition table": [
  null,
  "დაყოფის ცხრილის შექმნა"
 ],
 "Create snapshot": [
  null,
  "სწრაფი ასლის შექმნა"
 ],
 "Create snapshot and mount": [
  null,
  "სწრაფი ასლის შექმნა და მიმაგრება"
 ],
 "Create snapshot only": [
  null,
  "მხოლოდ სწრაფი ასლის შექმნა"
 ],
 "Create storage device": [
  null,
  "საცავის მოწყობილობების შექმნა"
 ],
 "Create subvolume": [
  null,
  "ქვეტომის შექმნა"
 ],
 "Create thin volume": [
  null,
  "თხელი ტომის შექმნა"
 ],
 "Create volume group": [
  null,
  "ტომების ჯგუფის შექმნა"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2 საცავების ჯგუფი $target-ის შექმნა"
 ],
 "Creating MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის შექმნა"
 ],
 "Creating VDO device": [
  null,
  "VDO მოწყობილობის შექმნა"
 ],
 "Creating filesystem on $target": [
  null,
  "$target-ზე ფაილური სისტემის შექმნა"
 ],
 "Creating logical volume $target": [
  null,
  "ლოგიკური საცავს $target-ის შექმნა"
 ],
 "Creating partition $target": [
  null,
  "დანაყოფის შექმნა $target"
 ],
 "Creating snapshot of $target": [
  null,
  "$taget-ის სწრაფი ასლის შექმნა"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "ამჟამად გამოიყენება"
 ],
 "Custom": [
  null,
  "ხელით"
 ],
 "Custom mount options": [
  null,
  "მიმაგრების მორგება"
 ],
 "Custom type": [
  null,
  "მომხმარებლის ტიპი"
 ],
 "Data": [
  null,
  "მონაცემები"
 ],
 "Data used": [
  null,
  "გამოყენებული მონაცემები"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "მონაცემები 2 ასლად იქნება შენახული და კიდევ, ცვალებადი მიდგომით, მონიშნულ ფიზიკურ ტომებზე, რათა გაუმჯობესდეს ორივე, სანდოობა და წარმადობა. საჭიროა, მინიმუმ, 4 ტომის მონიშვნა."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "მონაცემები შენახული იქნება ორი ან მეტი ასლის სახით მონიშნულ ფიზიკურ ტომებზე, რათა საიმედოობა გაზარდოს. საჭიროა, მინიმუმ, 2 ტომის მონიშვნა."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "მონაცემები შენახული იქნება მონიშნულ ფიზიკურ ტომებზე ცვალებადი სახით, რათა წარმადობა გაიზარდოს. საჭიროა, მინიმუმ, 2 ტომი."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "მონაცემები შეინახება მონიშნულ ფიზიკურ ტომებზე ისე, რომ შეგიძლიათ, ერთ-ერთი მათგანი მონაცემების დაკარგვის გარეშე დაკარგოთ. საჭიროა მინიმუმ 3 ტომი."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "მონაცემები შენახული იქნება მონიშნულ ფიზიკურ ტომებზე ისე, რომ ერთ-ერთი მათგანის დაკარგვა მონაცემების დაკარგვის გარეშე შეგიძლიათ. მონაცემები შენახული იქნება მონაცვლეობითი მიმდევრობით, წარმადობის გასაზრდელად. საჭიროა სულ ცოტა სამი ტომის მონიშვნა."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "მონაცემები შენახული იქნება მონიშნულ ფიზიკურ ტომებზე ისე, რომ, ერთდროულად, ორი მათგანი შეგეძლებათ დაკარგოთ, მონაცემების კარგვის გარეშე. მონაცემები შენახულია მონაცვლეობითი მიმდევრობით, რათა წარმადობა გაზარდოს. საჭიროა მინიმუმ ხუთი ტომის არჩევა."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "მონაცემები მონიშნულ ტომებზე დამატებითი საიმედოობის თუ წარმადობის გაზრდის გარეშე იქნება დამახსოვრებული."
 ],
 "Deactivate": [
  null,
  "დეაქტივაცია"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "მოხდეს ლოგიკური ტომის, $0/$1 დეაქტივაცია?"
 ],
 "Deactivating $target": [
  null,
  "$target-ის დეაქტივაცია"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "გამოყოფილი ლუწობა (RAID 4)"
 ],
 "Deduplication": [
  null,
  "დედუპლიკაცია"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Delete group": [
  null,
  "ჯგუფის წაშლა"
 ],
 "Delete pool": [
  null,
  "პულის წაშლა"
 ],
 "Deleting $target": [
  null,
  "$target-ის წაშლა"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2 საცავების ჯგუფი $taget-ის წაშლა"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Stratis-ის პულის წაშლა მასზე ჩაწერილი მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "ფაილური სისტემის წაშლა მასზე არსებული მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "ლოგიკური საცავის წაშლა მასზე მდებარე მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "დანაყოფის წაშლა მასზე მდებარე მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "MDRAID მოწყობილობის წაშლის შემთხვევაში ასევე წაიშლება ზედ მდებარე მონაცემებიც."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "VDO მოწყობილობის წაშლის შემთხვევაში ასევე წაიშლება ზედ მდებარე ყველა მონაცემი."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "საცავების ჯგუფის წაშლისას ასევე წაიშლება ზედ მდებარე მონაცემებიც."
 ],
 "Deleting erases all data on this subvolume and all it's children.": [
  null,
  "წაშლა გაანადგურებს მონაცემებს ამ ქვეტომზე და ყველა მის შვილზე."
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "Device": [
  null,
  "მოწყობილობა"
 ],
 "Device contains unrecognized data": [
  null,
  "მოწყობილობა უცნობ მონაცემებს შეიცავს"
 ],
 "Device file": [
  null,
  "მოწყობილობის ფაილი"
 ],
 "Device is read-only": [
  null,
  "მოწყობილობა მხოლოდ კითხვადია"
 ],
 "Device number": [
  null,
  "მოწყობილობის ნომერი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Disconnect": [
  null,
  "გათიშვა"
 ],
 "Disk is OK": [
  null,
  "დისკი კარგად გამოიყურება"
 ],
 "Disk is failing": [
  null,
  "დისკი კვდება"
 ],
 "Disk passphrase": [
  null,
  "დისკის საკვანძო სიტყვა"
 ],
 "Disks": [
  null,
  "დისკები"
 ],
 "Dismiss": [
  null,
  "მოცილება"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "განაწილებული ლუწობა (RAID 5)"
 ],
 "Do not mount": [
  null,
  "არ მიამაგრო"
 ],
 "Do not mount automatically on boot": [
  null,
  "ჩატვირთვისას არ მიმაგრება"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "Does not mount during boot": [
  null,
  "ჩატვირთვისას არ მიმაგრება"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "ორმაგად განაწილებული ლუწობა (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Drive": [
  null,
  "დისკი"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "EFI system partition": [
  null,
  "EFI-ის სისტემური დანაყოფი"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang გასაღებების სერვერის ჩასწორება"
 ],
 "Edit mount point": [
  null,
  "მიმაგრების წერტილის ჩასწორება"
 ],
 "Editing a key requires a free slot": [
  null,
  "გასაღების ჩასასწორებლად საჭიროა თავისუფალი სლოტი"
 ],
 "Ejecting $target": [
  null,
  "$target-ის გამოგდება"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Emptying $target": [
  null,
  "$target-ის დაცარიელება"
 ],
 "Enabling $0": [
  null,
  "$0-ის ჩართვა"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "მონაცემების დაშიფვრა Tang-ის გასაღებების სერვერით"
 ],
 "Encrypt data with a passphrase": [
  null,
  "დაშიფვრა საკვანძო ფრაზით"
 ],
 "Encrypted $0": [
  null,
  "$0 დაშიფრულია"
 ],
 "Encrypted Stratis pool": [
  null,
  "სტრატისის დაშიფრული პული"
 ],
 "Encrypted logical volume of $0": [
  null,
  "ლოგიკური დაშიფრული საცავი $0"
 ],
 "Encrypted partition of $0": [
  null,
  "$0-ის დაშიფრული სექცია"
 ],
 "Encryption": [
  null,
  "დაშიფვრა"
 ],
 "Encryption options": [
  null,
  "დაშიფვრის მორგება"
 ],
 "Encryption type": [
  null,
  "დაშიფვრის ტიპი"
 ],
 "Erasing $target": [
  null,
  "$target-ის წაშლა"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "$0-ის დაყენების შეცდომა: PackageKit დაყენებული არაა"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "საჭიროა ზუსტად $0 ფიზიკური ტომის მონიშვნა"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "საჭიროა ზუსტად $0 ფიზიკური ტომის მონიშვნა, თითო ზოლი თითო ლოგიკური ტომისთვის."
 ],
 "Excellent password": [
  null,
  "გადასარევი პაროლი"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Extended partition": [
  null,
  "გაფართოებული განაყოფი"
 ],
 "Failed": [
  null,
  "შეცდომით"
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld-ში $0-ის ჩართვის შეცდომა"
 ],
 "Filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "Filesystem is locked": [
  null,
  "ფაილური სისტემა ჩაკეტილია"
 ],
 "Filesystem name": [
  null,
  "ფაილური სისტემის სახელი"
 ],
 "Filesystem outside the target": [
  null,
  "ფაილური სისტემა სამიზნის გარეთ"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "ამ მიმაგრების წერტილის ქვეშ ფაილური სისტემები უკვე მიმაგრებულია."
 ],
 "Firmware version": [
  null,
  "მიკროკოდის ვერსია"
 ],
 "Fix NBDE support": [
  null,
  "NBDE-ის მხარდაჭერის გასწორება"
 ],
 "Format": [
  null,
  "ფორმატი"
 ],
 "Format $0": [
  null,
  "$0-ის დაფორმატება"
 ],
 "Format and mount": [
  null,
  "დაფორმატება და მიმაგრება"
 ],
 "Format and start": [
  null,
  "დაფორმატება და გაშვება"
 ],
 "Format only": [
  null,
  "მხოლოდ დაფორმატება"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "ფორმატირება ბლოკურ მოწყობილობაზე მდებარე ყველა მონაცემს წაშლის."
 ],
 "Free space": [
  null,
  "თავისუფალი სივრცე"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "Grow": [
  null,
  "გაზრდა"
 ],
 "Grow content": [
  null,
  "შემცველობის გაზრდა"
 ],
 "Grow logical size of $0": [
  null,
  "$0-ის ლოგიკური ზომის გადიდება"
 ],
 "Grow logical volume": [
  null,
  "ლოგიკური ტომის გაზრდა"
 ],
 "Grow partition": [
  null,
  "დანაყოფის გაზრდა"
 ],
 "Grow the pool to take all space": [
  null,
  "პულის გადიდება მაქს. შესაძლო ზომამდე"
 ],
 "Grow to take all space": [
  null,
  "გადიდება მაქს. შესაძლო ზომამდე"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "Hard Disk Drive": [
  null,
  "მყარი დისკი"
 ],
 "Hide confirmation password": [
  null,
  "დადასტურების პაროლის დამალვა"
 ],
 "Hide password": [
  null,
  "პაროლის დამალვა"
 ],
 "Host key is incorrect": [
  null,
  "ჰოსტის გასაღები არასწორია"
 ],
 "How to check": [
  null,
  "როგორ შევამოწმო"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "ვადასტურებ, მნებავს, ეს მონაცემები სამუდამოდ წაიშალოს"
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "შიდა შეცდომა - ეს ლოგიკური ტომი მონიშნულია, როგორც აქტიური და უნდა ჰქონდეს ასოცირებული ბლოკური მოწყობილობა. მაგრამ ასეთი ბლოკური მოწყობილობა აღმოჩენილი არაა."
 ],
 "Important data might be deleted:": [
  null,
  "შეიძლება, საჭირო მონაცემები წაგეშალოთ:"
 ],
 "In a terminal, run: ": [
  null,
  "ტერმინალში გაუშვით: "
 ],
 "In sync": [
  null,
  "სინქრონიზებულია"
 ],
 "Inactive logical volume": [
  null,
  "არააქტიური ლოგიკური ტომი"
 ],
 "Inconsistent filesystem mount": [
  null,
  "ფაილური სისტემის არასწორი მიმაგრება"
 ],
 "Index memory": [
  null,
  "ინდექსების მეხსიერება"
 ],
 "Initialize": [
  null,
  "ინიციალიზაცია"
 ],
 "Initialize disk $0": [
  null,
  "დისკის ინიციალიზაცია $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "ინიციალიზაცია დისკზე მდებარე მონაცემებს მთლიანად წაშლის."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Install NFS support": [
  null,
  "NFS-ის მხარდაჭერის დაყენება"
 ],
 "Install Stratis support": [
  null,
  "Stratis-ის მხარდაჭერის დაყენება"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0-ის დაყენება წაშლის $1-ს."
 ],
 "Installing packages": [
  null,
  "პაკეტების დაყენება"
 ],
 "Internal error": [
  null,
  "შიდა შეცდომა"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid file permissions": [
  null,
  "ფაილის არასწორი წვდომები"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "Invalid username or password": [
  null,
  "არასწორი მომხმარებელი ან პაროლი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Jobs": [
  null,
  "ამოცანები"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "უცნობი ტიპის გასაღებების ჩასწორება შეუძლებელია"
 ],
 "Key source": [
  null,
  "გასაღების წყარო"
 ],
 "Keys": [
  null,
  "გასაღებები"
 ],
 "Keyserver": [
  null,
  "გასაღებების სერვერი"
 ],
 "Keyserver address": [
  null,
  "გასაღების სერვერის მისამართი"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "გასაღებების სერვერის წაშლით თქვენ შეიძლება დაკარგოთ $0-ის განბლოკვის საშუალება."
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO პული"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 ლოგიკური ტომი"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 ლოგიკური ტომები"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 ფიზიკური ტომი"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 ფიზიკური ტომები"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 ტომების ჯგუფი"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 ტომის ჯგუფი $0"
 ],
 "Label": [
  null,
  "ჭდე"
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Last cannot be removed": [
  null,
  "ბოლოს ვერ წაშლით"
 ],
 "Last disk can not be removed": [
  null,
  "ბოლო დისკს ვერ წაშლით"
 ],
 "Last modified: $0": [
  null,
  "ბოლოს შეიცვალა: $0"
 ],
 "Layout": [
  null,
  "განლაგება"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Linear": [
  null,
  "წრფივი"
 ],
 "Linux filesystem data": [
  null,
  "Linux-ის ფაილური სისტემის მონაცემები"
 ],
 "Linux swap space": [
  null,
  "Linux-ის სვოპის სივრცე"
 ],
 "Loading system modifications...": [
  null,
  "სისტემის ცვლილებების ჩატვირთვა..."
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "Local mount point": [
  null,
  "მიმაგრების ლოკალური წერტილი"
 ],
 "Local storage": [
  null,
  "ლოკალური საცავი"
 ],
 "Location": [
  null,
  "მდებარეობა"
 ],
 "Lock": [
  null,
  "დაკეტვა"
 ],
 "Locked data": [
  null,
  "დაბლოკილი მონაცემები"
 ],
 "Locked encrypted device might contain data": [
  null,
  "ჩაკეტილი დაშიფრული მოწყობილობა, შეიძლება, მონაცემებს შეიცავდეს"
 ],
 "Locking $target": [
  null,
  "$target-ის ჩაკეტვა"
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "Logical": [
  null,
  "ლოგიკური"
 ],
 "Logical Volume Manager partition": [
  null,
  "ლოგიკური ტომების მმართველის დანაყოფი"
 ],
 "Logical size": [
  null,
  "ლოგიკური ზომა"
 ],
 "Logical volume": [
  null,
  "ლოგიკური ტომი"
 ],
 "Logical volume (snapshot)": [
  null,
  "ლოგიკური ტომი (სწრაფი ასლი)"
 ],
 "Logical volume of $0": [
  null,
  "$0-ის ლოგიკური სივრცე"
 ],
 "Login failed": [
  null,
  "შესვლა წარუმატებელია"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "MDRAID device": [
  null,
  "MDRAID მოწყობილობა"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID მოწყობილობა $0"
 ],
 "MDRAID device is recovering": [
  null,
  "მიმდინარეობს MDRAID მოწყობილობის აღდგენა"
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID მოწყობილობა გაშვებული უნდა იყოს"
 ],
 "MDRAID disk": [
  null,
  "MDRAID დისკი"
 ],
 "MDRAID disks": [
  null,
  "MDRAID დისკები"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Manage filesystem sizes": [
  null,
  "ფაილური სისტემის ზომების მართვა"
 ],
 "Manage storage": [
  null,
  "საცავის მართვა"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Marking $target as faulty": [
  null,
  "$target-ის გაფუჭებულად მონიშვნა"
 ],
 "Media drive": [
  null,
  "მედია დისკი"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Metadata used": [
  null,
  "გამოყენებული მეტამონაცემები"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Mirrored (RAID 1)": [
  null,
  "სარკისებური (RAID 1)"
 ],
 "Model": [
  null,
  "მოდელი"
 ],
 "Modifying $target": [
  null,
  "$target-ის ჩასწორება"
 ],
 "Mount": [
  null,
  "მიმაგრება"
 ],
 "Mount Point": [
  null,
  "მიმაგრების წერტილი"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "მიმაგრება ქსელის ჩართვის შემდეგ. გამოტოვება შეცდომის შემთხვევაში"
 ],
 "Mount also automatically on boot": [
  null,
  "ავტომატური მიმაგრება ჩატვირთვის დროს"
 ],
 "Mount at boot": [
  null,
  "ჩატვირთვისას მიმაგრება"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "$0-ზე ავტომატურად მიმაგრება ჩატვირთვის დროს"
 ],
 "Mount before services start": [
  null,
  "მიმაგრება სერვისების გაშვებამდე"
 ],
 "Mount configuration": [
  null,
  "მიმაგრების კონფიგურაცია"
 ],
 "Mount filesystem": [
  null,
  "ფაილური სისტემის მიმაგრება"
 ],
 "Mount now": [
  null,
  "ახლა მიმაგრება"
 ],
 "Mount on $0 now": [
  null,
  "$0-ზე მიმაგრება"
 ],
 "Mount options": [
  null,
  "მიმაგრების მორგება"
 ],
 "Mount point": [
  null,
  "მიმაგრების წერტილი"
 ],
 "Mount point cannot be empty": [
  null,
  "მიმაგრების წერტილი არ შეიძლება ცარიელი იყოს"
 ],
 "Mount point cannot be empty.": [
  null,
  "მიმაგრების წერტილი არ შეიძლება ცარიელი იყოს."
 ],
 "Mount point is already used for $0": [
  null,
  "მიმაგრების წერტილი უკვე გამოიყენება $0-თვის"
 ],
 "Mount point must start with \"/\".": [
  null,
  "მიმაგრების წერტილი უნდა იწყებოდეს \"/\"-ით."
 ],
 "Mount read only": [
  null,
  "მიმაგრებულია, მხოლოდ წასაკითხად"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "მიმაგრება დალოდების გარეშე. გამოტოვება შეცდომის შემთხვევაში"
 ],
 "Mounting $target": [
  null,
  "$target-ის მიმაგრება"
 ],
 "Mounts before services start": [
  null,
  "მიმაგრება სერვისების გაშვებამდე"
 ],
 "Mounts in parallel with services": [
  null,
  "სერვისების გაშვებასთან ერთად მიმაგრება"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "მიმაგრება სერვისების გაშვებასთან ერთად მას შემდეგ, რაც ქსელი ჩაირთვება"
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "Multipathed devices": [
  null,
  "მრავალბილიკა მოწყობილობები"
 ],
 "NFS mount": [
  null,
  "NFS მიმაგრება"
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Name can not be empty.": [
  null,
  "სახელი არ შეიძლება ცარიელი იყოს."
 ],
 "Name cannot be empty.": [
  null,
  "სახელი არ შეიძლება იყოს ცარიელი."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "სახელი არ შეიძლება $0 ბაიტზე გრძელი იყოს"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "სახელი არ შეიძლება $0 სიმბოლოზე მეტი იყოს"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "სახელი არ შეიძლება 127 სიმბოლოზე გრძელი იყოს."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "სახელი არ შეიძლება 255 სიმბოლოზე გრძელი იყოს."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "სახელი არ შეიძლება შეიცავდეს სიმბოლოს '$0'."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "სახელი არ შეიძლება შეიცავდეს სიმბოლოს '/'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "სახელი არ შეიძლება შეიცავდეს ცარიელ სიმბოლოებს."
 ],
 "Need a spare disk": [
  null,
  "საჭიროა სათადარიგო დისკი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "Networked storage": [
  null,
  "ქსელური საცავი"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "New NFS mount": [
  null,
  "ახალი NFS მიმაგრება"
 ],
 "New passphrase": [
  null,
  "ახალი საკვანძო ფრაზა"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "Next": [
  null,
  "შემდეგი"
 ],
 "No available slots": [
  null,
  "თავისუფალი სლოტი ხელმიუწვდომელია"
 ],
 "No block devices are available.": [
  null,
  "ბლოკური მოწყობილობები ხელმიუწვდომელია."
 ],
 "No block devices found": [
  null,
  "ბლოკური მოწყობილობები აღმოჩენილი არაა"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "No devices found": [
  null,
  "მოწყობილობები აღმოჩენილი არაა"
 ],
 "No disks are available.": [
  null,
  "დისკები ხელმიუწვდომელია."
 ],
 "No disks found": [
  null,
  "დისკები ვერ ვიპოვე"
 ],
 "No drives found": [
  null,
  "ამძრავები ვერ ვიპოვე"
 ],
 "No encryption": [
  null,
  "დაშიფვრის გარეშე"
 ],
 "No filesystem": [
  null,
  "ფაილური სისტემების გარეშე"
 ],
 "No filesystems": [
  null,
  "ფაილური სისტემების გარეშე"
 ],
 "No free key slots": [
  null,
  "გასაღების თავისუფალი სლოტების გარეშე"
 ],
 "No free space": [
  null,
  "თავისუფალი ადგილის გარეშე"
 ],
 "No free space after this partition": [
  null,
  "ამ დანაყოფის შემდეგ თავისუფალი ადგილი არაა"
 ],
 "No keys added": [
  null,
  "გასაღებები არ დამატებულა"
 ],
 "No logical volumes": [
  null,
  "ლოგიკური ტომების გარეშე"
 ],
 "No media inserted": [
  null,
  "დისკი არ დევს"
 ],
 "No partitioning": [
  null,
  "დანაყოფების გარეშე"
 ],
 "No partitions found": [
  null,
  "დანაყოფები ვერ ვიპოვე"
 ],
 "No physical volumes found": [
  null,
  "ფიზიკური ტომები ვერ ვიპოვე"
 ],
 "No snapshots found": [
  null,
  "სწრაფი ასლების გარეშე"
 ],
 "No storage found": [
  null,
  "საცავი ვერ ვიპოვე"
 ],
 "No subvolumes": [
  null,
  "ქვეტომების გარეშე"
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "No system modifications": [
  null,
  "სისტემა შეცვლილი არაა"
 ],
 "Not a valid private key": [
  null,
  "არ წარმოადგენს სწორ პირად გასაღებს"
 ],
 "Not enough free space": [
  null,
  "თავისუფალი ადგილი საკმარისი არაა"
 ],
 "Not enough space": [
  null,
  "ადგილი საკმარისი არაა"
 ],
 "Not enough space to grow": [
  null,
  "გასადიდებლად არასაკმარისი სივრცეა"
 ],
 "Not found": [
  null,
  "ნაპოვნი არაა"
 ],
 "Not permitted to perform this action.": [
  null,
  "არ გაქვთ მითითებული მოქმედების შესასრულებლად საკმარისი წვდომა."
 ],
 "Not running": [
  null,
  "გაშვებული არაა"
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Occurrences": [
  null,
  "გამოვლენები"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Old passphrase": [
  null,
  "ძველი საკვანძო ფრაზა"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "როცა Cockpit-ს დააყენებთ, შეგიძლიათ მისი ჩართვაც, ბრძანებით \"systemctl enable --now cockpit.socket\"."
 ],
 "Only $0 of $1 are used.": [
  null,
  "$1-დან გამოყენებულია მხოლოდ $0."
 ],
 "Operation '$operation' on $target": [
  null,
  "ოპერაცია '$operation' $target-ზე"
 ],
 "Options": [
  null,
  "პარამეტრები"
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "Overwrite": [
  null,
  "გადაწერა"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "არსებულ მონაცემებზე ნულების გადაწერა (ნელი)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "Partition": [
  null,
  "განაყოფი"
 ],
 "Partition of $0": [
  null,
  "$0-ის დანაყოფი"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "დანაყოფის ზომაა $0. შემცველობის ზომა კი - $1."
 ],
 "Partitioning": [
  null,
  "დაყოფა"
 ],
 "Partitions": [
  null,
  "დანაყოფები"
 ],
 "Passphrase": [
  null,
  "საკვანძო სიტყვა"
 ],
 "Passphrase can not be empty": [
  null,
  "საკვანძო ფრაზა ცარიელი არ შეიძლება იყოს"
 ],
 "Passphrase cannot be empty": [
  null,
  "საკვანძო ფრაზა არ შეიძლება ცარიელი იყოს"
 ],
 "Passphrase from any other key slot": [
  null,
  "საკვანძო ფრაზა ნებისმიერი სხვა გასაღების სლოტიდან"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "საკვანძო ფრაზის მოცილებამ შეიძლება შეუძლებელი გახადოს $0-ის განბლოკვა."
 ],
 "Passphrases do not match": [
  null,
  "საკვანძო ფრაზები ერთმანეთს არ ემთხვევა"
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Password is not acceptable": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Password is too weak": [
  null,
  "პაროლი ძალიან სუსტია"
 ],
 "Password not accepted": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Paste error": [
  null,
  "ჩასმის შეცდომა"
 ],
 "Path on server": [
  null,
  "ბილიკი სერვერზე"
 ],
 "Path on server cannot be empty.": [
  null,
  "სერვერზე ბილიკის ველი არ შეიძლება ცარიელი იყოს."
 ],
 "Path on server must start with \"/\".": [
  null,
  "ბილიკი სერვერზე უნდა იწყებოდეს სიმბოლოთი \"/\"."
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "Permanently delete $0?": [
  null,
  "წავშალო სამუდამოდ $0?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "წავშალო სამუდამოდ ლოგიკური ტომი $0/$1?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "წავშალო სამუდამოდ ქვეტომი $0?"
 ],
 "Physical": [
  null,
  "ფიზიკური"
 ],
 "Physical Volumes": [
  null,
  "ფიზიკური ტომები"
 ],
 "Physical volumes": [
  null,
  "ფიზიკური ტომები"
 ],
 "Physical volumes can not be resized here": [
  null,
  "ფიზიკურ ტომებს აქ ადგილს ვერ შეუცვლით"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Please unmount them first.": [
  null,
  "ჯერ ისინი მოხსენით."
 ],
 "Pool for thin logical volumes": [
  null,
  "თხელი ლოგიკური საცავების პული"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "პული თხლად გამოყოფილი LVM2 ლოგიკური ტომებისთვის"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "თხლად გაწერილი საცავების პული"
 ],
 "Pool passphrase": [
  null,
  "პულის საკვანძო ფრაზა"
 ],
 "Port": [
  null,
  "პორტი"
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP ჩატვირთვის დანაყოფი"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "Processes using the location": [
  null,
  "მდებარეობის გამოყენებელი პროცესები"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "მოთხოვნას ssh-add-ის გავლით დრო გაუვიდა"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "მოთხოვნას ssh-keygen-ის გავლით დრო გაუვიდა"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "შეიყვანეთ საკვანძო ფრაზა ამ ბლოკური მოწყობილობების პულისტვის:"
 ],
 "Purpose": [
  null,
  "დანიშნულება"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (სარკე)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (სარკეების ზოლები)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (გამოყოფილი ლუწობა)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (განაწილებული ლუწობა)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (ორმაგად განაწილებული ლუწობა)"
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "RAID level": [
  null,
  "RAID-ის დონე"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10-ს ფიზიკური ტომების ლუწი რიცხვი სჭირდება"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Reading": [
  null,
  "ვკითხულობ"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Recovering": [
  null,
  "აღდგენა"
 ],
 "Recovering MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის აღდგენა"
 ],
 "Regenerating initrd": [
  null,
  "Initrd-ის თავიდან გენერაცია"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "დაკავშირებული პროცესები და სერვისები ძალით იქნებიან გაჩერებული."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "დაკავშირებული პროცესები ძალით იქნება გაჩერებული."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "დაკავშირებული სერვისები ძალით იქნება გაჩერებული."
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Remove $0?": [
  null,
  "წავშალო $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "წავშალო Tang გასაღებების სერვერი?"
 ],
 "Remove device": [
  null,
  "მოწყობილობის წაშლა"
 ],
 "Remove missing physical volumes?": [
  null,
  "წავშალო ნაკლული ფიზიკური ტომები?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "წავშალო საკვანძო ფრაზა გასაღების სლოტი $0-დან?"
 ],
 "Remove passphrase?": [
  null,
  "წავშალო საკვანძო სიტყვა?"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Removing $target from MDRAID device": [
  null,
  "$target-ის MDRAID მოწყობილობიდან მოცილება"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "კვანძური ფრაზის წაშლას სხვა კვანძური ფრაზის ჩამატების გარეშე შეუძლია გამოიწვიოს გასაღებების მართვის დაბლოკვა, თუ სხვა საკვანძო ფრაზები დაგავწყდებათ."
 ],
 "Removing physical volume from $target": [
  null,
  "$target-დან ფიზიკური საცავის მოცილება"
 ],
 "Rename": [
  null,
  "სახელის გადარქმევა"
 ],
 "Rename Stratis pool": [
  null,
  "Stratis-ის პულისთვის სახელის გადარქმევა"
 ],
 "Rename filesystem": [
  null,
  "ფაილური სისტემის სახელის გადარქმევა"
 ],
 "Rename logical volume": [
  null,
  "ლოგიკური ტომისთვის სახელის გადარქმევა"
 ],
 "Rename volume group": [
  null,
  "ტომების ჯგუფისათვის სახელის გადარქმევა"
 ],
 "Renaming $target": [
  null,
  "$target-ის სახელის გადარქმევა"
 ],
 "Repair": [
  null,
  "შეკეთება"
 ],
 "Repair logical volume $0": [
  null,
  "ლოგიკური ტომის $0 შეკეთება"
 ],
 "Repairing $target": [
  null,
  "$target-ის შეკეთება"
 ],
 "Repeat passphrase": [
  null,
  "გაიმეორეთ საკვანძო სიტყვა"
 ],
 "Resizing $target": [
  null,
  "$target-ის ზომის შესვლა"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "დაშიფრული ფაილური სისტემის ზომის შეცვლას ჯერ დისკის განბლოკვა სჭირდება. შეიყვანეთ დისკის საკვანძო ფრაზა."
 ],
 "Reuse existing encryption": [
  null,
  "არსებული დაშიფვრის გამოყენება"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "არსებული დაშიფვრის ($0) გამოყენება"
 ],
 "Row expansion": [
  null,
  "მწკრივის გაფართოება"
 ],
 "Row select": [
  null,
  "მწკრივის არჩევა"
 ],
 "Running": [
  null,
  "გაშვებული"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "$target-ის SMART თვითშემოწმების გაშვება"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "ადგილის შენახვა ინდივიდუალური ბლოკების LZ4-ის საშუალებით შეკუმშვით"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "ადგილის შენახვა მონაცემების ერთნაირი ბლოკების მხოლოდ ერთხელ შენახვის საშუალებით"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "ახალი საკვანძო სიტყვის შესანახად საჭიროა დისკის განბლოკვა. შეიყვანეთ დისკის საკვანძო ფრაზა."
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Securely erasing $target": [
  null,
  "$target-ის გარანტირებული წაშლა"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Linux-ის გაფართოებული უსაფრთხოების (SELinux) მორგება და გამართვა"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At leat $0 are needed.": [
  null,
  "აირჩიეთ ფიზიკური ტომები, რომელიც ლოგიკური ტომის შესაკეთებლად იქნება გამოყენებული. საჭიროა მინიმუმ $0."
 ],
 "Serial number": [
  null,
  "სერიული ნომერი"
 ],
 "Server": [
  null,
  "სერვერი"
 ],
 "Server address": [
  null,
  "სერვერის მისამართი"
 ],
 "Server address cannot be empty.": [
  null,
  "სერვერის მისამართი ცარიელი არ შეიძლება იყოს."
 ],
 "Server cannot be empty.": [
  null,
  "სერვერი არ შეიძლება ცარიელი იყოს."
 ],
 "Server has closed the connection.": [
  null,
  "სერვერმა დახურა კავშირი."
 ],
 "Service": [
  null,
  "სერვისი"
 ],
 "Services using the location": [
  null,
  "მდებარეობის გამომყენებელი სერვისები"
 ],
 "Set partition type of $0": [
  null,
  "$0-ის დანაყოფის ტიპის დაყენება"
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Setting up loop device $target": [
  null,
  "$target-ზე მარყუჟული მოწყობილობის შექმნა"
 ],
 "Shell script": [
  null,
  "გარსის სკრიპტი"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "ყელა $0 მწკრივის ჩვენება"
 ],
 "Show confirmation password": [
  null,
  "დადასტურების პაროლის ჩვენება"
 ],
 "Show password": [
  null,
  "პაროლის ჩვენება"
 ],
 "Shrink": [
  null,
  "შეწნეხვა"
 ],
 "Shrink logical volume": [
  null,
  "ლოგიკური ტომის შემცირება"
 ],
 "Shrink partition": [
  null,
  "დანაყოფის შემცირება"
 ],
 "Shrink volume": [
  null,
  "ტომის შემცირება"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "Size cannot be negative": [
  null,
  "ზომა არ შეიძლება უარყოფითი იყოს"
 ],
 "Size cannot be zero": [
  null,
  "ზომა არ შეიძლება ნულის ტოლი იყოს"
 ],
 "Size is too large": [
  null,
  "ზომა ძალიან დიდია"
 ],
 "Size must be a number": [
  null,
  "ზომა რიცხვი უნდა იყოს"
 ],
 "Size must be at least $0": [
  null,
  "ზომის მინიმალური მნიშვნელობაა $0"
 ],
 "Slot $0": [
  null,
  "სლოტი $0"
 ],
 "Snapshot": [
  null,
  "სწრაფი ასლი"
 ],
 "Snapshot origin": [
  null,
  "სწრაფი ასლის წყარო"
 ],
 "Snapshots": [
  null,
  "სწრაფი ასლები"
 ],
 "Solid State Drive": [
  null,
  "მყარსხეულიანი დისკი"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "ამ პულში ზოგიერთი ბლოკური მოწყობილობა ზომაში პულის შექმნის შემდეგ გაიზარდა. პულის გაზრდა დამატებული ადგილის გამოსაყენებლად უსაფრთხოა."
 ],
 "Sorry": [
  null,
  "უკაცრავად"
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Spare": [
  null,
  "მარქაფი"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Start": [
  null,
  "დაწყება"
 ],
 "Start multipath": [
  null,
  "multipath-ის გაშვება"
 ],
 "Started": [
  null,
  "დაწყებულია"
 ],
 "Starting MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის გაშვება"
 ],
 "Starting swapspace $target": [
  null,
  "სვაპის ($target) გაშვება"
 ],
 "State": [
  null,
  "მდგომარეობა"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "გაჩერება"
 ],
 "Stop and remove": [
  null,
  "გაჩერება და წაშლა"
 ],
 "Stop and unmount": [
  null,
  "გაჩერება და მოძრობა"
 ],
 "Stop device": [
  null,
  "მოწყობილობის გაჩერება"
 ],
 "Stopping MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის გაჩერება"
 ],
 "Stopping swapspace $target": [
  null,
  "სვაპის ($target) გაჩერება"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Storage can not be managed on this system.": [
  null,
  "ამ სისტემაზე საცავის მართვა შეუძლებელია."
 ],
 "Storage logs": [
  null,
  "საცავის ჟურნალი"
 ],
 "Store passphrase": [
  null,
  "საკვანძო სიტყვის დამახსოვრება"
 ],
 "Stored passphrase": [
  null,
  "დამახსოვრებული საკვანძო სიტყვა"
 ],
 "Stratis block device": [
  null,
  "Stratis-ის ბლოკური მოწყობილობა"
 ],
 "Stratis block devices": [
  null,
  "Stratis-ის ბლოკური მოწყობილობები"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis ბლოკური მოწყობილობები მეტად ვეღარ დაპატარავდება"
 ],
 "Stratis filesystem": [
  null,
  "Stratis-ის ფაილური სისტემა"
 ],
 "Stratis filesystems": [
  null,
  "Stratis-ს ფაილური სისტემები"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis-ის ფაილური სისტემების პული"
 ],
 "Stratis pool": [
  null,
  "Startis-ის პული"
 ],
 "Striped (RAID 0)": [
  null,
  "ზოლებით (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "ზოლებით და სარკისებურად (RAID 10)"
 ],
 "Stripes": [
  null,
  "ზოლები"
 ],
 "Strong password": [
  null,
  "ძლიერი პაროლი"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Subvolume needs to be mounted": [
  null,
  "საჭიროა, ქვეტომი მიმაგრებული იყოს"
 ],
 "Subvolume needs to be mounted writable": [
  null,
  "აუცილებელია, ქვეტომი ჩაწერადად იყოს მიმაგრებული"
 ],
 "Successfully copied to clipboard!": [
  null,
  "წარმატებით დაკოპირდა ბუფერში!"
 ],
 "Swap": [
  null,
  "სვაპი"
 ],
 "Swap can not be resized here": [
  null,
  "სვოპის ზომას აქ ვერ შეცვლით"
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის სინქრონიზაცია"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "Tang keyserver": [
  null,
  "გასაღებების სერვერი Tang"
 ],
 "Target": [
  null,
  "სამიზნე"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 პაკეტი ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Stratis-ის პულის შესაქმნელად საჭიროა დაყენებული იყოს პაკეტი $0."
 ],
 "The $0 package must be installed.": [
  null,
  "საჭიროა დაყენებული იყოს პაკეტი $0."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "VDO მოწყობილობების შესაქმნელად დაყენდება პაკეტი $0."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID მოწყობილობა ავარიულ მდგომარეობაშია"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID მოწყობილობა გაშვებული უნდა იყოს"
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "VDO მოწყობილობის შექმნა გაუქმებულია. მოწყობილობის გამოყენება შეუძლებელია."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "ამჟამად შესულ მომხმარებელს არ აქვს უფლება გასაღებების შესახებ ინფორმაცია მოითხოვოს."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "დაფორმატებამდე საჭიროა დისკის განბლოკვა.  შეიყვანეთ საკვანძო ფრაზა."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "ფაილურ სისტემას მინიჭებული მამაგრების წერტილი არ გააჩნია."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "ფაილურ სისტემას მუდმივი მისამაგრებელი წერტილი არ გააჩნია."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "ფაილური სისტემა მორგებულია ჩატვირთვისას ავტომატურად მისამაგრებლად. მაგრამ დაშიფვრის მისი კონტეინერი ამ დროს განბლოკილი არ იქნება."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "ამჟამად ფაილური სისტემა მიმაგრებულია, მაგრამ შემდეგი ჩატვირთვისას აღარ იქნება."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "ფაილური სისტემა ამჟამად მიმაგრებულია $0-ზე, მაგრამ შემდეგი ჩატვირთვისას მიმაგრებული იქნება $1-ზე."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "ფაილური სისტემა უკვე მიმაგრებულია $0ზე, მაგრამ შემდეგი ჩატვირთვისას არ იქნება მიმაგრებული."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "ფაილური სისტემა ახლა მიმაგრებული არაა, მაგრამ იქნება შემდეგი ჩატვირთვისას."
 ],
 "The filesystem is not mounted.": [
  null,
  "ფაილური სისტემა მიმაგრებული არაა."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "ფაილური სისტემა განიბლოკება და მიმაგრდება შემდეგი ჩატვირთვისას. ამას საკვანძო სიტყვის შეყვანა შეიძლება დასჭირდეს."
 ],
 "The initrd must be regenerated.": [
  null,
  "Initrd-ის თავიდან გენერაცია აუცილებელია."
 ],
 "The last key slot can not be removed": [
  null,
  "ბოლო სლოტს ვერ წაშლით"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "ჩამოთვლილი პროცესები და სერვისები ძალით იქნება გაჩერებული."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "ჩამოთვლილი პროცესები ძალით გაჩერდება."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "ჩამოთვლილი სერვისები ძალით გაჩერდება."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "შესულ მომხმარებელს არ აქვს სისტემური ცვლილებების ნახვს უფლება"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "მიმაგრების წერტილი $0 დაკავებულია ჩამოთვლილი პროცესების მიერ:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "მიმაგრების წერტილი $0 გამოიყენება ჩამოთვლილი სერვისების მიერ:"
 ],
 "The passwords do not match.": [
  null,
  "პაროლები არ ემთხვევა."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "სერვერმა ყველა მხარდაჭერილი მეთოდით ავთენტიკაცია უარჰყო."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "სისტემას ამჟამად ჩატვირთვისას ფაილური სისტემის Tang-ის გასაღებების სერვერით განბლოკვის მხარდაჭერა არ გააჩნია."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "სისტემას ამჟამად ჩატვირთვისას Tang-ის გასაღებების სერვერით root ფაილური სისტემის განბლოკვის მხარდაჭერა არ გააჩნია."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "სისმტეაში არის მოწყობილობები მრავალი ბილიკით, მაგრამ multipath სერვისი გაშვებული არაა."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "შეკეთებისთვის საკმარისი ადგილი არაა. საჭიროა მინიმუმ $0 ადგილი ფიზიკურ ტომებზე, რომლებიც ლოგიკურ ტომებს არ უკავიათ."
 ],
 "There is not enough space in the pool to make a snapshot of this filesystem. At least $0 are required but only $1 are available.": [
  null,
  "პულში ამ ფაილური სისტემის სწრაფი ასლის ასაღებად საკმარისი ადგილი არაა. აუცილებელია სულ ცოტა $0, მაგრამ ხელმისაწვდომია, მხოლოდ, $1."
 ],
 "These additional steps are necessary:": [
  null,
  "საჭიროა ეს დამატებითი ნაბიჯები:"
 ],
 "These changes will be made:": [
  null,
  "მოხდება ეს ცვლილებები:"
 ],
 "Thin logical volume": [
  null,
  "თხელი ლოგიკური ტომი"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "თხლად გაწერილი LVM2 ლოგიკური ტომები"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce sychronization times significantly.": [
  null,
  "ამ MDRAID მოწყობილობას wirte-intent ბიტური რუკა არ გააჩნია. ასეთ ბიტურ რუკას სინქრონიზაციის დრო საგრძნობლად შეუძლია, შეამციროს."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "NFS მიმაგრება უკვე გამოიყენება და მხოლოდ მისი პარამეტრების შეცვლა შეგიძლიათ."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "VDO მოწყობილობა თავის ყველა ზურგის მოწყობილობას არ იყენებს."
 ],
 "This device can not be used for the installation target.": [
  null,
  "ამ მოწყობილობას დაყენების სამიზნედ ვერ გამოიყენებთ."
 ],
 "This device is currently in use.": [
  null,
  "მოწყობილობა უკვე გამოიყენება."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "ეს გასაღებების სერვერი ამ პულის განბლოკვის ერთად-ერთი საშუალებაა და მისი წაშლა შეუძლებელია."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "ლოგიკურმა ტომმა რამდენიმე ფიზიკური ტომი დაკარგა და ვეღარ გამოიყენებთ. საჭიროა, წაშალოთ ის და თავიდან შექმნათ."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "ამ ლოგიკურმა ტომმა რამდენიმე ფიზიკური ტომი დაკარგა, მაგრამ მონაცემები ჯერ არა. შეაკეთეთ ის საწყისი საიმედოობის დასაბრუნებლად."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "ამ ლოგიკურმა ტომმა რამდენიმე ფიზიკური ტომი დაკარგა, მაგრამ მონაცემები ჯერ არა. წესით, მისი შეკეთება უნდა შეძლოთ."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "ლოგიკური საცავი მთლიანად არ გამოიყენება."
 ],
 "This partition is not completely used by its content.": [
  null,
  "ეს დანაყოფი მისი შემცველობის მიერ სრულად არ გამოიყენება."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "ეს საკვანძო ფრაზა ამ პულის განბლოკვისთვის ერთად-ერთი საშუალებაა და მისი წაშლა შეუძლებელია."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "ეს პული მის ბლოკურ მოწყობილობებზე არსებულ ადგილს ბოლომდე არ იყენებს."
 ],
 "This pool is in a degraded state.": [
  null,
  "ეს პულ ავარიულ მდგომარეობაშია."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ეს პროგრამა როგორც SELinux-ის პოლიტიკის მორგებაში, ასევე მის ბოლომდე გაგებაში და პოლიტიკის დარღვევის გადაწყვეტაში დაგეხმარებათ."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "ეს პროგრამა სისტემას ბირთვის ავარიის შემთხვევაში დისკზე დამპის ჩაწერის მორგებაში დაგეხმარებათ."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ეს პროგრამა გაშვებული სისტემიდან კონფიგურაცისა და დიაგნოსტიკის მოგროვებაში დაგეხმარებათ. არქივი შეგიძლიათ ლოკალურად შეინახოთ, ან ცენტრალურად, ჩაწერისა და ტრეკინგის მიზნებისთვის, ან შეგიძლიათ გადააგზავნოთ მხარდაჭერის, პროგრამისტებისა და სისტემური ადმინისტრატორების ჯგუფებთან, რათა აპარატურული პრობლემები აღმოაჩინოთ და გადაჭრათ."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ეს პროგრამა ლოკალურ საცავს, როგორიცაა ფაილურ სისტემები, LVM2 ტომის ჯგუფები და NFS მიმაგრებები, მართავს."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ეს პროგრამა მართავს ქსელს. bond ინტერფეისების, ხიდების, ჯგუფური ინტერფეისების, VLAN-ების და ბრანდმაუერების მართვა NetworkManager-ისა და FIrewalld-ის საშუალებით. NetworkManager-ი Ubuntu-ის ნაგულისხმებ systemd-networkd და Debian-ის ifupdown სკრიპტებთან შეუთავსებელია."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "ამ ტომების ჯგუფის ფიზიკური ტომები აკლია."
 ],
 "Tier": [
  null,
  "კლასი"
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Too much data": [
  null,
  "მეტისმეტად ბევრი მონაცემი"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Trust key": [
  null,
  "ნდობის გასაღები"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "ტიპი შეიძლება, მხოლოდ, შეიცავდეს სიმბოლოებს 0-9, A-F და \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "ტიპი უნდა იყოს ფორმით NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "ტიპი, მხოლოდ, ზუსტად ორ თექვსმეტობით სიმბოლოს (0-9, A-F) უნდა შეიცავდეს."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "სერვერამდე მიღწევის შეცდომა"
 ],
 "Unable to remove mount": [
  null,
  "მიმაგრების მოხსნის შეცდომა"
 ],
 "Unable to repair logical volume $0": [
  null,
  "ლოგიკური ტომის ($0) შეკეთება შეუძლებელია"
 ],
 "Unable to unmount filesystem": [
  null,
  "ფაილური სისტემის მოძრობის შეცდომა"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "მოულოდნელი PackageKit-ის შეცდომა $0-ის დაყენებისას: $1"
 ],
 "Unformatted data": [
  null,
  "დაუფორმატებელი მონაცემები"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Unknown ($0)": [
  null,
  "უცნობი ($0)"
 ],
 "Unknown host name": [
  null,
  "ჰოსტის უცნობი სახელი"
 ],
 "Unknown type": [
  null,
  "უცნობი ტიპი"
 ],
 "Unlock": [
  null,
  "განბლოკვა"
 ],
 "Unlock automatically on boot": [
  null,
  "ავტომატური განბლოკვა ჩატვირთვისას"
 ],
 "Unlock before resizing": [
  null,
  "განბლოკვა ზომის შეცვლამდე"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Stratis-ის დაშიფრული პულის განბლოკვა"
 ],
 "Unlocking $target": [
  null,
  "$target-ის განბლოკვა"
 ],
 "Unlocking disk": [
  null,
  "დისკის განბლოკვა"
 ],
 "Unmount": [
  null,
  "მოძრობა"
 ],
 "Unmount filesystem $0": [
  null,
  "ფაილური სისტემის მოძრობა: $0"
 ],
 "Unmount now": [
  null,
  "მიმაგრების მოხსნა"
 ],
 "Unmounting $target": [
  null,
  "$target-ის მიმაგრების მოხსნა"
 ],
 "Unrecognized data": [
  null,
  "შეუცნობელი მონაცემები"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "აქ უცნობი მონაცემების დაპატარავება შეუძლებელია"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "აქ უცნობი მონაცემების დაპატარავება შეუძლებელია."
 ],
 "Unsupported logical volume": [
  null,
  "მხარდაუჭერელი ლოგიკური ტომი"
 ],
 "Untrusted host": [
  null,
  "არასანდო ჰოსტი"
 ],
 "Usage": [
  null,
  "გამოყენება"
 ],
 "Usage of $0": [
  null,
  "$0-ის გამოყენების წესები"
 ],
 "Use": [
  null,
  "გამოყენება"
 ],
 "Use compression": [
  null,
  "შეკუმშვის გამოყენება"
 ],
 "Use deduplication": [
  null,
  "დედუპლიკაციის გამოყენება"
 ],
 "Used": [
  null,
  "გამოყენებულია"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "გამოსადეგია მიმაგრების წერტილებისთვის, რომლებიც სავალდებული არაა და ჩარევას საჭიროებს (მაგ: საკვანძო სიტყვის შეყვანას)"
 ],
 "User": [
  null,
  "მომხმარებელი"
 ],
 "Username": [
  null,
  "მომხმარებლის სახელი"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-ის მხარდამჭერი მოწყობილობები მეტად ვეღარ დაპატარავდება"
 ],
 "VDO device $0": [
  null,
  "VDO მოწყობილობა: $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO ფაილური სისტემის საცავი (შეკუმშვა/დედუპლიკაცია)"
 ],
 "Vendor": [
  null,
  "მომწოდებელი"
 ],
 "Verify key": [
  null,
  "გასაღების შემოწმება"
 ],
 "Very securely erasing $target": [
  null,
  "$target-ის ძალიან უსაფრთხოდ წაშლა"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "View automation script": [
  null,
  "ავტომატიზაციის სკრიპტის ნახვა"
 ],
 "View logs": [
  null,
  "ჟურნალის ნახვა"
 ],
 "Visit firewall": [
  null,
  "ბრანდმაუერზე გადასვლა"
 ],
 "Volume group": [
  null,
  "ტომების ჯგუფი"
 ],
 "Volume group is missing physical volumes": [
  null,
  "ტომების ჯგუფს ფიზიკური ტომები აკლია"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "საცავის ზომაა $0. შემცველობის კი $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Weak password": [
  null,
  "სუსტი პაროლი"
 ],
 "Web Console for Linux servers": [
  null,
  "ვებ კონსოლი Linux სერვერებისთვის"
 ],
 "When this option is checked, the new pool will not allow overprovisioning. You need to specify a maximum size for each filesystem that is created in the pool. Filesystems can not be made larger after creation. Snapshots are fully allocated on creation. The sum of all maximum sizes can not exceed the size of the pool. The advantage of this is that filesystems in this pool can not run out of space in a surprising way. The disadvantage is that you need to know the maximum size for each filesystem in advance and creation of snapshots is limited.": [
  null,
  "როცა ეს პარამეტრი ჩართულია, ახალი პული დაშვებულზე მეტის სამუშაოდ მომზადებს უფლებას არ მოგცემთ. უნდა მიუთითოთ მაქსიმალური ზომა თითოეული ფაილური სისტემისთვის, რომელსაც პულში შექმნით. ფაილური სისტემების გაზრდა მათი შექმნის შემდეგ შეუძლებელი იქნება. სწრაფი ასლების გამოყოფა სრულად ხდება მათი შექმნისას. მათი ჯამური ზომა არ შეძლება, პულის ზომაზე მეტი იყოს. ამ მიდგომის დადებითი მხარე ისაა, რომ ამ პულში არსებულ ფაილურ სისტემებზე ადგილის გათავება თქვენთვის მოულოდნელობა არ იქნება. უარყოფითი მხარე კი ის, რომ ყველა ფაილური სისტემის ზომა წინასწარ უნდა იცოდეთ და სწრაფი ასლების შექმნა შეზღუდულია."
 ],
 "World wide name": [
  null,
  "WWN სახელი"
 ],
 "Write-mostly": [
  null,
  "ძირითადად-ჩაწერა"
 ],
 "Writing": [
  null,
  "ჩაწერა"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "თქვენს ბრაუზერს არ გააჩნია კონტექსტური მენიუდან ჩასმის მხარდაჭერა. სცადეთ დააჭიროთ Shift+Insert-ს."
 ],
 "Your session has been terminated.": [
  null,
  "თქვენი სესია გაწყვეტილია."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "სესიის ვადა გასულია. თავიდან შედით."
 ],
 "Zone": [
  null,
  "ზონა"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "after network": [
  null,
  "ქსელის ჩართვის შემდეგ"
 ],
 "backing device for VDO device": [
  null,
  "VDO მოწყობილობის მხარდამჭერი მოწყობილობა"
 ],
 "btrfs device": [
  null,
  "btrfs მოწყობილობება"
 ],
 "btrfs devices": [
  null,
  "btrfs მოწყობილობები"
 ],
 "btrfs filesystem": [
  null,
  "ფაილური სისტემა btrfs"
 ],
 "btrfs subvolume": [
  null,
  "Btrfs ქვეტომი"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs ქვეტომი $0 $1-დან"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs ქვეტომები"
 ],
 "btrfs volume": [
  null,
  "btrfs ტომი"
 ],
 "cache": [
  null,
  "კეში"
 ],
 "data": [
  null,
  "მონაცემები"
 ],
 "deactivate": [
  null,
  "დეაქტივაცია"
 ],
 "delete": [
  null,
  "წაშლა"
 ],
 "device of btrfs volume": [
  null,
  "btrfs ტომის მოწყობილობა"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "encrypted": [
  null,
  "დაშიფრულია"
 ],
 "format": [
  null,
  "ფორმატი"
 ],
 "grow": [
  null,
  "გაზრდა"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI დისკი"
 ],
 "iSCSI drives": [
  null,
  "iSCSI დისკები"
 ],
 "iSCSI portal": [
  null,
  "iSCSI პორტალი"
 ],
 "ignore failure": [
  null,
  "გამოტოვება შეცდომის შემთხვევაში"
 ],
 "in less than a minute": [
  null,
  "წუთზე ნაკლებში"
 ],
 "initialize": [
  null,
  "ინიციალიზაცია"
 ],
 "less than a minute ago": [
  null,
  "წუთზე ნაკლების წინ"
 ],
 "member of MDRAID device": [
  null,
  "MDRAID მოწყობილობის წევრი"
 ],
 "member of Stratis pool": [
  null,
  "Stratis-ის პულის წევრი"
 ],
 "mount": [
  null,
  "მიმაგრება"
 ],
 "never mount at boot": [
  null,
  "არასოდეს მიმაგრდება ჩატვირთვის დროს"
 ],
 "none": [
  null,
  "არცერთი"
 ],
 "password quality": [
  null,
  "პაროლის ხარისხი"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 საცავების ჯგუფის წევრი ფიზიკური საცავი"
 ],
 "read only": [
  null,
  "მხოლოდ კითხვისთვის"
 ],
 "remove from LVM2": [
  null,
  "LVM2-დან წაშლა"
 ],
 "remove from MDRAID": [
  null,
  "MDRAID-დან წაშლა"
 ],
 "remove from btrfs volume": [
  null,
  "წაშლა btrfs ტომიდან"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "shrink": [
  null,
  "შემცირება"
 ],
 "snapshot": [
  null,
  "სწრაფი ასლი"
 ],
 "stop": [
  null,
  "გაჩერება"
 ],
 "stop boot on failure": [
  null,
  "შეცდომის შემთხვევაში ჩატვირთვის გაჩერება"
 ],
 "stopped": [
  null,
  "გაჩერებულია"
 ],
 "unknown target": [
  null,
  "უცნობი სამიზნე ობიექტი"
 ],
 "unmount": [
  null,
  "მოძრობა"
 ],
 "unpartitioned space on $0": [
  null,
  "$0-ზე დარჩენილი დაუხლეჩავი სივრცე"
 ],
 "using key description $0": [
  null,
  "ვიყენებ გასაღების აღწერას $0"
 ],
 "yes": [
  null,
  "დიახ"
 ],
 "format-bytes\u0004bytes": [
  null,
  "ბაიტი"
 ]
});
