cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Managing LVMs": [
  null,
  "LVMs verwalten"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-Freigaben verwalten"
 ],
 "Managing RAIDs": [
  null,
  "RAIDs verwalten"
 ],
 "Managing VDOs": [
  null,
  "VDOs verwalten"
 ],
 "Managing partitions": [
  null,
  "Partitionen verwalten"
 ],
 "Managing physical drives": [
  null,
  "Physische Laufwerke verwalten"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS-Verschlüsselung verwenden"
 ],
 "Using Tang server": [
  null,
  "Tang-Server verwenden"
 ],
 "disk": [
  null,
  "Datenträger"
 ],
 "drive": [
  null,
  "Speichergerät"
 ],
 "encryption": [
  null,
  "Verschlüsselung"
 ],
 "filesystem": [
  null,
  "Dateisystem"
 ],
 "format": [
  null,
  "Formatieren"
 ],
 "fstab": [
  null,
  "Fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "Einhängen"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "Partition"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "Aushängen"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "Laufwerk"
 ]
});
