cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "$0 can not be made larger": [
  null,
  "$0 не можна збільшувати"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 не можна зменшувати"
 ],
 "$0 can not be resized": [
  null,
  "Розмір $0 не можна змінювати"
 ],
 "$0 can not be resized here": [
  null,
  "Тут не можна змінювати розмір $0"
 ],
 "$0 chunk size": [
  null,
  "Розмір фрагмента $0"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 даних + $1 додатково використано з $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 disk is missing": [
  null,
  "Не вистачає $0 диска",
  "Не вистачає $0 дисків",
  "Не вистачає $0 дисків"
 ],
 "$0 disks": [
  null,
  "Диски $0"
 ],
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "$0 filesystem": [
  null,
  "Файлова система $0"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 is in use": [
  null,
  "$0 використовується"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "$0 key changed": [
  null,
  "Змінено ключ $0"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 partitions": [
  null,
  "$0 розділів"
 ],
 "$0 slot remains": [
  null,
  "Лишився $0 слот",
  "Лишилося $0 слоти",
  "Лишилося $0 слотів"
 ],
 "$0 synchronized": [
  null,
  "$0 синхронізовано"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 використано з $1 ($2 заощаджено)"
 ],
 "$0 used, $1 total": [
  null,
  "використано $0, загалом $1"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "$name (from $host)": [
  null,
  "$name (з $host)"
 ],
 "(Not part of target)": [
  null,
  "(Не є частиною цілі)"
 ],
 "(no assigned mount point)": [
  null,
  "(немає пов'язаної точки монтування)"
 ],
 "(not mounted)": [
  null,
  "(не змонтовано)"
 ],
 "(recommended)": [
  null,
  "(рекомендовано)"
 ],
 "1 MiB": [
  null,
  "1 МіБ"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "128 KiB": [
  null,
  "128 КіБ"
 ],
 "16 KiB": [
  null,
  "16 КіБ"
 ],
 "2 MiB": [
  null,
  "2 МіБ"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "32 KiB": [
  null,
  "32 КіБ"
 ],
 "4 KiB": [
  null,
  "4 КіБ"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "512 KiB": [
  null,
  "512 КіБ"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "64 KiB": [
  null,
  "64 КіБ"
 ],
 "8 KiB": [
  null,
  "8 КіБ"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "На $0 не встановлено сумісної версії Cockpit."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "У цьому буфері вже існує файлова система із цією назвою."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Буде створено новий ключ SSH у $0 для $1 на $2 і його буде додано до файла $3 $4 на $5."
 ],
 "A pool with this name exists already.": [
  null,
  "Буфер із цією назвою вже існує."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Групу томів із пропущеними фізичними томами не можна перейменовувати."
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Acceptable password": [
  null,
  "Прийнятний пароль"
 ],
 "Action": [
  null,
  "Дія"
 ],
 "Actions": [
  null,
  "Дії"
 ],
 "Activate": [
  null,
  "Задіяти"
 ],
 "Activate before resizing": [
  null,
  "Активуйте до зміни розмірів"
 ],
 "Activating $target": [
  null,
  "Активуємо $target"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Додати шифрування диска з мережевою прив'язкоюю"
 ],
 "Add Tang keyserver": [
  null,
  "Додати сервер ключів Tang"
 ],
 "Add a bitmap": [
  null,
  "Додати бітову карту"
 ],
 "Add block devices": [
  null,
  "Додати блокові пристрої"
 ],
 "Add disk": [
  null,
  "Додати диск"
 ],
 "Add disks": [
  null,
  "Додати диски"
 ],
 "Add iSCSI portal": [
  null,
  "Додати портал iSCSI"
 ],
 "Add key": [
  null,
  "Додати ключ"
 ],
 "Add keyserver": [
  null,
  "Додати сервер ключів"
 ],
 "Add passphrase": [
  null,
  "Додати пароль"
 ],
 "Add physical volume": [
  null,
  "Додати фізичний том"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Додавання «$0» параметрів шифрування"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Додавання «$0» до параметрів файлової системи"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Додавання сервера ключів потребує розблокування буфера. Будь ласка, надайте пароль до наявного буфера."
 ],
 "Adding key": [
  null,
  "Додавання ключа"
 ],
 "Adding physical volume to $target": [
  null,
  "Додаємо фізичний том до $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Додавання rd.neednet=1 до командного рядка ядра"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Address": [
  null,
  "Адреса"
 ],
 "Address cannot be empty": [
  null,
  "Адреса не може бути порожньою"
 ],
 "Address is not a valid URL": [
  null,
  "Адреса є некоректною"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Адміністрування за допомогою вебконсолі Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Для вибраного компонування потрібні усі $0 вибрані фізичні томи."
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Allocated": [
  null,
  "Розподілено"
 ],
 "Allow overprovisioning": [
  null,
  "Дозволити перепрогнозування"
 ],
 "An additional $0 must be selected": [
  null,
  "пройдіть процес відвідування синагоги $0"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документація з ролей Ansible"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Придатне для критичних монтувань, зокрема /var"
 ],
 "Assessment": [
  null,
  "Оцінювання"
 ],
 "At boot": [
  null,
  "При завантаженні"
 ],
 "At least $0 disk is needed.": [
  null,
  "Потрібен принаймні $0 диск.",
  "Потрібно принаймні $0 диски.",
  "Потрібно принаймні $0 дисків."
 ],
 "At least one block device is needed.": [
  null,
  "Потрібен принаймні один блоковий пристрій."
 ],
 "At least one disk is needed.": [
  null,
  "Потрібен принаймні один диск."
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Має бути змонтовано принаймні один підтом"
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Щоб отримати доступ до виконання привілейованих завдань за допомогою вебконсолі Cockpit, слід пройти розпізнавання"
 ],
 "Authentication required": [
  null,
  "Слід пройти розпізнавання"
 ],
 "Authorize SSH key": [
  null,
  "Уповноважити ключ SSH"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматично за допомогою додаткових серверів NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Automation script": [
  null,
  "Скрипт автоматизації"
 ],
 "Available targets on $0": [
  null,
  "Доступні призначення на $0"
 ],
 "BIOS boot partition": [
  null,
  "Розділ завантаження BIOS"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Block device": [
  null,
  "Блоковий пристрій"
 ],
 "Block device for filesystems": [
  null,
  "Блоковий пристрій для файлових систем"
 ],
 "Block devices": [
  null,
  "Блокові пристрої"
 ],
 "Blocked": [
  null,
  "Заблоковано"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Завантаження зазнає невдачі, якщо не монтується ця файлова система, заважаючи віддаленому доступу"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Завантаження буде успішним, якщо файлову систему не змонтовано"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "Cache": [
  null,
  "Кеш"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "Capacity": [
  null,
  "Місткість"
 ],
 "Category": [
  null,
  "Категорія"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change iSCSI initiater name": [
  null,
  "Змінити назву ініціатора iSCSI"
 ],
 "Change iSCSI initiator name": [
  null,
  "Змінити назву ініціатора iSCSI"
 ],
 "Change label": [
  null,
  "Змінити мітку"
 ],
 "Change passphrase": [
  null,
  "Змінити пароль"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Зміна ключів часто є результатом перевстановлення операційної системи. Втім, неочікувана зміна може вказувати на сторонню спробу перехопити дані вашого з'єднання."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Зміна типів розділів може завадити нормальному завантаженню системи."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Перевірте, чи збігається хеш SHA-256 або SHA-1, який отримано за допомогою команди, з наведеним у цьому вікні."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Перевірити хеш ключа за допомогою сервера Tang."
 ],
 "Checking $target": [
  null,
  "Перевіряємо $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Перевіряємо пристрій MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Перевіряємо і відновлюємо пристрій MDRAID $target"
 ],
 "Checking filesystem usage": [
  null,
  "Перевіряємо використання файлової системи"
 ],
 "Checking for $0 package": [
  null,
  "Перевірка на пакунок $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Перевіряємо на підтримку NBDE у initrd"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "Chunk size": [
  null,
  "Розмір фрагмента"
 ],
 "Cleaning up for $target": [
  null,
  "Спорожнюємо для $target"
 ],
 "Cleartext device": [
  null,
  "Пристрій Cleartext"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Налаштування Cockpit для NetworkManager і Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit — програма для керування сервером, яка полегшує адміністрування ваших серверів під керуванням Linux за допомогою програми для перегляду сторінок інтернету. Ви зможете одночасно використовувати термінал і вебінструмент. Службу, яку було запущено за допомогою Cockpit, можна зупинити за допомогою термінала. І навпаки, якщо трапиться помилка у терміналі, ви побачите її у інтерфейсі журналу Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не встановлено"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit — чудовий інструмент для системних адміністраторів-початківців. За його допомогою вони без проблем впораються із простими завданнями, зокрема адмініструванням сховищ даних, інспектуванням журналів та запуском і зупиненням служб. Ви зможете одночасно стежити за роботою декількох серверів і адмініструвати ці сервери. Просто додайте їх одним клацанням кнопкою миші і ваш комп’ютер сам нагляне за своїми приятелями."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Збирати і пакувати діагностичні дані і дані щодо підтримки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Збирати дампи аварій ядра"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Сумісний із усіма системами та пристроями (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Сумісний зі сучасними системами та жорсткими дисками > 2 ТБ (GPT)"
 ],
 "Compression": [
  null,
  "Стискання"
 ],
 "Confirm": [
  null,
  "Підтвердити"
 ],
 "Confirm deletion of $0": [
  null,
  "Підтвердьте вилучення $0"
 ],
 "Confirm key password": [
  null,
  "Підтвердження пароля до ключа"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Підтвердьте вилучення введенням альтернативного пароля"
 ],
 "Confirm stopping of $0": [
  null,
  "Підтвердьте зупинку $0"
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Copied": [
  null,
  "Скопійовано"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Create $0": [
  null,
  "Створити $0"
 ],
 "Create LVM2 volume group": [
  null,
  "Створити групу томів LVM2"
 ],
 "Create MDRAID device": [
  null,
  "Створити пристрій MDRAID"
 ],
 "Create RAID device": [
  null,
  "Створити пристрій RAID"
 ],
 "Create Stratis pool": [
  null,
  "Створити буфер Stratis"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Створити ключ SSH і уповноважити його"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Створити знімок файлової системи $0"
 ],
 "Create and mount": [
  null,
  "Створити і змонтувати"
 ],
 "Create and start": [
  null,
  "Створити і запустити"
 ],
 "Create filesystem": [
  null,
  "Створити файлову систему"
 ],
 "Create logical volume": [
  null,
  "Створити логічний том"
 ],
 "Create new filesystem": [
  null,
  "Створити файлову систему"
 ],
 "Create new logical volume": [
  null,
  "Створити логічний том"
 ],
 "Create new task file with this content.": [
  null,
  "Створити файл завдання із цим вмістом."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Створити логічний том з тонким прогнозуванням"
 ],
 "Create only": [
  null,
  "Лише створити"
 ],
 "Create partition": [
  null,
  "Створити розділ"
 ],
 "Create partition on $0": [
  null,
  "Створити розділ на $0"
 ],
 "Create partition table": [
  null,
  "Створити таблицю розділів"
 ],
 "Create snapshot": [
  null,
  "Створення знімка"
 ],
 "Create snapshot and mount": [
  null,
  "Створити знімок і змонтувати"
 ],
 "Create snapshot only": [
  null,
  "Лише створити знімок"
 ],
 "Create storage device": [
  null,
  "Створити пристрій зберігання даних"
 ],
 "Create subvolume": [
  null,
  "Створити підтом"
 ],
 "Create thin volume": [
  null,
  "Створити тонкий том"
 ],
 "Create volume group": [
  null,
  "Створити групу томів"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Створюємо групу томів LVM2 $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "Створення пристрою MDRAID $target"
 ],
 "Creating VDO device": [
  null,
  "Створення пристрою VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "Створюємо файлову систему на $target"
 ],
 "Creating logical volume $target": [
  null,
  "Створюємо логічний том $target"
 ],
 "Creating partition $target": [
  null,
  "Створюємо розділ $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Створюємо знімок $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Зараз використовується"
 ],
 "Custom": [
  null,
  "Нетиповий"
 ],
 "Custom mount options": [
  null,
  "Нетипові параметри монтування"
 ],
 "Custom type": [
  null,
  "Нестандартний тип"
 ],
 "Data": [
  null,
  "Дані"
 ],
 "Data used": [
  null,
  "Використано даних"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Дані зберігатимуться як дві копії і також у інший спосіб на вибраних фізичних томах для підвищення надійності та швидкодії. Має бути вибрано принаймні чотири томи."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Дані зберігатимуться як дві або декілька копій на вибраних фізичних томах для підвищення надійності. Має бути вибрано принаймні два томи."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Дані будуть зберігатися на вибраних фізичних томах у інший спосіб для підвищення швидкодії. Має бути вибрано принаймні два томи."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Дані буде збережено на вибраних фізичних томах, один з яких може бути втрачено без втрати даних. Має бути вибрано принаймні три томи."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Дані буде збережено на вибраних фізичних томах, один з яких може бути втрачено без втрати даних. Дані також буде збережено в інший спосіб для підвищення швидкодії. Має бути вибрано принаймні три томи."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Дані буде збережено на вибраних фізичних томах, до двох з яких може бути одночасно втрачено без втрати даних. Дані також має бути збережено в інший спосіб для підвищення швидкодії. Має бути вибрано принаймні п'ять томів."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Дані буде збережено на вибраних фізичних томах без будь-якої надлишковості або підвищення швидкодії."
 ],
 "Deactivate": [
  null,
  "Вимкнути"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Деактивувати логічний том $0/$1?"
 ],
 "Deactivating $target": [
  null,
  "Деактивуємо $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Спеціальна парність (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Скасування дублювання"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Delete group": [
  null,
  "Вилучити групу"
 ],
 "Delete pool": [
  null,
  "Вилучити резерв"
 ],
 "Deleting $target": [
  null,
  "Вилучаємо $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Вилучаємо групу томів LVM2 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Вилучення буфера Stratis призведе до витирання усіх даних, що на ньому зберігаються."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Вилучення файлової системи призведе до вилучення усіх даних, що на ньому зберігаються."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Вилучення логічного тому призведе до витирання усіх даних, що на ньому зберігаються."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Вилучення розділу призведе до вилучення усіх даних, що на ньому зберігаються."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Вилучення призведе до витирання усіх даних на пристрої RAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Вилучення призведе до витирання усіх даних на пристрої VDO."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Вилучення призведе до витирання усіх даних на групі томів."
 ],
 "Deleting erases all data on this subvolume and all it's children.": [
  null,
  "Вилучення призведе до витирання усіх даних на підтомі та його дочірніх об'єктах."
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "Device": [
  null,
  "Пристрій"
 ],
 "Device contains unrecognized data": [
  null,
  "На пристрої містяться нерозпізнані дані"
 ],
 "Device file": [
  null,
  "Файл пристрою"
 ],
 "Device is read-only": [
  null,
  "Пристрій придатний лише для читання"
 ],
 "Device number": [
  null,
  "Номер пристрою"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Disconnect": [
  null,
  "Від’єднатися"
 ],
 "Disk is OK": [
  null,
  "З диском усе гаразд"
 ],
 "Disk is failing": [
  null,
  "Диск виходить з ладу"
 ],
 "Disk passphrase": [
  null,
  "Пароль до диска"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "Dismiss": [
  null,
  "Відкинути"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Розподілена парність (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Не монтувати"
 ],
 "Do not mount automatically on boot": [
  null,
  "Не монтувати автоматично під час завантаження"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "Does not mount during boot": [
  null,
  "Не монтується під час завантаження"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Подвійна розподілена парність (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "Отримуємо $0"
 ],
 "Drive": [
  null,
  "Диск"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "EFI system partition": [
  null,
  "Системний розділ EFI"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Edit Tang keyserver": [
  null,
  "Редагувати сервер ключів Tang"
 ],
 "Edit mount point": [
  null,
  "Редагувати точку монтування"
 ],
 "Editing a key requires a free slot": [
  null,
  "Редагування ключа потребує вільного слоту"
 ],
 "Ejecting $target": [
  null,
  "Видобуваємо $target"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Emptying $target": [
  null,
  "Спорожняємо $target"
 ],
 "Enabling $0": [
  null,
  "Вмикаємо $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Зашифрувати дані за допомогою сервера ключів Tang"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Зашифрувати дані за допомогою пароля шифрування"
 ],
 "Encrypted $0": [
  null,
  "Зашифрований $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "Шифрований буфер Stratis $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Зашифрований логічний том $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Шифрований розділ $0"
 ],
 "Encryption": [
  null,
  "Шифрування"
 ],
 "Encryption options": [
  null,
  "Параметри шифрування"
 ],
 "Encryption type": [
  null,
  "Тип шифрування"
 ],
 "Erasing $target": [
  null,
  "Витираємо $target"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Помилка під час спроби встановити $0: PackageKit не встановлено"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Має бути вибрано точно $0 фізичних томів"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Має бути вибрано точно $0 фізичних ктомів по одному на кожну смугу логічного тому."
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Extended partition": [
  null,
  "Розширений розділ"
 ],
 "Failed": [
  null,
  "Помилка"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Filesystem": [
  null,
  "Файлова система"
 ],
 "Filesystem is locked": [
  null,
  "Файлову систему заблоковано"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Файлову систему змонтовано лише для читання"
 ],
 "Filesystem name": [
  null,
  "Назва файлової системи"
 ],
 "Filesystem outside the target": [
  null,
  "Файлова система поза ціллю"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Під цією точкою монтування вже змонтовано файлові системи."
 ],
 "Firmware version": [
  null,
  "Версія мікропрограми"
 ],
 "Fix NBDE support": [
  null,
  "Виправити підтримку NBDE"
 ],
 "Format": [
  null,
  "Формат"
 ],
 "Format $0": [
  null,
  "Форматувати $0"
 ],
 "Format and mount": [
  null,
  "Форматувати і змонтувати"
 ],
 "Format and start": [
  null,
  "Форматувати і запустити"
 ],
 "Format only": [
  null,
  "Лише форматувати"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Форматування призведе до знищення усіх даних на пристрої для зберігання даних."
 ],
 "Free space": [
  null,
  "Вільне місце"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "Grow": [
  null,
  "Збільшити"
 ],
 "Grow content": [
  null,
  "Збільшити вміст"
 ],
 "Grow logical size of $0": [
  null,
  "Збільшити логічний розмір $0"
 ],
 "Grow logical volume": [
  null,
  "Збільшити логічний том"
 ],
 "Grow partition": [
  null,
  "Збільшити розділ"
 ],
 "Grow the pool to take all space": [
  null,
  "Збільшити буфер так, щоб використати усе місце"
 ],
 "Grow to take all space": [
  null,
  "Збільшити так, щоб використати усе місце"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "Hard Disk Drive": [
  null,
  "Жорсткий диск"
 ],
 "Hide confirmation password": [
  null,
  "Приховати підтвердження пароля"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "How to check": [
  null,
  "Як перевірити"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Підтверджую остаточну втрату цих даних"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ВНУТРІШНЯ ПОМИЛКА — цей логічний том позначено як активний, він повинен мати пов'язаний блоковий пристрій. Втім, знайти такий блоковий пристрій не вдалося."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Якщо відбиток є відповідним, натисніть «Довіряти і додати вузол». Якщо ж це не так, не встановлюйте з'єднання і повідомте про подію адміністратору."
 ],
 "Important data might be deleted:": [
  null,
  "Може бути вилучено важливі дані:"
 ],
 "In a terminal, run: ": [
  null,
  "У терміналі віддайте таку команду: "
 ],
 "In sync": [
  null,
  "Синхронізовано"
 ],
 "Inactive logical volume": [
  null,
  "Неактивний логічний том"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Несумісне монтування файлових систем"
 ],
 "Index memory": [
  null,
  "Пам'ять покажчика"
 ],
 "Initialize": [
  null,
  "Ініціалізувати"
 ],
 "Initialize disk $0": [
  null,
  "Ініціалізувати диск $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Ініціалізація призведе до знищення усіх даних, які зберігаються на диску."
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Install NFS support": [
  null,
  "Встановити підтримку NFS"
 ],
 "Install Stratis support": [
  null,
  "Встановити підтримку Stratis"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Встановлення $0 призведе до вилучення $1."
 ],
 "Installing packages": [
  null,
  "Встановлення пакунків"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "Invalid username or password": [
  null,
  "Некоректне ім’я користувача чи пароль"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Jobs": [
  null,
  "Завдання"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Key password": [
  null,
  "Пароль до ключа"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Тут не можна редагувати слоти ключів із невідомими типами"
 ],
 "Key source": [
  null,
  "Джерело ключа"
 ],
 "Keys": [
  null,
  "Ключі"
 ],
 "Keyserver": [
  null,
  "Сервер ключів"
 ],
 "Keyserver address": [
  null,
  "Адреса сервера ключів"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Вилучення сервера ключів може завадити розблокуванню $0."
 ],
 "LVM2 VDO pool": [
  null,
  "Буфер VDO LVM2"
 ],
 "LVM2 logical volume": [
  null,
  "Логічний том LVM2"
 ],
 "LVM2 logical volumes": [
  null,
  "Логічні томи LVM2"
 ],
 "LVM2 physical volume": [
  null,
  "Фізичний том LVM2"
 ],
 "LVM2 physical volumes": [
  null,
  "Фізичні томи LVM2"
 ],
 "LVM2 volume group": [
  null,
  "Група томів LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "Група томів LVM2 $0"
 ],
 "Label": [
  null,
  "Мітка"
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Last cannot be removed": [
  null,
  "Останній не можна вилучати"
 ],
 "Last disk can not be removed": [
  null,
  "Не можна вилучати останній диск"
 ],
 "Last modified: $0": [
  null,
  "Востаннє змінено: $0"
 ],
 "Layout": [
  null,
  "Розкладка"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Limit size": [
  null,
  "Обмеження розміру"
 ],
 "Limit virtual filesystem size": [
  null,
  "Обмежити розмір віртуальної файлової системи"
 ],
 "Linear": [
  null,
  "Лінійний"
 ],
 "Linux filesystem data": [
  null,
  "Дані файлової системи Linux"
 ],
 "Linux swap space": [
  null,
  "Резервна пам’ять Linux"
 ],
 "Loading system modifications...": [
  null,
  "Завантажуємо модифікації системи…"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "Local mount point": [
  null,
  "Локальна точка монтування"
 ],
 "Local storage": [
  null,
  "Локальне сховище даних"
 ],
 "Location": [
  null,
  "Розташування"
 ],
 "Lock": [
  null,
  "Заблокувати"
 ],
 "Lock $0?": [
  null,
  "Заблокувати $0?"
 ],
 "Locked data": [
  null,
  "Заблоковані дані"
 ],
 "Locked encrypted device might contain data": [
  null,
  "На заблокованому зашифрованому пристрої можуть міститися дані"
 ],
 "Locking $target": [
  null,
  "Блокуємо $target"
 ],
 "Log in": [
  null,
  "Увійти"
 ],
 "Log in to $0": [
  null,
  "Увійти до $0"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "Logical": [
  null,
  "Логічний"
 ],
 "Logical Volume Manager partition": [
  null,
  "Розділ засобу керування логічними томами (LVM)"
 ],
 "Logical size": [
  null,
  "Логічний розмір"
 ],
 "Logical volume": [
  null,
  "Логічний том"
 ],
 "Logical volume (snapshot)": [
  null,
  "Логічний том (знімок)"
 ],
 "Logical volume of $0": [
  null,
  "Логічний том $0"
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "MDRAID device": [
  null,
  "пристрій MDRAID"
 ],
 "MDRAID device $0": [
  null,
  "Пристій MDRAID $0"
 ],
 "MDRAID device is recovering": [
  null,
  "Пристрій MDRAID відновлюється"
 ],
 "MDRAID device must be running": [
  null,
  "Пристрій MDRAID має бути запущено"
 ],
 "MDRAID disk": [
  null,
  "Диск MDRAID"
 ],
 "MDRAID disks": [
  null,
  "Диски MDRAID"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Manage storage": [
  null,
  "Керування сховищем"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Marking $target as faulty": [
  null,
  "Позначаємо $target як помилковий"
 ],
 "Media drive": [
  null,
  "Мультимедійний носій"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Metadata used": [
  null,
  "Використано метаданих"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Віддзеркалений (RAID 1)"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Modifying $target": [
  null,
  "Змінюємо $target"
 ],
 "Mount": [
  null,
  "Змонтувати"
 ],
 "Mount Point": [
  null,
  "Точка монтування"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Змонтувати після того, як стане доступною мережа, ігнорувати помилки"
 ],
 "Mount also automatically on boot": [
  null,
  "Також монтувати автоматично під час завантаження"
 ],
 "Mount at boot": [
  null,
  "Змонтувати при завантаженні"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Монтувати автоматично до $0 під час завантаження"
 ],
 "Mount before services start": [
  null,
  "Змонтувати до запуску служб"
 ],
 "Mount configuration": [
  null,
  "Налаштування монтування"
 ],
 "Mount filesystem": [
  null,
  "Змонтувати файлову систему"
 ],
 "Mount now": [
  null,
  "Змонтувати зараз"
 ],
 "Mount on $0 now": [
  null,
  "Змонтувати до $0 зараз"
 ],
 "Mount options": [
  null,
  "Параметри монтування"
 ],
 "Mount point": [
  null,
  "Точка монтування"
 ],
 "Mount point cannot be empty": [
  null,
  "Точка монтування не може бути порожньою"
 ],
 "Mount point cannot be empty.": [
  null,
  "Точка монтування не може бути порожньою."
 ],
 "Mount point is already used for $0": [
  null,
  "Точку монтування вже використано для $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Запис точки монтування має починатися з «/»."
 ],
 "Mount read only": [
  null,
  "Змонтувати лише для читання"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Змонтувати без очікування, ігнорувати помилки"
 ],
 "Mounting $target": [
  null,
  "Монтуємо $target"
 ],
 "Mounts before services start": [
  null,
  "Монтується до запуску служб"
 ],
 "Mounts in parallel with services": [
  null,
  "Монтується паралельно зі службами"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Монтується паралельно зі службами, але після того, як стане доступною мережа"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "Multipathed devices": [
  null,
  "Пристрої із багатьма шляхами"
 ],
 "NFS mount": [
  null,
  "Змонтована NFS"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Name can not be empty.": [
  null,
  "Назва не повинна бути порожньою."
 ],
 "Name cannot be empty.": [
  null,
  "Назва не може бути порожньою."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Назва не повинна бути довшою за $0 байтів"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Назва не повинна бути довшою за $0 символів"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Назва не повинна бути довшою за 127 символів."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Назва не повинна бути довшою за 255 символів."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Назва не повинна містити символу «$0»."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Назва не повинна містити символу «/»."
 ],
 "Name cannot contain whitespace.": [
  null,
  "У назві не повинно бути пробілів."
 ],
 "Need a spare disk": [
  null,
  "Потрібен резервний диск"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "Networked storage": [
  null,
  "Мережеве сховище"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "New NFS mount": [
  null,
  "Нове монтування NFS"
 ],
 "New passphrase": [
  null,
  "Новий пароль"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "Next": [
  null,
  "Далі"
 ],
 "No available slots": [
  null,
  "Немає доступних слотів"
 ],
 "No block devices are available.": [
  null,
  "Немає доступних блокових пристроїв."
 ],
 "No block devices found": [
  null,
  "Не знайдено блокових пристроїв"
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "No devices found": [
  null,
  "Не знайдено пристроїв"
 ],
 "No disks are available.": [
  null,
  "Немає доступних дисків."
 ],
 "No disks found": [
  null,
  "Дисків не знайдено"
 ],
 "No drives found": [
  null,
  "Дисків не знайдено"
 ],
 "No encryption": [
  null,
  "Без шифрування"
 ],
 "No filesystem": [
  null,
  "Немає файлової системи"
 ],
 "No filesystems": [
  null,
  "Немає файлових систем"
 ],
 "No free key slots": [
  null,
  "Немає вільних слотів ключів"
 ],
 "No free space": [
  null,
  "Недостатньо вільного простору"
 ],
 "No free space after this partition": [
  null,
  "Після цього розділу є вільне місце"
 ],
 "No keys added": [
  null,
  "Не додано жодного ключа"
 ],
 "No logical volumes": [
  null,
  "Немає логічних томів"
 ],
 "No media inserted": [
  null,
  "Не виявлено носія даних"
 ],
 "No partitioning": [
  null,
  "Немає розподілу на розділи"
 ],
 "No partitions found": [
  null,
  "Розділів не знайдено"
 ],
 "No physical volumes found": [
  null,
  "Не знайдено фізичних томів"
 ],
 "No results found": [
  null,
  "Нічого не знайдено"
 ],
 "No snapshots found": [
  null,
  "Знімків не знайдено"
 ],
 "No storage found": [
  null,
  "Не знайдено сховища даних"
 ],
 "No subvolumes": [
  null,
  "Немає підтомів"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "No system modifications": [
  null,
  "Немає модифікацій системи"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Not enough free space": [
  null,
  "Недостатньо вільного місця"
 ],
 "Not enough space": [
  null,
  "Недостатньо місця"
 ],
 "Not enough space to grow": [
  null,
  "Недостатньо місця для збільшення"
 ],
 "Not found": [
  null,
  "Не знайдено"
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Not running": [
  null,
  "Зупинено"
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "Випадки"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Old passphrase": [
  null,
  "Старий пароль"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Після встановлення Cockpit його можна увімкнути за допомогою команди «systemctl enable --now cockpit.socket»."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Використано лише $0 з $1."
 ],
 "Operation '$operation' on $target": [
  null,
  "Дія «$operation» над $target"
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Other": [
  null,
  "Інше"
 ],
 "Overprovisioning": [
  null,
  "Перепрогнозування"
 ],
 "Overwrite": [
  null,
  "Перезаписати"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Перезаписати наявні дані нулями (повільно)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "Partition": [
  null,
  "Розділ"
 ],
 "Partition of $0": [
  null,
  "Розділ $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Розмір розділу — $0. Розмір даних — $1."
 ],
 "Partitioning": [
  null,
  "Розподіл"
 ],
 "Partitions": [
  null,
  "Розділи"
 ],
 "Passphrase": [
  null,
  "Пароль"
 ],
 "Passphrase can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "Passphrase cannot be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "Passphrase from any other key slot": [
  null,
  "Пароль з будь-якого іншого слоту ключів"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Вилучення пароля може завадити розблокуванню $0."
 ],
 "Passphrases do not match": [
  null,
  "Паролі не збігаються"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Paste error": [
  null,
  "Помилка вставлення"
 ],
 "Path on server": [
  null,
  "Шлях на сервері"
 ],
 "Path on server cannot be empty.": [
  null,
  "Шлях на сервері не може бути порожнім."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Шлях на сервері має починатися з «/»."
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "Permanently delete $0?": [
  null,
  "Остаточно вилучити $0?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Остаточно вилучити логічний том $0/$1?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Остаточно вилучити підтом $0?"
 ],
 "Physical": [
  null,
  "Фізичний"
 ],
 "Physical Volumes": [
  null,
  "Фізичні томи"
 ],
 "Physical volumes": [
  null,
  "Фізичні томи"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Тут не можна змінювати розміри фізичних томів"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Please unmount them first.": [
  null,
  "Будь ласка, спочатку демонтуйте їх."
 ],
 "Pool for thin logical volumes": [
  null,
  "Буфер для тонких логічних томів"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Буфер для тонких резервованих логічних томів LVM2"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Буфер для тонких резервованих томів"
 ],
 "Pool passphrase": [
  null,
  "Пароль до буфера"
 ],
 "Port": [
  null,
  "Порт"
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Розділ завантаження PowerPC PReP"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "Processes using the location": [
  null,
  "Процеси, що використовують це місце"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Вкажіть пароль до буфера даних на цих блокових пристроях:"
 ],
 "Purpose": [
  null,
  "Призначення"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Стрічка)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Дзеркало)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Стрічка дзеркал)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Пов’язана парність)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Розподілена парність)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Подвійна розподілена парність)"
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "RAID level": [
  null,
  "Рівень RAID"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "Для RAID10 потрібна парна кількість фізичних томів"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Reading": [
  null,
  "Читання"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Recovering": [
  null,
  "Відновлюємо"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Відновлюємо пристрій MDRAID $target"
 ],
 "Regenerating initrd": [
  null,
  "Повторно створюємо initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Пов'язані процеси і служби буде примусово зупинено."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Пов'язані процеси буде примусово зупинено."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Пов'язані служби буде примусово зупинено."
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Remove $0?": [
  null,
  "Вилучити $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Вилучити сервер ключів Tang?"
 ],
 "Remove device": [
  null,
  "Вилучити пристрій"
 ],
 "Remove missing physical volumes?": [
  null,
  "Вилучити пропущені фізичні томи?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Вилучити пароль у слоті ключів $0?"
 ],
 "Remove passphrase?": [
  null,
  "Вилучити пароль?"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Вилучаємо $target з пристрою MDRAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Вилучення пароля без підтвердження іншим паролем може закрити доступ до розблоковування або керування ключами, якщо інші паролі буде забуто або втрачено."
 ],
 "Removing physical volume from $target": [
  null,
  "Вилучаємо фізичний том з $target"
 ],
 "Rename": [
  null,
  "Перейменувати"
 ],
 "Rename Stratis pool": [
  null,
  "Перейменувати буфер Stratis"
 ],
 "Rename filesystem": [
  null,
  "Перейменувати файлову систему"
 ],
 "Rename logical volume": [
  null,
  "Перейменувати логічний том"
 ],
 "Rename volume group": [
  null,
  "Перейменувати групу томів"
 ],
 "Renaming $target": [
  null,
  "Перейменовуємо $target"
 ],
 "Repair": [
  null,
  "Полагодити"
 ],
 "Repair logical volume $0": [
  null,
  "Полагодити логічний том $0"
 ],
 "Repairing $target": [
  null,
  "Відновлюємо $target"
 ],
 "Repeat passphrase": [
  null,
  "Повторіть пароль"
 ],
 "Resizing $target": [
  null,
  "Зміна розміру $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Зміна розмірів зашифрованої системи потребує розблокування диска. Будь ласка, вкажіть поточний пароль до диска."
 ],
 "Reuse existing encryption": [
  null,
  "Повторно використати наявне шифрування"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Повторно використати наявне шифрування ($0)"
 ],
 "Row expansion": [
  null,
  "Розгортання рядка"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустити цю команду довіреною мережею або фізично на віддаленому комп'ютері:"
 ],
 "Running": [
  null,
  "Працює"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "Самоперевірка SMART $target"
 ],
 "SSH key": [
  null,
  "Ключ SSH"
 ],
 "SSH key login": [
  null,
  "Вхід за ключем SSH"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Заощаджувати місце стисканням окремих блоків за допомогою LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Заощаджувати місце, зберігаючи ідентичні блоки даних лише раз"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Збереження нового пароля потребує розблокування диска. Будь ласка, вкажіть поточний пароль до диска."
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Securely erasing $target": [
  null,
  "Безпечно витираємо $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Налаштування Security Enhanced Linux та усування вад"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Виберіть фізичні томи, якими слід скористатися для того, щоб полагодити логічний том. Потрібно принаймні $0."
 ],
 "Serial number": [
  null,
  "Серійний номер"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server address": [
  null,
  "Адреса сервера"
 ],
 "Server address cannot be empty.": [
  null,
  "Адреса сервера не може бути порожньою."
 ],
 "Server cannot be empty.": [
  null,
  "Запис сервера не може бути порожнім."
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Services using the location": [
  null,
  "Служби, що використовують це місце"
 ],
 "Set": [
  null,
  "Встановити"
 ],
 "Set initial size": [
  null,
  "Встановити початковий розмір"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Встановити обмеження розміру віртуальної файлової системи"
 ],
 "Set partition type of $0": [
  null,
  "Встановити тип розділу $0"
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Setting up loop device $target": [
  null,
  "Налаштовуємо петльовий пристрій $target"
 ],
 "Shell script": [
  null,
  "Скрипт оболонки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "Показати усі $0 рядків"
 ],
 "Show confirmation password": [
  null,
  "Показати підтвердження пароля"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Shrink": [
  null,
  "Стиснути"
 ],
 "Shrink logical volume": [
  null,
  "Стиснути логічний том"
 ],
 "Shrink partition": [
  null,
  "Стиснути розділ"
 ],
 "Shrink volume": [
  null,
  "Стиснути том"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "Size cannot be negative": [
  null,
  "Розмір не може бути від’ємним"
 ],
 "Size cannot be zero": [
  null,
  "Розмір не може бути нульовим"
 ],
 "Size is too large": [
  null,
  "Розмір є надто великим"
 ],
 "Size must be a number": [
  null,
  "Розмір має бути числом"
 ],
 "Size must be at least $0": [
  null,
  "Розмір має бути не меншим за $0"
 ],
 "Slot $0": [
  null,
  "Слот $0"
 ],
 "Snapshot": [
  null,
  "Знімок"
 ],
 "Snapshot origin": [
  null,
  "Походження знімка"
 ],
 "Snapshots": [
  null,
  "Знімки"
 ],
 "Solid State Drive": [
  null,
  "Твердотільний диск"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Після створення буфера зріс розмір деяких блокових пристроїв у цьому буфері. Розмір буфера можна безпечно збільшити з метою використання доданого місця."
 ],
 "Sorry": [
  null,
  "Вибачте"
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Spare": [
  null,
  "Запас"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Start": [
  null,
  "Почати"
 ],
 "Start multipath": [
  null,
  "Запустити Multipath"
 ],
 "Started": [
  null,
  "Почато"
 ],
 "Starting MDRAID device $target": [
  null,
  "Запускаємо пристрій MDRAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "Запускаємо резервну область пам’яті $target"
 ],
 "State": [
  null,
  "Стан"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "Stop": [
  null,
  "Зупинити"
 ],
 "Stop and remove": [
  null,
  "Зупинити і вилучити"
 ],
 "Stop and unmount": [
  null,
  "Зупинити і демонтувати"
 ],
 "Stop device": [
  null,
  "Зупинити пристрій"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Зупиняємо пристрій MDRAID $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Зупиняємо резервну область пам’яті $target"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Storage can not be managed on this system.": [
  null,
  "У цій системі не можна керувати сховищем даних."
 ],
 "Storage logs": [
  null,
  "Журнали зберігання"
 ],
 "Store passphrase": [
  null,
  "Зберігати пароль"
 ],
 "Stored passphrase": [
  null,
  "Збережений пароль"
 ],
 "Stratis block device": [
  null,
  "Блоковий пристрій Stratis"
 ],
 "Stratis block devices": [
  null,
  "Блокові пристрої Stratis"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Блокові пристрої Stratis не можна звужувати"
 ],
 "Stratis filesystem": [
  null,
  "Файлова система Stratis"
 ],
 "Stratis filesystems": [
  null,
  "Файлові системи Stratis"
 ],
 "Stratis filesystems pool": [
  null,
  "Буфер файлових систем Stratis"
 ],
 "Stratis pool": [
  null,
  "Буфер Stratis"
 ],
 "Striped (RAID 0)": [
  null,
  "Смуговий (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Смуговий і віддзеркалений (RAID 10)"
 ],
 "Stripes": [
  null,
  "Смуги"
 ],
 "Strong password": [
  null,
  "Складний пароль"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Успішно скопійовано до буфера обміну!"
 ],
 "Swap": [
  null,
  "Свопінґ"
 ],
 "Swap can not be resized here": [
  null,
  "Тут не можна змінювати розмір резервної пам'яті"
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Синхронізуємо пристрій MDRAID $target"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Tang keyserver": [
  null,
  "Сервер ключів Tang"
 ],
 "Target": [
  null,
  "Призначення"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Пакунка $0 немає у жодному зі сховищ."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Для створення буферів Stratis має бути встановлено пакунок $0."
 ],
 "The $0 package must be installed.": [
  null,
  "Має бути встановлено пакунок $0."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Для створення пристроїв VDO буде встановлено пакунок $0."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Пристрій MDRAID перебуває у стані із погіршеними властивостями"
 ],
 "The MDRAID device must be running": [
  null,
  "Пристрій MDRAID має працювати"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Ключ SSH $0 $1 на $2 буде додано до файла $3 $4 на $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Ключ SSH $0 буде доступним протягом решти сеансу і також буде доступним для входу на інші вузли."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено паролем, а на вузлі заборонено вхід без пароля. Буль ласка, вкажіть пароль до ключа у $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено. Ви можете увійти або за допомогою пароль до вашого облікового запису або вказавши пароль до ключа у $1."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Створення цього пристрою VDO не завершено, ним не можна користуватися."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Поточний користувач, від імені якого було здійснено вхід до системи, не має права перегляду даних щодо ключів."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Перед форматуванням диск має бути розблоковано. Будь ласка, надайте наявний пароль."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "У файлової системи немає пов'язаної точки монтування."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "У файлової системи немає сталої точки монтування."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Файлову систему налаштовано на автоматичне монтування при вході до системи, але її контейнер шифрування не буде розблоковано вчасно."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Файлову систему зараз змонтовано, але її не буде змонтовано після наступного завантаження."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Файлову систему зараз змонтовано до $0, але її буде змонтовано до $1 під час наступного завантаження."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Файлову систему зараз змонтовано до $0, але її не буде змонтовано після наступного завантаження."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Файлову систему зараз не змонтовано, але її буде змонтовано під час наступного завантаження."
 ],
 "The filesystem is not mounted.": [
  null,
  "Файлову систему не змонтовано."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Файлову систему буде розблоковано і змонтовано під час наступного завантаження. Це може потребувати введення пароля."
 ],
 "The fingerprint should match:": [
  null,
  "Відбиток має збігатися:"
 ],
 "The initrd must be regenerated.": [
  null,
  "initrd має бути створено повторно."
 ],
 "The key password can not be empty": [
  null,
  "Пароль до ключа не може бути порожнім"
 ],
 "The key passwords do not match": [
  null,
  "Паролі до ключа не збігаються"
 ],
 "The last key slot can not be removed": [
  null,
  "Не можна вилучати останній слот ключів"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Не можна вилучати останній змонтований підтом"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Процеси і служби зі списку буде примусово зупинено."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Процеси зі списку буде примусово зупинено."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Служби зі списку буде примусово зупинено."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Користувач, який увійшов до системи, не має права переглядати модифікації системи"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Точка монтування $0 перебуває у користуванні такими процесами:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Точка монтування $0 перебуває у користуванні такими службами:"
 ],
 "The password can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Відбиток-результат можна поширювати у спосіб із загальним доступом, зокрема електронною поштою."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Відбиток-результат можна поширювати відкритими способами, включно із електронною поштою. Якщо ви просите когось виконати перевірку для вас, вони можуть надсилати результати за допомогою будь-якого способу."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "У системі зараз не передбачено підтримки розблокування файлової системи з сервером ключів Tang під час завантаження."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "У системі зараз не передбачено підтримки розблокування кореневої файлової системи з сервером ключів Tang."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "У системі є пристрої із декількома шляхами доступу, але службу multipath не запущено."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Недостатньо місця, яким можна скористатися для того, щоб полагодити систему. Потрібно принаймні $0 на фізичний томах, які ще не використано для цього логічного тому."
 ],
 "These additional steps are necessary:": [
  null,
  "Потрібні такі додаткові кроки:"
 ],
 "These changes will be made:": [
  null,
  "Буде внесено такі зміни:"
 ],
 "Thin logical volume": [
  null,
  "Тонкий логічний том"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Тонкі резервовані логічні томи LVM2"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Цей пристрій MDRAID не має бітової карти призначення до запису. Така бітова карта може значно зменшити час синхронізації."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Це монтування NFS використовується; можна лише змінювати його параметри."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Цей пристрій VDO не використовує увесь об'єм резервного пристрою."
 ],
 "This device can not be used for the installation target.": [
  null,
  "Цей пристрій не можна використовувати для цілі встановлення."
 ],
 "This device is currently in use.": [
  null,
  "Цей пристрій зараз перебуває у користуванні."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Цей сервер ключів є єдиним способом розблокування буфера, його не можна вилучати."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Цей логічний том втратив частину його фізичних томів, ним не можна надалі користуватися. Вам слід вилучити його і створити новий, який займе його місце."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Цей логічний том втратив частину фізичних томів, але не втратив жодних даних. Вам слід полагодити його для відновлення початкової надлишковості."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Цей логічний том втратив частину своїх фізичних томів, але, ймовірно, жодних даних на ньому не втрачено. Ви, можливо, зможете його полагодити."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Місце на цьому логічному томі не повністю використано даними, які на ньому зберігаються."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Місце на цьому розділі не повністю використано даними, які на ньому зберігаються."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Цей пароль є єдиним способом розблокування буфера, його не можна вилучати."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Цей буфер даних не використовує усе доступне місце на його блокових пристроях."
 ],
 "This pool is in a degraded state.": [
  null,
  "Цей буфер перебуває у стані із погіршеними властивостями."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Цей інструмент налаштовує правила SELinux і може допомогти зрозуміти та усунути порушення правил."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Цей інструмент налаштовує систему на запис дампів аварій ядра. Передбачено підтримку призначень дампу «local» (диск), «ssh» та «nfs»."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Цей інструмент створюдє архів даних щодо налаштувань та діагностики для запущеної системи. Архів може бути збережено локально або централізовано з метою журналювання або стеження або надіслано до представників технічної підтримки, розробників або адміністраторів системи, щоб допомогти з пошуком технічних проблем та діагностикою."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Цей інструмент керує локальним сховищем даних, зокрема файловими системами, групами томів LVM2 та монтуваннями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Цей інструмент керує можливостями роботи у мережі, зокрема зв'язками, містками, командами, віртуальними LAN та брандмауерами, за допомогою NetworkManager і Firewalld. NetworkManager є несумісним із типовим для Ubuntu systemd-networkd та скриптами ifupdown Debian."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "У цій групі томів не вистачає деяких фізичних томів."
 ],
 "Tier": [
  null,
  "Клас"
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Щоб переконатися, що дані вашого з'єднання не буде перехоплено зловмисниками, будь ласка, підтвердьте відбиток ключа вузла:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Щоб перевірити відбиток, віддайте вказану нижче команду для $0 під час безпосередньої роботи на комп'ютері або з використанням надійної мережі:"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Trust and add host": [
  null,
  "Довіряти і додати вузол"
 ],
 "Trust key": [
  null,
  "Довіряти ключу"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Назва типу може містити лише символи від 0 до 9, від A до F і «-»."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Тип слід вказувати у формі NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Тип має містити точно дві шістнадцяткові цифри (від 0 до 9 або від A до F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не вдалося увійти до $0 за допомогою розпізнавання за ключем SSH. Будь ласка, вкажіть пароль."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не вдалося увійти до $0. Вузол не приймає входу за паролем або будь-яким з ваших ключів SSH."
 ],
 "Unable to reach server": [
  null,
  "Не вдалося досягти сервера"
 ],
 "Unable to remove mount": [
  null,
  "Не вдалося вилучити монтування"
 ],
 "Unable to repair logical volume $0": [
  null,
  "Не вдалося полагодити логічний том $0"
 ],
 "Unable to unmount filesystem": [
  null,
  "Не вдалося демонтувати файлову систему"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Неочікувана помилка PackageKit під час встановлення $0: $1"
 ],
 "Unformatted data": [
  null,
  "Неформатовані дані"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Unknown ($0)": [
  null,
  "Невідомий ($0)"
 ],
 "Unknown host name": [
  null,
  "Невідома назва вузла"
 ],
 "Unknown host: $0": [
  null,
  "Невідомий вузол: $0"
 ],
 "Unknown type": [
  null,
  "Невідомий тип"
 ],
 "Unlock": [
  null,
  "Розблокувати"
 ],
 "Unlock automatically on boot": [
  null,
  "Автоматично розблокувати при завантаженні"
 ],
 "Unlock before resizing": [
  null,
  "Розблокуйте до зміни розмірів"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Розблокувати зашифрований буфер Stratis"
 ],
 "Unlocking $target": [
  null,
  "Розблокуємо $target"
 ],
 "Unlocking disk": [
  null,
  "Розблоковуємо диск"
 ],
 "Unmount": [
  null,
  "Демонтувати"
 ],
 "Unmount filesystem $0": [
  null,
  "Демонтувати файлову систему $0"
 ],
 "Unmount now": [
  null,
  "Демонтувати зараз"
 ],
 "Unmounting $target": [
  null,
  "Демонтуємо $target"
 ],
 "Unrecognized data": [
  null,
  "Нерозпізнані дані"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Тут не можна зменшити об'єм нерозпізнаних даних"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Тут не можна зменшити об'єм нерозпізнаних даних."
 ],
 "Unsupported logical volume": [
  null,
  "Непідтримуваний логічний том"
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Usage": [
  null,
  "Використання"
 ],
 "Usage of $0": [
  null,
  "Вживання $0"
 ],
 "Use": [
  null,
  "Використати"
 ],
 "Use $0": [
  null,
  "Використати $0"
 ],
 "Use compression": [
  null,
  "Скористатися стисканням"
 ],
 "Use deduplication": [
  null,
  "Скористатися скасуванням дублювання"
 ],
 "Used": [
  null,
  "Використано"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Корисно для монтувань, які є необов'язковими або потребують взаємодії (зокрема паролів)"
 ],
 "User": [
  null,
  "Користувач"
 ],
 "Username": [
  null,
  "Користувач"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Пристрої резервного копіювання VDO не можна звужувати"
 ],
 "VDO device $0": [
  null,
  "Пристрій VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Том файлової системи VDO (стискання/дедублікація)"
 ],
 "Vendor": [
  null,
  "Постачальник"
 ],
 "Verify fingerprint": [
  null,
  "Перевірити відбиток"
 ],
 "Verify key": [
  null,
  "Перевірити ключ"
 ],
 "Very securely erasing $target": [
  null,
  "Дуже безпечно витираємо $target"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "View automation script": [
  null,
  "Переглянути скрипт автоматизації"
 ],
 "View logs": [
  null,
  "Переглянути журнали"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Розміри віртуальних файлових систем перевищують розміри буфера. Перепрогнозування не можна вимкнути."
 ],
 "Virtual size": [
  null,
  "Віртуальний розмір"
 ],
 "Virtual size limit": [
  null,
  "Обмеження віртуального розміру"
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Volume group": [
  null,
  "Група томів"
 ],
 "Volume group is missing physical volumes": [
  null,
  "У групі томів пропущено фізичні томи"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Розмір тому — $0. Розмір даних — $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Weak password": [
  null,
  "Простий пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Вебконсоль для серверів під керуванням Linux"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "Write-mostly": [
  null,
  "Здебільшого запис"
 ],
 "Writing": [
  null,
  "Запис"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Ви вперше встановлюєте з'єднання із $0."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "У вашій програмі для перегляду не передбачено можливості вставлення з контекстного меню. Ви можете скористатися для вставлення комбінацією Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "after network": [
  null,
  "після мережі"
 ],
 "backing device for VDO device": [
  null,
  "резервний пристрій для пристрою VDO"
 ],
 "btrfs device": [
  null,
  "Пристрій BTRFS"
 ],
 "btrfs devices": [
  null,
  "Пристрої BTRFS"
 ],
 "btrfs filesystem": [
  null,
  "Файлова система BTRFS"
 ],
 "btrfs subvolume": [
  null,
  "Підтом btrfs"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "Підтом BTRFS $0 з $1"
 ],
 "btrfs subvolumes": [
  null,
  "Підтоми BTRFS"
 ],
 "btrfs volume": [
  null,
  "Том BTRFS"
 ],
 "cache": [
  null,
  "кеш"
 ],
 "data": [
  null,
  "дані"
 ],
 "deactivate": [
  null,
  "вимкнути"
 ],
 "delete": [
  null,
  "вилучити"
 ],
 "device of btrfs volume": [
  null,
  "пристрій тому BTRFS"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "encrypted": [
  null,
  "зашифрований"
 ],
 "format": [
  null,
  "формат"
 ],
 "grow": [
  null,
  "збільшити"
 ],
 "iSCSI Drive": [
  null,
  "Диск iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Диски iSCSI"
 ],
 "iSCSI portal": [
  null,
  "Портал iSCSI"
 ],
 "ignore failure": [
  null,
  "ігнорувати помилки"
 ],
 "in less than a minute": [
  null,
  "за менше, ніж хвилину"
 ],
 "initialize": [
  null,
  "ініціалізувати"
 ],
 "less than a minute ago": [
  null,
  "менш, ніж хвилину тому"
 ],
 "lock": [
  null,
  "заблокувати"
 ],
 "member of MDRAID device": [
  null,
  "елемент пристрою MDRAID"
 ],
 "member of Stratis pool": [
  null,
  "частина буфера Stratis"
 ],
 "mount": [
  null,
  "монтування"
 ],
 "never mount at boot": [
  null,
  "ніколи не монтувати при завантаженні"
 ],
 "none": [
  null,
  "немає"
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "фізичний том групи томів LVM2"
 ],
 "read only": [
  null,
  "лише читання"
 ],
 "remove from LVM2": [
  null,
  "вилучити з LVM2"
 ],
 "remove from MDRAID": [
  null,
  "вилучити з MDRAID"
 ],
 "remove from btrfs volume": [
  null,
  "вилучити з тому BTRFS"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "shrink": [
  null,
  "стиснути"
 ],
 "snapshot": [
  null,
  "знімок"
 ],
 "stop": [
  null,
  "зупинити"
 ],
 "stop boot on failure": [
  null,
  "припинити завантаження при помилці"
 ],
 "stopped": [
  null,
  "зупинено"
 ],
 "unknown target": [
  null,
  "невідоме призначення"
 ],
 "unmount": [
  null,
  "демонтувати"
 ],
 "unpartitioned space on $0": [
  null,
  "нерозподілене місце на $0"
 ],
 "using key description $0": [
  null,
  "з використанням опису ключа $0"
 ],
 "yes": [
  null,
  "так"
 ],
 "format-bytes\u0004bytes": [
  null,
  "байтів"
 ]
});
