cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Managing LVMs": [
  null,
  "LVM'leri yönetme"
 ],
 "Managing NFS mounts": [
  null,
  "NFS bağlamalarını yönetme"
 ],
 "Managing RAIDs": [
  null,
  "RAID'leri yönetme"
 ],
 "Managing VDOs": [
  null,
  "VDO'ları yönetme"
 ],
 "Managing partitions": [
  null,
  "Bölümleri yönetme"
 ],
 "Managing physical drives": [
  null,
  "Fiziksel sürücüleri yönetme"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS şifrelemesi kullanma"
 ],
 "Using Tang server": [
  null,
  "Tang sunucusu kullanma"
 ],
 "disk": [
  null,
  "disk"
 ],
 "drive": [
  null,
  "sürücü"
 ],
 "encryption": [
  null,
  "şifreleme"
 ],
 "filesystem": [
  null,
  "dosya sistemi"
 ],
 "format": [
  null,
  "biçim"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "bağla"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "bölüm"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "bağlantıyı kaldır"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "birim"
 ]
});
