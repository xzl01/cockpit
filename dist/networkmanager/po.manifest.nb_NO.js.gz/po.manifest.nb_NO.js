cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Managing VLANs": [
  null,
  "Administrere VLAN"
 ],
 "Managing firewall": [
  null,
  "Administrere brannmur"
 ],
 "Managing networking bonds": [
  null,
  "Administrere nettverksbindinger"
 ],
 "Managing networking bridges": [
  null,
  "Administrere nettverksbroer"
 ],
 "Managing networking teams": [
  null,
  "Administrere nettverksteam"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Tjenester"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "bond": [
  null,
  "binding"
 ],
 "bridge": [
  null,
  "bro"
 ],
 "firewall": [
  null,
  "brannmur"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "grensesnitt"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "nettverk"
 ],
 "port": [
  null,
  "port"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "sone"
 ]
});
