cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Managing VLANs": [
  null,
  "Zarządzanie VLAN"
 ],
 "Managing firewall": [
  null,
  "Zarządzanie zaporą sieciową"
 ],
 "Managing networking bonds": [
  null,
  "Zarządzanie wiązaniami sieciowymi"
 ],
 "Managing networking bridges": [
  null,
  "Zarządzanie mostkami sieciowymi"
 ],
 "Managing networking teams": [
  null,
  "Zarządzanie zespołami sieciowymi"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Usługi"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "bond": [
  null,
  "wiązanie"
 ],
 "bridge": [
  null,
  "mostek"
 ],
 "firewall": [
  null,
  "zapora sieciowa"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "interfejs"
 ],
 "ipv4": [
  null,
  "IPv4"
 ],
 "ipv6": [
  null,
  "IPv6"
 ],
 "mac": [
  null,
  "MAC"
 ],
 "network": [
  null,
  "sieć"
 ],
 "port": [
  null,
  "port"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "team": [
  null,
  "zespołowe"
 ],
 "udp": [
  null,
  "UDP"
 ],
 "vlan": [
  null,
  "VLAN"
 ],
 "zone": [
  null,
  "strefa"
 ]
});
