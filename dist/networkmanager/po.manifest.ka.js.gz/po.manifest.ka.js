cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Managing VLANs": [
  null,
  "VLAN-ის მართვა"
 ],
 "Managing firewall": [
  null,
  "ბრანდმაუერის მართვა"
 ],
 "Managing networking bonds": [
  null,
  "ქსელის ბარათების გაერთიანების მართვა"
 ],
 "Managing networking bridges": [
  null,
  "ქსელური ხიდების მართვა"
 ],
 "Managing networking teams": [
  null,
  "ქსელური ბარათების გუნდების მართვა"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "სერვისები"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "bond": [
  null,
  "გადაბმა"
 ],
 "bridge": [
  null,
  "ხიდი"
 ],
 "firewall": [
  null,
  "ბრანდმაუერი"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "ინტერფეისი"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "ქსელი"
 ],
 "port": [
  null,
  "პორტი"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "გუნდი"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "ზონა"
 ]
});
