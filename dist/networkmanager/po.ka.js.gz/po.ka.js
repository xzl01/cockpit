cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "$0 active zone": [
  null,
  "$0 აქტიური ზონა",
  "$0 ცალი აქტიური ზონა"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 exited with code $1": [
  null,
  "$0-ის გამოსვლის კოდია $1"
 ],
 "$0 failed": [
  null,
  "$0 წარუმატებელია"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 მოკვდა სიგნალით $1"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "$0 zone": [
  null,
  "$0 ზონა"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "ქსელური bond აერთიანებს ქსელის მრავალ ინტერფეისს ერთ ლოგიკურ ინტერფეისში უფრო მაღალი გამტარობის ან წვდომადომის მისაღებად."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP-ის მონიტორინგი"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Acceptable password": [
  null,
  "მისაღები პაროლი"
 ],
 "Active": [
  null,
  "აქტიური"
 ],
 "Active backup": [
  null,
  "აქტიური მარქაფი"
 ],
 "Adaptive load balancing": [
  null,
  "დატვირთვის ადაპტიური გადანაწილება"
 ],
 "Adaptive transmit load balancing": [
  null,
  "გადაცემის დატვირთვის ადაპტაციური გადანაწილება"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "Add DNS server": [
  null,
  "DNS სერვერის დამატება"
 ],
 "Add VLAN": [
  null,
  "VLAN-ის დამატება"
 ],
 "Add VPN": [
  null,
  "VPN-ის დამატება"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN-ის დამატება"
 ],
 "Add a new zone": [
  null,
  "ახალი ზონის დამატება"
 ],
 "Add address": [
  null,
  "მისამართის დამატება"
 ],
 "Add bond": [
  null,
  "Bond-ის დამატება"
 ],
 "Add bridge": [
  null,
  "ხიდის დამატება"
 ],
 "Add member": [
  null,
  "წევრის დამატება"
 ],
 "Add new zone": [
  null,
  "ახალი ზონის დამატება"
 ],
 "Add peer": [
  null,
  "პარტნიორის დამატება"
 ],
 "Add ports": [
  null,
  "პორტების დამატება"
 ],
 "Add ports to $0 zone": [
  null,
  "პორტების დამატება ზონაში $0"
 ],
 "Add route": [
  null,
  "რაუტის დამატება"
 ],
 "Add search domain": [
  null,
  "საძებნი დომენის დამატება"
 ],
 "Add services": [
  null,
  "სერვისების დამატება"
 ],
 "Add services to $0 zone": [
  null,
  "სერვისების დამატება ზონაში $0"
 ],
 "Add services to zone $0": [
  null,
  "სერვისების დამატება ზონაში $0"
 ],
 "Add team": [
  null,
  "გუნდის დამატება"
 ],
 "Add zone": [
  null,
  "ზონის დამატება"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის დამატება გაწყვეტს კავშირს სერვერთან და ადმინისტრირების ინტერფეისს ხელმიუწვდომელს გახდის."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "მითითებული პორტების დაატება იწვევს firewalld-ის გადატვირთვას. ეს კი იწვევს გაშვებული კონფიგურაციის(ინახება მეხსიერებაში) დაკარგვას!"
 ],
 "Additional DNS $val": [
  null,
  "დამატებითი DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "DNS-ის დამატებითი საძებნი დომენები $val"
 ],
 "Additional address $val": [
  null,
  "დამატებითი მისამართი $val"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Additional ports": [
  null,
  "დამატებითი პორტები"
 ],
 "Address": [
  null,
  "მისამართი"
 ],
 "Address $val": [
  null,
  "მისამართი $val"
 ],
 "Addresses": [
  null,
  "მისამართები"
 ],
 "Addresses are not formatted correctly": [
  null,
  "მისამართის ფორმატი არასწორია"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockput ვებ კონსოლით ადმინისტრირება"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "Allowed IPs": [
  null,
  "დაშვებული IP-ები"
 ],
 "Allowed addresses": [
  null,
  "ნებადართული მისამართები"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-ის როლების დოკუმენტაცია"
 ],
 "Authenticating": [
  null,
  "ავთენტიკაცია"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit ვებ კონსოლში პრივილეგირებული ამოცანების შესასრულებლად საჭიროა ავთენტიკაცია"
 ],
 "Automatic": [
  null,
  "ავტომატური"
 ],
 "Automatic (DHCP only)": [
  null,
  "ავტომატური (მხოლოდ DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using additional NTP servers": [
  null,
  "დამატებითი NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automation script": [
  null,
  "ავტომატიზაციის სკრიპტი"
 ],
 "Balancer": [
  null,
  "ბალანსერი"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Bond": [
  null,
  "ინტერფეისების გადაბმა"
 ],
 "Bridge": [
  null,
  "ხიდი"
 ],
 "Bridge port": [
  null,
  "ხიდის პორტი"
 ],
 "Bridge port settings": [
  null,
  "ხიდის პორტის მორგება"
 ],
 "Broadcast": [
  null,
  "გადაცემა"
 ],
 "Broken configuration": [
  null,
  "გაფუჭებული კონფიგურაცია"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Cannot forward login credentials": [
  null,
  "მომხმარებლისადაპაროლის გადაგზავნის შეცდომა"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "Carrier": [
  null,
  "გადამზიდი"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Change the settings": [
  null,
  "პარამეტრების შეცვლა"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ამ პარამეტრის ცვლილებები გამოიწვევს კავშირის წვეტას და გათიშავს ადმინისტრირების ინტერფეისს."
 ],
 "Checking IP": [
  null,
  "IP-ის შემოწმება"
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager-ის და Firewalld-ის მორგება Cockpit-ით"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit-ს მითითებულ ჰოსტთან დაკავშირება არ შეუძლია ."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit წარმოადგენს სერვერის მმართველს, რომლითაც Linux სერვერების ადმინისტრირება ბრაუზერითაც შეგიძლიათ. ტერმინალსა და ვებ ხელსაწყოს შორის გადართვა პრობლემა არაა. Cockpit-ით გაშვებული სერვისი შეგიძლიათ გააჩეროთ ტერმინალთაც. ასევე, თუ შეცდომა დაფიქსირდება ტერმინალში, მისი ნახვა Cockpit-ის საშუალებითაც შეგიძლიათ."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit-ი შეუთავსებელია თქვენს სერვერზე დაყენებულ პროგრამულ უზრუნველყოფასთან."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit-ი ამ სისტემაზე დაყენებული არაა."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit შესანიშნავია ახალი სისტემური ადმინისტრატორებისთვის. ის მათ საშუალებას აძლევს ადვილად შეასრულონ ისეთი მარტივი ამოცანები, როგორიცაა შენახვის ადმინისტრირება, ჟურნალების შემოწმება და სერვისების დაწყება და გაჩერება. შეგიძლიათ ერთდროულად რამდენიმე სერვერის მონიტორინგი და ადმინისტრირება. უბრალოდ დაამატეთ ისინი ერთი დაწკაპუნებით და თქვენი მანქანები იზრუნებს მის მეგობრებზე."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "მოაგროვეთ დიაგნოსტიკური და მხარდაჭერის მონაცემები"
 ],
 "Collect kernel crash dumps": [
  null,
  "ოპერაციული სისტემის ბირთვის ავარიის დამპები"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "შესაძლო მნიშვნელობებია მძიმით გამოყოფილი პორტები, დიაპაზონები და სერვისები"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Configuring": [
  null,
  "მორგება"
 ],
 "Configuring IP": [
  null,
  "IP-ის მორგება"
 ],
 "Confirm removal of $0": [
  null,
  "დაადასტურეთ $0-ის წაშლა"
 ],
 "Connect automatically": [
  null,
  "ავტომატურად დაკავშირება"
 ],
 "Connection has timed out.": [
  null,
  "კავშირის დრო გავიდა."
 ],
 "Connection will be lost": [
  null,
  "კავშირი დაიკარგება"
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Copy to clipboard": [
  null,
  "ბაფერში კოპირება"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Create it": [
  null,
  "შექმნა"
 ],
 "Create new task file with this content.": [
  null,
  "ახალი ამოცანის ამ შემცველობით შექმნა."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის შექმნა გაწყვეტს სერვერთან კავშირს. ადმინისტრირების ინტერფეისი მიუწვდომელი გახდება."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "ხელით მითითებული პორტები"
 ],
 "Custom zones": [
  null,
  "ხელით მითითებული ზონები"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS-ში საძებნი დომენები"
 ],
 "DNS search domains $val": [
  null,
  "DNS-ში საძებნი დომენები $val"
 ],
 "Deactivating": [
  null,
  "დეაქტივაცია"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Delete $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის წაშლა შეწყვეტს კავშირს სერვერთან და ადმინისტრაციის ინტერფეისს მიუწვდომელს გახდის."
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Disable the firewall": [
  null,
  "ბრანდმაუერის გამორთვა"
 ],
 "Disabled": [
  null,
  "გათიშულია"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Edit VLAN settings": [
  null,
  "VLAN-ის პარამეტრების ჩასწორება"
 ],
 "Edit WireGuard VPN": [
  null,
  "WireGuard VPN-ის ჩასწორება"
 ],
 "Edit bond settings": [
  null,
  "Bond-ის პარამეტრების ჩასწორება"
 ],
 "Edit bridge settings": [
  null,
  "Bridge-ის პარამეტრების ჩასწორება"
 ],
 "Edit custom service in $0 zone": [
  null,
  "ხელით მითითებული სერვისის ჩასწორება ზონაში $0"
 ],
 "Edit rules and zones": [
  null,
  "წესებისა და ზონების ჩასწორება"
 ],
 "Edit service": [
  null,
  "სერვისის ჩასწორება"
 ],
 "Edit service $0": [
  null,
  "სერვისის ჩასწორება: $0"
 ],
 "Edit team settings": [
  null,
  "Team-ის პარამეტრების ჩასწორება"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Enable or disable the device": [
  null,
  "მოწყობილობის ჩართვა ან გამორთვა"
 ],
 "Enable service": [
  null,
  "სერვისის ჩართვა"
 ],
 "Enable the firewall": [
  null,
  "ბრანდმაუერის ჩართვა"
 ],
 "Enabled": [
  null,
  "ჩართულია"
 ],
 "Endpoint": [
  null,
  "ბოლოწერტილი"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "ბოლოწერტილები, რომლებიც იქცევიან, როგორც \"სერვერი\", ჰოსტი:პორტი სახით უნდა იყოს მითითებული, ან ცარიელი."
 ],
 "Enter a valid MAC address": [
  null,
  "შეიყვანეთ სწორი MAC მისამართი"
 ],
 "Entire subnet": [
  null,
  "მთელი ქვექსელი"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet-ის MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet-ის MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "მაგალითად: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "მაგალითად: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "გადასარევი პაროლი"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Failed": [
  null,
  "შეცდომით"
 ],
 "Failed to add port": [
  null,
  "პორტის დამატების შეცდომა"
 ],
 "Failed to add service": [
  null,
  "სერვისის დამატების შეცდომა"
 ],
 "Failed to add zone": [
  null,
  "ზონის დამატების შეცდომა"
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "Failed to edit service": [
  null,
  "სერვისის ჩასწორების შეცდომა"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld-ში $0-ის ჩართვის შეცდომა"
 ],
 "Failed to save settings": [
  null,
  "პარამეტრების შენახვის შეცდომა"
 ],
 "Filter services": [
  null,
  "სერვისების ფილტრი"
 ],
 "Firewall": [
  null,
  "ბრანდმაუერი"
 ],
 "Firewall is not available": [
  null,
  "ბრანდმაუერი ხელმიუწვდომელია"
 ],
 "Forward delay $forward_delay": [
  null,
  "გადაგზავნის დაყოვნება $forward_delay"
 ],
 "Gateway": [
  null,
  "რაუტერი"
 ],
 "General": [
  null,
  "საერთო"
 ],
 "Generated": [
  null,
  "გენერირებული"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "Group": [
  null,
  "ჯგუფი"
 ],
 "Hair pin mode": [
  null,
  "NAT Hairpin-ის რეჟიმი"
 ],
 "Hairpin mode": [
  null,
  "NAT hairpin რეჟიმი"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "Hello time $hello_time": [
  null,
  "მისალმების დრო $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "დადასტურების პაროლის დამალვა"
 ],
 "Hide password": [
  null,
  "პაროლის დამალვა"
 ],
 "Host key is incorrect": [
  null,
  "ჰოსტის გასაღები არასწორია"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP მისამართი"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP მისამართი რაუტინგის პრეფიქსით. ერთმანეთისგან გამოიყოფა მძიმით. მაგ: 192.0.2.0, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "IPv4 მისამართი"
 ],
 "IPv4 settings": [
  null,
  "IPv4-ის მორგება"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6-ის მორგება"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "თუ ცარიელია, ID დაგენერირდება შესაბამისი პორტის სერვისებისა და პორტის ნომრებისგან"
 ],
 "Ignore": [
  null,
  "იგნორი"
 ],
 "Inactive": [
  null,
  "არააქტიური"
 ],
 "Included services": [
  null,
  "მოყოლილი სერვისები"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "შემომავალი მოთხოვნები ნაგულისხმებად იბლოკება. გამავალი მოთხოვნები არ იბლოკება."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Interface": [
  null,
  "ცალი ინტერფეისი",
  "ინტერფეისი"
 ],
 "Interface members": [
  null,
  "ინტერფეისის წევრები"
 ],
 "Interfaces": [
  null,
  "ინტერფეისები"
 ],
 "Internal error": [
  null,
  "შიდა შეცდომა"
 ],
 "Invalid address $0": [
  null,
  "არასწორი მისამართი: $0"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid file permissions": [
  null,
  "ფაილის არასწორი წვდომები"
 ],
 "Invalid metric $0": [
  null,
  "არასწორი მეტრიკა $0"
 ],
 "Invalid port number": [
  null,
  "პორტის არასწორი ნომერი"
 ],
 "Invalid prefix $0": [
  null,
  "არასწორი პრეფიქსი $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "არასწორი პრეფიქსი ან ქსელის მასკა $0"
 ],
 "Invalid range": [
  null,
  "არასწორი დიაპაზონი"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Keep connection": [
  null,
  "კავშირის შენარჩუნება"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "LACP key": [
  null,
  "LACP გასაღები"
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Link down delay": [
  null,
  "კავშირის გათიშვის დაყოვნება"
 ],
 "Link local": [
  null,
  "ლოკალური ბმის მისამართი"
 ],
 "Link monitoring": [
  null,
  "კავშირის მონიტორინგი"
 ],
 "Link up delay": [
  null,
  "კავშირის აღდგენის დაყოვნება"
 ],
 "Link watch": [
  null,
  "კავშირის თვალყურმდევნი"
 ],
 "Listen port": [
  null,
  "პორტის მოსმენა"
 ],
 "Listen port must be a number": [
  null,
  "მოსასმენი პორტი რიცხვი უნდა იყოს"
 ],
 "Load balancing": [
  null,
  "დატვირთვის გადანაწილება"
 ],
 "Loading system modifications...": [
  null,
  "სისტემის ცვლილებების ჩატვირთვა..."
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "Login failed": [
  null,
  "შესვლა წარუმატებელია"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (რეკომენდებულია)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU დადებითი რიცხვი უნდა იყოს"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Manage storage": [
  null,
  "საცავის მართვა"
 ],
 "Managed interfaces": [
  null,
  "მართული ინტერფეისები"
 ],
 "Manual": [
  null,
  "ხელით მითითება"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Maximum message age $max_age": [
  null,
  "შეტყობინების მაქს. ვადა $max_age"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Metric": [
  null,
  "მეტრული"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Mode": [
  null,
  "რეჟიმი"
 ],
 "Monitoring interval": [
  null,
  "მონიტორინგის ინტერვალი"
 ],
 "Monitoring targets": [
  null,
  "სამიზნეების მონიტორინგი"
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "ერთზე მეტი მისამართის მითითება მძიმეებით ან გამოტოვებებით შეგიძლიათ."
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "Network bond": [
  null,
  "ქსელის ბარათების გაერთიანება"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "ქსელურ მოწყობილობებს და გრაფიკებს NetworkManager-ი ესაჭიროებათ"
 ],
 "Network logs": [
  null,
  "ქსელის ჟურნალი"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager დაყენებული არაა"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager გაშვებული არაა"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "No": [
  null,
  "არა"
 ],
 "No carrier": [
  null,
  "შეამოწმეთ კავშირი"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "No description available": [
  null,
  "აღწერა ხელმიუწვდომელია"
 ],
 "No peers added.": [
  null,
  "პარტნიორები დამატებული არაა."
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "No system modifications": [
  null,
  "სისტემა შეცვლილი არაა"
 ],
 "None": [
  null,
  "არცერთი"
 ],
 "Not a valid private key": [
  null,
  "არ წარმოადგენს სწორ პირად გასაღებს"
 ],
 "Not authorized to disable the firewall": [
  null,
  "ბრანდმაუერის გამოსართავად საჭიროა ავტორიზაცია"
 ],
 "Not authorized to enable the firewall": [
  null,
  "ბრანდმაუერის ჩასართავად საჭიროა ავტორიზაცია"
 ],
 "Not available": [
  null,
  "ხელმიუწვდომელია"
 ],
 "Not permitted to configure network devices": [
  null,
  "ქსელური მოწყობილობების მორგების უფლება არ გაქვთ"
 ],
 "Not permitted to perform this action.": [
  null,
  "არ გაქვთ მითითებული მოქმედების შესასრულებლად საკმარისი წვდომა."
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Occurrences": [
  null,
  "გამოვლენები"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "როცა Cockpit-ს დააყენებთ, შეგიძლიათ მისი ჩართვაც, ბრძანებით \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "პარამეტრები"
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "Parent": [
  null,
  "მშობელი"
 ],
 "Parent $parent": [
  null,
  "მშობელი $parent"
 ],
 "Part of $0": [
  null,
  "$0-ის ნაწილი"
 ],
 "Passive": [
  null,
  "პასიური"
 ],
 "Password is not acceptable": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Password is too weak": [
  null,
  "პაროლი ძალიან სუსტია"
 ],
 "Password not accepted": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Paste error": [
  null,
  "ჩასმის შეცდომა"
 ],
 "Paste existing key": [
  null,
  "არსებული გასაღების ჩასმა"
 ],
 "Path cost": [
  null,
  "ბილიკის ღირებულება"
 ],
 "Path cost $path_cost": [
  null,
  "ბილიკის ფასი $path_cost"
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "პარტნიორის #$0 ბოლოწერტილის პორტი არასწორია. პორტის ნომერი რიცხვი უნდა იყოს."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "პარტნიორის #$0 ბოლოწერტილი არასწორია. ის ჰოსტი:პორტი სახით უნდა იყოს მითითებული. მაგ: 1.3.4.5:41232 ან example.com:41223"
 ],
 "Peers": [
  null,
  "პარტნიორები"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "პარტნიორები სხვა მანქანებია, რომლებიც ამას უერთდებიან. საჯარო გასაღებები სხვა მანქანებიდან ასევე გაზიარებული იქნება."
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "Permanent": [
  null,
  "მუდმივი"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Ping interval": [
  null,
  "Ping-ის დაყოვნება"
 ],
 "Ping target": [
  null,
  "მიზნის დაპინგვა"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Please install the $0 package": [
  null,
  "დააყენეთ პაკეტი $0"
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "Ports": [
  null,
  "პორტები"
 ],
 "Prefix length": [
  null,
  "პრეფიქსის სიგრძე"
 ],
 "Prefix length or netmask": [
  null,
  "პრეფიქსის სიგრძე ან ნეტმასკა"
 ],
 "Preparing": [
  null,
  "მომზადება"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "Preserve": [
  null,
  "არ შეცვალო"
 ],
 "Primary": [
  null,
  "ძირითადი"
 ],
 "Priority": [
  null,
  "პრიორიტეტი"
 ],
 "Priority $priority": [
  null,
  "$priority პრიორიტეტი"
 ],
 "Private key": [
  null,
  "პირადი გასაღები"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "მოთხოვნას ssh-add-ის გავლით დრო გაუვიდა"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "მოთხოვნას ssh-keygen-ის გავლით დრო გაუვიდა"
 ],
 "Public key": [
  null,
  "საჯარო გასაღები"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "საჯარო გასაღები დაგენერირდება, როცა სწორ პირად გასაღებს შეიყვანთ"
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Random": [
  null,
  "შემთხვევითი"
 ],
 "Range": [
  null,
  "დიაპაზონი"
 ],
 "Range must be strictly ordered": [
  null,
  "დიაპაზონი მკაცრად უნდა იყოს განსაზღვრული"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Receiving": [
  null,
  "მიღება"
 ],
 "Regenerate": [
  null,
  "თავიდან გენერაცია"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Remove $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "$1 ზონიდან $0 სერვისის წაშლა"
 ],
 "Remove item": [
  null,
  "ელემენტის წაშლა"
 ],
 "Remove service $0": [
  null,
  "სერვისის წაშლა: $0"
 ],
 "Remove zone $0": [
  null,
  "ზონის წაშლა: $0"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის წაშლა გაწყვეტს კავშირს სერვერთან და შეუძლებელს გახდის ადმინისტრირების ინტერფეისთან წვდომას."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "cockpit-ის სერვისის წაშლამ შეიძლება ვებ კონსოლი მიუწვდომელი გახადოს. დარწმუნდით, რომ ზონის ცვლილება ვებ კონსოლთან კავშირს არ გაწყვეტს."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "ზონის წაშლა მასში მყოფი სერვისების წაშლასაც გამოიწევევს."
 ],
 "Restoring connection": [
  null,
  "კავშირის აღდგენა"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "მარშრუტები"
 ],
 "Row expansion": [
  null,
  "მწკრივის გაფართოება"
 ],
 "Row select": [
  null,
  "მწკრივის არჩევა"
 ],
 "Runner": [
  null,
  "გამშვები"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "STP forward delay": [
  null,
  "STP გადამისამართების დაყოვნება"
 ],
 "STP hello time": [
  null,
  "STP hello-ის დრო"
 ],
 "STP maximum message age": [
  null,
  "STP შეტყობინების მაქსიმალური ასაკი"
 ],
 "STP priority": [
  null,
  "STP პრიორიტეტი"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Search domain": [
  null,
  "ძებნის დომენი"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Linux-ის გაფართოებული უსაფრთხოების (SELinux) მორგება და გამართვა"
 ],
 "Select method": [
  null,
  "აირჩიეთ მეთოდი"
 ],
 "Sending": [
  null,
  "გაგზავნა"
 ],
 "Server": [
  null,
  "სერვერი"
 ],
 "Server has closed the connection.": [
  null,
  "სერვერმა დახურა კავშირი."
 ],
 "Service": [
  null,
  "სერვისი"
 ],
 "Services": [
  null,
  "სერვისები"
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Set to": [
  null,
  "გაგზავნის მიმღები"
 ],
 "Shared": [
  null,
  "ზიარი"
 ],
 "Shell script": [
  null,
  "გარსის სკრიპტი"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "დადასტურების პაროლის ჩვენება"
 ],
 "Show password": [
  null,
  "პაროლის ჩვენება"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Sorted from least to most trusted": [
  null,
  "დალაგებულია ყველაზე ნაკლებიდან ყველაზე მეტად სანდომდე"
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Stable": [
  null,
  "სტაბილური"
 ],
 "Start service": [
  null,
  "სერვისის გაშვება"
 ],
 "Status": [
  null,
  "მდგომარეობა"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sticky": [
  null,
  "წებოვანი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Strong password": [
  null,
  "ძლიერი პაროლი"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Switch of $0": [
  null,
  "$0-ის გამორთვა"
 ],
 "Switch off $0": [
  null,
  "$0-ის გამორთვა"
 ],
 "Switch on $0": [
  null,
  "$0-ის ჩართვა"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის გათიშვა დაარღვევს სერვერთან კავშირს და შეუძლებელს გახდის ადმინისტრირების ინტერფეისთან წვდომას."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის ჩართვა დაარღვევს სერვერთან კავშირს და შეუძლებელს გახდის ადმინისტრირების ინტერფეისთან წვდომას."
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "Team": [
  null,
  "გუნდი"
 ],
 "Team port": [
  null,
  "Team-ის პორტები"
 ],
 "Team port settings": [
  null,
  "გუნდური პორტის მორგება"
 ],
 "Testing connection": [
  null,
  "კავშირის შემოწმება"
 ],
 "The cockpit service is automatically included": [
  null,
  "Cocpit-ის სერვისი ავტომატურად მოჰყვება"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "შესულ მომხმარებელს არ აქვს სისტემური ცვლილებების ნახვს უფლება"
 ],
 "The passwords do not match.": [
  null,
  "პაროლები არ ემთხვევა."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "სერვერმა ყველა მხარდაჭერილი მეთოდით ავთენტიკაცია უარჰყო."
 ],
 "There are no active services in this zone": [
  null,
  "ამ ზონაში აქტიური სერვისები არ არსებობს"
 ],
 "This device cannot be managed here.": [
  null,
  "მოწყობილობა აქედან ვერ იმართება."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ეს პროგრამა როგორც SELinux-ის პოლიტიკის მორგებაში, ასევე მის ბოლომდე გაგებაში და პოლიტიკის დარღვევის გადაწყვეტაში დაგეხმარებათ."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "ეს პროგრამა სისტემას ბირთვის ავარიის შემთხვევაში დისკზე დამპის ჩაწერის მორგებაში დაგეხმარებათ."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ეს პროგრამა გაშვებული სისტემიდან კონფიგურაცისა და დიაგნოსტიკის მოგროვებაში დაგეხმარებათ. არქივი შეგიძლიათ ლოკალურად შეინახოთ, ან ცენტრალურად, ჩაწერისა და ტრეკინგის მიზნებისთვის, ან შეგიძლიათ გადააგზავნოთ მხარდაჭერის, პროგრამისტებისა და სისტემური ადმინისტრატორების ჯგუფებთან, რათა აპარატურული პრობლემები აღმოაჩინოთ და გადაჭრათ."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ეს პროგრამა ლოკალურ საცავს, როგორიცაა ფაილურ სისტემები, LVM2 ტომის ჯგუფები და NFS მიმაგრებები, მართავს."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ეს პროგრამა მართავს ქსელს. bond ინტერფეისების, ხიდების, ჯგუფური ინტერფეისების, VLAN-ების და ბრანდმაუერების მართვა NetworkManager-ისა და FIrewalld-ის საშუალებით. NetworkManager-ი Ubuntu-ის ნაგულისხმებ systemd-networkd და Debian-ის ifupdown სკრიპტებთან შეუთავსებელია."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "ზონა შეიცავს cockpit-ის სერვისს. დარწმუნდით, რომ ზონის ცვლილება ვებ კონსოლის თქვენს მიმდინარე სესიას არ ბლოკავს."
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Too much data": [
  null,
  "მეტისმეტად ბევრი მონაცემი"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Transmitting": [
  null,
  "გადაცემა"
 ],
 "Troubleshoot…": [
  null,
  "პრობლემების გადაწყვეტა…"
 ],
 "Trust level": [
  null,
  "ნდობის დონე"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "მოულოდნელი შეცდომა"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Unknown \"$0\"": [
  null,
  "უცნობი \"$0\""
 ],
 "Unknown configuration": [
  null,
  "უცნობი კონფიგურაცია"
 ],
 "Unknown service name": [
  null,
  "სერვისის უცნობი სახელი"
 ],
 "Unmanaged interfaces": [
  null,
  "უმართავი ინტერფეისები"
 ],
 "Untrusted host": [
  null,
  "არასანდო ჰოსტი"
 ],
 "Use": [
  null,
  "გამოყენება"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "View automation script": [
  null,
  "ავტომატიზაციის სკრიპტის ნახვა"
 ],
 "Visit firewall": [
  null,
  "ბრანდმაუერზე გადასვლა"
 ],
 "Waiting": [
  null,
  "მოლოდინი"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Weak password": [
  null,
  "სუსტი პაროლი"
 ],
 "Web Console for Linux servers": [
  null,
  "ვებ კონსოლი Linux სერვერებისთვის"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "დაყენებული იქნება \"ავტომატურზე\""
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "დიახ"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "ბრანდმაუერის ჩასწორების წვდომა აკრძალულია."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "თქვენს ბრაუზერს არ გააჩნია კონტექსტური მენიუდან ჩასმის მხარდაჭერა. სცადეთ დააჭიროთ Shift+Insert-ს."
 ],
 "Your session has been terminated.": [
  null,
  "თქვენი სესია გაწყვეტილია."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "სესიის ვადა გასულია. თავიდან შედით."
 ],
 "Zone": [
  null,
  "ზონა"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "in less than a minute": [
  null,
  "წუთზე ნაკლებში"
 ],
 "less than a minute ago": [
  null,
  "წუთზე ნაკლების წინ"
 ],
 "password quality": [
  null,
  "პაროლის ხარისხი"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "wireguard-tools package is not installed": [
  null,
  "პაკეტი wireguard-tools დაყენებული არაა"
 ]
});
