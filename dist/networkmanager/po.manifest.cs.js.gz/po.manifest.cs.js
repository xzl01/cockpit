cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Managing VLANs": [
  null,
  "Správa VLAN sítí"
 ],
 "Managing firewall": [
  null,
  "Správa brány firewall"
 ],
 "Managing networking bonds": [
  null,
  "Správa síťových spřažení (bond)"
 ],
 "Managing networking bridges": [
  null,
  "Správa síťových mostů"
 ],
 "Managing networking teams": [
  null,
  "Správa síťových spřažení (team)"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "bond": [
  null,
  "spřažení linek (bond)"
 ],
 "bridge": [
  null,
  "most"
 ],
 "firewall": [
  null,
  "brána firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "rozhraní"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac adresa"
 ],
 "network": [
  null,
  "síť"
 ],
 "port": [
  null,
  "port"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "spřažení linek (team)"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zóna"
 ]
});
