cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Managing VLANs": [
  null,
  "Gestion des réseaux locaux virtuels (VLAN)"
 ],
 "Managing firewall": [
  null,
  "Gestion du pare-feu"
 ],
 "Managing networking bonds": [
  null,
  "Gestion des liens de réseau"
 ],
 "Managing networking bridges": [
  null,
  "Gérer les ponts de mise en réseau"
 ],
 "Managing networking teams": [
  null,
  "Gestion du réseau"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "bond": [
  null,
  "bond"
 ],
 "bridge": [
  null,
  "pont"
 ],
 "firewall": [
  null,
  "pare-feu"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "Interface"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "réseau"
 ],
 "port": [
  null,
  "port"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "équipe"
 ],
 "udp": [
  null,
  "UDP"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zone"
 ]
});
