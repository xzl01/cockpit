cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 Zona Attiva",
  "$0 Zone Attive"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "$0 key changed": [
  null,
  "Chiave $0 modificata"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "$0 zone": [
  null,
  "Zona $0"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Una versione compatibile di Cockpit non è installata su $0."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Un bond di rete combina più interfacce di rete in un'unica interfaccia portata del canale o ridondanza più elevati."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Una nuova chiave SSH in $0 verrà creata per $1 su $2 e sarà aggiunta al file $3 di $4 su $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Monitoraggio ARP"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Active": [
  null,
  "Attivo"
 ],
 "Active backup": [
  null,
  "Backup attivo"
 ],
 "Adaptive load balancing": [
  null,
  "Bilanciamento del carico adattivo"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Bilanciamento del carico di trasmissione adattivo"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "Add VLAN": [
  null,
  "Aggiungi VLAN"
 ],
 "Add WireGuard VPN": [
  null,
  ""
 ],
 "Add a new zone": [
  null,
  "Aggiungi una nuova zona"
 ],
 "Add bond": [
  null,
  "Aggiungi bond"
 ],
 "Add bridge": [
  null,
  "Aggiungi bridge"
 ],
 "Add member": [
  null,
  "Aggiungi membro"
 ],
 "Add new zone": [
  null,
  "Aggiungi nuova zona"
 ],
 "Add ports": [
  null,
  "Aggiungi Porte"
 ],
 "Add ports to $0 zone": [
  null,
  "Aggiungi porte alla zona $0"
 ],
 "Add services": [
  null,
  "Aggiungi Servizi"
 ],
 "Add services to $0 zone": [
  null,
  "Aggiungi servizi alla zona $0"
 ],
 "Add services to zone $0": [
  null,
  "Aggiungi servizi alla zona $0"
 ],
 "Add team": [
  null,
  "Aggiungi team"
 ],
 "Add zone": [
  null,
  "Aggiungi zona"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L'aggiunta di $0 interromperà la connessione al server e renderà non disponibile l'interfaccia utente di amministrazione."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Aggiungere porte personalizzate ricaricherà firewalld. Un ricaricamento provocherà la perdita di qualsiasi configurazione non persistente!"
 ],
 "Additional DNS $val": [
  null,
  "DNS aggiuntivo $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Domini di ricerca DNS aggiuntivi $val"
 ],
 "Additional address $val": [
  null,
  "Indirizzo aggiuntivo $val"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Additional ports": [
  null,
  "Porte aggiuntive"
 ],
 "Address": [
  null,
  "Indirizzo"
 ],
 "Address $val": [
  null,
  "Indirizzo $val"
 ],
 "Addresses": [
  null,
  "Indirizzi"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Allowed addresses": [
  null,
  "Indirizzi consentiti"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Authenticating": [
  null,
  "Autenticazione"
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ],
 "Authorize SSH key": [
  null,
  "Autorizza chiave SSH"
 ],
 "Automatic": [
  null,
  "Automatico"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatico (solo DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "Balancer": [
  null,
  "Equilibratore"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Bridge": [
  null,
  "Ponte"
 ],
 "Bridge port": [
  null,
  "Porta del bridge"
 ],
 "Bridge port settings": [
  null,
  "Impostazioni della porta del bridge"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "Broken configuration": [
  null,
  "Configurazione errata"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "Carrier": [
  null,
  "Carrier"
 ],
 "Change": [
  null,
  "Cambia"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Change the settings": [
  null,
  "Modifica le impostazioni"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "La modifica delle chiavi sono di solito il risultato di una reinstallazione del sistema. Tuttavia, una modifica inaspettata può indicare un tentativo di intercettazione da parte di un soggetto terzo."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La modifica delle impostazioni interromperà la connessione al server e renderà l'interfaccia utente di amministrazione non disponibile."
 ],
 "Checking IP": [
  null,
  "Controllo dell'IP"
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit non è installato"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Sono accettate porte, intervalli e servizi separati da virgole"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Configuring": [
  null,
  "Configurazione"
 ],
 "Configuring IP": [
  null,
  "Configurazione dell'IP"
 ],
 "Confirm key password": [
  null,
  "Conferma la password chiave"
 ],
 "Confirm removal of $0": [
  null,
  "Conferma la rimozione di $0"
 ],
 "Connect automatically": [
  null,
  "Connessione automatica"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Connection will be lost": [
  null,
  "La connessione andrà persa"
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Copied": [
  null,
  "Copiato"
 ],
 "Copy": [
  null,
  "Copia"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crea una nuova chiave SSH e autorizzala"
 ],
 "Create it": [
  null,
  "Crea"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La creazione di questo $0 interromperà la connessione al server e renderà non disponibile l'interfaccia utente di amministrazione."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Porte personalizzate"
 ],
 "Custom zones": [
  null,
  "Zone personalizzate"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Domini di ricerca DNS"
 ],
 "DNS search domains $val": [
  null,
  "Domini di ricerca DNS $val"
 ],
 "Deactivating": [
  null,
  "Disattivazione"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Delete": [
  null,
  "Cancella"
 ],
 "Delete $0": [
  null,
  "Cancella $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L'eliminazione di $0 interromperà la connessione al server e renderà l'interfaccia utente di amministrazione non disponibile."
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Disable the firewall": [
  null,
  "Disabilita il firewall"
 ],
 "Disabled": [
  null,
  "Disabilitato"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Edit WireGuard VPN": [
  null,
  ""
 ],
 "Edit custom service in $0 zone": [
  null,
  "Modifica servizi personalizzati nella zona $0"
 ],
 "Edit rules and zones": [
  null,
  "Modifica regole e zone"
 ],
 "Edit service": [
  null,
  "Modifica servizio"
 ],
 "Edit service $0": [
  null,
  "Modifica servizio $0"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Enable or disable the device": [
  null,
  "Abilita o disabilita il dispositivo"
 ],
 "Enable service": [
  null,
  "Attiva il servizio"
 ],
 "Enable the firewall": [
  null,
  "Abilita il firewall"
 ],
 "Enabled": [
  null,
  "Attivato"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  ""
 ],
 "Enter a valid MAC address": [
  null,
  "Immettere un indirizzo MAC valido"
 ],
 "Entire subnet": [
  null,
  "Intera sottorete"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Esempio: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Esempio: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Failed": [
  null,
  "Fallito"
 ],
 "Failed to add port": [
  null,
  "Impossibile aggiungere la porta"
 ],
 "Failed to add service": [
  null,
  "Impossibile aggiungere il servizio"
 ],
 "Failed to add zone": [
  null,
  "Impossibile aggiungere la zona"
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "Failed to edit service": [
  null,
  "Impossibile modificare il servizio"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld"
 ],
 "Failed to save settings": [
  null,
  "Impossibile salvare le impostazioni"
 ],
 "Filter services": [
  null,
  "Filtra Servizi"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Firewall is not available": [
  null,
  "Il firewall non è disponibile"
 ],
 "Forward delay $forward_delay": [
  null,
  "Ritardo in avanti $forward_delay"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "General": [
  null,
  "Generale"
 ],
 "Generated": [
  null,
  "Generato"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "Group": [
  null,
  "Gruppo"
 ],
 "Hair pin mode": [
  null,
  "Modalità hairpin"
 ],
 "Hairpin mode": [
  null,
  "Modalità hairpin"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Hello time $hello_time": [
  null,
  "Ciao tempo $hello_time"
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "Indirizzo IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Indirizzo IP con prefisso di routing. Separare più valori con una virgola. Esempio: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "Impostazioni IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Impostazioni IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Se lasciato vuoto, l'ID verrà generato in base alla porta dei servizi associati e ai numeri di porta"
 ],
 "Ignore": [
  null,
  "Ignora"
 ],
 "Inactive": [
  null,
  "Inattiva"
 ],
 "Included services": [
  null,
  "Servizi inclusi"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Le richieste in ingresso sono bloccate per impostazione predefinita. Le richieste in uscita non sono bloccate."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Interface": [
  null,
  "Interfaccia",
  "Interfacce"
 ],
 "Interface members": [
  null,
  "Membri interfaccia"
 ],
 "Interfaces": [
  null,
  "Interfacce"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Invalid address $0": [
  null,
  "Indirizzo $0 non valido"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Invalid metric $0": [
  null,
  "Metrica $0 non valida"
 ],
 "Invalid port number": [
  null,
  "Numero porta non valido"
 ],
 "Invalid prefix $0": [
  null,
  "Prefisso $0 non valido"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Prefisso o maschera di rete non valido $0"
 ],
 "Invalid range": [
  null,
  "Intervallo non valido"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Keep connection": [
  null,
  "Mantenere la connessione"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Key password": [
  null,
  "Password della chiave"
 ],
 "LACP key": [
  null,
  "Chiave LACP"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "Link down delay": [
  null,
  "Ritardo caduta collegamento"
 ],
 "Link local": [
  null,
  "Collegamento locale"
 ],
 "Link monitoring": [
  null,
  "Monitoraggio dei collegamenti"
 ],
 "Link up delay": [
  null,
  "Ritardo ripristino collegamento"
 ],
 "Link watch": [
  null,
  "Link watch"
 ],
 "Load balancing": [
  null,
  "Bilanciamento del carico"
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "Log in": [
  null,
  "Accedi"
 ],
 "Log in to $0": [
  null,
  "Entra in $0"
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (consigliato)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU deve essere un numero positivo"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "Managed interfaces": [
  null,
  "Interfacce gestite"
 ],
 "Manual": [
  null,
  "Manuale"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Maximum message age $max_age": [
  null,
  "Età massima del messaggio $max_age"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Metric": [
  null,
  "Metriche"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mode": [
  null,
  "Modalità"
 ],
 "Monitoring interval": [
  null,
  "Intervallo di monitoraggio"
 ],
 "Monitoring targets": [
  null,
  "Obiettivi di monitoraggio"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  ""
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Network bond": [
  null,
  "Bond di Rete"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "I dispositivi di rete e i grafici richiedono NetworkManager"
 ],
 "Network logs": [
  null,
  "Log di rete"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager non è installato"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager non è in esecuzione"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "No": [
  null,
  "No"
 ],
 "No carrier": [
  null,
  "Nessun carrier"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "No description available": [
  null,
  "Nessuna descrizione disponibile"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "None": [
  null,
  "Nessuno"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Non autorizzato a disabilitare il firewall"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Non autorizzato ad abilitare il firewall"
 ],
 "Not available": [
  null,
  "Non disponibile"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Other": [
  null,
  "Altro"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "Parent": [
  null,
  "Genitore"
 ],
 "Parent $parent": [
  null,
  "Genitore $parent"
 ],
 "Part of $0": [
  null,
  "Parte di $0"
 ],
 "Passive": [
  null,
  "Passivo"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Path cost": [
  null,
  "Costo percorso"
 ],
 "Path cost $path_cost": [
  null,
  "Costo della traiettoria $path_cost"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  ""
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  ""
 ],
 "Peers": [
  null,
  ""
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "Permanent": [
  null,
  "Permanente"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Ping interval": [
  null,
  "Intervallo ping"
 ],
 "Ping target": [
  null,
  "Target ping"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please install the $0 package": [
  null,
  "Installare il pacchetto $0"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Ports": [
  null,
  "Porte"
 ],
 "Prefix length": [
  null,
  "Lunghezza prefisso"
 ],
 "Prefix length or netmask": [
  null,
  "Lunghezza prefisso o maschera di rete"
 ],
 "Preparing": [
  null,
  "Preparazione"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Preserve": [
  null,
  "Preserva"
 ],
 "Primary": [
  null,
  "Primario"
 ],
 "Priority": [
  null,
  "Priorità"
 ],
 "Priority $priority": [
  null,
  "Priorità $priority"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "Public key": [
  null,
  "Chiave pubblica"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Random": [
  null,
  "Casuale"
 ],
 "Range": [
  null,
  "Intervallo"
 ],
 "Range must be strictly ordered": [
  null,
  "L'intervallo deve essere rigorosamente ordinato"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Receiving": [
  null,
  "Ricevo"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Remove $0": [
  null,
  "Rimuovere $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Rimuovere il servizio $0 dalla zona $1"
 ],
 "Remove item": [
  null,
  "Rimuovere l'oggetto"
 ],
 "Remove service $0": [
  null,
  "Rimuovere il servizio $0"
 ],
 "Remove zone $0": [
  null,
  "Rimuovere la zona $0"
 ],
 "Removing $0": [
  null,
  "Rimozione $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La rimozione di $0 interromperà la connessione al server e renderà l'interfaccia utente di amministrazione non disponibile."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "La rimozione del servizio cockpit potrebbe rendere irraggiungibile la Web Console. Assicurarsi che questa zona non si applichi alla corrente connessione alla Web Console."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "La rimozione della zona rimuoverà tutti i servizi al suo interno."
 ],
 "Restoring connection": [
  null,
  "Ripristino della connessione"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Rotte"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Runner": [
  null,
  "Esecutore"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Chiave SSH"
 ],
 "STP forward delay": [
  null,
  "Ritardo in avanti STP"
 ],
 "STP hello time": [
  null,
  "Ciao tempo STP"
 ],
 "STP maximum message age": [
  null,
  "Età massima del messaggio STP"
 ],
 "STP priority": [
  null,
  "Priorità STP"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Search domain": [
  null,
  "dominio di ricerca"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "Select method": [
  null,
  "Seleziona metodo"
 ],
 "Sending": [
  null,
  "Invio"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Service": [
  null,
  "Servizio"
 ],
 "Services": [
  null,
  "Servizi"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Set to": [
  null,
  "Imposta a"
 ],
 "Shared": [
  null,
  "Condivisa"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shut down": [
  null,
  "Arresto"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Sorted from least to most trusted": [
  null,
  "Ordinati dal meno affidabile al più affidabile"
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Spanning tree protocol": [
  null,
  "Protocollo spanning tree"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protocollo dello spanning tree (STP)"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Stable": [
  null,
  "Stabile"
 ],
 "Start service": [
  null,
  "Avvia il servizio"
 ],
 "Status": [
  null,
  "Stato"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sticky": [
  null,
  "Sticky"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Switch off $0": [
  null,
  "Spegni $0"
 ],
 "Switch on $0": [
  null,
  "Accendi $0"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Team": [
  null,
  "Team"
 ],
 "Team port": [
  null,
  "Porta team"
 ],
 "Team port settings": [
  null,
  "Impostazioni della porta del team"
 ],
 "Testing connection": [
  null,
  "Test connessione"
 ],
 "The cockpit service is automatically included": [
  null,
  "Il servizio cockpit è incluso automaticamente"
 ],
 "The key password can not be empty": [
  null,
  "La password della chiave non può essere vuota"
 ],
 "The key passwords do not match": [
  null,
  "Le password della chiave non corrispondono"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L'impronta digitale risultante è idonea per la condivisione pubblica, email inclusa."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "There are no active services in this zone": [
  null,
  "Non ci sono servizi attivi in questa zona"
 ],
 "This device cannot be managed here.": [
  null,
  "Questo dispositivo non può essere gestito qui."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Questa zona contiene il servizio cockpit. Assicurarsi che questa zona non si applichi all'attuale connessione della Web Console."
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Per assicurare che la connessione non sia intercettata da un soggetto terzo malelvolo, verifica l'impronta digitale dell'host:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Per verificare un'impronta digitale, esegui su $0 mentre sei fisicamente di fronte alla macchina o attraverso una rete fidata:"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust level": [
  null,
  "Livello di fedeltà"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "Errore imprevisto"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Unknown \"$0\"": [
  null,
  "Sconosciuto \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Configurazione sconosciuta"
 ],
 "Unknown service name": [
  null,
  "Nome del servizio sconosciuto"
 ],
 "Unmanaged interfaces": [
  null,
  "Interfacce non gestite"
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "Waiting": [
  null,
  "In attesa"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "Will be set to \"Automatic\"": [
  null,
  ""
 ],
 "WireGuard": [
  null,
  ""
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Sì"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Collegamento a $0 per la prima volta"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Non sei autorizzato a modificare il firewall."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ]
});
