cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Managing VLANs": [
  null,
  "管理 VLAN"
 ],
 "Managing firewall": [
  null,
  "管理防火墙"
 ],
 "Managing networking bonds": [
  null,
  "管理网络绑定"
 ],
 "Managing networking bridges": [
  null,
  "管理网络桥接"
 ],
 "Managing networking teams": [
  null,
  "管理网络团队"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "服务"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "bond": [
  null,
  "绑定"
 ],
 "bridge": [
  null,
  "网桥"
 ],
 "firewall": [
  null,
  "防火墙"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "接口"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "网络"
 ],
 "port": [
  null,
  "端口"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "组"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "区"
 ]
});
