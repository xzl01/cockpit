cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 dag",
  "$0 dager"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avsluttet med koden $1"
 ],
 "$0 failed": [
  null,
  "$0 feilet"
 ],
 "$0 hour": [
  null,
  "$0 time",
  "$0 timer"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 er ikke tilgjengelig fra noe depot."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 drept med signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minutt",
  "$0 minutter"
 ],
 "$0 month": [
  null,
  "$0 måned",
  "$0 måneder"
 ],
 "$0 week": [
  null,
  "$0 uke",
  "$0 uker"
 ],
 "$0 will be installed.": [
  null,
  "$0 vil bli installert."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$0 zone": [
  null,
  "$0 sone"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 time"
 ],
 "1 minute": [
  null,
  "1 minutt"
 ],
 "1 week": [
  null,
  "1 uke"
 ],
 "20 minutes": [
  null,
  "20 minutter"
 ],
 "40 minutes": [
  null,
  "40 minutter"
 ],
 "5 minutes": [
  null,
  "5 minutter"
 ],
 "6 hours": [
  null,
  "6 timer"
 ],
 "60 minutes": [
  null,
  "60 minutter"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "En nettverksbinding kombinerer flere nettverksgrensesnitt til ett logisk grensesnitt med høyere gjennomstrømning eller redundans."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP overvåking"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "Fraværende"
 ],
 "Active": [
  null,
  "Aktiv"
 ],
 "Active backup": [
  null,
  ""
 ],
 "Adaptive load balancing": [
  null,
  "Adaptiv lastbalansering"
 ],
 "Adaptive transmit load balancing": [
  null,
  ""
 ],
 "Add": [
  null,
  "Legg til"
 ],
 "Add $0": [
  null,
  "Legg til $0"
 ],
 "Add VLAN": [
  null,
  "Legg til VLAN"
 ],
 "Add WireGuard VPN": [
  null,
  ""
 ],
 "Add a new zone": [
  null,
  "Legg til en ny sone"
 ],
 "Add bond": [
  null,
  "Legg til binding"
 ],
 "Add bridge": [
  null,
  "Legg til bridge"
 ],
 "Add member": [
  null,
  "Legg til medlem"
 ],
 "Add ports": [
  null,
  "Legg til porter"
 ],
 "Add ports to $0 zone": [
  null,
  "Legg til porter i $0 sonen"
 ],
 "Add services": [
  null,
  "Legg til tjenester"
 ],
 "Add services to $0 zone": [
  null,
  "Legg til tjenester i $0-sonen"
 ],
 "Add services to zone $0": [
  null,
  "Legg til tjenester i sone $0"
 ],
 "Add team": [
  null,
  "Legg til team"
 ],
 "Add zone": [
  null,
  "Legg til sone"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Hvis du legger til egendefinerte porter, lastes firewalld på nytt. En omlasting vil resultere i tap av en hvilken som helst kjøretidskonfigurasjon!"
 ],
 "Additional DNS $val": [
  null,
  "Ekstra DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Ekstra DNS-søkedomener $val"
 ],
 "Additional address $val": [
  null,
  "Ekstra adresse $val"
 ],
 "Additional packages:": [
  null,
  "Ekstra pakker:"
 ],
 "Additional ports": [
  null,
  "Ekstra porter"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address $val": [
  null,
  "Adresse $val"
 ],
 "Addresses": [
  null,
  "Adresser"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrasjon med Cockpit Web konsoll"
 ],
 "Advanced TCA": [
  null,
  "Avansert TCA"
 ],
 "All-in-one": [
  null,
  "Alt i ett"
 ],
 "Allowed addresses": [
  null,
  "Tillatte adresser"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible roller dokumentasjon"
 ],
 "Authenticating": [
  null,
  "Autentiserer"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering er nødvendig for å utføre privilegerte oppgaver med Cockpit Web konsoll"
 ],
 "Automatic": [
  null,
  "Automatisk"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatisk (kun DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Automatisk med bruk av NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisk med bruk av spesifikke NTP servere"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Balancer": [
  null,
  ""
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Blad-kabinett"
 ],
 "Bond": [
  null,
  "Binding"
 ],
 "Bridge": [
  null,
  "Bro"
 ],
 "Bridge port": [
  null,
  "Bro port"
 ],
 "Bridge port settings": [
  null,
  "Bro port innstillinger"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "Broken configuration": [
  null,
  "Ødelagt konfigurasjon"
 ],
 "Bus expansion chassis": [
  null,
  ""
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan ikke videresende påloggingsinformasjonen"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan ikke tidsplanlegge hendelse i fortiden"
 ],
 "Carrier": [
  null,
  "Transportør"
 ],
 "Change": [
  null,
  "Endre"
 ],
 "Change system time": [
  null,
  "Endre systemtid"
 ],
 "Change the settings": [
  null,
  "Endre innstillingene"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Endring av innstillingene vil bryte forbindelsen til serveren, og gjøre administrasjonsgrensesnittet utilgjengelig."
 ],
 "Checking IP": [
  null,
  "Sjekker IP"
 ],
 "Checking installed software": [
  null,
  "Kontrollerer installert programvare"
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  ""
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunne ikke kontakte den angitte verten."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit er en serveradministrator som gjør det enkelt å administrere Linux-serverne dine via en nettleser. Å bytte mellom terminalen og nettverktøyet er ikke noe problem. En tjeneste startet via Cockpit kan stoppes via terminalen. På samme måte, hvis det oppstår en feil i terminalen, kan den sees i Cockpit journal-grensesnittet."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit er ikke kompatibel med programvaren på systemet."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit er ikke installert på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit er perfekt for nye sysadminer, slik at de enkelt kan utføre enkle oppgaver som lagringsadministrasjon, inspisere journaler og starte og stoppe tjenester. Du kan overvåke og administrere flere servere samtidig. Bare legg dem til med et enkelt klikk, så vil maskinene dine se etter kompisene."
 ],
 "Collect and package diagnostic and support data": [
  null,
  ""
 ],
 "Compact PCI": [
  null,
  ""
 ],
 "Configuring": [
  null,
  "Konfigurerer"
 ],
 "Configuring IP": [
  null,
  "Konfigurerer IP"
 ],
 "Confirm removal of $0": [
  null,
  "Bekreft fjerning av $0"
 ],
 "Connect automatically": [
  null,
  "Koble til automatisk"
 ],
 "Connection has timed out.": [
  null,
  "Tidsavbrudd for tilkoblingen."
 ],
 "Connection will be lost": [
  null,
  "Tilkoblingen går tapt"
 ],
 "Convertible": [
  null,
  "Konverterbar"
 ],
 "Copy": [
  null,
  "Kopier"
 ],
 "Copy to clipboard": [
  null,
  "Kopier til utklippstavle"
 ],
 "Create": [
  null,
  "Opprett"
 ],
 "Create it": [
  null,
  "Opprett den"
 ],
 "Create new task file with this content.": [
  null,
  "Opprett ny oppgavefil med dette innholdet."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Egendefinerte porter"
 ],
 "Custom zones": [
  null,
  "Egendefinerte soner"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS-søkedomener"
 ],
 "DNS search domains $val": [
  null,
  "DNS-søkedomener $val"
 ],
 "Deactivating": [
  null,
  "Deaktiverer"
 ],
 "Delay": [
  null,
  "Forsinkelse"
 ],
 "Delete": [
  null,
  "Slett"
 ],
 "Delete $0": [
  null,
  "Slett $0"
 ],
 "Description": [
  null,
  "Beskrivelse"
 ],
 "Desktop": [
  null,
  ""
 ],
 "Detachable": [
  null,
  ""
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Disable the firewall": [
  null,
  "Deaktiver brannmuren"
 ],
 "Disabled": [
  null,
  "Deaktivert"
 ],
 "Docking station": [
  null,
  "Dokkingstasjon"
 ],
 "Downloading $0": [
  null,
  "Laster ned $0"
 ],
 "Dual rank": [
  null,
  "Dobbel rangering"
 ],
 "Edit": [
  null,
  "Rediger"
 ],
 "Edit WireGuard VPN": [
  null,
  ""
 ],
 "Edit rules and zones": [
  null,
  "Rediger regler og soner"
 ],
 "Embedded PC": [
  null,
  "Innebygd PC"
 ],
 "Enable or disable the device": [
  null,
  "Aktiver eller deaktiver enheten"
 ],
 "Enable service": [
  null,
  "Aktiver tjeneste"
 ],
 "Enable the firewall": [
  null,
  "Aktiver brannmuren"
 ],
 "Enabled": [
  null,
  "Aktivert"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  ""
 ],
 "Entire subnet": [
  null,
  "Hele subnettet"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Eksempel: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Eksempel: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Utmerket passord"
 ],
 "Expansion chassis": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Feilet"
 ],
 "Failed to add port": [
  null,
  "Kunne ikke legge til port"
 ],
 "Failed to add service": [
  null,
  "Kunne ikke legge til tjeneste"
 ],
 "Failed to add zone": [
  null,
  "Kunne ikke legge til sone"
 ],
 "Failed to change password": [
  null,
  "Kunne ikke endre passord"
 ],
 "Filter services": [
  null,
  "Filtrer tjenester"
 ],
 "Firewall": [
  null,
  "Brannmur"
 ],
 "Firewall is not available": [
  null,
  "Brannmur er ikke tilgjengelig"
 ],
 "Forward delay $forward_delay": [
  null,
  ""
 ],
 "General": [
  null,
  "Generelt"
 ],
 "Go to now": [
  null,
  "Gå til nå"
 ],
 "Group": [
  null,
  "Gruppe"
 ],
 "Hair pin mode": [
  null,
  ""
 ],
 "Hairpin mode": [
  null,
  ""
 ],
 "Handheld": [
  null,
  "Håndholdt"
 ],
 "Hello time $hello_time": [
  null,
  ""
 ],
 "Host key is incorrect": [
  null,
  "Vertsnøkkelen er feil"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP adresse"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-adresse med ruteprefiks. Separer flere verdier med komma. Eksempel: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "IPv4-innstillinger"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6-innstillinger"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  ""
 ],
 "Ignore": [
  null,
  "Ignorer"
 ],
 "Inactive": [
  null,
  "Inaktiv"
 ],
 "Included services": [
  null,
  "Inkluderte tjenester"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  ""
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install software": [
  null,
  "Installer programvare"
 ],
 "Installing $0": [
  null,
  "Installerer $0"
 ],
 "Interface members": [
  null,
  "Grensesnittmedlemmer"
 ],
 "Interfaces": [
  null,
  "Grensesnitt"
 ],
 "Internal error": [
  null,
  "Intern feil"
 ],
 "Invalid address $0": [
  null,
  "Ugyldig adresse $0"
 ],
 "Invalid date format": [
  null,
  "Ugyldig datoformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ugyldig datoformat og ugyldig tidsformat"
 ],
 "Invalid file permissions": [
  null,
  "Ugyldige filtillatelser"
 ],
 "Invalid metric $0": [
  null,
  "Ugyldig metrikk $0"
 ],
 "Invalid port number": [
  null,
  "Ugyldig portnummer"
 ],
 "Invalid prefix $0": [
  null,
  "Ugyldig prefiks $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Ugyldig prefiks eller nettmaske $0"
 ],
 "Invalid range": [
  null,
  "Ugyldig område"
 ],
 "Invalid time format": [
  null,
  "Ugyldig tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Ugyldig tidssone"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Keep connection": [
  null,
  "Hold forbindelsen"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "LACP key": [
  null,
  "LACP-nøkkel"
 ],
 "Laptop": [
  null,
  ""
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "Link down delay": [
  null,
  ""
 ],
 "Link local": [
  null,
  ""
 ],
 "Link monitoring": [
  null,
  "Linkovervåking"
 ],
 "Link up delay": [
  null,
  ""
 ],
 "Link watch": [
  null,
  ""
 ],
 "Load balancing": [
  null,
  "Lastbalansering"
 ],
 "Loading system modifications...": [
  null,
  "Laster inn systemendringer ..."
 ],
 "Log messages": [
  null,
  "Logg meldinger"
 ],
 "Login failed": [
  null,
  "Innlogging feilet"
 ],
 "Low profile desktop": [
  null,
  ""
 ],
 "Lunch box": [
  null,
  "Lunsjboks"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (anbefalt)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU må være et positivt tall"
 ],
 "Main server chassis": [
  null,
  ""
 ],
 "Managed interfaces": [
  null,
  "Administrerte grensesnitt"
 ],
 "Manual": [
  null,
  "Manuell"
 ],
 "Manually": [
  null,
  "Manuelt"
 ],
 "Maximum message age $max_age": [
  null,
  "Maksimal meldingsalder $ max_age"
 ],
 "Message to logged in users": [
  null,
  "Melding til innloggede brukere"
 ],
 "Metric": [
  null,
  ""
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  ""
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Monitoring interval": [
  null,
  "Overvåkingsintervall"
 ],
 "Monitoring targets": [
  null,
  "Overvåker mål"
 ],
 "Multi-system chassis": [
  null,
  ""
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  ""
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "NTP Server"
 ],
 "Name": [
  null,
  "Navn"
 ],
 "Need at least one NTP server": [
  null,
  "Trenger minst en NTP-server"
 ],
 "Network bond": [
  null,
  ""
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Nettverksenheter og grafer krever NetworkManager"
 ],
 "Network logs": [
  null,
  "Nettverkslogger"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager er ikke installert"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager kjører ikke"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "New password was not accepted": [
  null,
  "Nytt passord ble ikke godtatt"
 ],
 "No": [
  null,
  "Nei"
 ],
 "No carrier": [
  null,
  "Ingen transportør"
 ],
 "No delay": [
  null,
  "Ingen forsinkelse"
 ],
 "No description available": [
  null,
  "Ingen beskrivelse tilgjengelig"
 ],
 "No such file or directory": [
  null,
  "Ingen slik fil eller katalog"
 ],
 "No system modifications": [
  null,
  "Ingen systemendringer"
 ],
 "None": [
  null,
  "Ingen"
 ],
 "Not a valid private key": [
  null,
  "Ikke en gyldig privat nøkkel"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Ikke autorisert til å deaktivere brannmuren"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Ikke autorisert til å aktivere brannmuren"
 ],
 "Not available": [
  null,
  "Ikke tilgjengelig"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ikke tillatt å utføre denne handlingen."
 ],
 "Not synchronized": [
  null,
  "Ikke synkronisert"
 ],
 "Notebook": [
  null,
  ""
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Gammelt passord aksepteres ikke"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Når Cockpit er installert, kan den aktiveres med \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Alternativer"
 ],
 "Other": [
  null,
  "Annen"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit krasjet"
 ],
 "Parent": [
  null,
  ""
 ],
 "Parent $parent": [
  null,
  ""
 ],
 "Passive": [
  null,
  "Passiv"
 ],
 "Password is not acceptable": [
  null,
  "Passord er ikke akseptabelt"
 ],
 "Password is too weak": [
  null,
  "Passordet er for svakt"
 ],
 "Password not accepted": [
  null,
  "Passord ikke akseptert"
 ],
 "Paste": [
  null,
  "Lim inn"
 ],
 "Path cost": [
  null,
  "Sti kostnad"
 ],
 "Path cost $path_cost": [
  null,
  "Sti kostnad $path_cost"
 ],
 "Path to file": [
  null,
  "Sti til fil"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  ""
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  ""
 ],
 "Peers": [
  null,
  ""
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  "Perifert chassis"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Pick date": [
  null,
  "Velg dato"
 ],
 "Ping interval": [
  null,
  "Ping-intervall"
 ],
 "Ping target": [
  null,
  "Ping mål"
 ],
 "Pizza box": [
  null,
  "Pizzaboks"
 ],
 "Please install the $0 package": [
  null,
  "Vennligst installer $0-pakken"
 ],
 "Portable": [
  null,
  "Bærbar"
 ],
 "Ports": [
  null,
  "Porter"
 ],
 "Prefix length": [
  null,
  "Prefikslengde"
 ],
 "Prefix length or netmask": [
  null,
  "Prefikslengde eller nettmaske"
 ],
 "Preparing": [
  null,
  "Forbereder"
 ],
 "Present": [
  null,
  "Til stede"
 ],
 "Primary": [
  null,
  "Primær"
 ],
 "Priority": [
  null,
  "Prioritet"
 ],
 "Priority $priority": [
  null,
  "Prioritet $priority"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Spørring via ssh-add ble tidsavbrutt"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Spørring via ssh-keygen ble tidsavbrutt"
 ],
 "Public key": [
  null,
  "Offentlig nøkkel"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "RAID chassis"
 ],
 "Rack mount chassis": [
  null,
  ""
 ],
 "Random": [
  null,
  "Tilfeldig"
 ],
 "Range": [
  null,
  ""
 ],
 "Range must be strictly ordered": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Omstart"
 ],
 "Receiving": [
  null,
  "Mottar"
 ],
 "Removals:": [
  null,
  ""
 ],
 "Remove $0": [
  null,
  "Fjern $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Fjern $0-tjenesten fra $1-sonen"
 ],
 "Remove service $0": [
  null,
  "Fjern tjenesten $0"
 ],
 "Remove zone $0": [
  null,
  "Fjern sone $0"
 ],
 "Removing $0": [
  null,
  "Fjerner $0"
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Fjerning av cockpit-tjenesten kan føre til at web konsollet blir utilgjengelig. Forsikre deg om at denne sonen ikke gjelder for din nåværende web konsoll forbindelse."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Hvis du fjerner sonen, fjernes alle tjenester i den."
 ],
 "Restoring connection": [
  null,
  "Gjenoppretter tilkoblingen"
 ],
 "Round robin": [
  null,
  ""
 ],
 "Routes": [
  null,
  "Ruter"
 ],
 "Runner": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "STP forward delay": [
  null,
  ""
 ],
 "STP hello time": [
  null,
  ""
 ],
 "STP maximum message age": [
  null,
  "STP maksimal meldingsalder"
 ],
 "STP priority": [
  null,
  "STP-prioritet"
 ],
 "Save": [
  null,
  "Lagre"
 ],
 "Sealed-case PC": [
  null,
  ""
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Sending": [
  null,
  "Sender"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server has closed the connection.": [
  null,
  "Serveren har lukket forbindelsen."
 ],
 "Service": [
  null,
  "Tjeneste"
 ],
 "Services": [
  null,
  "Tjenester"
 ],
 "Set time": [
  null,
  "Sett tid"
 ],
 "Set to": [
  null,
  "Satt til"
 ],
 "Shared": [
  null,
  "Delt"
 ],
 "Shell script": [
  null,
  "Shell-skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shut down": [
  null,
  "Slå av"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Sorted from least to most trusted": [
  null,
  "Sortert fra minst til mest betrodd"
 ],
 "Space-saving computer": [
  null,
  "Plassbesparende datamaskin"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protokoll"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protokoll (STP)"
 ],
 "Specific time": [
  null,
  "Spesifikk tid"
 ],
 "Stable": [
  null,
  "Stabil"
 ],
 "Start service": [
  null,
  "Start tjenesten"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  ""
 ],
 "Sticky": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Sub-Chassis": [
  null,
  ""
 ],
 "Sub-Notebook": [
  null,
  ""
 ],
 "Switch of $0": [
  null,
  "Slå av $0"
 ],
 "Switch off $0": [
  null,
  "Slå av $0"
 ],
 "Switch on $0": [
  null,
  "Slå på $0"
 ],
 "Synchronized": [
  null,
  "Synkronisert"
 ],
 "Synchronized with $0": [
  null,
  "Synkronisert med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserer"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Nettbrett"
 ],
 "Team": [
  null,
  "Team"
 ],
 "Team port": [
  null,
  "Team port"
 ],
 "Team port settings": [
  null,
  "Team Port innstillinger"
 ],
 "Testing connection": [
  null,
  "Tester tilkobling"
 ],
 "The cockpit service is automatically included": [
  null,
  "Cockpit tjenesten er automatisk inkludert"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den påloggede brukeren har ikke lov til å se systemendringer"
 ],
 "The passwords do not match.": [
  null,
  "Passordene samsvarer ikke."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serveren nektet å godkjenne ved hjelp av de støttede metodene."
 ],
 "There are no active services in this zone": [
  null,
  "Det er ingen aktive tjenester i denne sonen"
 ],
 "This device cannot be managed here.": [
  null,
  "Denne enheten kan ikke administreres her."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  ""
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  ""
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  ""
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  ""
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Denne sonen inneholder cockpit-tjenesten. Forsikre deg om at denne sonen ikke gjelder for din nåværende web konsoll forbindelse."
 ],
 "Time zone": [
  null,
  "Tidssone"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "For mye data"
 ],
 "Total size: $0": [
  null,
  "Total størrelse: $0"
 ],
 "Tower": [
  null,
  ""
 ],
 "Troubleshoot…": [
  null,
  "Feilsøk…"
 ],
 "Trust level": [
  null,
  ""
 ],
 "Trying to synchronize with $0": [
  null,
  "Prøver å synkronisere med $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "Uventet feil"
 ],
 "Unknown": [
  null,
  "Ukjent"
 ],
 "Unknown \"$0\"": [
  null,
  "Ukjent \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Ukjent konfigurasjon"
 ],
 "Unknown service name": [
  null,
  "Ukjent tjenestenavn"
 ],
 "Unmanaged interfaces": [
  null,
  "Ikke-administrerte grensesnitt"
 ],
 "Untrusted host": [
  null,
  ""
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "View automation script": [
  null,
  "Vis automatiseringsskript"
 ],
 "Waiting": [
  null,
  "Venter"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Venter på at andre programvareadministrasjons-operasjoner skal fullføres"
 ],
 "Web Console for Linux servers": [
  null,
  "Web konsoll for Linux servere"
 ],
 "Will be set to \"Automatic\"": [
  null,
  ""
 ],
 "WireGuard": [
  null,
  ""
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Du er ikke autorisert til å endre brannmuren."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Økten din er avsluttet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Økten din har utløpt. Vennligst logg inn igjen."
 ],
 "Zone": [
  null,
  ""
 ],
 "[binary data]": [
  null,
  "[binære data]"
 ],
 "[no data]": [
  null,
  "[ingen data]"
 ],
 "edit": [
  null,
  "rediger"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "passordkvalitet"
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ]
});
