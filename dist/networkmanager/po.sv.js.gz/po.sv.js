cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "Aktiv zon $0",
  ""
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avslutade med kod $1"
 ],
 "$0 failed": [
  null,
  "$0 misslyckades"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dödad med signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$0 zone": [
  null,
  "zon $0"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "En bindning kombinerar flera nätverksportar till en logisk port med högre hastighet eller tillförlitlighet."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP-övervakning"
 ],
 "ARP ping": [
  null,
  "ARP-ping"
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Acceptable password": [
  null,
  "Acceptabelt lösenord"
 ],
 "Active": [
  null,
  "Aktivt"
 ],
 "Active backup": [
  null,
  "Aktiv reserv"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptiv lastbalansering"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptiv lastbalansering av sändning"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "Add DNS server": [
  null,
  "Lägg till DNS-server"
 ],
 "Add VLAN": [
  null,
  "Lägg till VLAN"
 ],
 "Add VPN": [
  null,
  "Lägg till VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Lägg till WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "Lägg till zon"
 ],
 "Add address": [
  null,
  "Lägg till adress"
 ],
 "Add bond": [
  null,
  "Lägg till bindning"
 ],
 "Add bridge": [
  null,
  "Lägg till brygga"
 ],
 "Add member": [
  null,
  "Lägg till medlem"
 ],
 "Add new zone": [
  null,
  "Lägg till zon"
 ],
 "Add peer": [
  null,
  "Lägg till jämnlike"
 ],
 "Add ports": [
  null,
  "Lägg till portar"
 ],
 "Add ports to $0 zone": [
  null,
  "Lägg till portar till zonen $0"
 ],
 "Add route": [
  null,
  "Lägg till rutt"
 ],
 "Add search domain": [
  null,
  "Lägg till sökdomän"
 ],
 "Add services": [
  null,
  "Lägg till tjänster"
 ],
 "Add services to $0 zone": [
  null,
  "Lägg till tjänster till zonen $0"
 ],
 "Add services to zone $0": [
  null,
  "Lägg till tjänster till zon $0"
 ],
 "Add team": [
  null,
  "Lägg till team"
 ],
 "Add zone": [
  null,
  "Lägg till zon"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att lägga till $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Att lägga till egna portar startar om firewalld . En omstart gör att osparade ändringar försvinner!"
 ],
 "Additional DNS $val": [
  null,
  "Ytterligare DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Ytterligare DNS-sökdomäner $val"
 ],
 "Additional address $val": [
  null,
  "Ytterligare adress $val"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Additional ports": [
  null,
  "Ytterligare portar"
 ],
 "Address": [
  null,
  "Adress"
 ],
 "Address $val": [
  null,
  "Adress $val"
 ],
 "Addresses": [
  null,
  "Adresser"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresser är inte korrekt formaterade"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration med Cockpits webbkonsol"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "Allowed IPs": [
  null,
  "Tillåtna IP-adresser"
 ],
 "Allowed addresses": [
  null,
  "Tillåtna adresser"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentation för Ansibleroller"
 ],
 "Authenticating": [
  null,
  "Autentiserar"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering krävs för att utföra privilegierade uppgifter med Cockpits webbkonsol"
 ],
 "Automatic": [
  null,
  "Automatisk"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatiskt (endast DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Använder automatiskt ytterligare NTP-servrar"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Balancer": [
  null,
  "Balanserare"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Bond": [
  null,
  "Binda"
 ],
 "Bridge": [
  null,
  "Brygga"
 ],
 "Bridge port": [
  null,
  "Bryggport"
 ],
 "Bridge port settings": [
  null,
  "Bryggportinställningar"
 ],
 "Broadcast": [
  null,
  "Utsändning"
 ],
 "Broken configuration": [
  null,
  "Trasig konfiguration"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inte vidarebefordra inloggningsuppgifterna"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "Carrier": [
  null,
  "Transport"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Change the settings": [
  null,
  "Ändra inställningarna"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att ändra inställningarna kommer bryta förbindelsen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Checking IP": [
  null,
  "Kontrollerar IP"
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit konfiguration av NetworkManager och Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunde inte kontakta den angivna värden."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit är en serverhanterare som gör det lätt att administrera dina Linuxservrar via en webbläsare. Att hoppa mellan terminalen och webbverktyget är inget problem. En tjänst som startas via Cockpit kan stoppas via terminalen. Likaledes, om ett fel uppstår i terminalen kan det ses i Cockpits journalgränssnitt."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit är inte kompatibelt med programvaran på systemet."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit är inte installerat på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit är perfekt för nya systemadministratörer, låter dem lätt utföra enkla uppgifter såsom lagringsadministration, inspektion av journaler och att starta och stoppa tjänster. Du kan övervaka och administrera flera servrar på samma gång. Lägg bara till dem med ett enda klick och dina maskiner kommer se efter sina kompisar."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Samla och paketera diagnostik och support data"
 ],
 "Collect kernel crash dumps": [
  null,
  "Samla kärnkraschdumpar"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Kommaseparerade portar, intervall och tjänster accepteras"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Configuring": [
  null,
  "Konfigurerar"
 ],
 "Configuring IP": [
  null,
  "Konfigurerar IP"
 ],
 "Confirm removal of $0": [
  null,
  "Bekräfta borttagning av $0"
 ],
 "Connect automatically": [
  null,
  "Anslut automatiskt"
 ],
 "Connection has timed out.": [
  null,
  "Anslutningens tidsgräns överskreds."
 ],
 "Connection will be lost": [
  null,
  "Anslutningen kommer gå förlorad"
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Create it": [
  null,
  "Skapa den"
 ],
 "Create new task file with this content.": [
  null,
  "Skapa en ny uppgiftsfil med detta innehåll."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att skapa detta $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Egna portar"
 ],
 "Custom zones": [
  null,
  "Egna zoner"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS-sökdomäner"
 ],
 "DNS search domains $val": [
  null,
  "DNS-sökdomäner $val"
 ],
 "Deactivating": [
  null,
  "Avaktiverar"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Delete $0": [
  null,
  "Ta bort $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att ta bort $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Disable the firewall": [
  null,
  "Stäng av brandväggen"
 ],
 "Disabled": [
  null,
  "Avaktiverad"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "Downloading $0": [
  null,
  "Hämtar $0"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Edit VLAN settings": [
  null,
  "Redigera VLAN-inställningar"
 ],
 "Edit WireGuard VPN": [
  null,
  "Redigera WireGuard VPN"
 ],
 "Edit bond settings": [
  null,
  "Redigera bondinställningar"
 ],
 "Edit bridge settings": [
  null,
  "Redigera brygginställningar"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Redigera anpassad tjänst i $0 zon"
 ],
 "Edit rules and zones": [
  null,
  "Redigera regler och zoner"
 ],
 "Edit service": [
  null,
  "Redigera tjänst"
 ],
 "Edit service $0": [
  null,
  "Redigera tjänst $0"
 ],
 "Edit team settings": [
  null,
  "Redigera Team-inställningar"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Enable or disable the device": [
  null,
  "Aktivera eller avaktivera denna enhet"
 ],
 "Enable service": [
  null,
  "Aktivera tjänst"
 ],
 "Enable the firewall": [
  null,
  "Slå på brandväggen"
 ],
 "Enabled": [
  null,
  "Aktiverad"
 ],
 "Endpoint": [
  null,
  "Ändpunkt"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Ändpunkt som fungerar som en \"server\" måste anges som värd:port, annars kan den lämnas tom."
 ],
 "Enter a valid MAC address": [
  null,
  "Ange en giltig MAC-adress"
 ],
 "Entire subnet": [
  null,
  "Hela subnätet"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet-MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet-MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Exempel: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Exempel: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Failed": [
  null,
  "Misslyckades"
 ],
 "Failed to add port": [
  null,
  "Kunde inte lägga till port"
 ],
 "Failed to add service": [
  null,
  "Kunde inte lägga till tjänst"
 ],
 "Failed to add zone": [
  null,
  "Kunde inte lägga till zon"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "Failed to edit service": [
  null,
  "Kunde inte redigera tjänst"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Failed to save settings": [
  null,
  "Misslyckades att spara inställningarna"
 ],
 "Filter services": [
  null,
  "Filtrera tjänster"
 ],
 "Firewall": [
  null,
  "Brandvägg"
 ],
 "Firewall is not available": [
  null,
  "Brandväggen är inte tillgänglig"
 ],
 "Forward delay $forward_delay": [
  null,
  "Fördröjning framåt $forward_delay"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "General": [
  null,
  "Allmänt"
 ],
 "Generated": [
  null,
  "Genererad"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "Group": [
  null,
  "Grupp"
 ],
 "Hair pin mode": [
  null,
  "Hårnålsläge"
 ],
 "Hairpin mode": [
  null,
  "Hårnålsläge"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "Hello time $hello_time": [
  null,
  "Hälsningstid $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Dölj bekräftelselösenord"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "Host key is incorrect": [
  null,
  "Värdnyckeln är felaktig"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP-adress"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-adress med prefix. Separera flera adresser med komma. Exempel: 192.0.2.0/24,2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "IPv4-adresser"
 ],
 "IPv4 settings": [
  null,
  "IPv4-inställningar"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6-inställningar"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Om det lämnas tomt kommer ett ID att genereras baserat på associerade porttjänster och portnummer"
 ],
 "Ignore": [
  null,
  "Ignorera"
 ],
 "Inactive": [
  null,
  "Inaktiv"
 ],
 "Included services": [
  null,
  "Inkluderade tjänster"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Inkommande förfrågningar blockeras som standard. Utgående förfrågningar blockeras inte."
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Interface": [
  null,
  "Gränssnitt",
  "Gränssnitt"
 ],
 "Interface members": [
  null,
  "Gränssnittsmedlemmar"
 ],
 "Interfaces": [
  null,
  "Gränssnitt"
 ],
 "Internal error": [
  null,
  "Internt fel"
 ],
 "Invalid address $0": [
  null,
  "Felaktig adress $0"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Invalid metric $0": [
  null,
  "Felaktigt mått $0"
 ],
 "Invalid port number": [
  null,
  "Felaktigt portnummer"
 ],
 "Invalid prefix $0": [
  null,
  "Felaktigt prefix $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Felaktigt prefix eller nätmask $0"
 ],
 "Invalid range": [
  null,
  "Felaktigt område"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Keep connection": [
  null,
  "Behåll förbindelsen"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "LACP key": [
  null,
  "LACP-nyckel"
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Link down delay": [
  null,
  "Fördröjning när länk nere"
 ],
 "Link local": [
  null,
  "Länklokal"
 ],
 "Link monitoring": [
  null,
  "Länkövervakning"
 ],
 "Link up delay": [
  null,
  "Fördröjning när länk uppe"
 ],
 "Link watch": [
  null,
  "Länkbetraktelse"
 ],
 "Listen port": [
  null,
  "Lyssna port"
 ],
 "Listen port must be a number": [
  null,
  "Lyssna port måste vara ett nummer"
 ],
 "Load balancing": [
  null,
  "Lastbalansering"
 ],
 "Loading system modifications...": [
  null,
  "Läser in anpassningar till systemet..."
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "Login failed": [
  null,
  "Inloggningen misslyckades"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (Rekommenderas)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU måste vara ett positivt tal"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Manage storage": [
  null,
  "Hantera lagring"
 ],
 "Managed interfaces": [
  null,
  "Hanterade gränssnitt"
 ],
 "Manual": [
  null,
  "Manuell"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximal meddelandeålder $max_age"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Metric": [
  null,
  "Mått"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Mode": [
  null,
  "Läge"
 ],
 "Monitoring interval": [
  null,
  "Övervakningsintervall"
 ],
 "Monitoring targets": [
  null,
  "Övervakningsmål"
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Flera adresser kan anges med kommatecken eller mellanslag som avgränsare."
 ],
 "NSNA ping": [
  null,
  "NSNA-ping"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "Network bond": [
  null,
  "Nätverksbindning"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Nätverksenheter och -grafer behöver NetworkManager"
 ],
 "Network logs": [
  null,
  "Nätverksloggar"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager är inte installerad"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager kör inte"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "No": [
  null,
  "Nej"
 ],
 "No carrier": [
  null,
  "Ingen bärvåg"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "No description available": [
  null,
  "Ingen beskrivning finns"
 ],
 "No peers added.": [
  null,
  "Inga jämlikar tillagda."
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "No system modifications": [
  null,
  "Inga systemändringar"
 ],
 "None": [
  null,
  "Inga"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Inte behörig att inaktivera brandväggen"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Inte behörig att aktivera brandväggen"
 ],
 "Not available": [
  null,
  "Inte tillgängligt"
 ],
 "Not permitted to configure network devices": [
  null,
  "Inte tillåtet att konfigurera nätverksenheter"
 ],
 "Not permitted to perform this action.": [
  null,
  "Inte tillåtet att utföra denna åtgärd."
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Occurrences": [
  null,
  "Förekomster"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "När Cockpit är installerat, aktivera det med ”systemctl enable --now cockpit.socket”."
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Other": [
  null,
  "Annan"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "Parent": [
  null,
  "Förälder"
 ],
 "Parent $parent": [
  null,
  "Förälder $parent"
 ],
 "Part of $0": [
  null,
  "Del av $0"
 ],
 "Passive": [
  null,
  "Passiv"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Paste error": [
  null,
  "Klistra in fel"
 ],
 "Paste existing key": [
  null,
  "Klistra in befintlig nyckel"
 ],
 "Path cost": [
  null,
  "Sökvägskostnad"
 ],
 "Path cost $path_cost": [
  null,
  "Sökvägskostnad $path_cost"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Jämlik #$0 har en ogiltig ändpunktsport. Port måste vara ett nummer."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "Jämlik #$0 har ogiltig ändpunkt. Det måste anges som värd:port, t.ex. 1.2.3.4:51820 eller exempel.com:51820"
 ],
 "Peers": [
  null,
  "Jämlikar"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Jämlikar är andra maskiner som ansluter till denna. Offentliga nycklar från andra maskiner kommer att delas med varandra."
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Ping interval": [
  null,
  "Ping-intervall"
 ],
 "Ping target": [
  null,
  "Ping-mål"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Please install the $0 package": [
  null,
  "Installera paketet $0"
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "Ports": [
  null,
  "Portar"
 ],
 "Prefix length": [
  null,
  "Prefixlängd"
 ],
 "Prefix length or netmask": [
  null,
  "Prefixlängd eller nätmask"
 ],
 "Preparing": [
  null,
  "Förbereder"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "Preserve": [
  null,
  "Bevara"
 ],
 "Primary": [
  null,
  "Primär"
 ],
 "Priority": [
  null,
  "Prioritet"
 ],
 "Priority $priority": [
  null,
  "Prioritet $priority"
 ],
 "Private key": [
  null,
  "Privatnyckel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "Public key": [
  null,
  "Publik nyckel"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Publik nyckel kommer att genereras när en giltig privat nyckel anges"
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Random": [
  null,
  "Slumpvis"
 ],
 "Range": [
  null,
  "Räckvidd"
 ],
 "Range must be strictly ordered": [
  null,
  "Räckvidden måste vara strikt ordnad"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Receiving": [
  null,
  "Tar emot"
 ],
 "Regenerate": [
  null,
  "Regenerera"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Remove $0": [
  null,
  "Ta bort $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Ta bort tjänsten $0 från zon $1"
 ],
 "Remove item": [
  null,
  "Ta bort post"
 ],
 "Remove service $0": [
  null,
  "Ta bort tjänst $0"
 ],
 "Remove zone $0": [
  null,
  "Ta bort zon $0"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att ta bort $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Att ta bort cockpittjänsten kan leda till att webbkonsolen blir oåtkomlig. Se till att den här zonen inte gäller din nuvarande webbkonsolanslutning."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Om du tar bort zonen tas alla tjänster inom den bort."
 ],
 "Restoring connection": [
  null,
  "Återställer förbindelsen"
 ],
 "Round robin": [
  null,
  "Turas om"
 ],
 "Routes": [
  null,
  "Rutter"
 ],
 "Row expansion": [
  null,
  "Radexpansion"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Runner": [
  null,
  "Körare"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "STP forward delay": [
  null,
  "Fördröjning av STP-vidarebefordran"
 ],
 "STP hello time": [
  null,
  "STP Hello-tid"
 ],
 "STP maximum message age": [
  null,
  "STP maximal meddelandeålder"
 ],
 "STP priority": [
  null,
  "STP-prioritet"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Search domain": [
  null,
  "Sökdomäner"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Säkerhetsförbättrad Linux-konfiguration och felsökning"
 ],
 "Select method": [
  null,
  "Välj metod"
 ],
 "Sending": [
  null,
  "Skickar"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server has closed the connection.": [
  null,
  "Servern har stängt förbindelsen."
 ],
 "Service": [
  null,
  "Tjänst"
 ],
 "Services": [
  null,
  "Tjänster"
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Set to": [
  null,
  "Sätt till"
 ],
 "Shared": [
  null,
  "Delad"
 ],
 "Shell script": [
  null,
  "Skalskript"
 ],
 "Shift+Insert": [
  null,
  "Skift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Visa bekräftelselösenord"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Sorted from least to most trusted": [
  null,
  "Sorterad från minst till mest betrodd"
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Spanning tree protocol": [
  null,
  "Uppspännande-träd-protokollet"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Uppspännande-träd-protokollet (STP)"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Stable": [
  null,
  "Stabilt"
 ],
 "Start service": [
  null,
  "Starta tjänst"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "Sticky": [
  null,
  "Fast"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Strong password": [
  null,
  "Starkt lösenord"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Switch of $0": [
  null,
  "Ändra till $0"
 ],
 "Switch off $0": [
  null,
  "Stäng av $0"
 ],
 "Switch on $0": [
  null,
  "Sätt på $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att slå av $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att sätta på $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "Team": [
  null,
  "Team"
 ],
 "Team port": [
  null,
  "Team-port"
 ],
 "Team port settings": [
  null,
  "Team-portsinställningar"
 ],
 "Testing connection": [
  null,
  "Testar anslutningen"
 ],
 "The cockpit service is automatically included": [
  null,
  "Cockpit tjänsten ingår automatiskt"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den inloggade användaren har inte tillåtelse att se systemändringar"
 ],
 "The passwords do not match.": [
  null,
  "Lösenorden stämmer inte överens."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Servern vägrade att autentisera med några stödda metoder."
 ],
 "There are no active services in this zone": [
  null,
  "Det finns inga aktiva tjänster i denna zon"
 ],
 "This device cannot be managed here.": [
  null,
  "Denna enhet kan inte hanteras här."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Det här verktyget konfigurerar SELinux-policyn och kan hjälpa till med att förstå och lösa policy överträdelser."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Det här verktyget konfigurerar systemet till att kunna skriva kärnkraschdumpar till disken."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Detta verktyg genererar ett arkiv med konfiguration och diagnostisk information från det körande systemet. Arkivet kan förvaras lokalt eller centralt för inspelning eller spårningsändamål eller kan skickas till tekniska supportrepresentanter, utvecklare eller systemadministratörer för att hjälpa till med teknisk felspårning och felsökning."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Detta verktyg hanterar lokal lagring, såsom filsystem, LVM2-volymgrupper och NFS-monteringar."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Detta verktyg hanterar nätverk som bindningar, broar, team, VLAN och brandväggar med NetworkManager och Firewalld. NetworkManager är inkompatibelt med Ubuntus standard systemd-networkd och Debians ifupdown skript."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Denna zon innehåller cockpit-tjänsten. Se till att denna zon inte gäller din aktuella webbkonsolanslutning."
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Too much data": [
  null,
  "För mycket data"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Transmitting": [
  null,
  "Överföring"
 ],
 "Troubleshoot…": [
  null,
  "Felsök…"
 ],
 "Trust level": [
  null,
  "Tillitsnivå"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "Oväntat fel"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Unknown \"$0\"": [
  null,
  "Okänt ”$0”"
 ],
 "Unknown configuration": [
  null,
  "Okänd konfiguration"
 ],
 "Unknown service name": [
  null,
  "Okänt tjänstnamn"
 ],
 "Unmanaged interfaces": [
  null,
  "Ej hanterade gränssnitt"
 ],
 "Untrusted host": [
  null,
  "Ej betrodd värd"
 ],
 "Use": [
  null,
  "Använd"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN-ID"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "View automation script": [
  null,
  "Visa automatiseringsskript"
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Waiting": [
  null,
  "Väntar"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder skall bli klara"
 ],
 "Weak password": [
  null,
  "Svagt lösenord"
 ],
 "Web Console for Linux servers": [
  null,
  "Webbkonsol för Linuxservrar"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Kommer att ställas in på \"Automatisk\""
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Du har inte rättigheter att ändra brandväggen."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Din webbläsare tillåter inte att klistra in från sammanhangsmenyn. Du kan använda Skift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Din session har avslutats."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Din session har gått ut. Logga in igen."
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "wireguard-tools package is not installed": [
  null,
  "wireguard-tools paketet är inte installerat"
 ]
});
