cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 aktívna zóna",
  "$0 aktívne zóny",
  "$0 aktívnych zón"
 ],
 "$0 day": [
  null,
  "$0 deň",
  "$0 dni",
  "$0 dní"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódom $1"
 ],
 "$0 failed": [
  null,
  "$0 sa nepodarilo"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodín"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "$0 key changed": [
  null,
  "$0 kľúč sa zmenil"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 nútene ukončené signálom $1"
 ],
 "$0 minute": [
  null,
  "$0 minúta",
  "$0 minúty",
  "$0 minút"
 ],
 "$0 month": [
  null,
  "$0 mesiac",
  "$0 mesiace",
  "$0 mesiacov"
 ],
 "$0 week": [
  null,
  "$0 týždeň",
  "$0 týždne",
  "$0 týždňov"
 ],
 "$0 will be installed.": [
  null,
  "Nainštaluje sa $0."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 rokov"
 ],
 "$0 zone": [
  null,
  "zóna $0"
 ],
 "1 day": [
  null,
  "1 deň"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "1 week": [
  null,
  "1 týždeň"
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "6 hours": [
  null,
  "6 hodín"
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie je nainštalovaná kompatibilná verzia Cockpitu."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Sieťové spojenie - bonding - spája viacero sieťových rozhraní do jedného logického rozhrania s vyššou priepustnosťou alebo odolnosťou voči výpadkom."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vygenerovaný nový kľúč SSH $1 na $2 a bude pridaný do súboru $3 $4 na $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP monitoring"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Acceptable password": [
  null,
  "Prijateľné heslo"
 ],
 "Active": [
  null,
  "Aktívna"
 ],
 "Active backup": [
  null,
  "Aktívna záloha"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptívne rozkladanie zátaže"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptívne rozkladanie prenosovej zátaže odosielania"
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "Add $0": [
  null,
  "Pridať $0"
 ],
 "Add DNS server": [
  null,
  "Pridať DNS server"
 ],
 "Add VLAN": [
  null,
  "Pridať VLAN"
 ],
 "Add VPN": [
  null,
  "Pridať VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Pridať WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "Pridať novú zónu"
 ],
 "Add address": [
  null,
  "Pridať adresu"
 ],
 "Add bond": [
  null,
  "Pridať spojenie liniek (bond)"
 ],
 "Add bridge": [
  null,
  "Pridať sieťový most"
 ],
 "Add member": [
  null,
  "Pridať člena"
 ],
 "Add new zone": [
  null,
  "Pridať novú zónu"
 ],
 "Add peer": [
  null,
  "Pridať protistranu"
 ],
 "Add ports": [
  null,
  "Pridať porty"
 ],
 "Add ports to $0 zone": [
  null,
  "Pridať porty do zóny $0"
 ],
 "Add route": [
  null,
  "Pridať trasu"
 ],
 "Add search domain": [
  null,
  "Pridať prehľadávanú doménu"
 ],
 "Add services": [
  null,
  "Pridať služby"
 ],
 "Add services to $0 zone": [
  null,
  "Pridať službu do zóny $0"
 ],
 "Add services to zone $0": [
  null,
  "Pridať služby do zóny $0"
 ],
 "Add team": [
  null,
  "Pridať teaming"
 ],
 "Add zone": [
  null,
  "Pridať zónu"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Pridaním $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Pridaním používateľom definovaných portov dôjde k opätovnému načítaniu firewallu, čím sa stratia nastavenia, ktoré boli vytvorené počas behu a neboli uložené!"
 ],
 "Additional DNS $val": [
  null,
  "Ďalšie DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Ďalšie DNS domény k prehľadávaniu $val"
 ],
 "Additional address $val": [
  null,
  "Ďalšia adresa $val"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Additional ports": [
  null,
  "Ďalšie porty"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "Address $val": [
  null,
  "Adresa $val"
 ],
 "Addresses": [
  null,
  "Adresy"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresy nie sú v správnom formáte"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocou webovej konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Allowed IPs": [
  null,
  "Povolené IP adresy"
 ],
 "Allowed addresses": [
  null,
  "Povolené adresy"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentácia k Ansible roliam"
 ],
 "Authenticating": [
  null,
  "Overujem"
 ],
 "Authentication": [
  null,
  "Overovanie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pre vykonávanie privilegovaných úloh pomocou webovej konzole Cockpit je potrebné overiť svoju totožnosť"
 ],
 "Authorize SSH key": [
  null,
  "Poveriť SSH kľúč"
 ],
 "Automatic": [
  null,
  "Automaticky"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automaticky (iba DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické využitím ďalších NTP serverov"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "Automation script": [
  null,
  "Automatizačný skript"
 ],
 "Balancer": [
  null,
  "Rozkladanie záťaže"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Bond": [
  null,
  "Väzba"
 ],
 "Bridge": [
  null,
  "Most"
 ],
 "Bridge port": [
  null,
  "Port mostu"
 ],
 "Bridge port settings": [
  null,
  "Nastavenia portov mostu"
 ],
 "Broadcast": [
  null,
  "Vysielanie"
 ],
 "Broken configuration": [
  null,
  "Chybné nastavenia"
 ],
 "Bus expansion chassis": [
  null,
  "Šasi pre rozšírenie zbernice"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Cannot forward login credentials": [
  null,
  "Nie je možné preposlať prístupové údaje"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "Carrier": [
  null,
  "Nosný signál"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Change the settings": [
  null,
  "Zmeniť nastavenia"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmenené kľúče sú často výsledkom preinštalovania operačného systému. Avšak neočakávaná zmena môže znamenať, že sa tretia strana snaží odpočúvať vaše spojenie."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Zmenou nastavení sa uší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Checking IP": [
  null,
  "Kontrolujem IP adresu"
 ],
 "Checking installed software": [
  null,
  "Zisťujem nainštalovaný softvér"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurácia NetworkManagera a Firewalld v Cockpite"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpitu sa nepodarilo kontaktovať daného hostiteľa."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správca serveru, který uľahčuje správu Linuxových serverov cez webový prehliadač. Nie je žiadnym problémom prechádzať medzi terminálom a webovým nástrojom. Služba spustená cez Cockpit môže byť zastavená v termináli. Podobne, pokiaľ dôjde k chybe v termináli, je toto vidieť v rozhraní žurnálu v Cockpite."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie je kompatibilný so sofvérom na systéme."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie je nainštalovaný"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie je nainštalovaný na tomto systéme."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je skvelý nástroj pre nových správcov serverov, ktorým jednoducho umožňuje vykonávať úlohy ako správa úložiska, kontrola žurnálu a spúšťanie či zastavovanie služieb. Môžte monitorovať a spravovať viacero serverov naraz. Stačí ich pridať jedným kliknutím a vaše stroje sa budú starať o svojích kamarátov."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zhromaždiť a zabaliť dáta pre diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Zhromaždiť výpisy pádov jadra systému"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Sú akceptované čiarkou oddelené porty, rozsahy a služby"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Configuring": [
  null,
  "Nastavujem"
 ],
 "Configuring IP": [
  null,
  "Nastavujem IP adresu"
 ],
 "Confirm key password": [
  null,
  "Potvrdiť heslo ku kľúči"
 ],
 "Confirm removal of $0": [
  null,
  "Potvrdiť odstránenie $0"
 ],
 "Connect automatically": [
  null,
  "Pripojiť sa automaticky"
 ],
 "Connection has timed out.": [
  null,
  "Časový limit spojenia vypršal."
 ],
 "Connection will be lost": [
  null,
  "Spojenie bude zrušené"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copied": [
  null,
  "Skopírované"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Copy to clipboard": [
  null,
  "Kopírovať do schránky"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvoriť nový SSH kľúč a poveriť ho"
 ],
 "Create it": [
  null,
  "Vytvoriť to"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvoriť nový súbor s úlohou s týmto obsahom."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Vytvorením $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Používateľom definované porty"
 ],
 "Custom zones": [
  null,
  "Používateľom definované zóny"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS prehľadávané domény"
 ],
 "DNS search domains $val": [
  null,
  "Prehľadávať DNS domény $val"
 ],
 "Deactivating": [
  null,
  "Deaktivujem"
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Delete": [
  null,
  "Odstrániť"
 ],
 "Delete $0": [
  null,
  "Odstrániť $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Odstránením $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Disable the firewall": [
  null,
  "Vypnúť bránu firewall"
 ],
 "Disabled": [
  null,
  "Vypnutá"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "Downloading $0": [
  null,
  "Sťahujem $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit": [
  null,
  "Upraviť"
 ],
 "Edit VLAN settings": [
  null,
  "Upraviť nastavenia VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Upraviť WireGuard VPN"
 ],
 "Edit bond settings": [
  null,
  "Upraviť nastavenia spojenia (bond)"
 ],
 "Edit bridge settings": [
  null,
  "Upraviť nastavenia mostu (bridge)"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Upraviť používateľom definovanú službu v zóne $0"
 ],
 "Edit rules and zones": [
  null,
  "Upraviť pravidlá a zóny"
 ],
 "Edit service": [
  null,
  "Upraviť službu"
 ],
 "Edit service $0": [
  null,
  "Upraviť službu $0"
 ],
 "Edit team settings": [
  null,
  "Upraviť nastavenia teamingu"
 ],
 "Embedded PC": [
  null,
  "Jednodoskový počítač"
 ],
 "Enable or disable the device": [
  null,
  "Povoliť alebo zakázať zariadenie"
 ],
 "Enable service": [
  null,
  "Zapnúť službu"
 ],
 "Enable the firewall": [
  null,
  "Zapnúť bránu firewall"
 ],
 "Enabled": [
  null,
  "Povolená"
 ],
 "Endpoint": [
  null,
  "Koncový bod"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Je potrebné zadať koncový bod slúžiaci ako „server\" v podobe stroj:port, inak je možné nechať pole nevyplnené."
 ],
 "Enter a valid MAC address": [
  null,
  "Zadajte platnú MAC adresu"
 ],
 "Entire subnet": [
  null,
  "Celá podsieť"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Príklad: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Príklad: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Skvelé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozširujúce šasi"
 ],
 "Failed": [
  null,
  "Neúspešné"
 ],
 "Failed to add port": [
  null,
  "Nepodarilo sa pridať port"
 ],
 "Failed to add service": [
  null,
  "Nepodarilo sa pridať službu"
 ],
 "Failed to add zone": [
  null,
  "Nepodarilo sa pridať zónu"
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "Failed to edit service": [
  null,
  "Službu sa nepodarilo upraviť"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodarilo sa povoliť $0 vo firewalld"
 ],
 "Failed to save settings": [
  null,
  "Nastavenia sa nepodarilo uložiť"
 ],
 "Filter services": [
  null,
  "Filtrovať služby"
 ],
 "Firewall": [
  null,
  "Brána firewall"
 ],
 "Firewall is not available": [
  null,
  "Brána firewall nie je k dispozícii"
 ],
 "Forward delay $forward_delay": [
  null,
  "Oneskorenie preposlania $forward_delay"
 ],
 "Gateway": [
  null,
  "Brána"
 ],
 "General": [
  null,
  "Všeobecné"
 ],
 "Generated": [
  null,
  "Vytvorené"
 ],
 "Go to now": [
  null,
  "Prejsť na súčasnosť"
 ],
 "Group": [
  null,
  "Skupina"
 ],
 "Hair pin mode": [
  null,
  "Režim Hair pin"
 ],
 "Hairpin mode": [
  null,
  "Režim Hair pin"
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "Hello time $hello_time": [
  null,
  "Oznamovací čas $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Skryť potvrdenie hesla"
 ],
 "Hide password": [
  null,
  "Skryť heslo"
 ],
 "Host key is incorrect": [
  null,
  "Kľúč stroja nie je správny"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP adresa"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP adresa so smerovacou predponou (prefix). Viacero hodnôt oddeľujte čiarkou. Príklad: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "IPv4 adresy"
 ],
 "IPv4 settings": [
  null,
  "Nastavenia IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Nastavenia IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Ak nie je vyplnené, identifikátor bude vytvorený na základe súvisiacich služieb na porte a čísiel portov"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Ak sa odtlačok zhoduje, kliknite na „Dôverovať a pridať stroj\". V opačnom prípade sa nepripájajte a obráťte sa na správcu systému."
 ],
 "Ignore": [
  null,
  "Ignorovať"
 ],
 "Inactive": [
  null,
  "Neaktívne"
 ],
 "Included services": [
  null,
  "Zahrnuté služby"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "V predvolenom nastavení sú prichádzajúce požiadavky blokované. Odchádzajúce blokované nie sú."
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Install software": [
  null,
  "Nainštalovať softvér"
 ],
 "Installing $0": [
  null,
  "Inštalujem $0"
 ],
 "Interface": [
  null,
  "Rozhranie",
  "Rozhrania",
  "Rozhraní"
 ],
 "Interface members": [
  null,
  "Čísla rozhraní"
 ],
 "Interfaces": [
  null,
  "Rozhrania"
 ],
 "Internal error": [
  null,
  "Interná chyba"
 ],
 "Invalid address $0": [
  null,
  "Neplatná adresa $0"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatné práva súborov"
 ],
 "Invalid metric $0": [
  null,
  "Neplatná metrika $0"
 ],
 "Invalid port number": [
  null,
  "Neplatné číslo portu"
 ],
 "Invalid prefix $0": [
  null,
  "Neplatná predpona $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Neplatná predpona alebo maska siete $0"
 ],
 "Invalid range": [
  null,
  "Neplatný rozsah"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "IoT gateway": [
  null,
  "Brána internetu vecí (IoT)"
 ],
 "Keep connection": [
  null,
  "Zachovať spojenie"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Key password": [
  null,
  "Heslo ku kľúču"
 ],
 "LACP key": [
  null,
  "LACP kľúč"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "Link down delay": [
  null,
  "Oneskorenie neaktívnej linky"
 ],
 "Link local": [
  null,
  "Lokálne prepojenie"
 ],
 "Link monitoring": [
  null,
  "Monitorovanie linky"
 ],
 "Link up delay": [
  null,
  "Oneskorenie aktívnej linky"
 ],
 "Link watch": [
  null,
  "Stráženie linky"
 ],
 "Listen port": [
  null,
  "Port, na ktorom očakávať pripojenia (počúvať)"
 ],
 "Listen port must be a number": [
  null,
  "Načúvací port musí byť číslo"
 ],
 "Load balancing": [
  null,
  "Rozkladanie záťaže"
 ],
 "Loading system modifications...": [
  null,
  "Načítavam systémové zmeny..."
 ],
 "Log in": [
  null,
  "Prihlásiť"
 ],
 "Log in to $0": [
  null,
  "Prihlásiť sa k $0"
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "Login failed": [
  null,
  "Prihlásenie sa nepodarilo"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (odporúčané)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU musí byť kladné číslo"
 ],
 "Main server chassis": [
  null,
  "Šasi hlavného servera"
 ],
 "Manage storage": [
  null,
  "Spravovať úložisko"
 ],
 "Managed interfaces": [
  null,
  "Spravované zariadenia"
 ],
 "Manual": [
  null,
  "Ručne"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximálny vek správ $max_age"
 ],
 "Message to logged in users": [
  null,
  "Správa pre prihlásených používateľov"
 ],
 "Metric": [
  null,
  "Metrika"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Miniveža"
 ],
 "Mode": [
  null,
  "Režim"
 ],
 "Monitoring interval": [
  null,
  "Interval monitorovania"
 ],
 "Monitoring targets": [
  null,
  "Ciele monitorovania"
 ],
 "Multi-system chassis": [
  null,
  "Šasi pre viac systémov"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Je možné zadať viacero adries (oddelených čiarkami alebo medzerami)."
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Need at least one NTP server": [
  null,
  "Je potrebný aspoň jeden server NTP"
 ],
 "Network bond": [
  null,
  "Sieťové spojenie (bond)"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Sieťové zariadenia a grafy vyžadujú NetworkManager"
 ],
 "Network logs": [
  null,
  "Záznamy udalostí siete"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager nie je nainštalovaný"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager nebeží"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "No": [
  null,
  "Nie"
 ],
 "No carrier": [
  null,
  "Bez signálu"
 ],
 "No delay": [
  null,
  "Bez oneskorenia"
 ],
 "No description available": [
  null,
  "Nie je k dispozícií žiaden popis"
 ],
 "No peers added.": [
  null,
  "Nepridané žiadne protistrany."
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "No such file or directory": [
  null,
  "Žiaden taký súbor alebo adresár neexistuje"
 ],
 "No system modifications": [
  null,
  "Žiadne systémové zmeny"
 ],
 "None": [
  null,
  "Žiadny"
 ],
 "Not a valid private key": [
  null,
  "Nie je platná súkromná časť kľúča"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Nemáte oprávnenie na vypnutie brány firewall"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Nemáte oprávnenie na zapnutie brány firewall"
 ],
 "Not available": [
  null,
  "edostupné"
 ],
 "Not permitted to configure network devices": [
  null,
  "Nemáte oprávnenie nastavovať sieťové zariadenia"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávený k vykonaniu tejto akcie."
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Keď bude Cockpit nainštalovaný, povoľte ho pomocou \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Možnosti"
 ],
 "Other": [
  null,
  "Iný"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Parent": [
  null,
  "Rodič"
 ],
 "Parent $parent": [
  null,
  "Nadradené $parent"
 ],
 "Part of $0": [
  null,
  "Súčasť $0"
 ],
 "Passive": [
  null,
  "Pasívny"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo nie je prijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je príliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nebolo prijaté"
 ],
 "Paste": [
  null,
  "Vložiť"
 ],
 "Paste error": [
  null,
  "Chyba vkladania"
 ],
 "Paste existing key": [
  null,
  "Vložiť existujúci kľúč"
 ],
 "Path cost": [
  null,
  "Náklady trasy"
 ],
 "Path cost $path_cost": [
  null,
  "Náklady trasy $path_cost"
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Protistrana č. $0 nemá platný port koncového bodu. Port musí byť číslo."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "Protistrana č. $0 nemá platný port koncového bodu. Je potrebné ho zadať ako stroj:port, napr. 1.2.3.4:51820 alebo priklad.com:51820"
 ],
 "Peers": [
  null,
  "Protistrany"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Protistrany sú iné stroje, ktoré sa k tomuto stroju prihlasujú. Verejné kľúče z ostatných strojov sa medzi sebou zdieľajú."
 ],
 "Peripheral chassis": [
  null,
  "Šasi pre periférie"
 ],
 "Permanent": [
  null,
  "Trvalá"
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Ping interval": [
  null,
  "Interval pre ping"
 ],
 "Ping target": [
  null,
  "Cieľ pre ping"
 ],
 "Pizza box": [
  null,
  "Veľkosť „krabice od pizzy“"
 ],
 "Please install the $0 package": [
  null,
  "Nainštalujte $0 balík"
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Prefix length": [
  null,
  "Dĺžka eor"
 ],
 "Prefix length or netmask": [
  null,
  "Dĺžka predpony alebo maska siete"
 ],
 "Preparing": [
  null,
  "Pripravujem"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "Preserve": [
  null,
  "Zachovať"
 ],
 "Primary": [
  null,
  "Primárny"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Priority $priority": [
  null,
  "Priorita $priority"
 ],
 "Private key": [
  null,
  "Súkromný kľúč"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-add bol prekročený"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-keygen bol prekročený"
 ],
 "Public key": [
  null,
  "Verejný kľúč"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Verejný kľúč bude vytvorený v okamihu zadania platného súkromného kľúča"
 ],
 "RAID chassis": [
  null,
  "Šasi pre RAID"
 ],
 "Rack mount chassis": [
  null,
  "Šasi pre umiestnenie do racku"
 ],
 "Random": [
  null,
  "Náhodná"
 ],
 "Range": [
  null,
  "Rozsah"
 ],
 "Range must be strictly ordered": [
  null,
  "Je potrebné, aby rozsah bol striktne radený"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Receiving": [
  null,
  "Prijímanie"
 ],
 "Regenerate": [
  null,
  "Znovu vytvoriť"
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Remove $0": [
  null,
  "Odobrať $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Odstrániť službu $0 zo zóny $1"
 ],
 "Remove item": [
  null,
  "Odstrániť položku"
 ],
 "Remove service $0": [
  null,
  "Odstrániť službu $0"
 ],
 "Remove zone $0": [
  null,
  "Odstrániť zónu $0"
 ],
 "Removing $0": [
  null,
  "Odstraňujem $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Odstránením $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Odstránenie služby cockpit môže viesť k tomu, že webová konzola prestane byť dostupná. Uistite sa, že sa táto zóna nevzťahuje na vaše súčasné pripojenie k tejto webovej konzoli."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Odstránenie zóny odoberie tiež všetky služby, ktoré obsahuje."
 ],
 "Restoring connection": [
  null,
  "Obnovujem spojenie"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Trasy"
 ],
 "Row expansion": [
  null,
  "Rozšírenie riadka"
 ],
 "Row select": [
  null,
  "Výber riadka"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdialenom stroji spustite – cez dôveryhodnú sieť alebo fyzicky priamo na ňom – tento príkaz:"
 ],
 "Runner": [
  null,
  "Spúšťač"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH kľúč"
 ],
 "STP forward delay": [
  null,
  "STP oneskorenie preposielania"
 ],
 "STP hello time": [
  null,
  "STP uvítací čas"
 ],
 "STP maximum message age": [
  null,
  "SFTP maximálny ved správy"
 ],
 "STP priority": [
  null,
  "STP priorita"
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Search domain": [
  null,
  "Prehľadávané domény"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavenie SELinuxu a riešenie problémov"
 ],
 "Select method": [
  null,
  "Vybrať metódu"
 ],
 "Sending": [
  null,
  "Odchádzajúce"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavrel spojenie."
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Set to": [
  null,
  "Nastaviť na"
 ],
 "Shared": [
  null,
  "Zdieľané"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Zobraziť potvrdenie hesla"
 ],
 "Show password": [
  null,
  "Zobraziť heslo"
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Sorted from least to most trusted": [
  null,
  "Zoradené od najmenej po najviac dôveryhodnú"
 ],
 "Space-saving computer": [
  null,
  "Priestorovo úsporný počítač"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Stable": [
  null,
  "Stabilná"
 ],
 "Start service": [
  null,
  "Spustiť službu"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Stick PC": [
  null,
  "Počítač vo forme USB kľúča"
 ],
 "Sticky": [
  null,
  "Lepkavé"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Strong password": [
  null,
  "Silné heslo"
 ],
 "Sub-Chassis": [
  null,
  "Menšie šasi"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Switch of $0": [
  null,
  "Vypnúť $0"
 ],
 "Switch off $0": [
  null,
  "Vypnúť $0"
 ],
 "Switch on $0": [
  null,
  "Zapnúť $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Vypnutím $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Zapnutím $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizujem"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Team": [
  null,
  "Teaming"
 ],
 "Team port": [
  null,
  "Port pre teaming"
 ],
 "Team port settings": [
  null,
  "Nastavenia portu pre teaming"
 ],
 "Testing connection": [
  null,
  "Testujem spojenie"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kľúč SSH $0 používateľa $1 na $2 bude pridaný do súboru $3 používateľa $4 na $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH kľúč $0 bude sprístupnený po celú reláciu a bude k dispozícií tiež pre prihlasovanie se k ostatním strojom."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený a hostiteľ neumožňuje prihlásenie pomocou hesla. Zadajte, prosím, heslo pre kľúč na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený. Môžete sa pripojiť buď pomocou prihlasovacím heslom alebo zadaním hesla ku kľúču na $1."
 ],
 "The cockpit service is automatically included": [
  null,
  "Služba cockpit je zahrnutá automaticky"
 ],
 "The fingerprint should match:": [
  null,
  "Odtlačok by sa mal zhodovať:"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ku kľúču nemôže byť prázdne"
 ],
 "The key passwords do not match": [
  null,
  "Heslá ku kľúču sa líšia"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Prihlásený používateľ nie je oprávnený zobrazovať modifikácie systému"
 ],
 "The password can not be empty": [
  null,
  "Heslo nemôže byť prázdne"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný odtlačok je možné zdieľať verejnými spôsobmi, vrátane e-mailu."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný odtlačok je bez problémov možné zdieľať prostredníctvom verejných spôsobov, vrátane e-mailu. Ak niekoho iného žiadate, aby urobil overovanie za vás, môže poslať výsledky ľubovoľnou cestou."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmietol overovanie pri všetkých podporovaných metódach."
 ],
 "There are no active services in this zone": [
  null,
  "V tejto zóne sa nenachádzajú žiadne aktívne služby"
 ],
 "This device cannot be managed here.": [
  null,
  "Toto zariadenie tu nie je možné spravovať."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje politiky pre SELinux a môže pomôcť s porozumením a riešením porušenia pravidiel."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytvára archív nastavení a diagnostických informácií z bežiaceho systému. Archív je možné uložiť lokálne alebo centrálne pre účely sledovania či záznamu alebo je možné ho poslať zástupcom technickej podpory, vývojárom alebo správcom systému, aby tak mohli pomôcť s nájdením technického nedostatku alebo ladením chyby."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje miestne úložisko, ako sú napríklad systémy súborov, LVM2 skupiny zväzkov a NFS pripojenia."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje sieťovanie ako napríklad sieťové spojenia (bond), teaming, mosty (bridge), VLAN siete a brány firewall pomocou nástroja NetworkManager a FIrewalld. NetworkManager nie je kompatibilný s Ubuntu v predvolenom stave pri používaní systemd-networkd a skriptami ifupdown v distribúcii Debian."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Táto zóna obsahuje službu cockpit. Overte, či sa táto zóna nevzťahuje na vaše aktuálne pripojenie k tejto webovej konzoli."
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby ste zaistili, že do vášho pripojenia nie je zasahované záškodníckou treťou stranou, overte odtlačok kľúča hostiteľa:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Ak chcete odtlačok overiť, spustite nasledujúce príkazy na $0 počas fyzickej prítomnosti pri stroji alebo prostredníctvom dôveryhodnej siete:"
 ],
 "Toggle date picker": [
  null,
  "Prepnúť vyberač dátumov"
 ],
 "Too much data": [
  null,
  "Príliš veľa dát"
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Transmitting": [
  null,
  "Odosielanie"
 ],
 "Troubleshoot…": [
  null,
  "Riešiť problém…"
 ],
 "Trust and add host": [
  null,
  "Dôverovať a pridať hostiteľa"
 ],
 "Trust level": [
  null,
  "Stupeň dôveryhodnosti"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizáciu s $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedarí sa prihlásiť k $0. Hostiteľ neprijíma prihlasovanie heslom ani žiaden z vašich SSH kľúčov."
 ],
 "Unexpected error": [
  null,
  "Neočakávaná chyba"
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Unknown \"$0\"": [
  null,
  "Neznáme \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Neznáma konfigurácia"
 ],
 "Unknown service name": [
  null,
  "Neznámy názov služby"
 ],
 "Unmanaged interfaces": [
  null,
  "Nespravované zariadenia"
 ],
 "Untrusted host": [
  null,
  "Nedôveryhodnotný stroj"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Verify fingerprint": [
  null,
  "Overiť odtlačok"
 ],
 "View all logs": [
  null,
  "Zobraziť všetky záznamy udalostí"
 ],
 "View automation script": [
  null,
  "Zobraziť automatizačný skript"
 ],
 "Visit firewall": [
  null,
  "Prejsť na bránu firewall"
 ],
 "Waiting": [
  null,
  "Čakám"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čakám na dokončenie ostatných operácií správy balíčkov"
 ],
 "Weak password": [
  null,
  "Ľahko prelomiteľné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzola pre linuxové servery"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Bude nastavené na „Automaticky“"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Áno"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 sa pripájate prvýkrát."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Nemáte oprávnenia na správu brány firewall."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vami používaný prehliadač neumožňuje vkladanie z kontextovej ponuky. Ako náhradu môžete použiť Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaša relácia bola ukončená."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnosť vašej relácie skončila. Prihláste sa, prosím, znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "edit": [
  null,
  "upraviť"
 ],
 "in less than a minute": [
  null,
  "o menej ako minútu"
 ],
 "less than a minute ago": [
  null,
  "pred menej ako minútou"
 ],
 "password quality": [
  null,
  "kvalita hesla"
 ],
 "show less": [
  null,
  "zobraziť menej"
 ],
 "show more": [
  null,
  "zobraziť viac"
 ],
 "wireguard-tools package is not installed": [
  null,
  "balíček wireguard-tools nie je nainštalovaný"
 ]
});
