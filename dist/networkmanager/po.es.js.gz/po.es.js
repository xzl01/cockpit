cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 zona activa",
  "$0 zonas activas"
 ],
 "$0 day": [
  null,
  "$0 día",
  "$0 días"
 ],
 "$0 exited with code $1": [
  null,
  "$0 finalizó con el código $1"
 ],
 "$0 failed": [
  null,
  "$0 falló"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 no está disponible en ningún repositorio."
 ],
 "$0 key changed": [
  null,
  "$0 clave cambiada"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminado con señal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mes",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "Se instalará: $0."
 ],
 "$0 year": [
  null,
  "$0 año",
  "$0 años"
 ],
 "$0 zone": [
  null,
  "Zona $0"
 ],
 "1 day": [
  null,
  "1 día"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "No se ha instalado una versión compatible de Cockpit en $0."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Una agregación de enlaces de red combina múltiples interfaces de red en una sola interfaz lógica con un mayor rendimiento o redundancia."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se creará una nueva clave SSH en $0 para $1 en $2 y se añadirá al fichero $3 de $4 en $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Supervisión de ARP"
 ],
 "ARP ping": [
  null,
  "Ping de ARP"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Acceptable password": [
  null,
  "Contraseña aceptable"
 ],
 "Active": [
  null,
  "Activo"
 ],
 "Active backup": [
  null,
  "Copia de seguridad activa"
 ],
 "Adaptive load balancing": [
  null,
  "Balanceo de carga adaptativo"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Transmisión adaptativo para el balanceo de carga"
 ],
 "Add": [
  null,
  "Añadir"
 ],
 "Add $0": [
  null,
  "Añadir $0"
 ],
 "Add DNS server": [
  null,
  "Añadir servidor DNS"
 ],
 "Add VLAN": [
  null,
  "Añadir VLAN"
 ],
 "Add VPN": [
  null,
  "Añadir VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Añadir VPN WireGuard"
 ],
 "Add a new zone": [
  null,
  "Añadir una nueva zona"
 ],
 "Add address": [
  null,
  "Añadir dirección"
 ],
 "Add bond": [
  null,
  "Añadir agregación"
 ],
 "Add bridge": [
  null,
  "Añadir puente"
 ],
 "Add member": [
  null,
  "Añadir miembro"
 ],
 "Add new zone": [
  null,
  "Añadir una nueva zona"
 ],
 "Add peer": [
  null,
  "Añadir usuario"
 ],
 "Add ports": [
  null,
  "Añadir puertos"
 ],
 "Add ports to $0 zone": [
  null,
  "Añadir puertos a la zona $0"
 ],
 "Add route": [
  null,
  "Añadir ruta"
 ],
 "Add search domain": [
  null,
  "Añadir dominio de búsqueda"
 ],
 "Add services": [
  null,
  "Añadir servicios"
 ],
 "Add services to $0 zone": [
  null,
  "Añadir servicios a la zona $0"
 ],
 "Add services to zone $0": [
  null,
  "Añadir servicios a la zona $0"
 ],
 "Add team": [
  null,
  "Añadir equipo"
 ],
 "Add zone": [
  null,
  "Añadir zona"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Si se añade $0 se cerrará la conexión con el servidor y se perderá acceso a la interfaz de administración."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Añadir puertos específicos hará que se recargue firewalld. ¡Puede que se pierda la configuración actual!"
 ],
 "Additional DNS $val": [
  null,
  "DNS adicional $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Búsqueda adicional de dominios DNS $val"
 ],
 "Additional address $val": [
  null,
  "Dirección adicional $val"
 ],
 "Additional packages:": [
  null,
  "Paquetes adicionales:"
 ],
 "Additional ports": [
  null,
  "Puertos adicionales"
 ],
 "Address": [
  null,
  "Dirección"
 ],
 "Address $val": [
  null,
  "Dirección $val"
 ],
 "Addresses": [
  null,
  "Dirección"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Las direcciones no tienen un formato válido"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrando con la consola Web de Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzado"
 ],
 "All-in-one": [
  null,
  "Todo en uno"
 ],
 "Allowed IPs": [
  null,
  "Direcciones IP permitidas"
 ],
 "Allowed addresses": [
  null,
  "Direcciones permitidas"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentación de los roles de Ansible"
 ],
 "Authenticating": [
  null,
  "Autenticando"
 ],
 "Authentication": [
  null,
  "Autenticación"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Se requiere autenticación para elevar privilegios y realizar tareas de administración en la consola Web de Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar la clave SSH"
 ],
 "Automatic": [
  null,
  "Automático"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automático (solo DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Utilizando NTP de forma automática"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP adicionales"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automatización"
 ],
 "Balancer": [
  null,
  "Equilibrador"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chasis tipo blade"
 ],
 "Bond": [
  null,
  "Agregación de enlaces"
 ],
 "Bridge": [
  null,
  "Puente"
 ],
 "Bridge port": [
  null,
  "Puerto puente"
 ],
 "Bridge port settings": [
  null,
  "Configuración del puerto puente"
 ],
 "Broadcast": [
  null,
  "Difusión"
 ],
 "Broken configuration": [
  null,
  "Configuración inválida"
 ],
 "Bus expansion chassis": [
  null,
  "Chasis de expansión de bus"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot forward login credentials": [
  null,
  "No se pueden transferir los datos de acceso"
 ],
 "Cannot schedule event in the past": [
  null,
  "No se puede planificar un evento ocurrido en el pasado"
 ],
 "Carrier": [
  null,
  "Transporte"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Change system time": [
  null,
  "Cambiar la hora del sistema"
 ],
 "Change the settings": [
  null,
  "Cambiar los ajustes"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Las llaves cambiadas pueden llevar una reinstalación del sistema operativo. Sin embargo, un cambio inesperado puede indicar un intento de interceptar su conexión mediante un tercero."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Cambiando los ajustes cerrará la conexión al servidor, y perderá el acceso a la IU de administración."
 ],
 "Checking IP": [
  null,
  "Comprobando la IP"
 ],
 "Checking installed software": [
  null,
  "Comprobando el software instalado"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuración en Cockpit de NetworkManager y Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit no se pudo conectar con el anfitrión especificado."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit es un gestor de servidores que facilita la administración de servidores Linux a través de un navegador web. Es posible alternar entre el portal web y la consola sin problemas. Un servicio que haya empezado por Cockpit se puede parar desde la terminal. Asimismo, si se produce un error en el terminal, podrá verlo en la bitácora de Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit no es compatible con el software del sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit no está instalado"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit no está instalado en el sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit es ideal para administradores de sistemas nóveles, ya que permite realizar con sencillez tareas como gestionar almacenamiento, inspeccionar bitácoras e iniciar y detener servicios. Puede monitorizar y administrar varios servidores a la vez. Tan solo añádalos con solo pulsar un botón y sus máquinas se encargarán del resto."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Recoger y empaquetar datos de diagnóstico y soporte"
 ],
 "Collect kernel crash dumps": [
  null,
  "Recoger volcados de colapso del kernel"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Los puertos, rangos y/o servicios deben estar separados por comas para que sean válidos"
 ],
 "Compact PCI": [
  null,
  "PCI compacto"
 ],
 "Configuring": [
  null,
  "Configurando"
 ],
 "Configuring IP": [
  null,
  "Configurando la IP"
 ],
 "Confirm key password": [
  null,
  "Confirme la contraseña de la clave"
 ],
 "Confirm removal of $0": [
  null,
  "Confirme el borrado de $0"
 ],
 "Connect automatically": [
  null,
  "Conectar automáticamente"
 ],
 "Connection has timed out.": [
  null,
  "La conexión ha caducado."
 ],
 "Connection will be lost": [
  null,
  "Se perderá la conexión"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar al portapapeles"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crear una clave SSH y autorizarla"
 ],
 "Create it": [
  null,
  "Crearlo"
 ],
 "Create new task file with this content.": [
  null,
  "Crear un archivo de tarea con este contenido."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Crear esta $0 cerrará la conexión con el servidor y hará que la interfaz de administración no esté disponible."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Puertos específicos"
 ],
 "Custom zones": [
  null,
  "Zonas personalizadas"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Búsqueda de dominios DNS"
 ],
 "DNS search domains $val": [
  null,
  "Buscar dominios DNS $val"
 ],
 "Deactivating": [
  null,
  "Desactivando"
 ],
 "Delay": [
  null,
  "Retardo"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Delete $0": [
  null,
  "Eliminar $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Eliminando $0 cerrará la conexión con el servidor y hará que la interfaz de administración no esté disponible."
 ],
 "Description": [
  null,
  "Descripción"
 ],
 "Desktop": [
  null,
  "Escritorio"
 ],
 "Detachable": [
  null,
  "Desmontable"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Disable the firewall": [
  null,
  "Desactivar el cortafuegos"
 ],
 "Disabled": [
  null,
  "Deshabilitado"
 ],
 "Docking station": [
  null,
  "Estación de acoplamiento"
 ],
 "Downloading $0": [
  null,
  "Descargando $0"
 ],
 "Dual rank": [
  null,
  "Rango dual"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit VLAN settings": [
  null,
  "Modificar la configuración VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Modificar VPN WireGuard"
 ],
 "Edit bond settings": [
  null,
  "Modificar la configuración de la agregación de enlaces"
 ],
 "Edit bridge settings": [
  null,
  "Modificar la configuración de puentes"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Editar servicio personalizado en la zona $0"
 ],
 "Edit rules and zones": [
  null,
  "Editar reglas y zonas"
 ],
 "Edit service": [
  null,
  "Editar servicio"
 ],
 "Edit service $0": [
  null,
  "Editar el servicio $0"
 ],
 "Edit team settings": [
  null,
  "Modificar la configuración de equipos"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Enable or disable the device": [
  null,
  "Habilitar o deshabilitar el dispositivo"
 ],
 "Enable service": [
  null,
  "Habilitar servicio"
 ],
 "Enable the firewall": [
  null,
  "Habilitar el cortafuegos"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Endpoint": [
  null,
  "Punto final"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Los puntos finales que actúen como \"servidor\" deben especificarse como anfitrión:puerto, en otro caso puede dejarse vacío."
 ],
 "Enter a valid MAC address": [
  null,
  "Introduzca una dirección MAC válida"
 ],
 "Entire subnet": [
  null,
  "En toda la subred"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Ejemplo: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Ejemplo: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Contraseña excelente"
 ],
 "Expansion chassis": [
  null,
  "Chasis de expansión"
 ],
 "Failed": [
  null,
  "Falló"
 ],
 "Failed to add port": [
  null,
  "Fallo al añadir el puerto"
 ],
 "Failed to add service": [
  null,
  "Fallo al añadir el servicio"
 ],
 "Failed to add zone": [
  null,
  "Fallo al añadir la zona"
 ],
 "Failed to change password": [
  null,
  "Error al cambiar contraseña"
 ],
 "Failed to edit service": [
  null,
  "Fallo al editar el servicio"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Fallo al habilitar $0 en firewalld"
 ],
 "Failed to save settings": [
  null,
  "Fallo al aplicar la configuración"
 ],
 "Filter services": [
  null,
  "Filtrar servicios"
 ],
 "Firewall": [
  null,
  "Cortafuegos"
 ],
 "Firewall is not available": [
  null,
  "El cortafuegos no está disponible"
 ],
 "Forward delay $forward_delay": [
  null,
  "Retardo del reenvío $forward_delay"
 ],
 "Gateway": [
  null,
  "Pasarela"
 ],
 "General": [
  null,
  "General"
 ],
 "Generated": [
  null,
  "Generado"
 ],
 "Go to now": [
  null,
  "Ir a ahora"
 ],
 "Group": [
  null,
  "Grupo"
 ],
 "Hair pin mode": [
  null,
  "Modo horquilla"
 ],
 "Hairpin mode": [
  null,
  "Modo horquilla"
 ],
 "Handheld": [
  null,
  "Dispositivo de mano"
 ],
 "Hello time $hello_time": [
  null,
  "Tiempo de vida $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar contraseña de confirmación"
 ],
 "Hide password": [
  null,
  "Ocultar contraseña"
 ],
 "Host key is incorrect": [
  null,
  "La tecla del anfitrión es incorrecta"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "Dirección IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Una dirección IP con un prefijo de enrutamiento. Separe los valores con una coma. Por ejemplo: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "Direcciones IPv4"
 ],
 "IPv4 settings": [
  null,
  "Configuración IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Configuración IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Si se deja vacío, se generará un ID basado en los servicios y números de puerto asociados"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si la huella coincide, pulse \"Confiar en el anfitrión y añadirlo\". En caso contrario, no se conecte y contacte con su administrador."
 ],
 "Ignore": [
  null,
  "Ignorar"
 ],
 "Inactive": [
  null,
  "Inactivo"
 ],
 "Included services": [
  null,
  "Servicios incluidos"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Las conexiones entrantes se bloquean por defecto. Las salientes no se bloquean."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install software": [
  null,
  "Instalar software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Interface": [
  null,
  "Interfaz",
  "Interfaces"
 ],
 "Interface members": [
  null,
  "Miembros de la interfaz"
 ],
 "Interfaces": [
  null,
  "Interfaces"
 ],
 "Internal error": [
  null,
  "Error interno"
 ],
 "Invalid address $0": [
  null,
  "La dirección $0 no es válida"
 ],
 "Invalid date format": [
  null,
  "Formato de fecha inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de fecha y hora inválidos"
 ],
 "Invalid file permissions": [
  null,
  "Permisos de archivo invalidos"
 ],
 "Invalid metric $0": [
  null,
  "La métrica $0 no es válida"
 ],
 "Invalid port number": [
  null,
  "Número de puerto inválido"
 ],
 "Invalid prefix $0": [
  null,
  "El prefijo $0 no es válido"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "El prefijo o la máscara de red $0 no es válido"
 ],
 "Invalid range": [
  null,
  "Rango inválido"
 ],
 "Invalid time format": [
  null,
  "Formato de hora inválido"
 ],
 "Invalid timezone": [
  null,
  "Zona horaria no válida"
 ],
 "IoT gateway": [
  null,
  "Pasarela IoT"
 ],
 "Keep connection": [
  null,
  "Mantener la conexión"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Key password": [
  null,
  "Contraseña de la clave"
 ],
 "LACP key": [
  null,
  "Clave de LACP"
 ],
 "Laptop": [
  null,
  "Portátil"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "Link down delay": [
  null,
  "Retardo a desconexión de enlace"
 ],
 "Link local": [
  null,
  "Enlace local"
 ],
 "Link monitoring": [
  null,
  "Monitorización del enlace"
 ],
 "Link up delay": [
  null,
  "Retardo a conexión de enlace"
 ],
 "Link watch": [
  null,
  "Ver enlace"
 ],
 "Listen port": [
  null,
  "Puerto de escucha"
 ],
 "Listen port must be a number": [
  null,
  "El puerto de escucha debe ser un número"
 ],
 "Load balancing": [
  null,
  "Balanceo de carga"
 ],
 "Loading system modifications...": [
  null,
  "Cargando modificaciones del sistema..."
 ],
 "Log in": [
  null,
  "Iniciar sesión"
 ],
 "Log in to $0": [
  null,
  "Iniciar sesión en $0"
 ],
 "Log messages": [
  null,
  "Mensajes de registro"
 ],
 "Login failed": [
  null,
  "Inicio de sesión fallido"
 ],
 "Low profile desktop": [
  null,
  "Perfil bajo de escritorio"
 ],
 "Lunch box": [
  null,
  "Caja de almuerzo"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (Recomendado)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "El MTU debe ser un número positivo"
 ],
 "Main server chassis": [
  null,
  "Chasis del servidor principal"
 ],
 "Manage storage": [
  null,
  "Gestionar el almacenamiento"
 ],
 "Managed interfaces": [
  null,
  "Interfaces gestionadas"
 ],
 "Manual": [
  null,
  "Manual"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Maximum message age $max_age": [
  null,
  "Tiempo máximo del mensaje $max_age"
 ],
 "Message to logged in users": [
  null,
  "Mensaje para usuarios activos"
 ],
 "Metric": [
  null,
  "Métrica"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Mode": [
  null,
  "Modo"
 ],
 "Monitoring interval": [
  null,
  "Intervalo de monitorización"
 ],
 "Monitoring targets": [
  null,
  "Monitorizar objetivos"
 ],
 "Multi-system chassis": [
  null,
  "Chasis multisistema"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Se pueden especificar múltiples direcciones utilizando comas o espacios como delimitadores."
 ],
 "NSNA ping": [
  null,
  "Ping de NSNA"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Need at least one NTP server": [
  null,
  "Se requiere al menos un servidor NTP"
 ],
 "Network bond": [
  null,
  "Agregación de enlaces de red"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Los dispositivos y los gráficos de red requieren de NetworkManager"
 ],
 "Network logs": [
  null,
  "Registros de redes"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager no está instalado"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager no se está ejecutando"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "New password was not accepted": [
  null,
  "No se aceptó la nueva contraseña"
 ],
 "No": [
  null,
  "No"
 ],
 "No carrier": [
  null,
  "No hay un proveedor"
 ],
 "No delay": [
  null,
  "Sin retardo"
 ],
 "No description available": [
  null,
  "No hay una descripción disponible"
 ],
 "No peers added.": [
  null,
  "Sin usuarios añadidos."
 ],
 "No results found": [
  null,
  "No se encontraron resultados"
 ],
 "No such file or directory": [
  null,
  "No existe el archivo o directorio"
 ],
 "No system modifications": [
  null,
  "No hay modificaciones para el sistema"
 ],
 "None": [
  null,
  "Ninguno"
 ],
 "Not a valid private key": [
  null,
  "No es una clave privada válida"
 ],
 "Not authorized to disable the firewall": [
  null,
  "No está autorizado para desactivar el cortafuegos"
 ],
 "Not authorized to enable the firewall": [
  null,
  "No está autorizado para activar el cortafuegos"
 ],
 "Not available": [
  null,
  "No está disponible"
 ],
 "Not permitted to configure network devices": [
  null,
  "Sin permisos para configurar dispositivos de red"
 ],
 "Not permitted to perform this action.": [
  null,
  "No está permitido llevar a cabo esta acción."
 ],
 "Not synchronized": [
  null,
  "No está sincronizado"
 ],
 "Notebook": [
  null,
  "Portátil"
 ],
 "Occurrences": [
  null,
  "Ocurrencias"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Old password not accepted": [
  null,
  "No se aceptó la contraseña vieja"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una vez que se instale Cockpit, habilítelo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Opciones"
 ],
 "Other": [
  null,
  "Otro"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "Parent": [
  null,
  "Padre"
 ],
 "Parent $parent": [
  null,
  "Padre $parent"
 ],
 "Part of $0": [
  null,
  "Parte de $0"
 ],
 "Passive": [
  null,
  "Pasivo"
 ],
 "Password": [
  null,
  "Contraseña"
 ],
 "Password is not acceptable": [
  null,
  "La contraseña no es válida"
 ],
 "Password is too weak": [
  null,
  "La contraseña es muy débil"
 ],
 "Password not accepted": [
  null,
  "Contraseña no válida"
 ],
 "Paste": [
  null,
  "Pegar"
 ],
 "Paste error": [
  null,
  "Error al pegar"
 ],
 "Paste existing key": [
  null,
  "Pegar clave existente"
 ],
 "Path cost": [
  null,
  "Coste de ruta"
 ],
 "Path cost $path_cost": [
  null,
  "Coste de la ruta $path_cost"
 ],
 "Path to file": [
  null,
  "Ruta al fichero"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "El usuario #$0 tiene un puerto de punto final no válido. El puerto debe ser un número."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "El usuario #$0 tiene un punto final no válido. Debe especificarse como anfitrión:puerto. Por ejemplo, 1.2.3.4:51820 o example.com:51820"
 ],
 "Peers": [
  null,
  "Usuarios"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Los usuarios son otras máquinas que se conectan con esta. Las claves públicas de otras máquinas se comparten entre sí."
 ],
 "Peripheral chassis": [
  null,
  "Chasis periférico"
 ],
 "Permanent": [
  null,
  "Permanente"
 ],
 "Pick date": [
  null,
  "Selecciona una fecha"
 ],
 "Ping interval": [
  null,
  "Intervalo de ping"
 ],
 "Ping target": [
  null,
  "Hacer ping al objetivo"
 ],
 "Pizza box": [
  null,
  "Caja de pizza"
 ],
 "Please install the $0 package": [
  null,
  "Por favor, instale el paquete $0"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Ports": [
  null,
  "Puertos"
 ],
 "Prefix length": [
  null,
  "Longitud del prefijo"
 ],
 "Prefix length or netmask": [
  null,
  "Tamaño del prefijo o máscara de red"
 ],
 "Preparing": [
  null,
  "Preparando"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Preserve": [
  null,
  "Mantener"
 ],
 "Primary": [
  null,
  "Primario"
 ],
 "Priority": [
  null,
  "Prioridad"
 ],
 "Priority $priority": [
  null,
  "Prioridad $priority"
 ],
 "Private key": [
  null,
  "Clave privada"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Ha expirado el tiempo de ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Se ha agotado el tiempo de espera para ssh-keygen"
 ],
 "Public key": [
  null,
  "Clave pública"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Se generará la clave pública cuando se introduzca una clave privada válida"
 ],
 "RAID chassis": [
  null,
  "Chasis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chasis montado en rack"
 ],
 "Random": [
  null,
  "Aleatorio"
 ],
 "Range": [
  null,
  "Rango"
 ],
 "Range must be strictly ordered": [
  null,
  "El rango debe estar estrictamente ordenado"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Receiving": [
  null,
  "Recibiendo"
 ],
 "Regenerate": [
  null,
  "Regenerar"
 ],
 "Removals:": [
  null,
  "Borrados:"
 ],
 "Remove $0": [
  null,
  "Eliminar $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Eliminar el servicio $0 la zona $1"
 ],
 "Remove item": [
  null,
  "Eliminar elemento"
 ],
 "Remove service $0": [
  null,
  "Eliminar el servicio $0"
 ],
 "Remove zone $0": [
  null,
  "Eliminar la zona $0"
 ],
 "Removing $0": [
  null,
  "Eliminando $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Eliminando $0 cerrará la conexión con el servidor y hará que la consola de administración no esté disponible."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Eliminando el servicio de cockpit cerrará la conexión con el servidor y hará que la consola de administración no esté disponible. Asegúrese de que esta zona se aplique en su conexión de la consola Web actual."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Eliminando la zona eliminará todos los servicios que estén asociados a esta."
 ],
 "Restoring connection": [
  null,
  "Restableciendo la conexión"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Rutas"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Ejecute este comando en la máquina remota a través de una red de confianza o de forma física:"
 ],
 "Runner": [
  null,
  "Lanzador"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clave SSH"
 ],
 "STP forward delay": [
  null,
  "Retardo del reenvío STP"
 ],
 "STP hello time": [
  null,
  "Tiempo de saludo STP"
 ],
 "STP maximum message age": [
  null,
  "Tiempo máximo del mensaje STP"
 ],
 "STP priority": [
  null,
  "Prioridad STP"
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "Sealed-case PC": [
  null,
  "PC de caja sellada"
 ],
 "Search domain": [
  null,
  "Dominio de búsquedas"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuración de Security Enhanced Linux y resolución de problemas"
 ],
 "Select method": [
  null,
  "Seleccionar método"
 ],
 "Sending": [
  null,
  "Enviando"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Server has closed the connection.": [
  null,
  "El servidor ha cerrado la conexión."
 ],
 "Service": [
  null,
  "Servicio"
 ],
 "Services": [
  null,
  "Servicios"
 ],
 "Set time": [
  null,
  "Establecer la hora"
 ],
 "Set to": [
  null,
  "Ajustar a"
 ],
 "Shared": [
  null,
  "Compartido"
 ],
 "Shell script": [
  null,
  "Script de shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Mostrar contraseña de confirmación"
 ],
 "Show password": [
  null,
  "Mostrar contraseña"
 ],
 "Shut down": [
  null,
  "Apagar"
 ],
 "Single rank": [
  null,
  "Rango único"
 ],
 "Sorted from least to most trusted": [
  null,
  "Ordenado de menos a más confiable"
 ],
 "Space-saving computer": [
  null,
  "Ordenador compacto"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "Specific time": [
  null,
  "Hora específica"
 ],
 "Stable": [
  null,
  "Estable"
 ],
 "Start service": [
  null,
  "Iniciar servicio"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Stick PC": [
  null,
  "PC USB"
 ],
 "Sticky": [
  null,
  "Pegajoso"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Strong password": [
  null,
  "Contraseña fuerte"
 ],
 "Sub-Chassis": [
  null,
  "Sub Chasis"
 ],
 "Sub-Notebook": [
  null,
  "Subportátil"
 ],
 "Switch of $0": [
  null,
  "Control de encendido de $0"
 ],
 "Switch off $0": [
  null,
  "Apagar $0"
 ],
 "Switch on $0": [
  null,
  "Encender $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Apagando $0 cerrará la conexión al servidor, y perderá el acceso a la IU de administración."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Encendiendo $0 cerrará la conexión al servidor, y perderá el acceso a la IU de administración."
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tableta"
 ],
 "Team": [
  null,
  "Equipo"
 ],
 "Team port": [
  null,
  "Puerto del equipo"
 ],
 "Team port settings": [
  null,
  "Ajustes del puerto del equipo"
 ],
 "Testing connection": [
  null,
  "Probando la conexión"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clave SSH $0 de $1 en $2 será añadida al archivo $3 de $4 en $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clave SSH $0 estará disponible durante el resto de la sesión y también lo estará para unirse a otros anfitriones."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida por contraseña, y el anfitrión no permite iniciar sesión con contraseña. Por favor, introduzca la contraseña de dicha clave en $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida. Puedes iniciar sesión tanto con la contraseña de usuario como introduciendo la contraseña de dicha clave en $1."
 ],
 "The cockpit service is automatically included": [
  null,
  "El servicio de cockpit está incluido de forma automática"
 ],
 "The fingerprint should match:": [
  null,
  "La huella debería coincidir con:"
 ],
 "The key password can not be empty": [
  null,
  "La contraseña de la clave no puede estar vacía"
 ],
 "The key passwords do not match": [
  null,
  "Las contraseñas de la clave no coinciden"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "El usuario autenticado no tiene permisos para ver las modificaciones del sistema"
 ],
 "The password can not be empty": [
  null,
  "La contraseña no puede estar vacía"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "La huella resultante es apta para compartirse en público, incluyendo correo electrónico."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "La huella resultante puede ser distribuida por medios públicos, incluyendo correo electrónico, sin riesgos. Si está pidiendo a alguien que haga la verificación por usted, pueden enviarle los resultados usando cualquier método."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "El servido rehusó autenticar usando los métodos soportados."
 ],
 "There are no active services in this zone": [
  null,
  "No hay servicios activos en esta zona"
 ],
 "This device cannot be managed here.": [
  null,
  "Este dispositivo no se puede gestionar aquí."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta herramienta configura la política de SELinux y puede ayudarle a comprender y resolver infracciones de la política."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta herramienta genera un archivo de configuración e información de diagnóstico del sistema en ejecución. El archivo puede ser almacenado localmente o centralmente para propósitos de registro o seguimiento, o puede ser enviado a representantes de soporte técnico, desarrolladores o administradores de sistemas para asistir con la detección de fallos y su corrección."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta herramienta gestiona el almacenamiento local, como sistemas de archivos, grupos de volúmenes LVM2 y montajes NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta herramienta gestiona la configuración de red como agrupaciones, puentes, grupos, las VLAN y cortafuegos usando NetworkManager y Firewalld. NetworkManager es incompatible con systemd-networkd habilitado por defecto en Ubuntu y con los scripts de ifupdown de Debian."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Esta zona contiene un servicio cockpit. Estese seguro de que esta zona no se aplica en su conexión con la consola web actual."
 ],
 "Time zone": [
  null,
  "Huso horario"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantizar que su conexión no sea interceptada por un tercero malicioso, por favor verifique la huella de clave del anfitrión:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar una huella, ejecute lo siguiente en $0 mientras se sitúa físicamente frente a la máquina o a través de una red de confianza:"
 ],
 "Toggle date picker": [
  null,
  "Alternar el selector de fecha"
 ],
 "Too much data": [
  null,
  "Demasiados datos"
 ],
 "Total size: $0": [
  null,
  "Tamaño total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Transmitting": [
  null,
  "Transmitiendo"
 ],
 "Troubleshoot…": [
  null,
  "Resolución de errores…"
 ],
 "Trust and add host": [
  null,
  "Confiar en el anfitrión y añadirlo"
 ],
 "Trust level": [
  null,
  "Nivel de confianza"
 ],
 "Trying to synchronize with $0": [
  null,
  "Intentando sincronizar con $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "No se pudo iniciar sesión en $0. El servidor no acepta inicio de sesión por contraseña ni ninguna de tus claves SSH."
 ],
 "Unexpected error": [
  null,
  "Error inesperado"
 ],
 "Unknown": [
  null,
  "Desconocido"
 ],
 "Unknown \"$0\"": [
  null,
  "Desconocido \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Configuración desconocida"
 ],
 "Unknown service name": [
  null,
  "Nombre del servicio desconocido"
 ],
 "Unmanaged interfaces": [
  null,
  "Interfaces no gestionadas"
 ],
 "Untrusted host": [
  null,
  "Anfitrión no seguro"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "ID de VLAN"
 ],
 "Verify fingerprint": [
  null,
  "Verifique la huella"
 ],
 "View all logs": [
  null,
  "Ver todos los registros"
 ],
 "View automation script": [
  null,
  "Ver el script de automatización"
 ],
 "Visit firewall": [
  null,
  "Ir al cortafuegos"
 ],
 "Waiting": [
  null,
  "Esperando"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Esperando a que finalicen otras operaciones de gestión de software"
 ],
 "Weak password": [
  null,
  "Contraseña débil"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web para servidores Linux"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Se establecerá a \"Automático\""
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Sí"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Se está conectando con $0 por primera vez."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Usted no está autorizado a modificar el cortafuegos."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tu navegador no admite pegar desde el menú contextual. Puedes usar Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Su sesión se ha terminado."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Su sesión ha expirado. Por favor inicie sesión otra vez."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[datos binarios]"
 ],
 "[no data]": [
  null,
  "[no hay datos]"
 ],
 "edit": [
  null,
  "editar"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "calidad de la contraseña"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ],
 "wireguard-tools package is not installed": [
  null,
  "El paquete wireguard-tools no está instalado"
 ]
});
