cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Managing VLANs": [
  null,
  "VLANs verwalten"
 ],
 "Managing firewall": [
  null,
  "Firewall verwalten"
 ],
 "Managing networking bonds": [
  null,
  "Verwalten der Netzwerkverbindungen"
 ],
 "Managing networking bridges": [
  null,
  "Netzwerkbrücken verwalten"
 ],
 "Managing networking teams": [
  null,
  "Verwalten der Netzwerkteams"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Dienste"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "bond": [
  null,
  "Bündel"
 ],
 "bridge": [
  null,
  "Brücke"
 ],
 "firewall": [
  null,
  "Firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "Schnittstelle"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "Netzwerk"
 ],
 "port": [
  null,
  "Port"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "team": [
  null,
  "Team"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "VLan"
 ],
 "zone": [
  null,
  "Zone"
 ]
});
