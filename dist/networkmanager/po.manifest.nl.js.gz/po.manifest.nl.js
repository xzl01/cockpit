cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Managing VLANs": [
  null,
  "VLAN's beheren"
 ],
 "Managing firewall": [
  null,
  "Firewall beheren"
 ],
 "Managing networking bonds": [
  null,
  "Netwerkbindingen beheren"
 ],
 "Managing networking bridges": [
  null,
  "Netwerkbruggen beheren"
 ],
 "Managing networking teams": [
  null,
  "Netwerkteams beheren"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "bond": [
  null,
  "binding"
 ],
 "bridge": [
  null,
  "brug"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "interface"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "netwerk"
 ],
 "port": [
  null,
  "poort"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zone"
 ]
});
