cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do Kernel"
 ],
 "Managing firewall": [
  null,
  ""
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "bond": [
  null,
  ""
 ],
 "bridge": [
  null,
  "ponte"
 ],
 "mac": [
  null,
  ""
 ],
 "network": [
  null,
  "rede"
 ],
 "port": [
  null,
  ""
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  ""
 ],
 "udp": [
  null,
  "udp"
 ],
 "zone": [
  null,
  "zona"
 ]
});
