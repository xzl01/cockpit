cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Managing VLANs": [
  null,
  "VLAN の管理"
 ],
 "Managing firewall": [
  null,
  "ファイアウォール管理"
 ],
 "Managing networking bonds": [
  null,
  "ネットワークボンディングの管理"
 ],
 "Managing networking bridges": [
  null,
  "ネットワークブリッジの管理"
 ],
 "Managing networking teams": [
  null,
  "ネットワークチームの管理"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "サービス"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "bond": [
  null,
  "ボンディング"
 ],
 "bridge": [
  null,
  "ブリッジ"
 ],
 "firewall": [
  null,
  "ファイアウォール"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "インターフェース"
 ],
 "ipv4": [
  null,
  "IPv4"
 ],
 "ipv6": [
  null,
  "IPv6"
 ],
 "mac": [
  null,
  "MAC"
 ],
 "network": [
  null,
  "ネットワーク"
 ],
 "port": [
  null,
  "ポート"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "team": [
  null,
  "チーム"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "VLAN"
 ],
 "zone": [
  null,
  "ゾーン"
 ]
});
