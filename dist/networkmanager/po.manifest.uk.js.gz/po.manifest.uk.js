cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Managing VLANs": [
  null,
  "Керування VLAN"
 ],
 "Managing firewall": [
  null,
  "Керування брандмауером"
 ],
 "Managing networking bonds": [
  null,
  "Керування зв'язками у мережі"
 ],
 "Managing networking bridges": [
  null,
  "Керування містками у мережі"
 ],
 "Managing networking teams": [
  null,
  "Керування командами у мережі"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Служби"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "bond": [
  null,
  "прив’язка"
 ],
 "bridge": [
  null,
  "місток"
 ],
 "firewall": [
  null,
  "брандмауер"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "інтерфейс"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "мережа"
 ],
 "port": [
  null,
  "порт"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "команда"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "зона"
 ]
});
