cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 etkin bölge",
  "$0 etkin bölge"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 exited with code $1": [
  null,
  "$0, $1 koduyla çıkış yaptı"
 ],
 "$0 failed": [
  null,
  "$0 başarısız oldu"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "$0 key changed": [
  null,
  "$0 anahtarı değişti"
 ],
 "$0 killed with signal $1": [
  null,
  "$0, $1 sinyali ile sonlandırıldı"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 will be installed.": [
  null,
  "$0 kurulacak."
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "$0 zone": [
  null,
  "$0 bölgesi"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0 üzerinde uyumlu bir Cockpit sürümü kurulu değil."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Bir ağ birleştirmesi (bond), birden çok ağ arayüzünü daha yüksek aktarım hızı veya yedeklilik ile tek bir mantıksal arayüzde birleştirir."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerinde $1 için $0 konumunda yeni bir SSH anahtarı oluşturulacak ve $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP izleme"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Acceptable password": [
  null,
  "Kabul edilebilir parola"
 ],
 "Active": [
  null,
  "Etkin"
 ],
 "Active backup": [
  null,
  "Etkin yedekleme"
 ],
 "Adaptive load balancing": [
  null,
  "Uyarlanabilir yük dengeleme"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Uyarlanabilir iletim yükü dengeleme"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Add $0": [
  null,
  "$0 ekle"
 ],
 "Add DNS server": [
  null,
  "DNS sunucusu ekle"
 ],
 "Add VLAN": [
  null,
  "VLAN ekle"
 ],
 "Add VPN": [
  null,
  "VPN ekle"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN ekle"
 ],
 "Add a new zone": [
  null,
  "Yeni bir bölge ekle"
 ],
 "Add address": [
  null,
  "Adres ekle"
 ],
 "Add bond": [
  null,
  "Birleştirme (Bond) ekle"
 ],
 "Add bridge": [
  null,
  "Köprü ekle"
 ],
 "Add member": [
  null,
  "Üye ekle"
 ],
 "Add new zone": [
  null,
  "Yeni bölge ekle"
 ],
 "Add peer": [
  null,
  "Kişi ekle"
 ],
 "Add ports": [
  null,
  "Bağlantı noktaları ekle"
 ],
 "Add ports to $0 zone": [
  null,
  "$0 bölgesine bağlantı noktaları ekle"
 ],
 "Add route": [
  null,
  "Yönlendirme ekle"
 ],
 "Add search domain": [
  null,
  "Arama etki alanı ekle"
 ],
 "Add services": [
  null,
  "Hizmetleri ekle"
 ],
 "Add services to $0 zone": [
  null,
  "$0 bölgesine hizmetleri ekle"
 ],
 "Add services to zone $0": [
  null,
  "$0 bölgesine hizmetleri ekle"
 ],
 "Add team": [
  null,
  "Takım ekle"
 ],
 "Add zone": [
  null,
  "Bölge ekle"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 eklemek sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Özel bağlantı noktalarının eklenmesi firewalld hizmetini yeniden yükleyecek. Yeniden yükleme, herhangi bir sadece çalışma zamanı yapılandırmasının kaybolmasına neden olacak!"
 ],
 "Additional DNS $val": [
  null,
  "Ek DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Ek DNS arama etki alanları $val"
 ],
 "Additional address $val": [
  null,
  "Ek adres $val"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Additional ports": [
  null,
  "Ek bağlantı noktaları"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address $val": [
  null,
  "Adres $val"
 ],
 "Addresses": [
  null,
  "Adresler"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresler doğru olarak biçimlendirilmemiş"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile Yönetim"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Allowed IPs": [
  null,
  "İzin verilen IP'ler"
 ],
 "Allowed addresses": [
  null,
  "İzin verilen adresler"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rolleri belgeleri"
 ],
 "Authenticating": [
  null,
  "Kimlik doğrulanıyor"
 ],
 "Authentication": [
  null,
  "Kimlik doğrulama"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile yetkili görevleri gerçekleştirmek için kimlik doğrulaması gerekir"
 ],
 "Authorize SSH key": [
  null,
  "SSH anahtarını yetkilendir"
 ],
 "Automatic": [
  null,
  "Otomatik"
 ],
 "Automatic (DHCP only)": [
  null,
  "Otomatik (Sadece DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Otomatik olarak ek NTP sunucularını kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "Automation script": [
  null,
  "Otomatikleştirme betiği"
 ],
 "Balancer": [
  null,
  "Dengeleyici"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Bond": [
  null,
  "Birleştirme (Bond)"
 ],
 "Bridge": [
  null,
  "Köprü"
 ],
 "Bridge port": [
  null,
  "Köprü bağlantı noktası"
 ],
 "Bridge port settings": [
  null,
  "Köprü bağlantı noktası ayarları"
 ],
 "Broadcast": [
  null,
  "Yayınlama"
 ],
 "Broken configuration": [
  null,
  "Bozuk yapılandırma"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Cannot forward login credentials": [
  null,
  "Oturum açma kimlik bilgileri yönlendirilemiyor"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "Carrier": [
  null,
  "Taşıyıcı"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Change the settings": [
  null,
  "Ayarları değiştir"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Değiştirilen anahtarlar genellikle bir işletim sisteminin yeniden kurulması sonucudur. Ancak, beklenmeyen bir değişiklik, üçüncü tarafın bağlantınıza müdahale etme girişimini gösterebilir."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Ayarların değiştirilmesi sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Checking IP": [
  null,
  "IP denetleniyor"
 ],
 "Checking installed software": [
  null,
  "Kurulu yazılımlar denetleniyor"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager ve Firewalld'un Cockpit yapılandırması"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit, verilen anamakineyle iletişim kuramadı."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit, Linux sunucularınızı bir web tarayıcısı aracılığıyla yönetmenizi kolaylaştıran bir sunucu yöneticisidir. Terminal ve web aracı arasında geçiş yapmak sorun değildir. Cockpit aracılığıyla başlatılan bir hizmet terminal aracılığıyla durdurulabilir. Aynı şekilde, terminalde bir hata meydana gelirse, Cockpit günlüğü arayüzünde görülebilir."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit, sistemdeki yazılımla uyumlu değil."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit kurulu değil"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit sistemde kurulu değil."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit yeni sistem yöneticileri için mükemmeldir; depolama yönetimi, günlükleri inceleme, hizmetleri başlatma ve durdurma gibi basit görevleri kolayca gerçekleştirmelerine olanak tanır. Aynı anda birkaç sunucuyu izleyebilir ve yönetebilirsiniz. Bunları tek bir tıklama ile ekleyin ve makineleriniz arkadaşlarıyla ilgilensin."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Tanılama ve destek verilerini topla ve paketle"
 ],
 "Collect kernel crash dumps": [
  null,
  "Çekirdek çökme dökümlerini topla"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Virgülle ayrılmış bağlantı noktaları, aralıklar ve hizmetler kabul edilir"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Configuring": [
  null,
  "Yapılandırılıyor"
 ],
 "Configuring IP": [
  null,
  "IP yapılandırma"
 ],
 "Confirm key password": [
  null,
  "Anahtar parolasını onayla"
 ],
 "Confirm removal of $0": [
  null,
  "$0 kaldırılmasını onayla"
 ],
 "Connect automatically": [
  null,
  "Otomatik olarak bağlan"
 ],
 "Connection has timed out.": [
  null,
  "Bağlantı zaman aşımına uğradı."
 ],
 "Connection will be lost": [
  null,
  "Bağlantı kaybolacaktır"
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Copied": [
  null,
  "Kopyalandı"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Create $0": [
  null,
  "$0 oluştur"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Yeni bir SSH anahtarı oluştur ve yetkilendir"
 ],
 "Create it": [
  null,
  "Oluştur"
 ],
 "Create new task file with this content.": [
  null,
  "Bu içerikle yeni görev dosyası oluştur."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Bu $0 oluşturmak sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Özel bağlantı noktaları"
 ],
 "Custom zones": [
  null,
  "Özel bölgeler"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS arama etki alanları"
 ],
 "DNS search domains $val": [
  null,
  "DNS arama etki alanları $val"
 ],
 "Deactivating": [
  null,
  "Devre dışı bırakılıyor"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Delete $0": [
  null,
  "$0 sil"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 silmek sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Disable the firewall": [
  null,
  "Güvenlik duvarını etkisizleştir"
 ],
 "Disabled": [
  null,
  "Etkisizleştirildi"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Edit VLAN settings": [
  null,
  "VLAN ayarlarını düzenle"
 ],
 "Edit WireGuard VPN": [
  null,
  "WireGuard VPN'i düzenle"
 ],
 "Edit bond settings": [
  null,
  "Birleştirme ayarlarını düzenle"
 ],
 "Edit bridge settings": [
  null,
  "Köprü ayarlarını düzenle"
 ],
 "Edit custom service in $0 zone": [
  null,
  "$0 bölgesinde özel hizmeti düzenle"
 ],
 "Edit rules and zones": [
  null,
  "Kuralları ve bölgeleri düzenle"
 ],
 "Edit service": [
  null,
  "Hizmeti düzenle"
 ],
 "Edit service $0": [
  null,
  "$0 hizmetini düzenle"
 ],
 "Edit team settings": [
  null,
  "Takım ayarlarını düzenle"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Enable or disable the device": [
  null,
  "Aygıtı etkinleştirin veya etkisizleştirin"
 ],
 "Enable service": [
  null,
  "Hizmeti etkinleştir"
 ],
 "Enable the firewall": [
  null,
  "Güvenlik duvarını etkinleştir"
 ],
 "Enabled": [
  null,
  "Etkinleştirildi"
 ],
 "Endpoint": [
  null,
  "Uç nokta"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "\"Sunucu\" gibi davranan uç noktanın anamakine:b.noktası olarak belirtilmesi gerekir, aksi takdirde boş bırakılabilir."
 ],
 "Enter a valid MAC address": [
  null,
  "Geçerli bir MAC adresi girin"
 ],
 "Entire subnet": [
  null,
  "Tüm alt ağ"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC adresi"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU değeri"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Örnek: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Örnek: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Failed": [
  null,
  "Başarısız oldu"
 ],
 "Failed to add port": [
  null,
  "Bağlantı noktası ekleme başarısız oldu"
 ],
 "Failed to add service": [
  null,
  "Hizmet ekleme başarısız oldu"
 ],
 "Failed to add zone": [
  null,
  "Bölge ekleme başarısız oldu"
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "Failed to edit service": [
  null,
  "Hizmeti düzenleme başarısız oldu"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld içinde $0 etkinleştirme başarısız oldu"
 ],
 "Failed to save settings": [
  null,
  "Ayarları kaydetme başarısız oldu"
 ],
 "Filter services": [
  null,
  "Hizmetleri süz"
 ],
 "Firewall": [
  null,
  "Güvenlik duvarı"
 ],
 "Firewall is not available": [
  null,
  "Güvenlik duvarı kullanılabilir değil"
 ],
 "Forward delay $forward_delay": [
  null,
  "Yönlendirme gecikmesi $forward_delay"
 ],
 "Gateway": [
  null,
  "Ağ geçidi"
 ],
 "General": [
  null,
  "Genel"
 ],
 "Generated": [
  null,
  "Oluşturuldu"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Hair pin mode": [
  null,
  "Hair pin kipi"
 ],
 "Hairpin mode": [
  null,
  "Hairpin kipi"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Hello time $hello_time": [
  null,
  "Merhaba süresi $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Onay parolasını gizle"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "Host key is incorrect": [
  null,
  "Anamakine anahtarı yanlış"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "ID $id": [
  null,
  "Kimlik $id"
 ],
 "IP address": [
  null,
  "IP adresi"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Yönlendirme ön ekiyle birlikte IP adresi. Birden çok değeri virgülle ayırın. Örnek: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "IPv4 adresleri"
 ],
 "IPv4 settings": [
  null,
  "IPv4 ayarları"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6 ayarları"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Eğer boş bırakılırsa, ilişkilendirilmiş bağlantı noktası hizmetlerine ve bağlantı noktası numaralarına dayanarak kimlik oluşturulacaktır"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Eğer parmak izi eşleşirse, 'Anamakineye güven ve ekle'ye tıklayın. Aksi takdirde, bağlanmayın ve yöneticinize başvurun."
 ],
 "Ignore": [
  null,
  "Yoksay"
 ],
 "Inactive": [
  null,
  "Etkin değil"
 ],
 "Included services": [
  null,
  "Dahil olan hizmetler"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Gelen istekler varsayılan olarak engellenir. Giden istekler engellenmez."
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Install software": [
  null,
  "Yazılım kur"
 ],
 "Installing $0": [
  null,
  "$0 kuruluyor"
 ],
 "Interface": [
  null,
  "Arayüz",
  "Arayüzler"
 ],
 "Interface members": [
  null,
  "Arayüz üyeleri"
 ],
 "Interfaces": [
  null,
  "Arayüzler"
 ],
 "Internal error": [
  null,
  "İç hata"
 ],
 "Invalid address $0": [
  null,
  "Geçersiz adres $0"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid file permissions": [
  null,
  "Geçersiz dosya izinleri"
 ],
 "Invalid metric $0": [
  null,
  "Geçersiz ölçüm $0"
 ],
 "Invalid port number": [
  null,
  "Geçersiz bağlantı noktası numarası"
 ],
 "Invalid prefix $0": [
  null,
  "Geçersiz ön ek $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Geçersiz ön ek veya ağ maskesi $0"
 ],
 "Invalid range": [
  null,
  "Geçersiz aralık"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Keep connection": [
  null,
  "Bağlantıyı koru"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Key password": [
  null,
  "Anahtar parolası"
 ],
 "LACP key": [
  null,
  "LACP anahtarı"
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "Link down delay": [
  null,
  "Bağlantı kapanma gecikmesi"
 ],
 "Link local": [
  null,
  "Yerel bağlantı"
 ],
 "Link monitoring": [
  null,
  "Bağlantı izleme"
 ],
 "Link up delay": [
  null,
  "Bağlantı açılma gecikmesi"
 ],
 "Link watch": [
  null,
  "Bağlantı izleme"
 ],
 "Listen port": [
  null,
  "Dinlenen bağlantı noktası"
 ],
 "Listen port must be a number": [
  null,
  "Dinlenen bağlantı noktası bir sayı olmak zorundadır"
 ],
 "Load balancing": [
  null,
  "Yük dengeleme"
 ],
 "Loading system modifications...": [
  null,
  "Sistem değişiklikleri yükleniyor..."
 ],
 "Log in": [
  null,
  "Oturum aç"
 ],
 "Log in to $0": [
  null,
  "$0 üzerinde oturum aç"
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "Login failed": [
  null,
  "Oturum açma başarısız oldu"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (önerilir)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU pozitif bir sayı olmak zorundadır"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Manage storage": [
  null,
  "Depolamayı yönet"
 ],
 "Managed interfaces": [
  null,
  "Yönetilen arayüzler"
 ],
 "Manual": [
  null,
  "Elle"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Maximum message age $max_age": [
  null,
  "En fazla ileti yaşı $max_age"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Metric": [
  null,
  "Ölçüm"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mode": [
  null,
  "Kip"
 ],
 "Monitoring interval": [
  null,
  "İzleme aralığı"
 ],
 "Monitoring targets": [
  null,
  "İzleme hedefleri"
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Sınırlayıcılar olarak virgüller veya boşluklar kullanılarak birden çok adres belirtilebilir."
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "Network bond": [
  null,
  "Ağ birleştirme (bond)"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Ağ aygıtları ve grafikleri için NetworkManager gerekir"
 ],
 "Network logs": [
  null,
  "Ağ günlükleri"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager kurulu değil"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager çalışmıyor"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "No": [
  null,
  "Hayır"
 ],
 "No carrier": [
  null,
  "Taşıyıcı yok"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "No description available": [
  null,
  "Mevcut açıklama yok"
 ],
 "No peers added.": [
  null,
  "Eklenen kişiler yok."
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "No system modifications": [
  null,
  "Sistem değişiklikleri yok"
 ],
 "None": [
  null,
  "Yok"
 ],
 "Not a valid private key": [
  null,
  "Geçerli bir özel anahtar değil"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Güvenlik duvarını etkisizleştirmeye yetkili değil"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Güvenlik duvarını etkinleştirmeye yetkili değil"
 ],
 "Not available": [
  null,
  "Mevcut değil"
 ],
 "Not permitted to configure network devices": [
  null,
  "Ağ aygıtlarını yapılandırmaya izin verilmiyor"
 ],
 "Not permitted to perform this action.": [
  null,
  "Bu eylemi gerçekleştirmeye izinli değil."
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Oluşumlar"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit kurulduktan sonra, \"systemctl enable --now cockpit.socket\" komutuyla etkinleştirin."
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "Parent": [
  null,
  "Üst öğe"
 ],
 "Parent $parent": [
  null,
  "Üst öğe $parent"
 ],
 "Part of $0": [
  null,
  "$0 parçası"
 ],
 "Passive": [
  null,
  "Pasif"
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Password not accepted": [
  null,
  "Parola kabul edilmedi"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Paste existing key": [
  null,
  "Varolan anahtarı yapıştır"
 ],
 "Path cost": [
  null,
  "Yol maliyeti"
 ],
 "Path cost $path_cost": [
  null,
  "Yol maliyeti $path_cost"
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Kişi #$0 geçersiz uç nokta bağlantı noktasına sahip. Bağlantı noktası bir sayı olmak zorundadır."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "Kişi #$0 geçersiz uç noktaya sahip. Anamakine:b.noktası olarak belirtilmek zorundadır, örn. 1.2.3.4:51820 veya ornek.com:51820"
 ],
 "Peers": [
  null,
  "Kişiler"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Bununla bağlantı kuran kişiler diğer makinelerdir. Diğer makinelerin ortak anahtarları birbirleriyle paylaşılacaktır."
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "Permanent": [
  null,
  "Kalıcı"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Ping interval": [
  null,
  "Ping aralığı"
 ],
 "Ping target": [
  null,
  "Ping hedefi"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please install the $0 package": [
  null,
  "Lütfen $0 paketini kurun"
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Ports": [
  null,
  "Bağlantı noktaları"
 ],
 "Prefix length": [
  null,
  "Ön ek uzunluğu"
 ],
 "Prefix length or netmask": [
  null,
  "Ön ek uzunluğu veya ağ maskesi"
 ],
 "Preparing": [
  null,
  "Hazırlanıyor"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Preserve": [
  null,
  "Koru"
 ],
 "Primary": [
  null,
  "Birincil"
 ],
 "Priority": [
  null,
  "Öncelik"
 ],
 "Priority $priority": [
  null,
  "Öncelik $priority"
 ],
 "Private key": [
  null,
  "Özel anahtar"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Public key": [
  null,
  "Ortak anahtar"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Geçerli bir özel anahtar girildiğinde ortak anahtar oluşturulacaktır"
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Random": [
  null,
  "Rastgele"
 ],
 "Range": [
  null,
  "Aralık"
 ],
 "Range must be strictly ordered": [
  null,
  "Aralık kesin bir şekilde sıralı olmalıdır"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Receiving": [
  null,
  "Alınan"
 ],
 "Regenerate": [
  null,
  "Yeniden oluştur"
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Remove $0": [
  null,
  "$0'ı kaldır"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "$0 hizmetini $1 bölgesinden kaldır"
 ],
 "Remove item": [
  null,
  "Öğeyi kaldır"
 ],
 "Remove service $0": [
  null,
  "$0 hizmetini kaldır"
 ],
 "Remove zone $0": [
  null,
  "$0 bölgesini kaldır"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 kaldırmak sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Cockpit hizmetinin kaldırılması web konsolunu erişilemez hale getirebilir. Bu bölgenin şu anki web konsolu bağlantınıza uygulanmadığından emin olun."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Bölgenin kaldırılması, içindeki tüm hizmetleri kaldıracak."
 ],
 "Restoring connection": [
  null,
  "Bağlantı geri yükleniyor"
 ],
 "Round robin": [
  null,
  "Döngüsel"
 ],
 "Routes": [
  null,
  "Yönlendirmeler"
 ],
 "Row expansion": [
  null,
  "Satır genişletme"
 ],
 "Row select": [
  null,
  "Satır seçimi"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Bu komutu güvenilir bir ağ üzerinden veya fiziksel olarak uzaktaki makinede çalıştırın:"
 ],
 "Runner": [
  null,
  "Çalıştırıcı"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH anahtarı"
 ],
 "SSH key login": [
  null,
  "SSH anahtarı oturum açma"
 ],
 "STP forward delay": [
  null,
  "STP yönlendirme gecikmesi"
 ],
 "STP hello time": [
  null,
  "STP merhaba süresi"
 ],
 "STP maximum message age": [
  null,
  "STP en fazla ileti yaşı"
 ],
 "STP priority": [
  null,
  "STP önceliği"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Search domain": [
  null,
  "Etki alanını ara"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Güvenlik Gelişmiş Linux yapılandırması ve sorun giderme"
 ],
 "Select method": [
  null,
  "Yöntem seç"
 ],
 "Sending": [
  null,
  "Gönderilen"
 ],
 "Server": [
  null,
  "Sunucu"
 ],
 "Server has closed the connection.": [
  null,
  "Sunucu bağlantıyı kapattı."
 ],
 "Service": [
  null,
  "Hizmet"
 ],
 "Services": [
  null,
  "Hizmetler"
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Set to": [
  null,
  "Şuna ayarla"
 ],
 "Shared": [
  null,
  "Paylaşılan"
 ],
 "Shell script": [
  null,
  "Kabuk betiği"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Onay parolasını göster"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Sorted from least to most trusted": [
  null,
  "En azdan en çok güvenilene doğru sıralandı"
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protokolü"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protokolü (STP)"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Stable": [
  null,
  "Kararlı"
 ],
 "Start service": [
  null,
  "Hizmeti başlat"
 ],
 "Status": [
  null,
  "Durum"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "Sticky": [
  null,
  "Yapışkan"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Strong password": [
  null,
  "Güçlü parola"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Switch of $0": [
  null,
  "$0 anahtarı"
 ],
 "Switch off $0": [
  null,
  "$0 arayüzünü kapat"
 ],
 "Switch on $0": [
  null,
  "$0 arayüzünü aç"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 kapatmak sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 açmak sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Team": [
  null,
  "Takım"
 ],
 "Team port": [
  null,
  "Takım bağlantı noktası"
 ],
 "Team port settings": [
  null,
  "Takım bağlantı noktası ayarları"
 ],
 "Testing connection": [
  null,
  "Bağlantı deneniyor"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerindeki $1 kullanıcısının $0 SSH anahtarı, $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "$0 SSH anahtarı, oturumun geri kalanı için kullanılabilir olacak ve diğer anamakinelerde oturum açmak için de kullanılabilecektir."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı ve anamakine bir parola ile oturum açmaya izin vermiyor. Lütfen $1 konumundaki anahtarın parolasını sağlayın."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı. Oturum açma parolanızla veya $1 konumundaki anahtarın parolasını sağlayarak oturum açabilirsiniz."
 ],
 "The cockpit service is automatically included": [
  null,
  "Cockpit hizmeti otomatik olarak dahil edildi"
 ],
 "The fingerprint should match:": [
  null,
  "Parmak izi eşleşmeli:"
 ],
 "The key password can not be empty": [
  null,
  "Anahtar parolası boş olamaz"
 ],
 "The key passwords do not match": [
  null,
  "Anahtar parolaları eşleşmiyor"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Oturum açmış kullanıcının sistem değişikliklerini görüntülemesine izin verilmiyor"
 ],
 "The password can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Ortaya çıkan parmak izinin, e-posta dahil olmak üzere herkese açık yöntemlerle paylaşılması uygundur."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Ortaya çıkan parmak izi, e-posta dahil ortak yöntemler aracılığıyla paylaşılabilir. Eğer başka birinden doğrulamayı sizin için yapmasını istiyorsanız, sonuçları herhangi bir yöntemi kullanarak gönderebilirler."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Sunucu, desteklenen herhangi bir yöntemi kullanarak kimlik doğrulamayı reddetti."
 ],
 "There are no active services in this zone": [
  null,
  "Bu bölgede etkin hizmetler yok"
 ],
 "This device cannot be managed here.": [
  null,
  "Bu aygıt burada yönetilemez."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Bu araç, SELinux ilkesini yapılandırır ve ilke ihlallerinin anlaşılmasına ve çözülmesine yardımcı olabilir."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Bu araç, sistemi çekirdek çökme dökümlerini yazmak için yapılandırır. \"Yerel\" (disk), \"ssh\" ve \"nfs\" döküm hedeflerini destekler."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Bu araç, çalışan sistemden bir yapılandırma ve tanılama bilgileri arşivi oluşturur. Arşiv, kayıt veya izleme amacıyla yerel veya merkezi olarak depolanabilir veya teknik hata bulma ve hata ayıklamaya yardımcı olması için teknik destek temsilcilerine, geliştiricilere veya sistem yöneticilerine gönderilebilir."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Bu araç, dosya sistemleri, LVM2 birim grupları ve NFS bağlamaları gibi yerel depolamayı yönetir."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Bu araç, NetworkManager ve Firewalld kullanarak birleştirmeler, köprüler, takımlar, VLAN'lar ve güvenlik duvarları gibi ağları yönetir. NetworkManager, Ubuntu'nun varsayılan systemd-networkd ve Debian'ın ifupdown betikleriyle uyumsuzdur."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Bu bölge cockpit hizmetini içeriyor. Bu bölgenin geçerli web konsolu bağlantınıza uygulanmadığından emin olun."
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Bağlantınızın kötü niyetli bir üçüncü tarafça engellenmediğinden emin olmak için lütfen anamakine anahtar parmak izini doğrulayın:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Bir parmak izini doğrulamak için makinede fiziksel olarak bulunurken veya güvenilir bir ağ aracılığıyla $0 üzerinde aşağıdakileri çalıştırın:"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Too much data": [
  null,
  "Çok fazla veri"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transmitting": [
  null,
  "Aktarma"
 ],
 "Troubleshoot…": [
  null,
  "Sorun gider…"
 ],
 "Trust and add host": [
  null,
  "Anamakineye güven ve ekle"
 ],
 "Trust level": [
  null,
  "Güven seviyesi"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 için oturum açılamıyor. Lütfen parolayı girin."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 üzerinde oturum açılamıyor. Anamakine, parola ile oturum açmayı veya SSH anahtarlarınızdan hiçbirini kabul etmiyor."
 ],
 "Unexpected error": [
  null,
  "Beklenmeyen hata"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Unknown \"$0\"": [
  null,
  "Bilinmeyen \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Bilinmeyen yapılandırma"
 ],
 "Unknown host: $0": [
  null,
  "Bilinmeyen anamakine: $0"
 ],
 "Unknown service name": [
  null,
  "Bilinmeyen hizmet adı"
 ],
 "Unmanaged interfaces": [
  null,
  "Yönetilmeyen arayüzler"
 ],
 "Untrusted host": [
  null,
  "Güvenilmeyen anamakine"
 ],
 "Use $0": [
  null,
  "$0 kullan"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN kimliği"
 ],
 "Verify fingerprint": [
  null,
  "Parmak izini doğrula"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "View automation script": [
  null,
  "Otomatikleştirme betiğini görüntüle"
 ],
 "Visit firewall": [
  null,
  "Güvenlik duvarını ziyaret et"
 ],
 "Waiting": [
  null,
  "Bekleniyor"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Weak password": [
  null,
  "Zayıf parola"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux sunucuları için Web Konsolu"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "\"Otomatik\" olarak ayarlanacak"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Evet"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "İlk kez $0 için bağlanıyorsunuz."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Güvenlik duvarını değiştirmek için yetkili değilsiniz."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Your session has been terminated.": [
  null,
  "Oturumunuz sonlandırıldı."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Oturumunuzun süresi doldu. Lütfen tekrar oturum açın."
 ],
 "Zone": [
  null,
  "Bölge"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "in less than a minute": [
  null,
  "bir dakikadan az süre"
 ],
 "less than a minute ago": [
  null,
  "bir dakikadan az bir süre önce"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ],
 "wireguard-tools package is not installed": [
  null,
  "wireguard-tools paketi kurulu değil"
 ]
});
