cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 aktivní zóna",
  "$0 aktivní zóny",
  "$0 aktivních zón"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 key changed": [
  null,
  "$0 klíč změněn"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainstalováno."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "$0 zone": [
  null,
  "zóna $0"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 není nainstalovaná kompatibilní verze Cockpit."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Síťové spřažení spojuje vícero síťových rozhraní do jednoho logického s vyšší propustností nebo odolností proti výpadku."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vytvořen nový SSH klíč pro $1 na $2 a bude přidán do souboru $3 od $4 na $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP monitorování"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Active": [
  null,
  "Aktivní"
 ],
 "Active backup": [
  null,
  "Aktivní záloha"
 ],
 "Adaptive load balancing": [
  null,
  "Přizpůsobující se rozkládání zátěže"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Přizpůsobující se rozkládání přenosové zátěže odesílání"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "Add DNS server": [
  null,
  "Přidat DNS server"
 ],
 "Add VLAN": [
  null,
  "Přidat VLAN"
 ],
 "Add VPN": [
  null,
  "Přidat VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Přidat WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "Přidat novou zónu"
 ],
 "Add address": [
  null,
  "Přidat adresu"
 ],
 "Add bond": [
  null,
  "Přidat spřažení linek (bond)"
 ],
 "Add bridge": [
  null,
  "Přidat síťový most"
 ],
 "Add member": [
  null,
  "Přidat člena"
 ],
 "Add new zone": [
  null,
  "Přidat novou zónu"
 ],
 "Add peer": [
  null,
  "Přidat protějšek"
 ],
 "Add ports": [
  null,
  "Přidat porty"
 ],
 "Add ports to $0 zone": [
  null,
  "Přidat porty do zóny $0"
 ],
 "Add route": [
  null,
  "Přidat trasu"
 ],
 "Add search domain": [
  null,
  "Přidat prohledávanou doménu"
 ],
 "Add services": [
  null,
  "Přidat služby"
 ],
 "Add services to $0 zone": [
  null,
  "Přidat služby do zóny $0"
 ],
 "Add services to zone $0": [
  null,
  "Přidat služby do zóny $0"
 ],
 "Add team": [
  null,
  "Přidat spřažení (team)"
 ],
 "Add zone": [
  null,
  "Přidat zónu"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Přidání $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Přidání uživatelsky určených portů znovunačte firewalld. To povede ke ztrátě jakéhokoli nastavení, které bylo učiněno pouze za běhu a neuloženo!"
 ],
 "Additional DNS $val": [
  null,
  "Další DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Další DNS domény k prohledávání $val"
 ],
 "Additional address $val": [
  null,
  "Další adresa $val"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Additional ports": [
  null,
  "Další porty"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "Address $val": [
  null,
  "Adresa $val"
 ],
 "Addresses": [
  null,
  "Adresy"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresy nemají správný formát"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Allowed IPs": [
  null,
  "IP adresy, které umožněny"
 ],
 "Allowed addresses": [
  null,
  "Adresy, které umožněny"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Authenticating": [
  null,
  "Ověřování se"
 ],
 "Authentication": [
  null,
  "Ověření se"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ],
 "Authorize SSH key": [
  null,
  "Pověřit SSH klíč"
 ],
 "Automatic": [
  null,
  "Automaticky"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automaticky (pouze DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Automatické použití NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické použití dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatické použití uvedených NTP serverů"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "Balancer": [
  null,
  "Rozkládání zátěže"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Bond": [
  null,
  "Spřažení linek (bond)"
 ],
 "Bridge": [
  null,
  "Most"
 ],
 "Bridge port": [
  null,
  "Port mostu"
 ],
 "Bridge port settings": [
  null,
  "Nastavení portu mostu"
 ],
 "Broadcast": [
  null,
  "Vysílání"
 ],
 "Broken configuration": [
  null,
  "Chybné nastavení"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "Carrier": [
  null,
  "Nosný signál"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Change the settings": [
  null,
  "Změnit nastavení"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Změněné klíče jsou často výsledkem přeinstalace operačního systému. Nicméně, neočekávaná změna může značit pokus třetí strany o vložení se do vaší komunikace."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Změna nastavení přeruší spojení se serverem a znepřístupní tak uživatelské rozhraní pro jeho správu."
 ],
 "Checking IP": [
  null,
  "Kontroluje se IP adresa"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je nástroj, který usnadňuje správu linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit není nainstalován"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce systémů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Je možné souběžně sledovat a spravovat několik serverů naráz. Stačí je jedním kliknutím přidat a vaše stroje se budou starat o své kamarády."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Jsou přijímány čárkou oddělované porty, rozsahy a služby"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Configuring": [
  null,
  "Nastavuje se"
 ],
 "Configuring IP": [
  null,
  "Nastavuje se IP adresa"
 ],
 "Confirm key password": [
  null,
  "Potvrdit heslo ke klíči"
 ],
 "Confirm removal of $0": [
  null,
  "Potvrdit odebrání $0"
 ],
 "Connect automatically": [
  null,
  "Připojit se automaticky"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Connection will be lost": [
  null,
  "Spojení bude ztraceno"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copied": [
  null,
  "Zkopírováno"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvořit nový SSH klíč a pověřit ho"
 ],
 "Create it": [
  null,
  "Vytvořit to"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořte nový soubor s úlohou s tímto obsahem."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Vytvoření tohoto $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Uživatelsky určené porty"
 ],
 "Custom zones": [
  null,
  "Uživatelsky určené zóny"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Prohledávané DNS domény"
 ],
 "DNS search domains $val": [
  null,
  "Prohledávat DNS domény $val"
 ],
 "Deactivating": [
  null,
  "Deaktivuje se"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Delete $0": [
  null,
  "Smazat $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Smazání $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Disable the firewall": [
  null,
  "Vypnout bránu firewall"
 ],
 "Disabled": [
  null,
  "Vypnuto"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Edit VLAN settings": [
  null,
  "Upravit nastavení VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Upravit WireGuard VPN"
 ],
 "Edit bond settings": [
  null,
  "Upravit nastavení spřažení linek (bond)"
 ],
 "Edit bridge settings": [
  null,
  "Upravit nastavení mostu"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Upravit uživatelsky určenou službu v zóně $0"
 ],
 "Edit rules and zones": [
  null,
  "Upravit pravidla a zóny"
 ],
 "Edit service": [
  null,
  "Upravit službu"
 ],
 "Edit service $0": [
  null,
  "Upravit službu $0"
 ],
 "Edit team settings": [
  null,
  "Upravit nastavení spřažení (team)"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Enable or disable the device": [
  null,
  "Povolit nebo zakázat zařízení"
 ],
 "Enable service": [
  null,
  "Zapnout službu"
 ],
 "Enable the firewall": [
  null,
  "Zapnout bránu firewall"
 ],
 "Enabled": [
  null,
  "Povoleno"
 ],
 "Endpoint": [
  null,
  "Koncový bod"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Je třeba zadat koncový bod sloužící jako „server“ v podobě stroj:port, jinak je možné ponechat nevyplněné."
 ],
 "Enter a valid MAC address": [
  null,
  "Zadejte platnou MAC adresu"
 ],
 "Entire subnet": [
  null,
  "Celá podsíť"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC adresa"
 ],
 "Ethernet MTU": [
  null,
  "MTU ethernetu"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Příklad: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Příklad: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Failed": [
  null,
  "Neúspěšné"
 ],
 "Failed to add port": [
  null,
  "Přidání portu se nezdařilo"
 ],
 "Failed to add service": [
  null,
  "Službu se nepodařilo přidat"
 ],
 "Failed to add zone": [
  null,
  "Zónu se nepodařilo přidat"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "Failed to edit service": [
  null,
  "Službu se nepodařilo upravit"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Failed to save settings": [
  null,
  "Nastavení se nepodařilo uložit"
 ],
 "Filter services": [
  null,
  "Filtrovat služby"
 ],
 "Firewall": [
  null,
  "Brána firewall"
 ],
 "Firewall is not available": [
  null,
  "Brána firewall není k dispozici"
 ],
 "Forward delay $forward_delay": [
  null,
  "Prodleva přeposílání $forward_delay"
 ],
 "Gateway": [
  null,
  "Brána"
 ],
 "General": [
  null,
  "Obecné"
 ],
 "Generated": [
  null,
  "Vytvořeno"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "Group": [
  null,
  "Skupina"
 ],
 "Hair pin mode": [
  null,
  "Hair pin režim"
 ],
 "Hairpin mode": [
  null,
  "Hair pin režim"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Hello time $hello_time": [
  null,
  "Oznamovací čas $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "ID $id": [
  null,
  "Identif. $id"
 ],
 "IP address": [
  null,
  "IP adresa"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP adresa se směrovací předponou (prefix). Vícero hodnot oddělujte čárkou. Příklad: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "IPv4 adresy"
 ],
 "IPv4 settings": [
  null,
  "Nastavení IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Nastavení IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Pokud nevyplněno, identifikátor bude vytvořen na základě souvisejících služeb na portu a čísel portů"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Pokud se otisk shoduje, klikněte na „Důvěřovat a přidat stroj“. V opačném případě se nepřipojujte a obraťte se na správce."
 ],
 "Ignore": [
  null,
  "Ignorovat"
 ],
 "Inactive": [
  null,
  "Neaktivní"
 ],
 "Included services": [
  null,
  "Obsažené služby"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Ve výchozím stavu jsou příchozí požadavky blokovány. Ty odchozí nejsou."
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Interface": [
  null,
  "Rozhraní",
  "Rozhraní",
  "Rozhraní"
 ],
 "Interface members": [
  null,
  "Členové rozhraní"
 ],
 "Interfaces": [
  null,
  "Rozhraní"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Invalid address $0": [
  null,
  "Neplatná adresa $0"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná oprávnění k souboru"
 ],
 "Invalid metric $0": [
  null,
  "Neplatná metrika $0"
 ],
 "Invalid port number": [
  null,
  "Neplatné číslo portu"
 ],
 "Invalid prefix $0": [
  null,
  "Neplatná předpona $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Neplatná předpona nebo maska sítě $0"
 ],
 "Invalid range": [
  null,
  "Neplatný rozsah"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Keep connection": [
  null,
  "Zachovat spojení"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Key password": [
  null,
  "Heslo ke klíči"
 ],
 "LACP key": [
  null,
  "LACP klíč"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Learn more": [
  null,
  "Zjistit více"
 ],
 "Link down delay": [
  null,
  "Prodleva neaktivní linky"
 ],
 "Link local": [
  null,
  "Místní propoj"
 ],
 "Link monitoring": [
  null,
  "Monitorování linky"
 ],
 "Link up delay": [
  null,
  "Prodleva aktivní linky"
 ],
 "Link watch": [
  null,
  "Hlídání linky"
 ],
 "Listen port": [
  null,
  "Port na kterém očekávat spojení"
 ],
 "Listen port must be a number": [
  null,
  "Je třeba, aby port, na kterém očekávat spojení, bylo číslo"
 ],
 "Load balancing": [
  null,
  "Rozkládání zátěže"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "Log in": [
  null,
  "Přihlásit se"
 ],
 "Log in to $0": [
  null,
  "Přihlásit se k $0"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (doporučeno)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "Je třeba, aby MTU bylo kladné číslo"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "Managed interfaces": [
  null,
  "Spravovaná rozhraní"
 ],
 "Manual": [
  null,
  "Ruční"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximální stáří zpráv $max_age"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Metric": [
  null,
  "Metrika"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Mode": [
  null,
  "Režim"
 ],
 "Monitoring interval": [
  null,
  "Interval monitorování"
 ],
 "Monitoring targets": [
  null,
  "Cíle monitorování"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Je možné zadat vícero adres (oddělovaných čárkami nebo mezerami)."
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Network bond": [
  null,
  "Síťové spřažení linek (bond)"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Síťová zařízení a grafy vyžadují NetworkManager"
 ],
 "Network logs": [
  null,
  "Záznamy událostí sítě"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager není nainstalovaný"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager není spuštěný"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "No": [
  null,
  "Ne"
 ],
 "No carrier": [
  null,
  "Bez signálu"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "No description available": [
  null,
  "Není k dispozici žádný popis"
 ],
 "No peers added.": [
  null,
  "Nepřidány žádné protějšky."
 ],
 "No results found": [
  null,
  "Nenalezeny žádné výsledky"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "None": [
  null,
  "Žádné"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Nemáte oprávnění pro vypnutí brány firewall"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Nemáte oprávnění pro zapnutí brány firewall"
 ],
 "Not available": [
  null,
  "Není k dispozici"
 ],
 "Not permitted to configure network devices": [
  null,
  "Nemáte oprávnění nastavovat síťová zařízení"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Options": [
  null,
  "Přepínače"
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Parent": [
  null,
  "Nadřazené"
 ],
 "Parent $parent": [
  null,
  "Nadřazené $parent"
 ],
 "Part of $0": [
  null,
  "Součástí $0"
 ],
 "Passive": [
  null,
  "Pasivní"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nepřijato"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Paste existing key": [
  null,
  "Vložit existující klíč"
 ],
 "Path cost": [
  null,
  "Náklady trasy"
 ],
 "Path cost $path_cost": [
  null,
  "Náklady trasy $path_cost"
 ],
 "Path to file": [
  null,
  "Popis umístění souboru"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Protějšek č.$0 nemá platný port koncového bodu. Je třeba, aby port bylo číslo."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "Protějšek č.$0 nemá platný port koncového bodu. Je třeba, aby bylo zadáno jako stroj:port, např. 1.2.3.4:51820 nebo example.com:51820"
 ],
 "Peers": [
  null,
  "Protějšky"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Protějšky jsou ostatní stroje, které se připojují k tomuto. Veřejné klíč z ostatních strojů budou sdíleny mezi sebou."
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "Permanent": [
  null,
  "Trvalá"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Ping interval": [
  null,
  "Interval pro ping"
 ],
 "Ping target": [
  null,
  "Cíl pro ping"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Please install the $0 package": [
  null,
  "Nainstalujte balíček $0"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Prefix length": [
  null,
  "Délka předpony"
 ],
 "Prefix length or netmask": [
  null,
  "Délka předpony nebo maska sítě"
 ],
 "Preparing": [
  null,
  "Příprava"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Preserve": [
  null,
  "Zachovat"
 ],
 "Primary": [
  null,
  "Primární"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Priority $priority": [
  null,
  "Priorita $priority"
 ],
 "Private key": [
  null,
  "Soukromý klíč"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "Public key": [
  null,
  "Veřejná část klíče"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Veřejný klíč bude vytvořen v okamžiku zadání platného soukromého"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Random": [
  null,
  "Náhodné"
 ],
 "Range": [
  null,
  "Rozsah"
 ],
 "Range must be strictly ordered": [
  null,
  "Je třeba, aby rozsah byl striktně řazený"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Receiving": [
  null,
  "Příchozí"
 ],
 "Regenerate": [
  null,
  "Znovu vytvořit"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Remove $0": [
  null,
  "Odebrat $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Odebrat službu $0 ze zóny $1"
 ],
 "Remove item": [
  null,
  "Odebrat položku"
 ],
 "Remove service $0": [
  null,
  "Odebrat službu $0"
 ],
 "Remove zone $0": [
  null,
  "Odebrat zónu $0"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Odebrání $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Odebrání služby cockpit může vést k tomu, že webová konzole přestane být dostupná. Ověřte, že se tato zóna nevztahuje na vaše stávající spojení s touto webovou konzolí."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Odebrání zóny odebere také všechny služby, které obsahuje."
 ],
 "Restoring connection": [
  null,
  "Obnovování spojení"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Trasy"
 ],
 "Row expansion": [
  null,
  "Rozbalení řádku"
 ],
 "Row select": [
  null,
  "Výběr řádku"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdáleném stroji spusťte – přes důvěryhodnou síť nebo fyzicky přímo na něm – tento příkaz:"
 ],
 "Runner": [
  null,
  "Spouštěč"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH klíč"
 ],
 "SSH key login": [
  null,
  "Přihlášení SSH klíčem"
 ],
 "STP forward delay": [
  null,
  "STP prodleva přeposílání"
 ],
 "STP hello time": [
  null,
  "STP uvítací doba"
 ],
 "STP maximum message age": [
  null,
  "STP maximální stáří zprávy"
 ],
 "STP priority": [
  null,
  "STP priorita"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Search domain": [
  null,
  "Prohledávané domény"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "Select method": [
  null,
  "Vybrat metodu"
 ],
 "Sending": [
  null,
  "Odchozí"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Set to": [
  null,
  "Nastavit na"
 ],
 "Shared": [
  null,
  "Sdílené"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Sorted from least to most trusted": [
  null,
  "Seřazeno od nejméně po nejvíce důvěryhodné"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Stable": [
  null,
  "Stabilní"
 ],
 "Start service": [
  null,
  "Spustit službu"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "Sticky": [
  null,
  "Lepkavé"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Switch of $0": [
  null,
  "Přepnutí $0"
 ],
 "Switch off $0": [
  null,
  "Vypnout $0"
 ],
 "Switch on $0": [
  null,
  "Zapnout $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Vypnutí $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Zapnutí $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Team": [
  null,
  "Spřažení linek (team)"
 ],
 "Team port": [
  null,
  "Port spřažení linek (team)"
 ],
 "Team port settings": [
  null,
  "Nastavení portu spřažení linek (team)"
 ],
 "Testing connection": [
  null,
  "Zkouška spojení"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH klíč $0 uživatele $1 na $2 bude přidán do souboru $3 uživatele $4 na $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH klíč $0 bude zpřístupněn po celou relaci a bude k dispozici také pro přihlašování se k ostatním strojům."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "The cockpit service is automatically included": [
  null,
  "Služba cockpit je obsažena automaticky"
 ],
 "The fingerprint should match:": [
  null,
  "Otisk by se měl shodovat:"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ke klíči je třeba vyplnit"
 ],
 "The key passwords do not match": [
  null,
  "Zadání hesla ke klíči se neshodují"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "The password can not be empty": [
  null,
  "Heslo je třeba vyplnit"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný otisk je možné sdílet veřejnými způsoby, včetně e-mailu."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný otisk je možné bez problémů sdílet prostřednictvím veřejných metod, včetně e-mailu. Pokud někoho jiného požádáte, aby pro vás ověřil, může výsledky poslat libovolnou metodou."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "There are no active services in this zone": [
  null,
  "V této zóně se nenacházejí žádné aktivní služby"
 ],
 "This device cannot be managed here.": [
  null,
  "Toto zařízení zde nelze spravovat."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje zásady pro SELinux a může pomoci s porozuměním a řešením jejich porušení."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tento nástroj nastavuje systém tak, aby byly zapisovány výpisy pádů jádra. Podporuje cíle výstupu „local“ (disk), „ssh“ a „nfs“."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení linek (typu bond i tým), mosty, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s výchozím stavem v Ubuntu (to používá systemd-networkd) a skripty ifupdown v distribuci Debian."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Tato zóna obsahuje službu cockpit. Ověřte, že se tato zóna nevztahuje na vaše stávající spojení s touto webovou konzolí."
 ],
 "Time zone": [
  null,
  "Časové pásmo"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Abyste zajistili, že do vašeho připojení není zasahováno záškodnickou třetí stranou, ověřte otisk klíče hostitele:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pokud chcete otisk ověřit, spusťte následující na $0 když jste fyzicky u stroje nebo prostřednictvím důvěryhodné sítě:"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Transmitting": [
  null,
  "Přenáší se"
 ],
 "Troubleshoot…": [
  null,
  "Řešit potíže…"
 ],
 "Trust and add host": [
  null,
  "Důvěřovat a přidat hostitele"
 ],
 "Trust level": [
  null,
  "Stupeň důvěryhodnosti"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nepodařilo se přihlásit k $0 pomocí ověření se SSH klíčem. Prosím zadejte heslo."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedaří se přihlásit k $0. Hostitel nepřijímá přihlášení heslem nebo žádný z vašich SSH klíčů."
 ],
 "Unexpected error": [
  null,
  "Neočekávaná chyba"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Unknown \"$0\"": [
  null,
  "Neznámé „$0“"
 ],
 "Unknown configuration": [
  null,
  "Neznámé nastavení"
 ],
 "Unknown host: $0": [
  null,
  "Neznámý hostitel: $0"
 ],
 "Unknown service name": [
  null,
  "Neznámý název služby"
 ],
 "Unmanaged interfaces": [
  null,
  "Nespravovaná rozhraní"
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "Identif. VLAN"
 ],
 "Verify fingerprint": [
  null,
  "Ověřit otisk"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Waiting": [
  null,
  "Čeká se"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Bude nastaveno na „Automaticky“"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Ano"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 se připojujete poprvé."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Nemáte oprávnění upravovat bránu firewall."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "in less than a minute": [
  null,
  "za méně než minutu"
 ],
 "less than a minute ago": [
  null,
  "před méně než minutou"
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "wireguard-tools package is not installed": [
  null,
  "není nainstalovaný balíček wireguard-tools"
 ]
});
