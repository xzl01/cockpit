cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 zone active",
  "$0 zones actives"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 exited with code $1": [
  null,
  "$0 quitté avec le code $1"
 ],
 "$0 failed": [
  null,
  "$0 échoué"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun référentiel."
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 killed avec un signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "$0 zone": [
  null,
  "$0 zone"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "1 minute": [
  null,
  "1 minute"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "20 minutes": [
  null,
  "20 minutes"
 ],
 "40 minutes": [
  null,
  "40 minutes"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "60 minutes": [
  null,
  "60 minutes"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Une version compatible de Cockpit n’est pas installée sur $0."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Une agrégation réseau combine plusieurs interfaces réseau en une seule interface logique avec un débit plus élevé ou une redondance."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Une nouvelle clé SSH à $0 sera créée pour $1 sur $2 et elle sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Surveillance ARP"
 ],
 "ARP ping": [
  null,
  "Ping ARP"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Acceptable password": [
  null,
  "Mot de passe acceptable"
 ],
 "Active": [
  null,
  "Actif"
 ],
 "Active backup": [
  null,
  "Sauvegarde active"
 ],
 "Adaptive load balancing": [
  null,
  "Répartition adaptative de la charge"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Répartition adaptative de la charge d’émission"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "Add DNS server": [
  null,
  "Ajouter le serveur DNS"
 ],
 "Add VLAN": [
  null,
  "Ajouter un VLAN"
 ],
 "Add VPN": [
  null,
  "Ajouter un VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Ajouter un VPN WireGuard"
 ],
 "Add a new zone": [
  null,
  "Ajouter une nouvelle zone"
 ],
 "Add address": [
  null,
  "Ajouter une adresse"
 ],
 "Add bond": [
  null,
  "Ajouter un lien"
 ],
 "Add bridge": [
  null,
  "Ajouter un pont"
 ],
 "Add member": [
  null,
  "Ajouter un membre"
 ],
 "Add new zone": [
  null,
  "Ajouter une nouvelle zone"
 ],
 "Add peer": [
  null,
  "Ajouter un pair"
 ],
 "Add ports": [
  null,
  "Ajouter des ports"
 ],
 "Add ports to $0 zone": [
  null,
  "Ajouter des ports à la zone $0"
 ],
 "Add route": [
  null,
  "Ajouter une route"
 ],
 "Add search domain": [
  null,
  "Ajouter un domaine de recherche"
 ],
 "Add services": [
  null,
  "Ajouter des services"
 ],
 "Add services to $0 zone": [
  null,
  "Ajouter des services à la zone $0"
 ],
 "Add services to zone $0": [
  null,
  "Ajouter des services à la zone $0"
 ],
 "Add team": [
  null,
  "Ajouter une équipe"
 ],
 "Add zone": [
  null,
  "Ajouter une zone"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L’ajout de $0 interrompra la connexion au serveur et rendra l’interface d’administration indisponible."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Ajouter des ports personnalisés rechargera firewalld. Le rechargement de la configuration entraînera la perte de celle en cours d’exécution !"
 ],
 "Additional DNS $val": [
  null,
  "DNS supplémentaire $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Domaines de recherche DNS supplémentaires $val"
 ],
 "Additional address $val": [
  null,
  "Adresse supplémentaire $val"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Additional ports": [
  null,
  "Ports additionnels"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address $val": [
  null,
  "Adresse $val"
 ],
 "Addresses": [
  null,
  "Adresses"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Les adresses ne sont pas formatées correctement"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration avec la console web de Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Allowed IPs": [
  null,
  "IP autorisées"
 ],
 "Allowed addresses": [
  null,
  "Adresses autorisées"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentation des rôles Ansible"
 ],
 "Authenticating": [
  null,
  "Authentification"
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Une authentification est nécessaire pour effectuer les tâches privilégiées dans la console web Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autoriser la clé SSH"
 ],
 "Automatic": [
  null,
  "Automatique"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatique (DHCP uniquement)"
 ],
 "Automatically using NTP": [
  null,
  "Utiliser automatiquement NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilisation automatique de serveurs NTP supplémentaires"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utiliser automatiquement des serveurs NTP spécifiques"
 ],
 "Automation script": [
  null,
  "Script d’automatisation"
 ],
 "Balancer": [
  null,
  "Répartiteur de charge"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Bond": [
  null,
  "Liaison"
 ],
 "Bridge": [
  null,
  "Pont"
 ],
 "Bridge port": [
  null,
  "Port du pont"
 ],
 "Bridge port settings": [
  null,
  "Paramètres du port du pont"
 ],
 "Broadcast": [
  null,
  "Diffuser"
 ],
 "Broken configuration": [
  null,
  "Configuration endommagée"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossible de transférer les identifiants de connexion"
 ],
 "Cannot schedule event in the past": [
  null,
  "Impossible de planifier un événement dans le passé"
 ],
 "Carrier": [
  null,
  "Opérateur"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Change system time": [
  null,
  "Modifier l’heure du système"
 ],
 "Change the settings": [
  null,
  "Modifier les paramètres"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La modification des paramètres interrompt la connexion au serveur et rend l’interface utilisateur d’administration indisponible."
 ],
 "Checking IP": [
  null,
  "Vérification de l’adresse IP"
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuration du cockpit de NetworkManager et Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit n’a pas pu contacter l’hôte indiqué."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit n’est pas compatible avec le logiciel sur le système."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit n’est pas installé"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit n’est pas installé sur le système."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Collecte et regroupement des données de diagnostic et d'assistance"
 ],
 "Collect kernel crash dumps": [
  null,
  "Collecter les vidages de mémoire sur incidents du noyau"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Les ports, les plages et les services séparés par des virgules sont acceptés"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Configuring": [
  null,
  "Configuration en cours"
 ],
 "Configuring IP": [
  null,
  "Configuration de l’adresse IP"
 ],
 "Confirm key password": [
  null,
  "Confirmer le mot de passe de la clé"
 ],
 "Confirm removal of $0": [
  null,
  "Confirmer la suppression de $0"
 ],
 "Connect automatically": [
  null,
  "Connecter automatiquement"
 ],
 "Connection has timed out.": [
  null,
  "La connexion a expiré."
 ],
 "Connection will be lost": [
  null,
  "La connexion sera perdue"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copié"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Create $0": [
  null,
  "Créer $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Créer une nouvelle clé SSH et l’autoriser"
 ],
 "Create it": [
  null,
  "Créez-le"
 ],
 "Create new task file with this content.": [
  null,
  "Créez un nouveau fichier de tâches avec ce contenu."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La création de $0 interrompra la connexion au serveur et rendra l’interface d’administration indisponible."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Inser"
 ],
 "Custom ports": [
  null,
  "Ports personnalisés"
 ],
 "Custom zones": [
  null,
  "Zones personnalisées"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Domaines de recherche DNS"
 ],
 "DNS search domains $val": [
  null,
  "Domaines de recherche DNS $val"
 ],
 "Deactivating": [
  null,
  "Désactivation en cours"
 ],
 "Delay": [
  null,
  "Retard"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Delete $0": [
  null,
  "Supprimer $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La suppression de $0 interrompra la connexion au serveur et rendra l’interface d’administration indisponible."
 ],
 "Description": [
  null,
  "Description"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Disable the firewall": [
  null,
  "Désactiver le pare-feu"
 ],
 "Disabled": [
  null,
  "Désactivé"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "Downloading $0": [
  null,
  "Téléchargement de $0"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Edit VLAN settings": [
  null,
  "Modifier les paramètres VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Modifier un VPN WireGuard"
 ],
 "Edit bond settings": [
  null,
  "Modifier les paramètres de liaison"
 ],
 "Edit bridge settings": [
  null,
  "Modifier les paramètres de pont"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Modifier le service personnalisé dans la zone $0"
 ],
 "Edit rules and zones": [
  null,
  "Modifier les règles et les zones"
 ],
 "Edit service": [
  null,
  "Modifier le service"
 ],
 "Edit service $0": [
  null,
  "Service d'édition $0"
 ],
 "Edit team settings": [
  null,
  "Modifier les paramètres de l'équipe"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Enable or disable the device": [
  null,
  "Activer ou désactiver le périphérique"
 ],
 "Enable service": [
  null,
  "Activer le service"
 ],
 "Enable the firewall": [
  null,
  "Activer le pare-feu"
 ],
 "Enabled": [
  null,
  "Activée"
 ],
 "Endpoint": [
  null,
  "Point de terminaison"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Le point de terminaison agissant comme un \"serveur\" doit être spécifié au format hôte:port, sinon le champ peut être laissé vide."
 ],
 "Enter a valid MAC address": [
  null,
  "Entrez une adresse MAC valide"
 ],
 "Entire subnet": [
  null,
  "Ensemble du sous-réseau"
 ],
 "Ethernet MAC": [
  null,
  "MAC Ethernet"
 ],
 "Ethernet MTU": [
  null,
  "MTU Ethernet"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Exemple : 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Exemple : 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Failed": [
  null,
  "Échoué"
 ],
 "Failed to add port": [
  null,
  "Échec de l’ajout du port"
 ],
 "Failed to add service": [
  null,
  "Échec de l’ajout du service"
 ],
 "Failed to add zone": [
  null,
  "Échec de l’ajout de la zone"
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "Failed to edit service": [
  null,
  "Échec de la modification du service"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Failed to save settings": [
  null,
  "Échec de l’enregistrement des paramètres"
 ],
 "Filter services": [
  null,
  "Services de filtrage"
 ],
 "Firewall": [
  null,
  "Pare-feu"
 ],
 "Firewall is not available": [
  null,
  "Le pare-feu n’est pas disponible"
 ],
 "Forward delay $forward_delay": [
  null,
  "Délai d’attente de redirection $forward_delay"
 ],
 "Gateway": [
  null,
  "Passerelle"
 ],
 "General": [
  null,
  "Général"
 ],
 "Generated": [
  null,
  "Généré"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "Group": [
  null,
  "Groupe"
 ],
 "Hair pin mode": [
  null,
  "Mode Hair Pin"
 ],
 "Hairpin mode": [
  null,
  "Mode Hair Pin"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "Hello time $hello_time": [
  null,
  "Bonjour $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe."
 ],
 "Host key is incorrect": [
  null,
  "La clé de l’hôte est incorrecte"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "Adresse IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Adresse IP avec préfixe de routage. Séparez les valeurs multiples par une virgule. Exemple : 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "Adresses IPv4"
 ],
 "IPv4 settings": [
  null,
  "Paramètres IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Paramètres IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "S’il est laissé vide, l’ID sera généré sur la base des services et des numéros de port associés"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et ajouter l'hôte ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "Ignore": [
  null,
  "Ignorer"
 ],
 "Inactive": [
  null,
  "Inactif"
 ],
 "Included services": [
  null,
  "services inclus"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Les requêtes entrantes sont bloquées par défaut. Les requêtes sortantes ne sont pas bloquées."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Interface": [
  null,
  "Interface",
  "Interfaces"
 ],
 "Interface members": [
  null,
  "Membres de l’interface"
 ],
 "Interfaces": [
  null,
  "Interfaces"
 ],
 "Internal error": [
  null,
  "Erreur interne"
 ],
 "Invalid address $0": [
  null,
  "Adresse non valide $0"
 ],
 "Invalid date format": [
  null,
  "Format de date non valide"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de date non valide et format d’heure non valide"
 ],
 "Invalid file permissions": [
  null,
  "Les autorisations de fichier ne sont pas valides"
 ],
 "Invalid metric $0": [
  null,
  "Métrique non valide $0"
 ],
 "Invalid port number": [
  null,
  "Numéro de port invalide"
 ],
 "Invalid prefix $0": [
  null,
  "Préfixe non valide $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Préfixe ou masque de réseau non valide $0"
 ],
 "Invalid range": [
  null,
  "Plage invalide"
 ],
 "Invalid time format": [
  null,
  "Format d’heure non valide"
 ],
 "Invalid timezone": [
  null,
  "Fuseau horaire incorrect"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Keep connection": [
  null,
  "Gardez la connexion"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Key password": [
  null,
  "Mot de passe clé"
 ],
 "LACP key": [
  null,
  "Clé LACP"
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Link down delay": [
  null,
  "Délai de chute de lien"
 ],
 "Link local": [
  null,
  "Lien local"
 ],
 "Link monitoring": [
  null,
  "Surveillance du lien"
 ],
 "Link up delay": [
  null,
  "Délai d’activation de lien"
 ],
 "Link watch": [
  null,
  "Observation du lien"
 ],
 "Listen port": [
  null,
  "Port d'écoute"
 ],
 "Listen port must be a number": [
  null,
  "Le port d'écoute doit être un nombre"
 ],
 "Load balancing": [
  null,
  "L’équilibrage de charge"
 ],
 "Loading system modifications...": [
  null,
  "Chargement des modifications système..."
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Log in to $0": [
  null,
  "Connectez-vous à $0"
 ],
 "Log messages": [
  null,
  "Enregistrer les messages"
 ],
 "Login failed": [
  null,
  "Échec de la connexion"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (recommandé)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU doit être un nombre positif"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Manage storage": [
  null,
  "Gérer le stockage"
 ],
 "Managed interfaces": [
  null,
  "Interfaces non gérées"
 ],
 "Manual": [
  null,
  "Manuel"
 ],
 "Manually": [
  null,
  "Manuellement"
 ],
 "Maximum message age $max_age": [
  null,
  "Âge maximal du message $max_age"
 ],
 "Message to logged in users": [
  null,
  "Message aux utilisateurs connectés"
 ],
 "Metric": [
  null,
  "Métrique"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Mode": [
  null,
  "Mode"
 ],
 "Monitoring interval": [
  null,
  "Intervalle de surveillance"
 ],
 "Monitoring targets": [
  null,
  "Objectifs de surveillance"
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Différentes adresses peuvent être spécifiées en utilisant des virgules ou des espaces comme séparateurs."
 ],
 "NSNA ping": [
  null,
  "Ping NSNA"
 ],
 "NTP server": [
  null,
  "Serveur NTP"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Need at least one NTP server": [
  null,
  "Besoin d’au moins un serveur NTP"
 ],
 "Network bond": [
  null,
  "Agrégation de réseau"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Les périphériques réseau et les graphiques nécessitent NetworkManager"
 ],
 "Network logs": [
  null,
  "Journaux du réseau"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager n’est pas installé"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager n’est pas en cours d’exécution"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "No": [
  null,
  "Non"
 ],
 "No carrier": [
  null,
  "Pas de transporteur"
 ],
 "No delay": [
  null,
  "Aucun délai"
 ],
 "No description available": [
  null,
  "Aucune description disponible"
 ],
 "No peers added.": [
  null,
  "Aucun pair ajouté."
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "No system modifications": [
  null,
  "Aucune modification système"
 ],
 "None": [
  null,
  "Aucun"
 ],
 "Not a valid private key": [
  null,
  "Clé privée non valide"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Non autorisé à désactiver le pare-feu"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Non autorisé à activer le pare-feu"
 ],
 "Not available": [
  null,
  "Indisponible"
 ],
 "Not permitted to configure network devices": [
  null,
  "Non autorisé à configurer les périphériques réseau"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non autorisé à effectuer cette action."
 ],
 "Not synchronized": [
  null,
  "Non synchronisé"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Occurrences": [
  null,
  "Occurrences"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Options": [
  null,
  "Options"
 ],
 "Other": [
  null,
  "Autre"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "Parent": [
  null,
  "Parent"
 ],
 "Parent $parent": [
  null,
  "Parent $parent"
 ],
 "Part of $0": [
  null,
  "Partie de $0"
 ],
 "Passive": [
  null,
  "Passif"
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Password not accepted": [
  null,
  "Mot de passe non accepté"
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Paste error": [
  null,
  "Erreur de collage"
 ],
 "Paste existing key": [
  null,
  "Coller la clé existante"
 ],
 "Path cost": [
  null,
  "Coût du chemin"
 ],
 "Path cost $path_cost": [
  null,
  "Coût du chemin $path_cost"
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Le port de point de terminaison du pair n°$1 est invalide. Le port doit être un nombre."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "Le point de terminaison du pair n°$1 est invalide. Il doit être spécifié au format hôte:port, ex. 1.2.3.4:51820 ou exemple.fr:51820"
 ],
 "Peers": [
  null,
  "Pairs"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Les pairs sont d'autres machines se connectant à celle-ci. Les machines partageront leurs clés publiques entre elles."
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Ping interval": [
  null,
  "Intervalle de ping"
 ],
 "Ping target": [
  null,
  "Cible de ping"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Please install the $0 package": [
  null,
  "Veuillez installer le paquet $0"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Prefix length": [
  null,
  "Longueur du préfixe"
 ],
 "Prefix length or netmask": [
  null,
  "Longueur du préfixe ou masque de réseau"
 ],
 "Preparing": [
  null,
  "Préparation en cours"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "Preserve": [
  null,
  "Préserver"
 ],
 "Primary": [
  null,
  "Primaire"
 ],
 "Priority": [
  null,
  "Priorité"
 ],
 "Priority $priority": [
  null,
  "Priorité $priority"
 ],
 "Private key": [
  null,
  "Clé privée"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "L’invite via ssh-add a expiré"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "L’invite via ssh-keygen a expiré"
 ],
 "Public key": [
  null,
  "Clé publique"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "La clé publique sera générée une fois qu'une clé privée valide aura été saisie"
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Random": [
  null,
  "Aléatoire"
 ],
 "Range": [
  null,
  "Gamme"
 ],
 "Range must be strictly ordered": [
  null,
  "La plage doit être strictement ordonnée"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Receiving": [
  null,
  "Réception"
 ],
 "Regenerate": [
  null,
  "Régénéré"
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Remove $0": [
  null,
  "Supprimer $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Supprimer le service $0 de la zone $1"
 ],
 "Remove item": [
  null,
  "Supprimer l’élément"
 ],
 "Remove service $0": [
  null,
  "Supprimer le service $0"
 ],
 "Remove zone $0": [
  null,
  "Supprimer la zone $0"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La suppression de $0 interrompra la connexion au serveur et rendra l’interface utilisateur d’administration indisponible."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "La suppression du service de cockpit pourrait rendre la console Web inaccessible. Assurez-vous que cette zone ne s’applique pas à votre connexion actuelle à la console Web."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "La suppression de la zone supprime tous les services qui s’y trouvent."
 ],
 "Restoring connection": [
  null,
  "Restauration de la connexion"
 ],
 "Round robin": [
  null,
  "Round-robin"
 ],
 "Routes": [
  null,
  "Routes"
 ],
 "Row expansion": [
  null,
  "Agrandissement de ligne"
 ],
 "Row select": [
  null,
  "Sélection de ligne"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Exécutez cette commande sur un réseau de confiance ou en la tapant physiquement sur la machine distante :"
 ],
 "Runner": [
  null,
  "Exécuteur"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clé SSH"
 ],
 "SSH key login": [
  null,
  "Connexion par clé SSH"
 ],
 "STP forward delay": [
  null,
  "Délai de réacheminement STP"
 ],
 "STP hello time": [
  null,
  "Durée Hello STP"
 ],
 "STP maximum message age": [
  null,
  "Âge maximal de message STP"
 ],
 "STP priority": [
  null,
  "Priorité STP"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Search domain": [
  null,
  "Domaine de recherche"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuration et dépannage de Linux avec renforcement de la sécurité"
 ],
 "Select method": [
  null,
  "Sélectionnez la méthode"
 ],
 "Sending": [
  null,
  "Envoi"
 ],
 "Server": [
  null,
  "Serveur"
 ],
 "Server has closed the connection.": [
  null,
  "Le serveur a fermé la connexion."
 ],
 "Service": [
  null,
  "Service"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Set time": [
  null,
  "Régler l’heure"
 ],
 "Set to": [
  null,
  "Mis à"
 ],
 "Shared": [
  null,
  "Partagé"
 ],
 "Shell script": [
  null,
  "Script shell"
 ],
 "Shift+Insert": [
  null,
  "Maj+Inser"
 ],
 "Show confirmation password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Sorted from least to most trusted": [
  null,
  "Trié du moins fiable au plus fiable"
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Spanning tree protocol": [
  null,
  "Protocole Spanning Tree"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protocole Spanning Tree (STP)"
 ],
 "Specific time": [
  null,
  "Temps spécifique"
 ],
 "Stable": [
  null,
  "Stable"
 ],
 "Start service": [
  null,
  "Démarrer le service"
 ],
 "Status": [
  null,
  "État"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sticky": [
  null,
  "Persistant"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Strong password": [
  null,
  "Mot de passe fort"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Switch of $0": [
  null,
  "Éteindre $0"
 ],
 "Switch off $0": [
  null,
  "Éteindre $0"
 ],
 "Switch on $0": [
  null,
  "Allumer $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La désactivation de $0 interrompra la connexion au serveur et rendra l’interface utilisateur d’administration indisponible."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L’activation de $0 interrompra la connexion au serveur et rendra l’interface utilisateur d’administration indisponible."
 ],
 "Synchronized": [
  null,
  "Synchronisé"
 ],
 "Synchronized with $0": [
  null,
  "Synchronisé avec $0"
 ],
 "Synchronizing": [
  null,
  "Synchronisation"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "Team": [
  null,
  "Équipe"
 ],
 "Team port": [
  null,
  "Port de l’équipe"
 ],
 "Team port settings": [
  null,
  "Paramètres du port de l’équipe"
 ],
 "Testing connection": [
  null,
  "Test de connexion"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clé SSH $0 de $1 sur $2 sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clé SSH $0 sera disponible pour le reste de la session et sera également disponible pour la connexion à d’autres hôtes."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée par un mot de passe, et l’hôte ne permet pas de se connecter avec un mot de passe. Veuillez fournir le mot de passe de la clé à $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée. Vous pouvez vous connecter avec votre mot de passe de connexion ou en fournissant le mot de passe de la clé à $1."
 ],
 "The cockpit service is automatically included": [
  null,
  "Le service de cockpit est automatiquement inclus"
 ],
 "The fingerprint should match:": [
  null,
  "Les empreintes doivent correspondre :"
 ],
 "The key password can not be empty": [
  null,
  "Le mot de passe de la clé ne peut pas être vide"
 ],
 "The key passwords do not match": [
  null,
  "Les mots de passe sont différents"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les modifications système"
 ],
 "The password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'empreinte qui en découle peut être partagée publiquement par e-mail ou autre sans risque. Si vous demandez à quelqu'un d'autre de faire la vérification pour vous, cette personne peut vous envoyer les résultats par n'importe quel biais."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Le serveur a refusé d’authentifier en utilisant des méthodes prises en charge."
 ],
 "There are no active services in this zone": [
  null,
  "Il n’y a pas de services actifs dans cette zone"
 ],
 "This device cannot be managed here.": [
  null,
  "Ce périphérique ne peut pas être géré ici."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Cet outil configure la politique SELinux et peut aider à comprendre et à résoudre les violations de la politique."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Cet outil configure le système pour qu'il écrive les vidages de mémoire sur incidents du noyau. Il prend en charge les cibles \"local\" (disque), \"ssh\" et \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Cet outil génère une archive des informations de configuration et de diagnostic du système en cours d'exécution. Ces archives peuvent être stockées localement ou centralement à des fins d'enregistrement ou de suivi, ou être envoyées aux représentants du support technique, aux développeurs ou aux administrateurs système pour les aider dans la recherche d'erreurs techniques et le débogage."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Cet outil gère le stockage local, tel que les systèmes de fichiers, les groupes de volumes LVM2 et les montages NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Cet outil gère les réseaux tels que les liens, les ponts, les équipes, les VLAN et les pare-feu en utilisant NetworkManager et Firewalld. NetworkManager est incompatible avec les scripts par défaut systemd-networkd d'Ubuntu et ifupdown de Debian."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Cette zone contient le service du cockpit. Assurez-vous que cette zone ne s’applique pas à votre connexion actuelle à la console Web."
 ],
 "Time zone": [
  null,
  "Fuseau horaire"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Too much data": [
  null,
  "Trop de données"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transmitting": [
  null,
  "Transmission"
 ],
 "Troubleshoot…": [
  null,
  "Dépannage…"
 ],
 "Trust and add host": [
  null,
  "Faire confiance à l'hôte et l'ajouter"
 ],
 "Trust level": [
  null,
  "Niveau de confiance"
 ],
 "Trying to synchronize with $0": [
  null,
  "Synchronisation avec $0 en cours d'essai"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossible de se connecter à $0 en utilisant l'authentification par clé SSH. Veuillez fournir le mot de passe."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossible de se connecter à $0. L’hôte n’accepte pas le mot de passe de connexion ou l’une de vos clés SSH."
 ],
 "Unexpected error": [
  null,
  "Erreur inattendue"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Unknown \"$0\"": [
  null,
  "Inconnu « $0 »"
 ],
 "Unknown configuration": [
  null,
  "Configuration inconnue"
 ],
 "Unknown host: $0": [
  null,
  "Hôte inconnu : $0"
 ],
 "Unknown service name": [
  null,
  "Nom de service inconnu"
 ],
 "Unmanaged interfaces": [
  null,
  "Interfaces non gérées"
 ],
 "Untrusted host": [
  null,
  "Hôte non sécurisé"
 ],
 "Use $0": [
  null,
  "Utiliser $0"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Verify fingerprint": [
  null,
  "Vérifier l'empreinte digitale"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "View automation script": [
  null,
  "Afficher le script d’automation"
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Waiting": [
  null,
  "Attente"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Weak password": [
  null,
  "Mot de passe faible"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Sera défini sur \"Automatique\""
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Oui"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Vous n’êtes pas autorisé à modifier le pare-feu."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Votre navigateur n’autorise pas le collage à partir du menu contextuel. Vous pouvez utiliser Maj+Insérer."
 ],
 "Your session has been terminated.": [
  null,
  "Votre session a été interrompue."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Votre session a expiré. Veuillez vous reconnecter."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "in less than a minute": [
  null,
  "dans moins d'une minute"
 ],
 "less than a minute ago": [
  null,
  "il y a moins d'une minute"
 ],
 "password quality": [
  null,
  "qualité mot de passe"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "wireguard-tools package is not installed": [
  null,
  "le paquet wireguard-tools n'est pas installé"
 ]
});
