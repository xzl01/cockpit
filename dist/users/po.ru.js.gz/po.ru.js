cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "# пользователей"
 ],
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 is an existing file": [
  null,
  "$0 — существующий файл"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 more...": [
  null,
  "На $0 больше…"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "A group with this name already exists": [
  null,
  "Группа с таким названием уже существует."
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Account expiration": [
  null,
  "Срок действия учётной записи"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Учётная запись недоступна или не может быть изменена."
 ],
 "Accounts": [
  null,
  "Учётные записи"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "Add key": [
  null,
  "Добавить ключ"
 ],
 "Add public key": [
  null,
  "Добавить открытый ключ"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ],
 "Authorized public SSH keys": [
  null,
  "Авторизованные открытые SSH-ключи"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "Back to accounts": [
  null,
  "Вернуться к учётным записям"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change shell": [
  null,
  "Изменить оболочку"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Confirm new password": [
  null,
  "Подтвердите новый пароль"
 ],
 "Confirm password": [
  null,
  "Подтвердите пароль"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Create": [
  null,
  "Создать"
 ],
 "Create account with non-unique UID": [
  null,
  "Создать учётную запись с неуникальным UID"
 ],
 "Create account with weak password": [
  null,
  "Создать учётную запись со слабым паролем"
 ],
 "Create and change ownership of home directory": [
  null,
  "Создание и изменение права собственности на домашний каталог"
 ],
 "Create new account": [
  null,
  "Создать учётную запись"
 ],
 "Create new group": [
  null,
  "Создать новую группу"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Delete $0": [
  null,
  "Удалить $0"
 ],
 "Delete account": [
  null,
  "Удалить учётную запись"
 ],
 "Delete files": [
  null,
  "Удалить файлы"
 ],
 "Delete group": [
  null,
  "Удалить группу"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Disallow interactive password": [
  null,
  "Запретить интерактивный пароль"
 ],
 "Disallow password authentication": [
  null,
  "Запретить проверку подлинности с помощью пароля"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Edit user": [
  null,
  "Изменить пользователя"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Empty password": [
  null,
  "Пустой пароль"
 ],
 "Ended": [
  null,
  "Завершение"
 ],
 "Error saving authorized keys: ": [
  null,
  "Ошибка при сохранении авторизованных ключей: "
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Expire account on": [
  null,
  "Дата завершения срока действия учётной записи"
 ],
 "Expire account on $0": [
  null,
  "Дата завершения срока действия учётной записи: $0"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Failed to load authorized keys.": [
  null,
  "Не удалось загрузить авторизованные ключи."
 ],
 "Fingerprint": [
  null,
  "Отпечаток"
 ],
 "Force change": [
  null,
  "Принудительно изменить"
 ],
 "Force delete": [
  null,
  "Принудительно удалить"
 ],
 "Force password change": [
  null,
  "Принудительно изменить пароль"
 ],
 "From": [
  null,
  "От"
 ],
 "Full name": [
  null,
  "Полное имя"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "Group": [
  null,
  "Группа"
 ],
 "Group name": [
  null,
  "Имя группы"
 ],
 "Groups": [
  null,
  "Группы"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "Home directory": [
  null,
  "Домашний каталог"
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "ID": [
  null,
  "Идентификатор"
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid expiration date": [
  null,
  "Неверная дата окончания срока действия"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Invalid key": [
  null,
  "Недопустимый ключ"
 ],
 "Invalid number of days": [
  null,
  "Недопустимое количество дней"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Last active": [
  null,
  "Последняя активность"
 ],
 "Last login": [
  null,
  "Последний вход"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "Loading...": [
  null,
  "Загрузка…"
 ],
 "Local accounts": [
  null,
  "Локальные учётные записи"
 ],
 "Lock": [
  null,
  "Заблокировать"
 ],
 "Lock $0": [
  null,
  "Блокирование $0"
 ],
 "Lock account": [
  null,
  "Заблокировать учётную запись"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "Log out": [
  null,
  "Выход"
 ],
 "Log user out": [
  null,
  "Выполнить выход пользователя"
 ],
 "Logged in": [
  null,
  "Вход выполнен"
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "Login history": [
  null,
  "История входов"
 ],
 "Login history list": [
  null,
  "Список истории входов"
 ],
 "Logout $0": [
  null,
  "Выход $0"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "Never": [
  null,
  "Никогда"
 ],
 "Never expire account": [
  null,
  "Учётная запись без срока действия"
 ],
 "Never expire password": [
  null,
  "Пароль с неограниченным сроком действия"
 ],
 "Never logged in": [
  null,
  "Вход никогда не выполнялся"
 ],
 "New name": [
  null,
  "Новое имя"
 ],
 "New password": [
  null,
  "Новый пароль"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "No ID specified": [
  null,
  "Не указан идентификатор"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "No group name specified": [
  null,
  "Не указано имя группы"
 ],
 "No matching results": [
  null,
  "Соответствующие результаты не найдены"
 ],
 "No real name specified": [
  null,
  "Не указано настоящее имя"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "No user name specified": [
  null,
  "Не указано имя пользователя"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password": [
  null,
  "Старый пароль"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Другие методы проверки подлинности остаются доступны даже при запрете интерактивной проверки подлинности пароля."
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password expiration": [
  null,
  "Срок действия пароля"
 ],
 "Password is longer than 256 characters": [
  null,
  "Длина пароля составляет более 256 символов"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Password must be changed": [
  null,
  "Необходимо изменить пароль"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Вставьте сюда содержимое вашего файла открытого SSH-ключа"
 ],
 "Path to directory": [
  null,
  "Путь к каталогу"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "Permanently delete $0 group?": [
  null,
  "Окончательно удалить группу $0?"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Please specify an expiration date": [
  null,
  "Укажите дату окончания срока действия"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Prompting via passwd timed out": [
  null,
  "Превышено время ожидания запроса по passwd"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Rename": [
  null,
  "Переименовать"
 ],
 "Rename group": [
  null,
  "Переименовать группу"
 ],
 "Rename group $0": [
  null,
  "Переименовать группу $0"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "Переименование группы может повлиять на sudo и другие подобные правила"
 ],
 "Require password change every $0 days": [
  null,
  "Требовать изменения пароля каждые $0 дней"
 ],
 "Require password change on $0": [
  null,
  "Потребовать смену пароля $0"
 ],
 "Require password change on first login": [
  null,
  "Потребовать смену пароля при первом входе в систему"
 ],
 "Reset password": [
  null,
  "Сбросить пароль"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Search for name or ID": [
  null,
  "Поиск имени или идентификатора"
 ],
 "Search for name, group or ID": [
  null,
  "Поиск имени, группы или идентификатора"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Set password": [
  null,
  "Задать пароль"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Set weak password": [
  null,
  "Задать слабый пароль"
 ],
 "Shell": [
  null,
  "Оболочка"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Started": [
  null,
  "Начало"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "Tablet": [
  null,
  "Планшетный ПК"
 ],
 "Terminate session": [
  null,
  "Завершить сеанс"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Для учётной записи «$0» будет запрошено принудительное изменение пароля при следующем входе в систему"
 ],
 "The full name must not contain colons.": [
  null,
  "Полное имя не должно содержать двоеточий."
 ],
 "The group ID must be positive integer": [
  null,
  "Идентификатор группы должен быть положительным целым числом"
 ],
 "The group name can only consist of letters from a-z, digits, dots, dashes and underscores": [
  null,
  "Имя группы может содержать только латинские буквы a-z, цифры, точки, тире и символы подчёркивания"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "Домашний каталог $0 уже существует. Право владения им перейдёт новому пользователю."
 ],
 "The key you provided was not valid.": [
  null,
  "Предоставленный ключ недействителен."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "The passwords do not match": [
  null,
  "Пароли не совпадают"
 ],
 "The passwords do not match.": [
  null,
  "Пароли не совпадают."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "Пользователь должен выйти и снова войти в систему, чтобы применить изменения параметров."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Имя пользователя может содержать только латинские буквы a-z, цифры, точки, тире и символы подчёркивания."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Для этой учётной записи нет авторизованных открытых ключей."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Данная группа является основной группой для следующих пользователей:"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Этот инструмент настраивает систему для записи аварийных дампов ядра на диск."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "This user name already exists": [
  null,
  "Такое имя пользователя уже существует"
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "Undo": [
  null,
  "Отменить изменения"
 ],
 "Unexpected error": [
  null,
  "Непредвиденная ошибка"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Unnamed": [
  null,
  "Без названия"
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "Use password": [
  null,
  "Введите пароль"
 ],
 "User ID": [
  null,
  "Идентификатор пользователя"
 ],
 "User ID is already used by another user": [
  null,
  "Этот идентификатор уже используется другим пользователем"
 ],
 "User ID must be a positive integer": [
  null,
  "Идентификатор пользователя должен быть положительным целым числом"
 ],
 "User ID must not be higher than $0": [
  null,
  "Идентификатор пользователя не должен быть числом, превышающим $0"
 ],
 "User ID must not be lower than $0": [
  null,
  "Идентификатор пользователя не должен быть меньше $0"
 ],
 "User name": [
  null,
  "Имя пользователя"
 ],
 "Username": [
  null,
  "Имя пользователя"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Отсутствует разрешение на просмотр авторизованных открытых ключей для этой учётной записи."
 ],
 "You must wait longer to change your password": [
  null,
  "Для изменения пароля необходимо подождать"
 ],
 "Your account": [
  null,
  "Текущая учётная запись"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "change": [
  null,
  "Изменить"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "user": [
  null,
  "пользователь"
 ]
});
