cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "ანგარიშები"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Managing user accounts": [
  null,
  "მომხმარებლების ანგარიშების მართვა"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "access": [
  null,
  "წვდომა"
 ],
 "keys": [
  null,
  "გასაღებები"
 ],
 "login": [
  null,
  "შესვლა"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "პაროლი"
 ],
 "roles": [
  null,
  "როლები"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "მომხმარებელი"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "მომხმარებლის სახელი"
 ]
});
