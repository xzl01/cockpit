cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "계정"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Managing user accounts": [
  null,
  "사용자 계정 관리"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "access": [
  null,
  "접근"
 ],
 "keys": [
  null,
  "키"
 ],
 "login": [
  null,
  "로그인"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "비밀번호"
 ],
 "roles": [
  null,
  "역할"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "사용자"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "사용자 이름"
 ]
});
