cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Konta"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Managing user accounts": [
  null,
  "Zarządzanie kontami użytkowników"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "access": [
  null,
  "dostęp"
 ],
 "keys": [
  null,
  "klucze"
 ],
 "login": [
  null,
  "logowanie"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "hasło"
 ],
 "roles": [
  null,
  "role"
 ],
 "ssh": [
  null,
  "SSH"
 ],
 "user": [
  null,
  "użytkownik"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nazwa użytkownika"
 ]
});
