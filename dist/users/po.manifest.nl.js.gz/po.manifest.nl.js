cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Accounts"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Managing user accounts": [
  null,
  "Gebruikersaccounts beheren"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "access": [
  null,
  "toegang"
 ],
 "keys": [
  null,
  "sleutels"
 ],
 "login": [
  null,
  "inloggen"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "wachtwoord"
 ],
 "roles": [
  null,
  "rollen"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "gebruiker"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "gebruikersnaam"
 ]
});
