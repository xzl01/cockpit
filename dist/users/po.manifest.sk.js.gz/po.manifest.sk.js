cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Účty"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Managing user accounts": [
  null,
  "Správa používateľských účtov"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "access": [
  null,
  "prístup"
 ],
 "keys": [
  null,
  "kľúče"
 ],
 "login": [
  null,
  "prihlásenie"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "heslo"
 ],
 "roles": [
  null,
  "role"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "používateľ"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "username"
 ]
});
