cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "用户账户"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Managing user accounts": [
  null,
  "管理用户帐户"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "access": [
  null,
  "访问"
 ],
 "keys": [
  null,
  "密钥"
 ],
 "login": [
  null,
  "登录"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "密码"
 ],
 "roles": [
  null,
  "角色"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "用户"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "用户名"
 ]
});
