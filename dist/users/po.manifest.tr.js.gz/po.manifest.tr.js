cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Hesaplar"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Managing user accounts": [
  null,
  "Kullanıcı hesaplarını yönetme"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "access": [
  null,
  "erişim"
 ],
 "keys": [
  null,
  "anahtarlar"
 ],
 "login": [
  null,
  "oturum aç"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "parola"
 ],
 "roles": [
  null,
  "roller"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "kullanıcı"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "kullanıcı adı"
 ]
});
