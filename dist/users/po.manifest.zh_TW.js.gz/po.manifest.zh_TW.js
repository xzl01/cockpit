cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "帳號管理"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Managing user accounts": [
  null,
  "管理使用者帳號"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "access": [
  null,
  "存取"
 ],
 "keys": [
  null,
  "金鑰"
 ],
 "login": [
  null,
  "登入"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "密碼"
 ],
 "roles": [
  null,
  "角色"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "使用者"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "使用者名稱"
 ]
});
