cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Konten"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Managing user accounts": [
  null,
  "Benutzerkonten verwalten"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "access": [
  null,
  "Zugriff"
 ],
 "keys": [
  null,
  "Schlüssel"
 ],
 "login": [
  null,
  "Login"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "Passwort"
 ],
 "roles": [
  null,
  "Rollen"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "Benutzer"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "Benutzername"
 ]
});
