cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Account"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Managing user accounts": [
  null,
  "Gestione degli account utente"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "access": [
  null,
  "accesso"
 ],
 "keys": [
  null,
  "chiavi"
 ],
 "login": [
  null,
  "accesso"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "password"
 ],
 "roles": [
  null,
  "ruoli"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "utente"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nome utente"
 ]
});
