cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "di utenti"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 is an existing file": [
  null,
  "$0 è un file non esistente"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 more...": [
  null,
  "$0 di più..."
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "A group with this name already exists": [
  null,
  "Esiste già un gruppo con questo nome."
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Account expiration": [
  null,
  "Scadenza account"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Account non disponibile o non modificabile."
 ],
 "Accounts": [
  null,
  "Account"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "Add key": [
  null,
  "Aggiungi chiave"
 ],
 "Add public key": [
  null,
  "Aggiungi chiave pubblica"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ],
 "Authorized public SSH keys": [
  null,
  "Chiavi SSH pubbliche autorizzate"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "Back to accounts": [
  null,
  "Torna agli account"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "Change": [
  null,
  "Cambia"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Confirm new password": [
  null,
  "Conferma nuova password"
 ],
 "Confirm password": [
  null,
  "Conferma la password"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Copy": [
  null,
  "Copia"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Create account with non-unique UID": [
  null,
  "Crea un account con un UID non univoco"
 ],
 "Create account with weak password": [
  null,
  "Crea l'account con una password debole"
 ],
 "Create and change ownership of home directory": [
  null,
  "Creare e cambiare la proprietà della home directory"
 ],
 "Create new account": [
  null,
  "Crea un nuovo account"
 ],
 "Create new group": [
  null,
  "Crea nuovo gruppo"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Delete": [
  null,
  "Cancella"
 ],
 "Delete $0": [
  null,
  "Cancella $0"
 ],
 "Delete account": [
  null,
  "Elimina un account"
 ],
 "Delete files": [
  null,
  "Cancella file"
 ],
 "Delete group": [
  null,
  "Elimina gruppo"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Disallow interactive password": [
  null,
  "Non consentire password interattiva"
 ],
 "Disallow password authentication": [
  null,
  "Non consentire l'autenticazione con password"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit user": [
  null,
  "Modifica utente"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Empty password": [
  null,
  "Password vuota"
 ],
 "Ended": [
  null,
  "Concluso"
 ],
 "Error saving authorized keys: ": [
  null,
  "Errore nel salvare le chiavi autorizzate: "
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Expire account on": [
  null,
  "Scadenza dell'account il"
 ],
 "Expire account on $0": [
  null,
  "Scadenza dell'account il $0"
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld"
 ],
 "Failed to load authorized keys.": [
  null,
  "Impossibile caricare le chiavi autorizzate."
 ],
 "Fingerprint": [
  null,
  "Impronta digitale"
 ],
 "Force change": [
  null,
  "Forza modifica"
 ],
 "Force delete": [
  null,
  "Forza Cancella"
 ],
 "Force password change": [
  null,
  "Forzare la modifica della password"
 ],
 "From": [
  null,
  "Da"
 ],
 "Full name": [
  null,
  "Nome completo"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "Group": [
  null,
  "Gruppo"
 ],
 "Group name": [
  null,
  "Nome del gruppo"
 ],
 "Groups": [
  null,
  "Gruppi"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Home directory": [
  null,
  "Home Directory"
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid expiration date": [
  null,
  "Data di scadenza non valida"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Invalid key": [
  null,
  "Chiave non valida"
 ],
 "Invalid number of days": [
  null,
  "Numero di giorni non valido"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Last active": [
  null,
  "ultima attività"
 ],
 "Last login": [
  null,
  "Ultimo accesso"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "Local accounts": [
  null,
  "Account locali"
 ],
 "Lock": [
  null,
  "Blocca"
 ],
 "Lock $0": [
  null,
  "Blocca $0"
 ],
 "Lock account": [
  null,
  "Blocca account"
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "Log out": [
  null,
  "Esci"
 ],
 "Log user out": [
  null,
  "disconnetti l'utente"
 ],
 "Logged in": [
  null,
  "Autenticato"
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "Login history": [
  null,
  "Cronologia accessi"
 ],
 "Login history list": [
  null,
  "Elenco cronologia accessi"
 ],
 "Logout $0": [
  null,
  "Disconnetti $0"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "Never": [
  null,
  "Mai"
 ],
 "Never expire account": [
  null,
  "Nessun account scaduto"
 ],
 "Never expire password": [
  null,
  "Non far scadere mai la password"
 ],
 "Never logged in": [
  null,
  "Nessuno autenticato"
 ],
 "New name": [
  null,
  "Nuovo nome"
 ],
 "New password": [
  null,
  "Nuova password"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "No ID specified": [
  null,
  "Nessun ID specificato"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "No group name specified": [
  null,
  "Non è stato specificato il nome del gruppo"
 ],
 "No matching results": [
  null,
  "Nessun risultato corrispondente"
 ],
 "No real name specified": [
  null,
  "Nessun nome reale specificato"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "No user name specified": [
  null,
  "Nessun nome utente specificato"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password": [
  null,
  "Vecchia password"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Other": [
  null,
  "Altro"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Altri metodi di autenticazione sono ancora disponibili anche quando l'autenticazione tramite password interattiva non è consentita."
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Password expiration": [
  null,
  "Scadenza della password"
 ],
 "Password is longer than 256 characters": [
  null,
  "La password è più lunga di 256 caratteri"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Password must be changed": [
  null,
  "La password deve essere cambiata"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Incollare qui il contenuto del file della chiave SSH pubblica"
 ],
 "Path to directory": [
  null,
  "Percorso della directory"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "Permanently delete $0 group?": [
  null,
  "Eliminare definitivamente $0 il gruppo?"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please specify an expiration date": [
  null,
  "Specifica una data di scadenza"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Prompting via passwd timed out": [
  null,
  "Richiesta tramite passwd scaduta"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Remove": [
  null,
  "Elimina"
 ],
 "Removing $0": [
  null,
  "Rimozione $0"
 ],
 "Rename": [
  null,
  "Rinomina"
 ],
 "Rename group": [
  null,
  "Rinomina il gruppo"
 ],
 "Rename group $0": [
  null,
  "Rinominare il gruppo $0"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "Rinominare un gruppo può influenzare le regole di sudo e simili"
 ],
 "Require password change every $0 days": [
  null,
  "Richiedi la modifica della password ogni $0 giorni"
 ],
 "Require password change on $0": [
  null,
  "Richiedi la modifica della password su $0"
 ],
 "Require password change on first login": [
  null,
  "Richiedi la modifica della password al primo accesso"
 ],
 "Reset password": [
  null,
  "Resetta password"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Search for name or ID": [
  null,
  "Cerca per nome o ID"
 ],
 "Search for name, group or ID": [
  null,
  "Cerca per nome, gruppo o ID"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Set password": [
  null,
  "Imposta password"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Set weak password": [
  null,
  "Imposta una password debole"
 ],
 "Shell": [
  null,
  "Shell"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shut down": [
  null,
  "Arresto"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Started": [
  null,
  "Avviato"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Terminate session": [
  null,
  "Termina la sessione"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "L'account '$0' sarà costretto a cambiare la propria password al prossimo login"
 ],
 "The full name must not contain colons.": [
  null,
  "Il nome completo non deve contenere i due punti."
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "La directory home $0 esiste già. La sua proprietà verrà cambiata con quella del nuovo utente."
 ],
 "The key you provided was not valid.": [
  null,
  "La chiave fornita non era valida."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "The passwords do not match": [
  null,
  "Le password non corrispondono"
 ],
 "The passwords do not match.": [
  null,
  "Le password non corrispondono."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Il nome utente può essere composto solo da lettere da a-z, cifre, punti, trattini e sottolineature."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Non ci sono chiavi pubbliche autorizzate per questo account."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Questo gruppo è il gruppo principale per i seguenti utenti:"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Questo strumento configura il sistema per scrivere i crash dump del kernel su disco."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "This user name already exists": [
  null,
  "Questo nome utente esiste già"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Undo": [
  null,
  "Annulla"
 ],
 "Unexpected error": [
  null,
  "Errore imprevisto"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Unnamed": [
  null,
  "Senza nome"
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "User ID must not be higher than $0": [
  null,
  "L'ID utente non deve essere superiore a $0"
 ],
 "User name": [
  null,
  "Nome utente"
 ],
 "Username": [
  null,
  "Nome utente"
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Non hai il permesso di visualizzare le chiavi pubbliche autorizzate per questo account."
 ],
 "You must wait longer to change your password": [
  null,
  "Devi aspettare più a lungo per cambiare la tua password"
 ],
 "Your account": [
  null,
  "Il tuo account"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "user": [
  null,
  "utente"
 ]
});
