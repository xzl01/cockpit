cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Contas"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do Kernel"
 ],
 "Managing user accounts": [
  null,
  ""
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "access": [
  null,
  "acesso"
 ],
 "keys": [
  null,
  "chaves"
 ],
 "login": [
  null,
  "login"
 ],
 "password": [
  null,
  "senha"
 ],
 "roles": [
  null,
  ""
 ],
 "user": [
  null,
  "usuário"
 ],
 "username": [
  null,
  ""
 ]
});
