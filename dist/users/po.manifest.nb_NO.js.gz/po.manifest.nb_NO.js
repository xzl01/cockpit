cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Kontoer"
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Managing user accounts": [
  null,
  "Administrere brukerkontoer"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "access": [
  null,
  "tilgang"
 ],
 "keys": [
  null,
  "nøkler"
 ],
 "login": [
  null,
  ""
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "passord"
 ],
 "roles": [
  null,
  "roller"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "bruker"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "brukernavn"
 ]
});
