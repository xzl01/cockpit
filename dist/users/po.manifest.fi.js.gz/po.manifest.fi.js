cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Käyttäjätilit"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Managing user accounts": [
  null,
  "Käyttäjätilien hallinta"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "access": [
  null,
  "pääsy"
 ],
 "keys": [
  null,
  "avaimet"
 ],
 "login": [
  null,
  "sisäänkirjautuminen"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "salasana"
 ],
 "roles": [
  null,
  "roolit"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "käyttäjä"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "käyttäjänimi"
 ]
});
