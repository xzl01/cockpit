cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Účty"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Managing user accounts": [
  null,
  "Správa uživatelských účtů"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "access": [
  null,
  "přístup"
 ],
 "keys": [
  null,
  "klíče"
 ],
 "login": [
  null,
  "přihlášení"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "heslo"
 ],
 "roles": [
  null,
  "role"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "uživatel"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "uživatelské jméno"
 ]
});
