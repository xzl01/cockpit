cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "Número de usuarios"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 día",
  "$0 días"
 ],
 "$0 exited with code $1": [
  null,
  "$0 finalizó con el código $1"
 ],
 "$0 failed": [
  null,
  "$0 falló"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 is an existing file": [
  null,
  "$0 es un fichero existente"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 no está disponible en ningún repositorio."
 ],
 "$0 key changed": [
  null,
  "$0 clave cambiada"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminado con señal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mes",
  "$0 meses"
 ],
 "$0 more...": [
  null,
  "$0 más..."
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "Se instalará: $0."
 ],
 "$0 year": [
  null,
  "$0 año",
  "$0 años"
 ],
 "1 day": [
  null,
  "1 día"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "No se ha instalado una versión compatible de Cockpit en $0."
 ],
 "A group with this name already exists": [
  null,
  "Ya existe un grupo con este nombre"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se creará una nueva clave SSH en $0 para $1 en $2 y se añadirá al fichero $3 de $4 en $5."
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Acceptable password": [
  null,
  "Contraseña aceptable"
 ],
 "Account expiration": [
  null,
  "Expiración de la cuenta"
 ],
 "Account not available or cannot be edited.": [
  null,
  "La cuenta no está disponible o no se puede modificar."
 ],
 "Accounts": [
  null,
  "Cuentas"
 ],
 "Add": [
  null,
  "Añadir"
 ],
 "Add $0": [
  null,
  "Añadir $0"
 ],
 "Add key": [
  null,
  "Añadir clave"
 ],
 "Add public key": [
  null,
  "Añadir clave pública"
 ],
 "Additional packages:": [
  null,
  "Paquetes adicionales:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrando con la consola Web de Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzado"
 ],
 "All-in-one": [
  null,
  "Todo en uno"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentación de los roles de Ansible"
 ],
 "Authentication": [
  null,
  "Autenticación"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Se requiere autenticación para elevar privilegios y realizar tareas de administración en la consola Web de Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar la clave SSH"
 ],
 "Authorized public SSH keys": [
  null,
  "Claves SSH públicas autorizadas"
 ],
 "Automatically using NTP": [
  null,
  "Utilizando NTP de forma automática"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP adicionales"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automatización"
 ],
 "Back to accounts": [
  null,
  "Volver a cuentas de usuario"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chasis tipo blade"
 ],
 "Bus expansion chassis": [
  null,
  "Chasis de expansión de bus"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot forward login credentials": [
  null,
  "No se pueden transferir los datos de acceso"
 ],
 "Cannot schedule event in the past": [
  null,
  "No se puede planificar un evento ocurrido en el pasado"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Change shell": [
  null,
  "Cambiar shell"
 ],
 "Change system time": [
  null,
  "Cambiar la hora del sistema"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Las llaves cambiadas pueden llevar una reinstalación del sistema operativo. Sin embargo, un cambio inesperado puede indicar un intento de interceptar su conexión mediante un tercero."
 ],
 "Checking installed software": [
  null,
  "Comprobando el software instalado"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuración en Cockpit de NetworkManager y Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit no se pudo conectar con el anfitrión especificado."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit es un gestor de servidores que facilita la administración de servidores Linux a través de un navegador web. Es posible alternar entre el portal web y la consola sin problemas. Un servicio que haya empezado por Cockpit se puede parar desde la terminal. Asimismo, si se produce un error en el terminal, podrá verlo en la bitácora de Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit no es compatible con el software del sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit no está instalado"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit no está instalado en el sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit es ideal para administradores de sistemas nóveles, ya que permite realizar con sencillez tareas como gestionar almacenamiento, inspeccionar bitácoras e iniciar y detener servicios. Puede monitorizar y administrar varios servidores a la vez. Tan solo añádalos con solo pulsar un botón y sus máquinas se encargarán del resto."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Recoger y empaquetar datos de diagnóstico y soporte"
 ],
 "Collect kernel crash dumps": [
  null,
  "Recoger volcados de colapso del kernel"
 ],
 "Compact PCI": [
  null,
  "PCI compacto"
 ],
 "Confirm key password": [
  null,
  "Confirme la contraseña de la clave"
 ],
 "Confirm new password": [
  null,
  "Confirme la nueva contraseña"
 ],
 "Confirm password": [
  null,
  "Confirmar contraseña"
 ],
 "Connection has timed out.": [
  null,
  "La conexión ha caducado."
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar al portapapeles"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crear una clave SSH y autorizarla"
 ],
 "Create account with non-unique UID": [
  null,
  "Crear la cuenta con el UID no único"
 ],
 "Create account with weak password": [
  null,
  "Crear la cuenta con la contraseña débil"
 ],
 "Create and change ownership of home directory": [
  null,
  "Crear y cambiar propiedad del directorio personal"
 ],
 "Create new account": [
  null,
  "Crear una cuenta"
 ],
 "Create new group": [
  null,
  "Crear nuevo grupo"
 ],
 "Create new task file with this content.": [
  null,
  "Crear un archivo de tarea con este contenido."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Retardo"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Delete $0": [
  null,
  "Eliminar $0"
 ],
 "Delete account": [
  null,
  "Eliminar cuenta"
 ],
 "Delete files": [
  null,
  "Borrar ficheros"
 ],
 "Delete group": [
  null,
  "Eliminar grupo"
 ],
 "Desktop": [
  null,
  "Escritorio"
 ],
 "Detachable": [
  null,
  "Desmontable"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Disallow interactive password": [
  null,
  "Denegar la autenticación interactiva con contraseña"
 ],
 "Disallow password authentication": [
  null,
  "Denegar autenticación por contraseña"
 ],
 "Docking station": [
  null,
  "Estación de acoplamiento"
 ],
 "Downloading $0": [
  null,
  "Descargando $0"
 ],
 "Dual rank": [
  null,
  "Rango dual"
 ],
 "Edit user": [
  null,
  "Editar usuario"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Empty password": [
  null,
  "Contraseña vacía"
 ],
 "Ended": [
  null,
  "Finalizado"
 ],
 "Error saving authorized keys: ": [
  null,
  "Error al guardar las llaves autorizadas: "
 ],
 "Excellent password": [
  null,
  "Contraseña excelente"
 ],
 "Expansion chassis": [
  null,
  "Chasis de expansión"
 ],
 "Expire account on": [
  null,
  "Expirar la cuenta en"
 ],
 "Expire account on $0": [
  null,
  "Expirar la cuenta en $0"
 ],
 "Failed to change password": [
  null,
  "Error al cambiar contraseña"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Fallo al habilitar $0 en firewalld"
 ],
 "Failed to load authorized keys.": [
  null,
  "Fallo al cargar las claves autorizadas."
 ],
 "Fingerprint": [
  null,
  "Huella dactilar"
 ],
 "Force change": [
  null,
  "Forzar cambio"
 ],
 "Force delete": [
  null,
  "Forzar el borrado"
 ],
 "Force password change": [
  null,
  "Cambio forzado de la contraseña"
 ],
 "From": [
  null,
  "Desde"
 ],
 "Full name": [
  null,
  "Nombre completo"
 ],
 "Go to now": [
  null,
  "Ir a ahora"
 ],
 "Group": [
  null,
  "Grupo"
 ],
 "Group name": [
  null,
  "Nombre del grupo"
 ],
 "Groups": [
  null,
  "Grupos"
 ],
 "Handheld": [
  null,
  "Dispositivo de mano"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar contraseña de confirmación"
 ],
 "Hide password": [
  null,
  "Ocultar contraseña"
 ],
 "Home directory": [
  null,
  "Directorio personal"
 ],
 "Host key is incorrect": [
  null,
  "La tecla del anfitrión es incorrecta"
 ],
 "ID": [
  null,
  "ID"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si la huella coincide, pulse \"Confiar en el anfitrión y añadirlo\". En caso contrario, no se conecte y contacte con su administrador."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install software": [
  null,
  "Instalar software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Internal error": [
  null,
  "Error interno"
 ],
 "Invalid date format": [
  null,
  "Formato de fecha inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de fecha y hora inválidos"
 ],
 "Invalid expiration date": [
  null,
  "Fecha de expiración invalida"
 ],
 "Invalid file permissions": [
  null,
  "Permisos de archivo invalidos"
 ],
 "Invalid key": [
  null,
  "Llave inválida"
 ],
 "Invalid number of days": [
  null,
  "Numero de días incorrecto"
 ],
 "Invalid time format": [
  null,
  "Formato de hora inválido"
 ],
 "Invalid timezone": [
  null,
  "Zona horaria no válida"
 ],
 "IoT gateway": [
  null,
  "Pasarela IoT"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Key password": [
  null,
  "Contraseña de la clave"
 ],
 "Laptop": [
  null,
  "Portátil"
 ],
 "Last active": [
  null,
  "Última vez activo"
 ],
 "Last login": [
  null,
  "Último inicio de sesión"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "Loading system modifications...": [
  null,
  "Cargando modificaciones del sistema..."
 ],
 "Loading...": [
  null,
  "Cargando..."
 ],
 "Local accounts": [
  null,
  "Cuentas locales"
 ],
 "Lock": [
  null,
  "Bloquear"
 ],
 "Lock $0": [
  null,
  "Bloquear a $0"
 ],
 "Lock account": [
  null,
  "Bloquear cuenta"
 ],
 "Log in": [
  null,
  "Iniciar sesión"
 ],
 "Log in to $0": [
  null,
  "Iniciar sesión en $0"
 ],
 "Log messages": [
  null,
  "Mensajes de registro"
 ],
 "Log out": [
  null,
  "Salir"
 ],
 "Log user out": [
  null,
  "Finalizar sesión del usuario"
 ],
 "Logged in": [
  null,
  "Sesión iniciada"
 ],
 "Login failed": [
  null,
  "Inicio de sesión fallido"
 ],
 "Login history": [
  null,
  "Historial de inicios de sesión"
 ],
 "Login history list": [
  null,
  "Lista del historial de inicios de sesión"
 ],
 "Logout $0": [
  null,
  "Finalizar sesión de $0"
 ],
 "Low profile desktop": [
  null,
  "Perfil bajo de escritorio"
 ],
 "Lunch box": [
  null,
  "Caja de almuerzo"
 ],
 "Main server chassis": [
  null,
  "Chasis del servidor principal"
 ],
 "Manage storage": [
  null,
  "Gestionar el almacenamiento"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Mensaje para usuarios activos"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Multi-system chassis": [
  null,
  "Chasis multisistema"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Need at least one NTP server": [
  null,
  "Se requiere al menos un servidor NTP"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "Never": [
  null,
  "Nunca"
 ],
 "Never expire account": [
  null,
  "La cuenta nunca expira"
 ],
 "Never expire password": [
  null,
  "La clave nunca expira"
 ],
 "Never logged in": [
  null,
  "Nunca ha iniciado sesión"
 ],
 "New name": [
  null,
  "Nuevo nombre"
 ],
 "New password": [
  null,
  "Nueva contraseña"
 ],
 "New password was not accepted": [
  null,
  "No se aceptó la nueva contraseña"
 ],
 "No ID specified": [
  null,
  "No se ha especificado un ID"
 ],
 "No delay": [
  null,
  "Sin retardo"
 ],
 "No group name specified": [
  null,
  "No se ha especificado un nombre de grupo"
 ],
 "No matching results": [
  null,
  "No se encontraron resultados"
 ],
 "No real name specified": [
  null,
  "No hay un nombre real especificado"
 ],
 "No results found": [
  null,
  "No se encontraron resultados"
 ],
 "No such file or directory": [
  null,
  "No existe el archivo o directorio"
 ],
 "No system modifications": [
  null,
  "No hay modificaciones para el sistema"
 ],
 "No user name specified": [
  null,
  "Nombre de usuario no especificado"
 ],
 "Not a valid private key": [
  null,
  "No es una clave privada válida"
 ],
 "Not permitted to perform this action.": [
  null,
  "No está permitido llevar a cabo esta acción."
 ],
 "Not synchronized": [
  null,
  "No está sincronizado"
 ],
 "Notebook": [
  null,
  "Portátil"
 ],
 "Occurrences": [
  null,
  "Ocurrencias"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Old password": [
  null,
  "Contraseña vieja"
 ],
 "Old password not accepted": [
  null,
  "No se aceptó la contraseña vieja"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una vez que se instale Cockpit, habilítelo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Opciones"
 ],
 "Other": [
  null,
  "Otro"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Hay otros métodos de autenticación disponibles incluso cuando se deshabilita la autenticación interactiva con contraseña."
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "Password": [
  null,
  "Contraseña"
 ],
 "Password expiration": [
  null,
  "Expiración de la contraseña"
 ],
 "Password is longer than 256 characters": [
  null,
  "La contraseña no puede superar los 256 caracteres"
 ],
 "Password is not acceptable": [
  null,
  "La contraseña no es válida"
 ],
 "Password is too weak": [
  null,
  "La contraseña es muy débil"
 ],
 "Password must be changed": [
  null,
  "Se debe cambiar la contraseña"
 ],
 "Password not accepted": [
  null,
  "Contraseña no válida"
 ],
 "Paste": [
  null,
  "Pegar"
 ],
 "Paste error": [
  null,
  "Error al pegar"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Pegue aquí el contenido de su clave SSH pública"
 ],
 "Path to directory": [
  null,
  "Ruta del directorio"
 ],
 "Path to file": [
  null,
  "Ruta al fichero"
 ],
 "Peripheral chassis": [
  null,
  "Chasis periférico"
 ],
 "Permanently delete $0 group?": [
  null,
  "¿Eliminar el grupo $0 permanentemente?"
 ],
 "Pick date": [
  null,
  "Selecciona una fecha"
 ],
 "Pizza box": [
  null,
  "Caja de pizza"
 ],
 "Please specify an expiration date": [
  null,
  "Por favor especifique una fecha de expiración"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Prompting via passwd timed out": [
  null,
  "Se ha agotado el tiempo de espera para passwd"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Ha expirado el tiempo de ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Se ha agotado el tiempo de espera para ssh-keygen"
 ],
 "RAID chassis": [
  null,
  "Chasis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chasis montado en rack"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Removals:": [
  null,
  "Borrados:"
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "Removing $0": [
  null,
  "Eliminando $0"
 ],
 "Rename": [
  null,
  "Renombrar"
 ],
 "Rename group": [
  null,
  "Renombrar grupo"
 ],
 "Rename group $0": [
  null,
  "Renombrar grupo $0"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "Renombrar un grupo puede afectar a sudo y reglas similares"
 ],
 "Require password change every $0 days": [
  null,
  "Hay que cambiar la contraseña cada $0 días"
 ],
 "Require password change on $0": [
  null,
  "Hay que cambiar la contraseña en $0"
 ],
 "Require password change on first login": [
  null,
  "Requerir cambiar la contraseña en el primer inicio de sesión"
 ],
 "Reset password": [
  null,
  "Restablecer contraseña"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Ejecute este comando en la máquina remota a través de una red de confianza o de forma física:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clave SSH"
 ],
 "Sealed-case PC": [
  null,
  "PC de caja sellada"
 ],
 "Search for name or ID": [
  null,
  "Buscar por nombre o ID"
 ],
 "Search for name, group or ID": [
  null,
  "Buscar por nombre, grupo o ID"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuración de Security Enhanced Linux y resolución de problemas"
 ],
 "Server has closed the connection.": [
  null,
  "El servidor ha cerrado la conexión."
 ],
 "Set password": [
  null,
  "Establecer contraseña"
 ],
 "Set time": [
  null,
  "Establecer la hora"
 ],
 "Set weak password": [
  null,
  "Establecer contraseña débil"
 ],
 "Shell": [
  null,
  "Shell"
 ],
 "Shell script": [
  null,
  "Script de shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Mostrar contraseña de confirmación"
 ],
 "Show password": [
  null,
  "Mostrar contraseña"
 ],
 "Shut down": [
  null,
  "Apagar"
 ],
 "Single rank": [
  null,
  "Rango único"
 ],
 "Space-saving computer": [
  null,
  "Ordenador compacto"
 ],
 "Specific time": [
  null,
  "Hora específica"
 ],
 "Started": [
  null,
  "Iniciado"
 ],
 "Stick PC": [
  null,
  "PC USB"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Strong password": [
  null,
  "Contraseña fuerte"
 ],
 "Sub-Chassis": [
  null,
  "Sub Chasis"
 ],
 "Sub-Notebook": [
  null,
  "Subportátil"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "Tablet": [
  null,
  "Tableta"
 ],
 "Terminate session": [
  null,
  "Cerrar sesión"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clave SSH $0 de $1 en $2 será añadida al archivo $3 de $4 en $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clave SSH $0 estará disponible durante el resto de la sesión y también lo estará para unirse a otros anfitriones."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida por contraseña, y el anfitrión no permite iniciar sesión con contraseña. Por favor, introduzca la contraseña de dicha clave en $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida. Puedes iniciar sesión tanto con la contraseña de usuario como introduciendo la contraseña de dicha clave en $1."
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Se forzará a la cuenta '$0' para que cambie su contraseña en el próximo acceso"
 ],
 "The fingerprint should match:": [
  null,
  "La huella debería coincidir con:"
 ],
 "The full name must not contain colons.": [
  null,
  "El nombre completo no debe contener dos puntos."
 ],
 "The group ID must be positive integer": [
  null,
  "El ID de grupo debe ser un número entero positivo"
 ],
 "The group name can only consist of letters from a-z, digits, dots, dashes and underscores": [
  null,
  "El nombre de grupo sólo puede contener letras (a-z), dígitos, puntos, guiones y guiones bajos"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "El directorio personal $0 ya existe. Su propiedad será cambiada al nuevo usuario."
 ],
 "The key password can not be empty": [
  null,
  "La contraseña de la clave no puede estar vacía"
 ],
 "The key passwords do not match": [
  null,
  "Las contraseñas de la clave no coinciden"
 ],
 "The key you provided was not valid.": [
  null,
  "La clave introducida no resultó válida."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "El usuario autenticado no tiene permisos para ver las modificaciones del sistema"
 ],
 "The password can not be empty": [
  null,
  "La contraseña no puede estar vacía"
 ],
 "The passwords do not match": [
  null,
  "Las contraseñas no coinciden"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "La huella resultante es apta para compartirse en público, incluyendo correo electrónico."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "La huella resultante puede ser distribuida por medios públicos, incluyendo correo electrónico, sin riesgos. Si está pidiendo a alguien que haga la verificación por usted, pueden enviarle los resultados usando cualquier método."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "El servido rehusó autenticar usando los métodos soportados."
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "El usuario debe cerrar sesión y volver a iniciarla para que la nueva configuración tome efecto."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "El nombre de usuario sólo puede contener letras (a-z), dígitos, puntos, guiones y guiones bajos."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "No hay claves públicas autorizadas para esta cuenta."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Este grupo es el grupo primario para los siguientes usuarios:"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta herramienta configura la política de SELinux y puede ayudarle a comprender y resolver infracciones de la política."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta herramienta genera un archivo de configuración e información de diagnóstico del sistema en ejecución. El archivo puede ser almacenado localmente o centralmente para propósitos de registro o seguimiento, o puede ser enviado a representantes de soporte técnico, desarrolladores o administradores de sistemas para asistir con la detección de fallos y su corrección."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta herramienta gestiona el almacenamiento local, como sistemas de archivos, grupos de volúmenes LVM2 y montajes NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta herramienta gestiona la configuración de red como agrupaciones, puentes, grupos, las VLAN y cortafuegos usando NetworkManager y Firewalld. NetworkManager es incompatible con systemd-networkd habilitado por defecto en Ubuntu y con los scripts de ifupdown de Debian."
 ],
 "This user name already exists": [
  null,
  "El nombre del usuario ya existe"
 ],
 "Time zone": [
  null,
  "Huso horario"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantizar que su conexión no sea interceptada por un tercero malicioso, por favor verifique la huella de clave del anfitrión:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar una huella, ejecute lo siguiente en $0 mientras se sitúa físicamente frente a la máquina o a través de una red de confianza:"
 ],
 "Toggle date picker": [
  null,
  "Alternar el selector de fecha"
 ],
 "Too much data": [
  null,
  "Demasiados datos"
 ],
 "Total size: $0": [
  null,
  "Tamaño total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Trust and add host": [
  null,
  "Confiar en el anfitrión y añadirlo"
 ],
 "Trying to synchronize with $0": [
  null,
  "Intentando sincronizar con $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "No se pudo iniciar sesión en $0. El servidor no acepta inicio de sesión por contraseña ni ninguna de tus claves SSH."
 ],
 "Undo": [
  null,
  "Deshacer"
 ],
 "Unexpected error": [
  null,
  "Error inesperado"
 ],
 "Unknown": [
  null,
  "Desconocido"
 ],
 "Unnamed": [
  null,
  "Sin nombre"
 ],
 "Untrusted host": [
  null,
  "Anfitrión no seguro"
 ],
 "Use password": [
  null,
  "Usar contraseña"
 ],
 "User ID": [
  null,
  "ID de Usuario (UID)"
 ],
 "User ID is already used by another user": [
  null,
  "Otro usuario ya utiliza este UID"
 ],
 "User ID must be a positive integer": [
  null,
  "El UID debe ser un número entero positivo"
 ],
 "User ID must not be higher than $0": [
  null,
  "El UID no debe ser superior a $0"
 ],
 "User ID must not be lower than $0": [
  null,
  "El UID no debe ser inferior a $0"
 ],
 "User name": [
  null,
  "Nombre de usuario"
 ],
 "Username": [
  null,
  "Nombre de usuario"
 ],
 "Verify fingerprint": [
  null,
  "Verifique la huella"
 ],
 "View all logs": [
  null,
  "Ver todos los registros"
 ],
 "View automation script": [
  null,
  "Ver el script de automatización"
 ],
 "Visit firewall": [
  null,
  "Ir al cortafuegos"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Esperando a que finalicen otras operaciones de gestión de software"
 ],
 "Weak password": [
  null,
  "Contraseña débil"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web para servidores Linux"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Se está conectando con $0 por primera vez."
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "No tiene permiso para ver las claves públicas autorizadas para esta cuenta."
 ],
 "You must wait longer to change your password": [
  null,
  "Debe esperar más tiempo para cambiar su contraseña"
 ],
 "Your account": [
  null,
  "Su cuenta"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tu navegador no admite pegar desde el menú contextual. Puedes usar Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Su sesión se ha terminado."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Su sesión ha expirado. Por favor inicie sesión otra vez."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[datos binarios]"
 ],
 "[no data]": [
  null,
  "[no hay datos]"
 ],
 "change": [
  null,
  "cambiar"
 ],
 "edit": [
  null,
  "editar"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "calidad de la contraseña"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ],
 "user": [
  null,
  "usuario"
 ]
});
