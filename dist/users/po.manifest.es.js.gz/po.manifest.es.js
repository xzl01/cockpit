cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Cuentas"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Managing user accounts": [
  null,
  "Gestión de cuentas de usuario"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "access": [
  null,
  "acceso"
 ],
 "keys": [
  null,
  "teclas"
 ],
 "login": [
  null,
  "login"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "contraseña"
 ],
 "roles": [
  null,
  "roles"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "usuario"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nombre de usuario"
 ]
});
