cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Konton"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Managing user accounts": [
  null,
  "Hantera användarkonton"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "access": [
  null,
  "åtkomst"
 ],
 "keys": [
  null,
  "nycklar"
 ],
 "login": [
  null,
  "login"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "lösenord"
 ],
 "roles": [
  null,
  "roller"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "användare"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "användarnamn"
 ]
});
