cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Облікові записи"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Managing user accounts": [
  null,
  "Керування обліковими записами користувачів"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "access": [
  null,
  "доступ"
 ],
 "keys": [
  null,
  "ключі"
 ],
 "login": [
  null,
  "вхід"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "пароль"
 ],
 "roles": [
  null,
  "ролі"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "користувач"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "користувач"
 ]
});
