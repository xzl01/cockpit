cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "К-ть користувачів"
 ],
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 is an existing file": [
  null,
  "$0 є наявним файлом"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 more...": [
  null,
  "І ще $0…"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "A group with this name already exists": [
  null,
  "Група з такою назвою вже існує"
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Acceptable password": [
  null,
  "Прийнятний пароль"
 ],
 "Account expiration": [
  null,
  "Строк дії облікового запису"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Обліковий запис недоступний або його не можна редагувати."
 ],
 "Accounts": [
  null,
  "Облікові записи"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "Add key": [
  null,
  "Додати ключ"
 ],
 "Add public key": [
  null,
  "Додати відкритий ключ"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Адміністрування за допомогою вебконсолі Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документація з ролей Ansible"
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Щоб отримати доступ до виконання привілейованих завдань за допомогою вебконсолі Cockpit, слід пройти розпізнавання"
 ],
 "Authorized public SSH keys": [
  null,
  "Уповноважені відкриті ключі SSH"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматично за допомогою додаткових серверів NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Automation script": [
  null,
  "Скрипт автоматизації"
 ],
 "Back to accounts": [
  null,
  "Назад до облікових записів"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change shell": [
  null,
  "Змінити оболонку"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Налаштування Cockpit для NetworkManager і Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit — програма для керування сервером, яка полегшує адміністрування ваших серверів під керуванням Linux за допомогою програми для перегляду сторінок інтернету. Ви зможете одночасно використовувати термінал і вебінструмент. Службу, яку було запущено за допомогою Cockpit, можна зупинити за допомогою термінала. І навпаки, якщо трапиться помилка у терміналі, ви побачите її у інтерфейсі журналу Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit — чудовий інструмент для системних адміністраторів-початківців. За його допомогою вони без проблем впораються із простими завданнями, зокрема адмініструванням сховищ даних, інспектуванням журналів та запуском і зупиненням служб. Ви зможете одночасно стежити за роботою декількох серверів і адмініструвати ці сервери. Просто додайте їх одним клацанням кнопкою миші і ваш комп’ютер сам нагляне за своїми приятелями."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Збирати і пакувати діагностичні дані і дані щодо підтримки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Збирати дампи аварій ядра"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Confirm new password": [
  null,
  "Підтвердження нового пароля"
 ],
 "Confirm password": [
  null,
  "Підтвердження пароля"
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Create account with non-unique UID": [
  null,
  "Створити обліковий запис із повторюваним UID"
 ],
 "Create account with weak password": [
  null,
  "Створити обліковий запис із простим паролем"
 ],
 "Create and change ownership of home directory": [
  null,
  "Створення і зміна прав власності на домашній каталог"
 ],
 "Create new account": [
  null,
  "Створити новий рахунок"
 ],
 "Create new group": [
  null,
  "Створити групу"
 ],
 "Create new task file with this content.": [
  null,
  "Створити файл завдання із цим вмістом."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Delete $0": [
  null,
  "Вилучити $0"
 ],
 "Delete account": [
  null,
  "Вилучити обліковий запис"
 ],
 "Delete files": [
  null,
  "Вилучити файли"
 ],
 "Delete group": [
  null,
  "Вилучити групу"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Disallow interactive password": [
  null,
  "Заборонити інтерактивний пароль"
 ],
 "Disallow password authentication": [
  null,
  "Заборонити розпізнавання за паролем"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "Downloading $0": [
  null,
  "Отримуємо $0"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "Edit user": [
  null,
  "Змінити запис користувача"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Empty password": [
  null,
  "Порожній пароль"
 ],
 "Ended": [
  null,
  "Завершено"
 ],
 "Error saving authorized keys: ": [
  null,
  "Помилка під час спроби зберегти уповноважені ключі: "
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Expire account on": [
  null,
  "Завершити строк дії облікового запису"
 ],
 "Expire account on $0": [
  null,
  "Завершити строк дії облікового запису $0"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Failed to load authorized keys.": [
  null,
  "Не вдалося завантажити уповноважені ключі."
 ],
 "Fingerprint": [
  null,
  "Відбиток"
 ],
 "Force change": [
  null,
  "Примусова зміна"
 ],
 "Force delete": [
  null,
  "Примусове вилучення"
 ],
 "Force password change": [
  null,
  "Примусова зміна пароля"
 ],
 "From": [
  null,
  "Від"
 ],
 "Full name": [
  null,
  "Повне ім'я"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "Group": [
  null,
  "Група"
 ],
 "Group name": [
  null,
  "Назва групи"
 ],
 "Groups": [
  null,
  "Групи"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "Hide confirmation password": [
  null,
  "Приховати підтвердження пароля"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "Home directory": [
  null,
  "Домашній каталог"
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid expiration date": [
  null,
  "Некоректна дата строку завершення дії"
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Invalid key": [
  null,
  "Некоректний ключ"
 ],
 "Invalid number of days": [
  null,
  "Некоректна кількість днів"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Last active": [
  null,
  "Останній активний"
 ],
 "Last login": [
  null,
  "Останній вхід"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Loading system modifications...": [
  null,
  "Завантажуємо модифікації системи…"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "Local accounts": [
  null,
  "Локальні облікові записи"
 ],
 "Lock": [
  null,
  "Заблокувати"
 ],
 "Lock $0": [
  null,
  "Заблокувати $0"
 ],
 "Lock account": [
  null,
  "Заблокувати обліковий запис"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "Log out": [
  null,
  "Вийти"
 ],
 "Log user out": [
  null,
  "Вийти з облікового запису користувача"
 ],
 "Logged in": [
  null,
  "Вхід"
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "Login history": [
  null,
  "Журнал входів"
 ],
 "Login history list": [
  null,
  "Список журналу входів"
 ],
 "Logout $0": [
  null,
  "Вийти з $0"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Manage storage": [
  null,
  "Керування сховищем"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "Never": [
  null,
  "Ніколи"
 ],
 "Never expire account": [
  null,
  "Строк дії облікового запису є нескінченним"
 ],
 "Never expire password": [
  null,
  "Необмежений строк дії пароля"
 ],
 "Never logged in": [
  null,
  "Ніколи не входив"
 ],
 "New name": [
  null,
  "Нова назва"
 ],
 "New password": [
  null,
  "Новий пароль"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "No ID specified": [
  null,
  "Не вказано ідентифікатора"
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "No group name specified": [
  null,
  "Не вказано назви групи"
 ],
 "No matching results": [
  null,
  "Нічого не знайдено"
 ],
 "No real name specified": [
  null,
  "Не вказано справжнього імені"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "No system modifications": [
  null,
  "Немає модифікацій системи"
 ],
 "No user name specified": [
  null,
  "Не вказано імені користувача"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "Випадки"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Old password": [
  null,
  "Старий пароль"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Після встановлення Cockpit його можна увімкнути за допомогою команди «systemctl enable --now cockpit.socket»."
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Other": [
  null,
  "Інше"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Навіть якщо розпізнавання за інтерактивним паролем заборонено, можна скористатися іншими способами розпізнавання."
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password expiration": [
  null,
  "Строк дії пароля"
 ],
 "Password is longer than 256 characters": [
  null,
  "Довжина пароля перевищує 256 символів"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Password must be changed": [
  null,
  "Пароль має бути змінено"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Paste error": [
  null,
  "Помилка вставлення"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Сюди слід вставити вміст файла вашого відкритого ключа SSH"
 ],
 "Path to directory": [
  null,
  "Шлях до каталогу"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "Permanently delete $0 group?": [
  null,
  "Остаточно вилучити групу $0?"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Please specify an expiration date": [
  null,
  "Будь ласка, вкажіть кінцеву дату строку дії"
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "Prompting via passwd timed out": [
  null,
  "Час очікування відповіді на запит за допомогою passwd вичерпано"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Rename": [
  null,
  "Перейменувати"
 ],
 "Rename group": [
  null,
  "Перейменувати групу"
 ],
 "Rename group $0": [
  null,
  "Перейменувати групу $0"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "Перейменування групи може вплинути на роботу sudo та подібних правил"
 ],
 "Require password change every $0 days": [
  null,
  "Вимагати зміну пароля кожні $0 днів"
 ],
 "Require password change on $0": [
  null,
  "Вимагати зміну пароля $0"
 ],
 "Require password change on first login": [
  null,
  "Вимагати зміну пароля при першому вході"
 ],
 "Reset password": [
  null,
  "Скинути пароль"
 ],
 "Row expansion": [
  null,
  "Розгортання рядка"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Search for name or ID": [
  null,
  "Шукати за назвою або ідентифікатором"
 ],
 "Search for name, group or ID": [
  null,
  "Шукати за назвою, групою або ідентифікатором"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Налаштування Security Enhanced Linux та усування вад"
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "Set password": [
  null,
  "Встановити пароль"
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Set weak password": [
  null,
  "Встановити простий пароль"
 ],
 "Shell": [
  null,
  "Оболонка"
 ],
 "Shell script": [
  null,
  "Скрипт оболонки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Показати підтвердження пароля"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Started": [
  null,
  "Почато"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Strong password": [
  null,
  "Складний пароль"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Terminate session": [
  null,
  "Перервати сеанс"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Обліковий запис «$0» має примусово змінити пароль під час наступного входу"
 ],
 "The full name must not contain colons.": [
  null,
  "У повному імені не повинно міститися двокрапок."
 ],
 "The group ID must be positive integer": [
  null,
  "Ідентифікатор групи має бути додатнім цілим числом"
 ],
 "The group name can only consist of letters from a-z, digits, dots, dashes and underscores": [
  null,
  "Назва групи може складатися лише із літер a-z, цифр, крапок, дефісів та символів підкреслювання"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "Домашній каталог $0 вже існує. Права власності на нього буде змінено для допуску нового користувача."
 ],
 "The key you provided was not valid.": [
  null,
  "Наданий вами ключ є некоректним."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Користувач, який увійшов до системи, не має права переглядати модифікації системи"
 ],
 "The passwords do not match": [
  null,
  "Паролі не збігаються"
 ],
 "The passwords do not match.": [
  null,
  "Паролі не збігаються."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "Для набуття чинності новими налаштуваннями користувач має вийти із системи і увійти до неї знову."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Ім’я користувача може складатися лише із літер a-z, цифр, крапок, дефісів та символів підкреслювання."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Для цього облікового запису немає уповноважених відкритих ключів."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Ця група є основою групою для таких користувачів:"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Цей інструмент налаштовує правила SELinux і може допомогти зрозуміти та усунути порушення правил."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Цей інструмент налаштовує систему на запис дампів аварій ядра на диск."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Цей інструмент створюдє архів даних щодо налаштувань та діагностики для запущеної системи. Архів може бути збережено локально або централізовано з метою журналювання або стеження або надіслано до представників технічної підтримки, розробників або адміністраторів системи, щоб допомогти з пошуком технічних проблем та діагностикою."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Цей інструмент керує локальним сховищем даних, зокрема файловими системами, групами томів LVM2 та монтуваннями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Цей інструмент керує можливостями роботи у мережі, зокрема зв'язками, містками, командами, віртуальними LAN та брандмауерами, за допомогою NetworkManager і Firewalld. NetworkManager є несумісним із типовим для Ubuntu systemd-networkd та скриптами ifupdown Debian."
 ],
 "This user name already exists": [
  null,
  "Запис користувача із таким іменем уже існує"
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "Undo": [
  null,
  "Скасувати"
 ],
 "Unexpected error": [
  null,
  "Неочікувана помилка"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Unnamed": [
  null,
  "Без назви"
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Use password": [
  null,
  "Використати пароль"
 ],
 "User ID": [
  null,
  "Ід. користувача"
 ],
 "User ID is already used by another user": [
  null,
  "Ідентифікатор користувача вже використано для іншого користувача"
 ],
 "User ID must be a positive integer": [
  null,
  "Ідентифікатор користувача має бути додатним цілим числом"
 ],
 "User ID must not be higher than $0": [
  null,
  "Ідентифікатор користувача має бути числом, що перевищує $0"
 ],
 "User ID must not be lower than $0": [
  null,
  "Ідентифікатор користувача не повинен бути меншим за $0"
 ],
 "User name": [
  null,
  "Ім'я користувача"
 ],
 "Username": [
  null,
  "Користувач"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "View automation script": [
  null,
  "Переглянути скрипт автоматизації"
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Weak password": [
  null,
  "Простий пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Вебконсоль для серверів під керуванням Linux"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "У вас немає прав доступу для перегляду уповноважених відкритих ключів для цього облікового запису."
 ],
 "You must wait longer to change your password": [
  null,
  "Для зміни вашого пароля вам доведеться ще почекати"
 ],
 "Your account": [
  null,
  "Ваш обліковий запис"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "У вашій програмі для перегляду не передбачено можливості вставлення з контекстного меню. Ви можете скористатися для вставлення комбінацією Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "change": [
  null,
  "змінити"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "user": [
  null,
  "користувач"
 ]
});
