cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "počet uživatelů"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 is an existing file": [
  null,
  "$0 je existující soubor"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 more...": [
  null,
  "$0 další…"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainstalováno."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "A group with this name already exists": [
  null,
  "Skupina s takovým názvem už existuje"
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Account expiration": [
  null,
  "Skončení platnosti účtu"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Účet není k dispozici nebo ho není možné upravovat."
 ],
 "Accounts": [
  null,
  "Účty"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "Add key": [
  null,
  "Přidat klíč"
 ],
 "Add public key": [
  null,
  "Přidat veřejnou část klíče"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Authentication": [
  null,
  "Ověření se"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ],
 "Authorized public SSH keys": [
  null,
  "Pověřené veřejné SSH klíče"
 ],
 "Automatically using NTP": [
  null,
  "Automatické použití NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické použití dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatické použití uvedených NTP serverů"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "Back to accounts": [
  null,
  "Zpět k účtům"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change shell": [
  null,
  "Změnit shell"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správce serveru, který usnadňuje správu Linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce serverů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Můžete současně sledovat a spravovat několik serverů najednou. Stačí je přidat jedním kliknutím a vaše stroje se budou starat o své kamarády."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Confirm new password": [
  null,
  "Potvrdit nové heslo"
 ],
 "Confirm password": [
  null,
  "Potvrzení hesla"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Create account with non-unique UID": [
  null,
  "Vytvořit účet s identifikátorem, který už je použit"
 ],
 "Create account with weak password": [
  null,
  "Vytvořit účet se snadno prolomitelným heslem"
 ],
 "Create and change ownership of home directory": [
  null,
  "Vytvořit a změnit vlastnictví domovské složky"
 ],
 "Create new account": [
  null,
  "Vytvořit nový účet"
 ],
 "Create new group": [
  null,
  "Vytvořit novou skupinu"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořit nový soubor s úlohou s tímto obsahem."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Delete $0": [
  null,
  "Smazat $0"
 ],
 "Delete account": [
  null,
  "Smazat účet"
 ],
 "Delete files": [
  null,
  "Smazat soubory"
 ],
 "Delete group": [
  null,
  "Smazat skupinu"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Disallow interactive password": [
  null,
  "Neumožnit přihlašování zadáním hesla"
 ],
 "Disallow password authentication": [
  null,
  "Neumožnit přihlašování heslem"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit user": [
  null,
  "Upravit uživatele"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Empty password": [
  null,
  "Prázdné heslo"
 ],
 "Ended": [
  null,
  "Ukončeno"
 ],
 "Error saving authorized keys: ": [
  null,
  "Chyba při ukládání pověřených klíčů: "
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Expire account on": [
  null,
  "Ukončit platnost účtu v"
 ],
 "Expire account on $0": [
  null,
  "Ukončit platnost účtu v $0"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Failed to load authorized keys.": [
  null,
  "Nepodařilo se načíst pověřené klíče."
 ],
 "Fingerprint": [
  null,
  "Otisk"
 ],
 "Force change": [
  null,
  "Vynutit změnu"
 ],
 "Force delete": [
  null,
  "Vynutit smazání"
 ],
 "Force password change": [
  null,
  "Vynutit změnu hesla"
 ],
 "From": [
  null,
  "Z"
 ],
 "Full name": [
  null,
  "Celé jméno"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "Group": [
  null,
  "Skupina"
 ],
 "Group name": [
  null,
  "Název skupiny"
 ],
 "Groups": [
  null,
  "Skupiny"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "Home directory": [
  null,
  "Domovská složka"
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid expiration date": [
  null,
  "Neplatné datum skončení platnosti"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná souborová práva"
 ],
 "Invalid key": [
  null,
  "Neplatný klíč"
 ],
 "Invalid number of days": [
  null,
  "Neplatný počet dnů"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Last active": [
  null,
  "Naposledy aktivní"
 ],
 "Last login": [
  null,
  "Poslední přihlášení"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "Local accounts": [
  null,
  "Místní účty"
 ],
 "Lock": [
  null,
  "Uzamknout"
 ],
 "Lock $0": [
  null,
  "Uzamknout $0"
 ],
 "Lock account": [
  null,
  "Uzamknout účet"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "Log out": [
  null,
  "Odhlásit"
 ],
 "Log user out": [
  null,
  "Odhlásit uživatele"
 ],
 "Logged in": [
  null,
  "Přihlášeni"
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "Login history": [
  null,
  "Historie přihlášení"
 ],
 "Login history list": [
  null,
  "Seznam historie přihlašování"
 ],
 "Logout $0": [
  null,
  "Odhlásit $0"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "Never": [
  null,
  "Nikdy"
 ],
 "Never expire account": [
  null,
  "Účet s neomezenou dobou platnosti"
 ],
 "Never expire password": [
  null,
  "Heslo platí napořád"
 ],
 "Never logged in": [
  null,
  "Nikdy nepříhlášen(a)"
 ],
 "New name": [
  null,
  "Nový název"
 ],
 "New password": [
  null,
  "Nové heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "No ID specified": [
  null,
  "Nezadán žádný identifikátor"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "No group name specified": [
  null,
  "Nezadán žádný název skupiny"
 ],
 "No matching results": [
  null,
  "Žádné shodující se výsledky"
 ],
 "No real name specified": [
  null,
  "Není zadán skutečný název"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "No user name specified": [
  null,
  "Nebylo zadáno uživatelské jméno"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password": [
  null,
  "Původní heslo"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Options": [
  null,
  "Přepínače"
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "I když není umožněno přihlašování se heslem, ostatní metody ověřování se jsou pořád k dispozici."
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password expiration": [
  null,
  "Skončení platnosti hesla"
 ],
 "Password is longer than 256 characters": [
  null,
  "Heslo nemůže být delší než 256 znaků"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Password must be changed": [
  null,
  "Heslo je třeba změnit"
 ],
 "Password not accepted": [
  null,
  "Heslo nebylo přijato"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Sem vložte obsah veřejné části svého ssh klíče"
 ],
 "Path to directory": [
  null,
  "Popis umístění složky"
 ],
 "Path to file": [
  null,
  "Popis umístění serveru"
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "Permanently delete $0 group?": [
  null,
  "Nenávratně smazat skupinu $0?"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Please specify an expiration date": [
  null,
  "Zadejte datum skončení platnosti"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Prompting via passwd timed out": [
  null,
  "Časový limit výzvy prostřednictvím hesla překročen"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Rename": [
  null,
  "Přejmenovat"
 ],
 "Rename group": [
  null,
  "Přejmenovat skupinu"
 ],
 "Rename group $0": [
  null,
  "Přejmenovat skupinu $0"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "Přejmenování skupiny může ovlivnit sudo a podobná pravidla"
 ],
 "Require password change every $0 days": [
  null,
  "Vyžadovat změnu hesla každých $0 dnů"
 ],
 "Require password change on $0": [
  null,
  "Vyžadovat změnu hesla na $0"
 ],
 "Require password change on first login": [
  null,
  "Při prvním přihlášení vyžadovat změnu hesla"
 ],
 "Reset password": [
  null,
  "Resetovat heslo"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Search for name or ID": [
  null,
  "Hledat název nebo identif."
 ],
 "Search for name, group or ID": [
  null,
  "Hledat jméno, skupinu nebo identif."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Set password": [
  null,
  "Nastavit heslo"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Set weak password": [
  null,
  "Nastavit snadno prolomitelné heslo"
 ],
 "Shell": [
  null,
  "Shell"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Started": [
  null,
  "Spuštěno"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Terminate session": [
  null,
  "Ukončit sezení"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Účet „$0“ bude při příštím přihlášení vyzván k vynucené změně hesla"
 ],
 "The full name must not contain colons.": [
  null,
  "Je třeba, aby celé jméno neobsahovalo dvojtečky."
 ],
 "The group ID must be positive integer": [
  null,
  "Je třeba, aby identif. skupiny bylo celé kladné číslo"
 ],
 "The group name can only consist of letters from a-z, digits, dots, dashes and underscores": [
  null,
  "Název skupiny se může sestávat pouze z písmen a-z (bez diakritiky), číslic, teček, spojovníků a podtržítek"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "Domovská složka $0 už existuje. Její vlastnictví bude změněno na nového uživatele."
 ],
 "The key you provided was not valid.": [
  null,
  "Zadaný klíč není platný."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "The passwords do not match": [
  null,
  "Zadání hesla se neshodují"
 ],
 "The passwords do not match.": [
  null,
  "Zadání hesla se neshodují."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "Aby se nová nastavení projevila je třeba, aby se uživatel odhlásil a přihlásil znovu."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Uživatelské jméno se může sestávat pouze z písmen a-z (bez diakritiky), číslic, teček, spojovníků a podtržítek."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Pro tento účet nejsou žádné pověřené klíče."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Tato skupina je primární skupinou pro následující uživatele:"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje pravidla pro SELinux a může pomoci s porozuměním a řešením porušení pravidel."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Tento nástroj nastavuje systém pro zapisování výpisů pádů jádra na disk."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení, mosty, spojení, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s Ubuntu ve výchozím stavu používaným systemd-networkd a skripty ifupdown v distribuci Debian."
 ],
 "This user name already exists": [
  null,
  "Toto uživatelské jméno už existuje"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Undo": [
  null,
  "Zpět"
 ],
 "Unexpected error": [
  null,
  "Neočekávaná chyba"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Unnamed": [
  null,
  "Bez názvu"
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "Use password": [
  null,
  "Použít heslo"
 ],
 "User ID": [
  null,
  "Identif. uživatele"
 ],
 "User ID is already used by another user": [
  null,
  "Identif. uživatele už je používán jiným uživatelem"
 ],
 "User ID must be a positive integer": [
  null,
  "Je třeba, aby identif. uživatele bylo celé kladné číslo"
 ],
 "User ID must not be higher than $0": [
  null,
  "Je třeba, aby identif. nebyl vyšší než $0"
 ],
 "User ID must not be lower than $0": [
  null,
  "Identif. uživatele nemůže být delší než $0"
 ],
 "User name": [
  null,
  "Uživatelské jméno"
 ],
 "Username": [
  null,
  "Uživatelské jméno"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Nemáte oprávnění zobrazovat pověřené klíče pro tento účet."
 ],
 "You must wait longer to change your password": [
  null,
  "Pro změnu hesla je třeba vyčkat déle"
 ],
 "Your account": [
  null,
  "Váš účet"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "change": [
  null,
  "změnit"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "user": [
  null,
  "uživatel"
 ]
});
