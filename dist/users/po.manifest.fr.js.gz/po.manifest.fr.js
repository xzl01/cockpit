cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Comptes"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Managing user accounts": [
  null,
  "Gestion des comptes utilisateurs"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "access": [
  null,
  "accès"
 ],
 "keys": [
  null,
  "clés"
 ],
 "login": [
  null,
  "login"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "mot de passe"
 ],
 "roles": [
  null,
  "rôles"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "utilisateur"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nom d’utilisateur"
 ]
});
