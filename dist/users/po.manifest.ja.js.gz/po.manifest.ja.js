cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "アカウント"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Managing user accounts": [
  null,
  "ユーザーアカウント管理"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "access": [
  null,
  "アクセス"
 ],
 "keys": [
  null,
  "鍵"
 ],
 "login": [
  null,
  "ログイン"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "パスワード"
 ],
 "roles": [
  null,
  "ロール"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "ユーザー"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "ユーザー名"
 ]
});
