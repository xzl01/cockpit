cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "ユーザー数"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 exited with code $1": [
  null,
  "$0 がコード $1 で終了しました"
 ],
 "$0 failed": [
  null,
  "$0 が失敗しました"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 is an existing file": [
  null,
  "$0 は既存のファイルです"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 がシグナル $1 で終了しました"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 more...": [
  null,
  "$0 詳細表示..."
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "A group with this name already exists": [
  null,
  "この名前のグループはすでに存在します"
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Acceptable password": [
  null,
  "受け入れられるパスワード"
 ],
 "Account expiration": [
  null,
  "アカウントの有効期限"
 ],
 "Account not available or cannot be edited.": [
  null,
  "アカウントが利用可能でないか、アカウントを編集できません。"
 ],
 "Accounts": [
  null,
  "アカウント"
 ],
 "Add": [
  null,
  "追加"
 ],
 "Add $0": [
  null,
  "$0 の追加"
 ],
 "Add key": [
  null,
  "キーの追加"
 ],
 "Add public key": [
  null,
  "公開鍵の追加"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの管理"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible ロールのドキュメント"
 ],
 "Authentication": [
  null,
  "認証"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの特権タスクの実行には、認証が必要です"
 ],
 "Authorized public SSH keys": [
  null,
  "承認された公開 SSH 鍵"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using additional NTP servers": [
  null,
  "追加の NTP サーバーを自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "Automation script": [
  null,
  "オートメーションスクリプト"
 ],
 "Back to accounts": [
  null,
  "アカウントに戻る"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Cannot forward login credentials": [
  null,
  "ログインのクレデンシャルをフォワードできません"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change shell": [
  null,
  "シェルの変更"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit の NetworkManager と Firewalld の設定"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit は該当するホストに接続できませんでした。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit は、Web ブラウザーで Linux サーバーを簡単に管理できるサーバーマネージャーです。端末と Web ツールを区別せずに使用できます。Cockpit で起動されたサービスは端末で停止できます。同様に、端末でエラーが発生した場合は、そのエラーを Cockpit ジャーナルインターフェースで確認できます。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit にはシステム上のそのソフトウェアとの互換性がありません。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit はシステムにインストールされていません。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit は経験が少ないシステム管理者に最適です。これらのシステム管理者はストレージの管理、ジャーナルの検査、サービスの起動および停止などの単純なタスクを簡単に実行できるようになります。また、複数のサーバーを同時に監視および管理できます。これらのサーバーはクリックするだけで追加できます。追加後に、ご使用のマシンは他のマシンを管理するようになります。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "診断およびサポートデータの収集とパッケージ化"
 ],
 "Collect kernel crash dumps": [
  null,
  "カーネルクラッシュダンプの収集"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Confirm new password": [
  null,
  "新規パスワードの確認"
 ],
 "Confirm password": [
  null,
  "パスワードの確認"
 ],
 "Connection has timed out.": [
  null,
  "接続がタイムアウトしました。"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Create account with non-unique UID": [
  null,
  "一意ではない UID を使用したアカウントの作成"
 ],
 "Create account with weak password": [
  null,
  "脆弱なパスワードを使用したアカウントの作成"
 ],
 "Create and change ownership of home directory": [
  null,
  "ホームディレクトリーの所有権の作成および変更"
 ],
 "Create new account": [
  null,
  "アカウントの新規作成"
 ],
 "Create new group": [
  null,
  "グループの新規作成"
 ],
 "Create new task file with this content.": [
  null,
  "このコンテンツで新しいタスクファイルを作成します。"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Delete $0": [
  null,
  "$0 の削除"
 ],
 "Delete account": [
  null,
  "アカウントの削除"
 ],
 "Delete files": [
  null,
  "ファイルの削除"
 ],
 "Delete group": [
  null,
  "グループの削除"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Disallow interactive password": [
  null,
  "対話式パスワードを禁止する"
 ],
 "Disallow password authentication": [
  null,
  "パスワード認証を禁止する"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "Edit user": [
  null,
  "ユーザーの編集"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Empty password": [
  null,
  "パスワードが入力されていません"
 ],
 "Ended": [
  null,
  "終了"
 ],
 "Error saving authorized keys: ": [
  null,
  "承認された鍵の保存中にエラーが発生しました: "
 ],
 "Excellent password": [
  null,
  "優れたパスワード"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Expire account on": [
  null,
  "アカウントの有効期限:"
 ],
 "Expire account on $0": [
  null,
  "アカウントの有効期限: $0"
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld での $0 の有効化に失敗しました"
 ],
 "Failed to load authorized keys.": [
  null,
  "承認された鍵のロードに失敗しました。"
 ],
 "Fingerprint": [
  null,
  "フィンガープリント"
 ],
 "Force change": [
  null,
  "変更の強制"
 ],
 "Force delete": [
  null,
  "削除の強制"
 ],
 "Force password change": [
  null,
  "パスワード変更の強制"
 ],
 "From": [
  null,
  "ログイン元"
 ],
 "Full name": [
  null,
  "フルネーム"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "Group": [
  null,
  "グループ"
 ],
 "Group name": [
  null,
  "グループ名"
 ],
 "Groups": [
  null,
  "グループ"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "Hide confirmation password": [
  null,
  "確認パスワードの非表示"
 ],
 "Hide password": [
  null,
  "パスワードの非表示"
 ],
 "Home directory": [
  null,
  "ホームディレクトリー"
 ],
 "Host key is incorrect": [
  null,
  "ホスト鍵が正しくありません"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Internal error": [
  null,
  "内部エラー"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid expiration date": [
  null,
  "無効な有効期限"
 ],
 "Invalid file permissions": [
  null,
  "無効なファイルパーミッション"
 ],
 "Invalid key": [
  null,
  "無効な鍵"
 ],
 "Invalid number of days": [
  null,
  "無効な日数"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Last active": [
  null,
  "最後に操作を行った時間"
 ],
 "Last login": [
  null,
  "最終ログイン"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Loading system modifications...": [
  null,
  "システム変更をロード中..."
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "Local accounts": [
  null,
  "ローカルアカウント"
 ],
 "Lock": [
  null,
  "ロック"
 ],
 "Lock $0": [
  null,
  "$0 のロック"
 ],
 "Lock account": [
  null,
  "アカウントのロック"
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "Log out": [
  null,
  "ログアウト"
 ],
 "Log user out": [
  null,
  "ユーザーのログアウト"
 ],
 "Logged in": [
  null,
  "すでにログインしています"
 ],
 "Login failed": [
  null,
  "ログインが失敗しました"
 ],
 "Login history": [
  null,
  "ログイン履歴"
 ],
 "Login history list": [
  null,
  "ログイン履歴の一覧"
 ],
 "Logout $0": [
  null,
  "$0 のログアウト"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Lunch box": [
  null,
  "ランチボックス"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Manage storage": [
  null,
  "ストレージの管理"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Never": [
  null,
  "しない"
 ],
 "Never expire account": [
  null,
  "アカウントを失効しない"
 ],
 "Never expire password": [
  null,
  "パスワードを失効しない"
 ],
 "Never logged in": [
  null,
  "ログインされていません"
 ],
 "New name": [
  null,
  "新しい名前"
 ],
 "New password": [
  null,
  "新規パスワード"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "No ID specified": [
  null,
  "ID が指定されていません"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "No group name specified": [
  null,
  "グループ名が指定されていません"
 ],
 "No matching results": [
  null,
  "一致する結果はありません"
 ],
 "No real name specified": [
  null,
  "実際の名前が指定されていません"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "No system modifications": [
  null,
  "システム変更がありません"
 ],
 "No user name specified": [
  null,
  "ユーザー名が指定されていません"
 ],
 "Not a valid private key": [
  null,
  "有効な秘密鍵ではありません"
 ],
 "Not permitted to perform this action.": [
  null,
  "この動作を実行する権限がありません。"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Occurrences": [
  null,
  "発生"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password": [
  null,
  "古いパスワード"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit がインストールされたら、\"systemctl enable --now cockpit.socket\" コマンドで有効にします。"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Other": [
  null,
  "その他"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "対話式パスワード認証が許可されない場合でも、他の認証方法を利用できます。"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Password expiration": [
  null,
  "パスワードの有効期限"
 ],
 "Password is longer than 256 characters": [
  null,
  "パスワードは 256 文字以内で設定する必要があります"
 ],
 "Password is not acceptable": [
  null,
  "パスワードは受け入れられません"
 ],
 "Password is too weak": [
  null,
  "パスワードが弱すぎます"
 ],
 "Password must be changed": [
  null,
  "パスワードを変更する必要があります"
 ],
 "Password not accepted": [
  null,
  "パスワードは受け入れられません"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Paste error": [
  null,
  "貼り付けエラー"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "公開 SSH 鍵ファイルの内容をここに貼り付けます"
 ],
 "Path to directory": [
  null,
  "ディレクトリーへのパス"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "Permanently delete $0 group?": [
  null,
  "$0 グループを完全に削除しますか ?"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please specify an expiration date": [
  null,
  "有効期限を指定してください"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Prompting via passwd timed out": [
  null,
  "passwd によるプロンプトがタイムアウトしました"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add によるプロンプトがタイムアウトしました"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen によるプロンプトがタイムアウトしました"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Rename": [
  null,
  "名前変更"
 ],
 "Rename group": [
  null,
  "グループの名前変更"
 ],
 "Rename group $0": [
  null,
  "グループ $0 の名前変更"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "グループの名前を変更すると、sudo や同様のルールに影響が及ぶ可能性があります"
 ],
 "Require password change every $0 days": [
  null,
  "$0 日ごとのパスワードの変更が必要"
 ],
 "Require password change on $0": [
  null,
  "$0 でパスワードの変更が必要"
 ],
 "Require password change on first login": [
  null,
  "初回ログイン時にパスワードの変更が必要"
 ],
 "Reset password": [
  null,
  "パスワードのリセット"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Search for name or ID": [
  null,
  "名前または ID の検索"
 ],
 "Search for name, group or ID": [
  null,
  "名前、グループ、または ID の検索"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux の設定とトラブルシューティング"
 ],
 "Server has closed the connection.": [
  null,
  "サーバーの接続が終了しました。"
 ],
 "Set password": [
  null,
  "パスワードの設定"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Set weak password": [
  null,
  "脆弱なパスワードの設定"
 ],
 "Shell": [
  null,
  "シェル"
 ],
 "Shell script": [
  null,
  "シェルスクリプト"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "確認パスワードの表示"
 ],
 "Show password": [
  null,
  "パスワードを表示する"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Started": [
  null,
  "開始"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Strong password": [
  null,
  "強固なパスワード"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "Terminate session": [
  null,
  "セッションの終了"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "アカウント '$0' が次回ログインする際に、パスワードの変更が求められます"
 ],
 "The full name must not contain colons.": [
  null,
  "フルネームにはコロンを含めることはできません。"
 ],
 "The group ID must be positive integer": [
  null,
  "グループ ID は正の整数である必要があります"
 ],
 "The group name can only consist of letters from a-z, digits, dots, dashes and underscores": [
  null,
  "グループ名には、a-z、数字、ドット、ダッシュ、およびアンダースコアだけが指定できます"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "ホームディレクトリー $0 はすでに存在します。その所有権が新しいユーザーに変更されます。"
 ],
 "The key you provided was not valid.": [
  null,
  "提供した鍵が有効ではありません。"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ログインしているユーザーには、システム変更を表示する権限がありません"
 ],
 "The passwords do not match": [
  null,
  "パスワードが一致しません"
 ],
 "The passwords do not match.": [
  null,
  "パスワードが一致しません。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "サーバーはサポートされた方法を使用した認証を拒否しました。"
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "新しい設定を有効にするには、ユーザーはログアウトしてログインし直す必要があります。"
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "ユーザー名は a〜z の文字、数字、ドット、ダッシュ、およびアンダースコアだけで構成されます。"
 ],
 "There are no authorized public keys for this account.": [
  null,
  "このアカウントに承認された公開鍵がありません。"
 ],
 "This group is the primary group for the following users:": [
  null,
  "このグループは、以下のユーザーのプライマリーグループです:"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "このツールは、SELinux ポリシーを設定します。また、ポリシー違反の把握と解決に役立ちます。"
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "このツールは、カーネルクラッシュダンプをディスクに書き込むようにシステムを設定します。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "このツールは、実行中のシステムから設定および診断情報のアーカイブを生成します。アーカイブは、記録や追跡の目的でローカルまたは一元的に保存することも、技術的な障害の発見やデバッグを支援するためにテクニカルサポート担当者、開発者、システム管理者に送信することもできます。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "このツールは、ファイルシステム、LVM2 ボリュームグループ、NFS マウントなどのローカルストレージを管理します。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "このツールは、NetworkManager と Firewalld を使用して、ボンディング、ブリッジ、チーム、VLAN、ファイアウォールなどのネットワーク設定を管理します。NetworkManager は、Ubuntu のデフォルトの systemd-networkd および Debian の ifupdown スクリプトと互換性がありません。"
 ],
 "This user name already exists": [
  null,
  "このユーザー名はすでに存在します"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Too much data": [
  null,
  "データが多すぎます"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "Undo": [
  null,
  "元に戻す"
 ],
 "Unexpected error": [
  null,
  "予期しないエラー"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unnamed": [
  null,
  "名前なし"
 ],
 "Untrusted host": [
  null,
  "信用できないホスト"
 ],
 "Use password": [
  null,
  "ユーザーパスワード"
 ],
 "User ID": [
  null,
  "ユーザー ID"
 ],
 "User ID is already used by another user": [
  null,
  "ユーザー ID が別のユーザーによってすでに使用されています"
 ],
 "User ID must be a positive integer": [
  null,
  "ユーザー ID は正の整数である必要があります"
 ],
 "User ID must not be higher than $0": [
  null,
  "ユーザー ID は $0 よりも大きくすることはできません"
 ],
 "User ID must not be lower than $0": [
  null,
  "ユーザー ID は $0 よりも小さくすることはできません"
 ],
 "User name": [
  null,
  "ユーザー名"
 ],
 "Username": [
  null,
  "ユーザー名"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "View automation script": [
  null,
  "オートメーションスクリプトの表示"
 ],
 "Visit firewall": [
  null,
  "ファイアウォールへのアクセス"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Weak password": [
  null,
  "脆弱なパスワード"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux サーバー用 Web コンソール"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "このアカウントに承認された公開鍵を表示するパーミッションがありません。"
 ],
 "You must wait longer to change your password": [
  null,
  "パスワードを変更するにはより長い時間の経過が必要です"
 ],
 "Your account": [
  null,
  "お使いのアカウント"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "お使いのブラウザーでは、コンテキストメニューからの貼り付けが許可されていません。Shift+Insert を使用できます。"
 ],
 "Your session has been terminated.": [
  null,
  "セッションが終了しました。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "セッションの有効期限が切れました。再度ログインしてください。"
 ],
 "Zone": [
  null,
  "ゾーン"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "change": [
  null,
  "変更"
 ],
 "edit": [
  null,
  "編集"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "パスワードの強度"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "user": [
  null,
  "ユーザー"
 ]
});
