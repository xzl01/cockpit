cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 次缓存命中（含关键命中）"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 exited with code $1": [
  null,
  "进程 $0 已退出，返回码为 $1"
 ],
 "$0 failed": [
  null,
  "进程 $0 运行时出错"
 ],
 "$0 failed login attempt": [
  null,
  "$0 次登录失败"
 ],
 "$0 hour": [
  null,
  "$0 小时"
 ],
 "$0 important hit": [
  null,
  "$0 次命中（含关键命中）"
 ],
 "$0 is not available from any repository.": [
  null,
  "没有提供 $0 组件的仓库。"
 ],
 "$0 killed with signal $1": [
  null,
  "进程 $0 被信号 $1 终止"
 ],
 "$0 low severity hit": [
  null,
  "$0 次低关键性命中"
 ],
 "$0 minute": [
  null,
  "$0 分钟"
 ],
 "$0 moderate hit": [
  null,
  "$0 次命中（含中等关键性命中）"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 service has failed": [
  null,
  "$0 个系统服务故障"
 ],
 "$0 week": [
  null,
  "$0 周"
 ],
 "$0 will be installed.": [
  null,
  "即将安装 $0。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0: crash at $1": [
  null,
  "$0：于 $1 崩溃"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 hour": [
  null,
  "1 小时"
 ],
 "1 minute": [
  null,
  "1 分钟"
 ],
 "1 week": [
  null,
  "1 周"
 ],
 "10th": [
  null,
  "10 日"
 ],
 "11th": [
  null,
  "11 日"
 ],
 "12th": [
  null,
  "12 日"
 ],
 "13th": [
  null,
  "13 日"
 ],
 "14th": [
  null,
  "14 日"
 ],
 "15th": [
  null,
  "15 日"
 ],
 "16th": [
  null,
  "16 日"
 ],
 "17th": [
  null,
  "17 日"
 ],
 "18th": [
  null,
  "18 日"
 ],
 "19th": [
  null,
  "19 日"
 ],
 "1st": [
  null,
  "1 日"
 ],
 "20 minutes": [
  null,
  "20 分钟"
 ],
 "20th": [
  null,
  "20 日"
 ],
 "21th": [
  null,
  "21 日"
 ],
 "22th": [
  null,
  "22 日"
 ],
 "23th": [
  null,
  "23 日"
 ],
 "24th": [
  null,
  "24 日"
 ],
 "25th": [
  null,
  "25 日"
 ],
 "26th": [
  null,
  "26 日"
 ],
 "27th": [
  null,
  "27 日"
 ],
 "28th": [
  null,
  "28 日"
 ],
 "29th": [
  null,
  "29 日"
 ],
 "2nd": [
  null,
  "2 日"
 ],
 "30th": [
  null,
  "30 日"
 ],
 "31st": [
  null,
  "31 日"
 ],
 "3rd": [
  null,
  "3 日"
 ],
 "40 minutes": [
  null,
  "40 分钟"
 ],
 "4th": [
  null,
  "4 日"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "5th": [
  null,
  "5 日"
 ],
 "6 hours": [
  null,
  "6 小时"
 ],
 "60 minutes": [
  null,
  "60 分钟"
 ],
 "6th": [
  null,
  "6 日"
 ],
 "7th": [
  null,
  "7 日"
 ],
 "8th": [
  null,
  "8 日"
 ],
 "9th": [
  null,
  "9 日"
 ],
 "Absent": [
  null,
  "空缺"
 ],
 "Acceptable password": [
  null,
  "可行的密码"
 ],
 "Active since ": [
  null,
  "完成启动时间： "
 ],
 "Active state": [
  null,
  "启动状态"
 ],
 "Add": [
  null,
  "添加"
 ],
 "Add $0": [
  null,
  "添加 $0"
 ],
 "Additional actions": [
  null,
  "额外操作"
 ],
 "Additional packages:": [
  null,
  "额外软件包："
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 网页控制台管理系统"
 ],
 "Advanced TCA": [
  null,
  "高级 TCA"
 ],
 "After": [
  null,
  "后于"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "离开该域后，仅有使用本地凭据的用户可以登录到该主机。这一操作还可能更改 DNS 解析设置及 CA 信任列表，进而影响其他服务。"
 ],
 "After system boot": [
  null,
  "系统引导后"
 ],
 "Alert and above": [
  null,
  "“警报 (Alert)”及更高级别"
 ],
 "Alias": [
  null,
  "别名"
 ],
 "All": [
  null,
  "所有"
 ],
 "All-in-one": [
  null,
  "一体机"
 ],
 "Allow running (unmask)": [
  null,
  "启用服务 (unmask)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文档"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "您可以对日志中的任意文本字符串进行过滤（可使用正则表达式）。此外，本过滤器支持按消息日志字段进行过滤：各字段由空格分隔（格式为 FIELD=VALUE），其中赋值 (VALUE) 亦可是由逗号分隔列出的、符合格式的各种赋值。"
 ],
 "Appearance": [
  null,
  "外观"
 ],
 "Apply and reboot": [
  null,
  "应用并重启"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "正在应用新策略…… 这可能需要几分钟时间。"
 ],
 "Asset tag": [
  null,
  "资产标签"
 ],
 "At minute": [
  null,
  "在分钟"
 ],
 "At second": [
  null,
  "在秒"
 ],
 "At specific time": [
  null,
  "在指定时间"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "通过Cockpit Web Console进行验证后才能执行特权操作"
 ],
 "Automatically starts": [
  null,
  "自动启动"
 ],
 "Automatically using NTP": [
  null,
  "自动使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自动使用额外的 NTP 服务器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自动使用指定的 NTP 服务器"
 ],
 "Automation script": [
  null,
  "自动化脚本"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS 日期"
 ],
 "BIOS version": [
  null,
  "BIOS 版本"
 ],
 "Bad": [
  null,
  "错误"
 ],
 "Bad setting": [
  null,
  "错误设置"
 ],
 "Before": [
  null,
  "前于"
 ],
 "Binds to": [
  null,
  "绑定到"
 ],
 "Black": [
  null,
  "黑色"
 ],
 "Blade": [
  null,
  "刀片"
 ],
 "Blade enclosure": [
  null,
  "刀片机箱"
 ],
 "Boot": [
  null,
  "引导"
 ],
 "Bound by": [
  null,
  "边界为"
 ],
 "Bus expansion chassis": [
  null,
  "总线扩展机箱"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU安全性"
 ],
 "CPU security toggles": [
  null,
  "CPU安全性开关"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "使用当前的过滤器组合找不到任何日志。"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cancel poweroff": [
  null,
  "取消关机"
 ],
 "Cancel reboot": [
  null,
  "取消重启"
 ],
 "Cannot be enabled": [
  null,
  "无法被启用"
 ],
 "Cannot forward login credentials": [
  null,
  "无法转发登录凭证"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "无法加入域，因为 realmd 在此系统上不可用"
 ],
 "Cannot schedule event in the past": [
  null,
  "无法调度以前的事件"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Change cryptographic policy": [
  null,
  "更改加密策略"
 ],
 "Change host name": [
  null,
  "修改主机名"
 ],
 "Change performance profile": [
  null,
  "变更性能配置"
 ],
 "Change profile": [
  null,
  "变更配置"
 ],
 "Change system time": [
  null,
  "修改系统时间"
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "Class": [
  null,
  "等级"
 ],
 "Clear 'Failed to start'": [
  null,
  "清除 'Failed to start'"
 ],
 "Clear all filters": [
  null,
  "清除所有过滤规则"
 ],
 "Client software": [
  null,
  "客户端软件"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 的 Cockpit 配置和防火墙"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 无法联系指定的主机。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一个服务器管理工具，可以方便地通过浏览器来管理您的 Linux 服务器。在终端和 web 工具间自由切换将不是问题。通过 Cockpit 启动的服务可以通过终端停止。同样，如果在终端中发生错误, 也可以在 Cockpit 的日志接口中看到。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 与系统上的软件不兼容。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安装在系统上。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 是完美的系统管理员工具，它可以轻松完成简单的任务, 如存储管理, 检查日志信息，以及启动/停止服务。 您可以同时监控和管理多个服务器。点一键就可以添加服务器，并开始进行管理。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集并打包诊断和支持数据"
 ],
 "Collect kernel crash dumps": [
  null,
  "收集内核崩溃转储"
 ],
 "Command": [
  null,
  "命令"
 ],
 "Command not found": [
  null,
  "未找到命令"
 ],
 "Communication with tuned has failed": [
  null,
  "与 tuned 通信失败"
 ],
 "Compact PCI": [
  null,
  "紧凑型 PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "条件 $0=$1 不满足"
 ],
 "Condition failed": [
  null,
  "条件失败"
 ],
 "Configuration": [
  null,
  "配置"
 ],
 "Confirm deletion of $0": [
  null,
  "确认删除 $0"
 ],
 "Conflicted by": [
  null,
  "冲突"
 ],
 "Conflicts": [
  null,
  "冲突"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "连接到 dbus 失败：$0"
 ],
 "Connection has timed out.": [
  null,
  "连接超时。"
 ],
 "Consists of": [
  null,
  "组成"
 ],
 "Contacted domain": [
  null,
  "联系的域"
 ],
 "Controller": [
  null,
  "控制器"
 ],
 "Convertible": [
  null,
  "可转换"
 ],
 "Copy": [
  null,
  "复制"
 ],
 "Copy to clipboard": [
  null,
  "复制到剪贴板"
 ],
 "Crash reporting": [
  null,
  "崩溃报告"
 ],
 "Create": [
  null,
  "创建"
 ],
 "Create new task file with this content.": [
  null,
  "使用此内容创建新的任务文件。"
 ],
 "Create timer": [
  null,
  "创建定时器"
 ],
 "Critical and above": [
  null,
  "Critical 及更高级别"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "加密策略是一个系统组件，它配置内核加密子系统，覆盖 TLS、IPSec、SSH、DNSSec 和 Kerberos 协议。"
 ],
 "Cryptographic policy": [
  null,
  "加密策略"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "加密策略不一致"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "当前启动"
 ],
 "Custom cryptographic policy": [
  null,
  "自定义加密策略"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "允许带有 SHA-1 签名验证的 DEFAULT。"
 ],
 "Daily": [
  null,
  "每日"
 ],
 "Dark": [
  null,
  "暗色"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "日期规格应为 YYYY-MM-DD hh:mm:ss 格式。另外，也可以使用字符串 'yesterday', 'today', 'tomorrow'。'now' 代表当前时间。另外，还可以指定相对时间，前缀为 '-' 或 '+'"
 ],
 "Debug and above": [
  null,
  "Debug 及更高级别"
 ],
 "Decrease by one": [
  null,
  "减一"
 ],
 "Default": [
  null,
  "默认"
 ],
 "Delay": [
  null,
  "延时"
 ],
 "Delay must be a number": [
  null,
  "延迟必须是一个数字"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Deletion will remove the following files:": [
  null,
  "删除操作会删除以下文件："
 ],
 "Description": [
  null,
  "描述"
 ],
 "Desktop": [
  null,
  "桌面"
 ],
 "Detachable": [
  null,
  "可拆开"
 ],
 "Details": [
  null,
  "详情"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Disable simultaneous multithreading": [
  null,
  "禁用同步多线程"
 ],
 "Disable tuned": [
  null,
  "禁用 tuned"
 ],
 "Disabled": [
  null,
  "禁用"
 ],
 "Disallow running (mask)": [
  null,
  "不允许运行 (屏蔽)"
 ],
 "Docking station": [
  null,
  "扩展坞"
 ],
 "Does not automatically start": [
  null,
  "不自动启动"
 ],
 "Domain": [
  null,
  "域"
 ],
 "Domain address": [
  null,
  "域地址"
 ],
 "Domain administrator name": [
  null,
  "域管理员用户名"
 ],
 "Domain administrator password": [
  null,
  "域管理员密码"
 ],
 "Domain could not be contacted": [
  null,
  "无法联系到域"
 ],
 "Domain is not supported": [
  null,
  "不支持域"
 ],
 "Don't repeat": [
  null,
  "不要重复"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Dual rank": [
  null,
  "双通道"
 ],
 "Edit /etc/motd": [
  null,
  "编辑 /etc/motd"
 ],
 "Edit motd": [
  null,
  "编辑 motd"
 ],
 "Embedded PC": [
  null,
  "嵌入式 PC"
 ],
 "Enabled": [
  null,
  "启用"
 ],
 "Entry at $0": [
  null,
  "于 $0 的条目"
 ],
 "Error": [
  null,
  "错误"
 ],
 "Error and above": [
  null,
  "Error 及更高级别"
 ],
 "Error message": [
  null,
  "错误信息"
 ],
 "Excellent password": [
  null,
  "密码强度良好"
 ],
 "Expansion chassis": [
  null,
  "扩展机箱"
 ],
 "Extended information": [
  null,
  "扩展的信息"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS 没有被正确启用"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "具有进一步通用标准限制的 FIPS。"
 ],
 "Failed to change password": [
  null,
  "修改密码失败"
 ],
 "Failed to disable tuned": [
  null,
  "禁用 tuned 失败"
 ],
 "Failed to disable tuned profile": [
  null,
  "禁用调优的配置文件失败"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "在 firewalld 中启用 $0 失败"
 ],
 "Failed to enable tuned": [
  null,
  "启用 tuned 失败"
 ],
 "Failed to fetch logs": [
  null,
  "获取日志失败"
 ],
 "Failed to load unit": [
  null,
  "加载单元失败"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "保存 /etc/motd 中的更改失败"
 ],
 "Failed to start": [
  null,
  "启动失败"
 ],
 "Failed to switch profile": [
  null,
  "切换配置集失败"
 ],
 "File state": [
  null,
  "文件状态"
 ],
 "Filter by name or description": [
  null,
  "根据名称或描述进行过滤"
 ],
 "Filters": [
  null,
  "过滤"
 ],
 "Font size": [
  null,
  "字体大小"
 ],
 "Forbidden from running": [
  null,
  "禁止运行"
 ],
 "Frame number": [
  null,
  "帧号"
 ],
 "Free-form search": [
  null,
  "自由形式搜索"
 ],
 "Fridays": [
  null,
  "周五"
 ],
 "General": [
  null,
  "通用"
 ],
 "Generated": [
  null,
  "生成的"
 ],
 "Go to $0": [
  null,
  "前往 $0"
 ],
 "Go to now": [
  null,
  "转到现在"
 ],
 "Handheld": [
  null,
  "手持式"
 ],
 "Hardware information": [
  null,
  "硬件信息"
 ],
 "Health": [
  null,
  "健康"
 ],
 "Help": [
  null,
  "帮助"
 ],
 "Hide confirmation password": [
  null,
  "隐藏确认密码"
 ],
 "Hide password": [
  null,
  "隐藏密码"
 ],
 "Hierarchy ID": [
  null,
  "层次结构 ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "更高的互操作性会增加被安全攻击的面积。"
 ],
 "Host key is incorrect": [
  null,
  "主机密钥不正确"
 ],
 "Hostname": [
  null,
  "主机名"
 ],
 "Hourly": [
  null,
  "每小时"
 ],
 "Hours": [
  null,
  "小时"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "标识符"
 ],
 "Increase by one": [
  null,
  "加一"
 ],
 "Indirect": [
  null,
  "间接的"
 ],
 "Info and above": [
  null,
  "Info 及更高级别"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "安装"
 ],
 "Install realmd support": [
  null,
  "安装 realmd 支持"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Internal error": [
  null,
  "内部错误"
 ],
 "Invalid": [
  null,
  "无效"
 ],
 "Invalid date format": [
  null,
  "无效的日期格式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "无效的日期格式和时间格式"
 ],
 "Invalid file permissions": [
  null,
  "无效的文件权限"
 ],
 "Invalid time format": [
  null,
  "无效的时间格式"
 ],
 "Invalid timezone": [
  null,
  "无效的时区"
 ],
 "IoT gateway": [
  null,
  "IoT 网关"
 ],
 "Join": [
  null,
  "加入"
 ],
 "Join domain": [
  null,
  "加入域"
 ],
 "Joining": [
  null,
  "加入"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "加入域需要安装 realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "不支持加入该域"
 ],
 "Joins namespace of": [
  null,
  "加入命名空间"
 ],
 "Journal": [
  null,
  "日志"
 ],
 "Journal entry": [
  null,
  "日志条目"
 ],
 "Journal entry not found": [
  null,
  "未找到日志条目"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "具有活动目录互操作性的 LEGACY。"
 ],
 "Laptop": [
  null,
  "笔记本电脑"
 ],
 "Last 24 hours": [
  null,
  "最近 24 小时"
 ],
 "Last 7 days": [
  null,
  "最近 7 天"
 ],
 "Last successful login:": [
  null,
  "最后成功的登录："
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Leave $0": [
  null,
  "离开 $0"
 ],
 "Leave domain": [
  null,
  "离开域"
 ],
 "Light": [
  null,
  "亮色"
 ],
 "Limits": [
  null,
  "限制"
 ],
 "Linked": [
  null,
  "连接"
 ],
 "Listen": [
  null,
  "监听"
 ],
 "Listing units": [
  null,
  "列出单元"
 ],
 "Listing units failed: $0": [
  null,
  "列出单元失败：$0"
 ],
 "Load earlier entries": [
  null,
  "载入更早条目"
 ],
 "Loading earlier entries": [
  null,
  "载入更早的条目"
 ],
 "Loading keys...": [
  null,
  "正在加载密钥 ......"
 ],
 "Loading of SSH keys failed": [
  null,
  "加载 SSH 密钥失败"
 ],
 "Loading of units failed": [
  null,
  "单元加载失败"
 ],
 "Loading system modifications...": [
  null,
  "加载系统改变..."
 ],
 "Loading unit failed": [
  null,
  "加载单元失败"
 ],
 "Loading...": [
  null,
  "载入中..."
 ],
 "Log messages": [
  null,
  "日志消息"
 ],
 "Login failed": [
  null,
  "登录失败"
 ],
 "Login format": [
  null,
  "登陆格式"
 ],
 "Logs": [
  null,
  "日志"
 ],
 "Low profile desktop": [
  null,
  "低调桌面"
 ],
 "Lunch box": [
  null,
  "主机类型"
 ],
 "Machine ID": [
  null,
  "机器编号"
 ],
 "Machine SSH key fingerprints": [
  null,
  "主机 SSH 密钥指纹"
 ],
 "Main server chassis": [
  null,
  "主服务器机箱"
 ],
 "Maintenance": [
  null,
  "维护"
 ],
 "Manage storage": [
  null,
  "管理存储"
 ],
 "Manually": [
  null,
  "手动的"
 ],
 "Mask service": [
  null,
  "屏蔽服务"
 ],
 "Masked": [
  null,
  "已屏蔽"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "屏蔽服务会阻止所有依赖的单元被运行。这所造成的影响可能会比预期的大。请确认您需要屏蔽这个单元。"
 ],
 "Memory": [
  null,
  "内存"
 ],
 "Memory technology": [
  null,
  "内存拓扑"
 ],
 "Merged": [
  null,
  "合并"
 ],
 "Message to logged in users": [
  null,
  "发送给已登录用户的信息"
 ],
 "Mini PC": [
  null,
  "迷你电脑"
 ],
 "Mini tower": [
  null,
  "迷你塔式主机"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "分钟需要是 0-59 间的数字"
 ],
 "Minutely": [
  null,
  "每分钟"
 ],
 "Minutes": [
  null,
  "分钟"
 ],
 "Mitigations": [
  null,
  "缓解"
 ],
 "Model": [
  null,
  "型号"
 ],
 "Mondays": [
  null,
  "周一"
 ],
 "Monthly": [
  null,
  "每月"
 ],
 "Multi-system chassis": [
  null,
  "多系统机箱"
 ],
 "NTP server": [
  null,
  "NTP 服务器"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一个 NTP 服务器"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "New password was not accepted": [
  null,
  "新密码不被接受"
 ],
 "No": [
  null,
  "否"
 ],
 "No delay": [
  null,
  "无延时"
 ],
 "No host keys found.": [
  null,
  "没有找到主机密钥。"
 ],
 "No log entries": [
  null,
  "无日志条目"
 ],
 "No logs found": [
  null,
  "没有找到日志"
 ],
 "No matching results": [
  null,
  "没有找到匹配的结果"
 ],
 "No results found": [
  null,
  "没有找到结果"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "没有结果符合过滤条件。清除所有过滤器以显示结果。"
 ],
 "No rule hits": [
  null,
  "无规则命中"
 ],
 "No such file or directory": [
  null,
  "没有该文件或目录"
 ],
 "No system modifications": [
  null,
  "没有系统改变"
 ],
 "None": [
  null,
  "无"
 ],
 "Not a valid private key": [
  null,
  "无效的私钥"
 ],
 "Not connected to Insights": [
  null,
  "没有连接到 Insights"
 ],
 "Not found": [
  null,
  "未找到"
 ],
 "Not permitted to configure realms": [
  null,
  "不允许配置域"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允许执行该操作。"
 ],
 "Not running": [
  null,
  "未运行"
 ],
 "Not synchronized": [
  null,
  "未同步"
 ],
 "Note": [
  null,
  "注意"
 ],
 "Notebook": [
  null,
  "笔记本"
 ],
 "Notice and above": [
  null,
  "Notice 及更高级别"
 ],
 "Occurrences": [
  null,
  "发生"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Old password not accepted": [
  null,
  "旧密码不被接受"
 ],
 "On failure": [
  null,
  "失败时"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "在安装 Cockpit 后，使用 \"systemctl enable --now cockpit.socket\" 启用它。"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "只允许使用字母, 数字, : , _ , . , @ , -"
 ],
 "Only emergency": [
  null,
  "只限紧急情况"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "仅在使用 FIPS 模式引导时才使用已批准和允许的算法。"
 ],
 "Other": [
  null,
  "其他"
 ],
 "Overview": [
  null,
  "概览"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "Part of": [
  null,
  "部分"
 ],
 "Password is not acceptable": [
  null,
  "不接受该密码"
 ],
 "Password is too weak": [
  null,
  "密码太弱"
 ],
 "Password not accepted": [
  null,
  "密码未接受"
 ],
 "Paste": [
  null,
  "粘贴"
 ],
 "Paste error": [
  null,
  "粘贴错误"
 ],
 "Path": [
  null,
  "路径"
 ],
 "Path to file": [
  null,
  "文件路径"
 ],
 "Paths": [
  null,
  "路径"
 ],
 "Pause": [
  null,
  "暂停"
 ],
 "Performance profile": [
  null,
  "性能配置集"
 ],
 "Peripheral chassis": [
  null,
  "外设机箱"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Pin unit": [
  null,
  "固定单元"
 ],
 "Pinned unit": [
  null,
  "固定单元"
 ],
 "Pizza box": [
  null,
  "披萨盒"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Present": [
  null,
  "当前"
 ],
 "Pretty host name": [
  null,
  "易读主机名"
 ],
 "Previous boot": [
  null,
  "以前启动"
 ],
 "Priority": [
  null,
  "优先级"
 ],
 "Problem details": [
  null,
  "问题详情"
 ],
 "Problem info": [
  null,
  "问题信息"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "通过 ssh-add 提示超时"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "通过 ssh-keygen 提示超时"
 ],
 "Propagates reload to": [
  null,
  "传播重新加载到"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "防止近期被安全攻击会降低互操作性。"
 ],
 "RAID chassis": [
  null,
  "RAID 机箱"
 ],
 "Rack mount chassis": [
  null,
  "机架式机箱"
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Read more...": [
  null,
  "了解更多..."
 ],
 "Read-only": [
  null,
  "只读"
 ],
 "Real host name": [
  null,
  "实际主机名"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "实际主机名仅包含小写字母、数字、破折号和句号（包括填充的子域）"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "实际主机名必须小于等于64个字符"
 ],
 "Reapply and reboot": [
  null,
  "重新应用并重启"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "建议的，当前威胁模型的安全设置。"
 ],
 "Reload": [
  null,
  "重载"
 ],
 "Reload propagated from": [
  null,
  "重新加载的传播来自"
 ],
 "Reloading": [
  null,
  "重新加载中"
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Remove": [
  null,
  "删除"
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Repeat": [
  null,
  "重复"
 ],
 "Repeat monthly": [
  null,
  "每月重复"
 ],
 "Repeat weekly": [
  null,
  "每周重复"
 ],
 "Report": [
  null,
  "报告"
 ],
 "Report to ABRT Analytics": [
  null,
  "向ABRT Analytics 报告"
 ],
 "Reported; no links available": [
  null,
  "已报告；没有可用的链接"
 ],
 "Reporting failed": [
  null,
  "报告失败"
 ],
 "Reporting was canceled": [
  null,
  "报告已取消"
 ],
 "Reports:": [
  null,
  "报告："
 ],
 "Required by": [
  null,
  "要求的"
 ],
 "Required by ": [
  null,
  "要求自 "
 ],
 "Requires": [
  null,
  "要求"
 ],
 "Requires administration access to edit": [
  null,
  "需要管理访问权限进行编辑"
 ],
 "Requisite": [
  null,
  "必要"
 ],
 "Requisite of": [
  null,
  "必备的"
 ],
 "Reset": [
  null,
  "重置"
 ],
 "Restart": [
  null,
  "重启"
 ],
 "Resume": [
  null,
  "恢复"
 ],
 "Review cryptographic policy": [
  null,
  "检查加密策略"
 ],
 "Run at": [
  null,
  "运行于"
 ],
 "Run on": [
  null,
  "运行于"
 ],
 "Running": [
  null,
  "运行中"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "周六"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save and reboot": [
  null,
  "保存并重启"
 ],
 "Save changes": [
  null,
  "保存更改"
 ],
 "Scheduled poweroff at $0": [
  null,
  "计划在 $0 关闭电源"
 ],
 "Scheduled reboot at $0": [
  null,
  "计划在 $0 重启"
 ],
 "Sealed-case PC": [
  null,
  "密封式 PC"
 ],
 "Search": [
  null,
  "搜索"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "秒需要是 0-59 之间的数字"
 ],
 "Seconds": [
  null,
  "秒"
 ],
 "Secure shell keys": [
  null,
  "安全 shell 密钥"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 配置和故障排除"
 ],
 "Select a identifier": [
  null,
  "选择标识符"
 ],
 "Send": [
  null,
  "发送"
 ],
 "Server has closed the connection.": [
  null,
  "服务器关闭了连接。"
 ],
 "Server software": [
  null,
  "服务器软件"
 ],
 "Service logs": [
  null,
  "服务日志"
 ],
 "Services": [
  null,
  "服务"
 ],
 "Set hostname": [
  null,
  "设置主机名"
 ],
 "Set time": [
  null,
  "设置时间"
 ],
 "Shell script": [
  null,
  "Shell 脚本"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "显示所有线程"
 ],
 "Show confirmation password": [
  null,
  "显示确认密码"
 ],
 "Show fingerprints": [
  null,
  "显示指纹"
 ],
 "Show messages containing given string.": [
  null,
  "显示包含给定字符串的消息."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "显示指定 systemd 单元的消息。"
 ],
 "Show messages from a specific boot.": [
  null,
  "显示来自特定引导的消息."
 ],
 "Show more relationships": [
  null,
  "显示更多关系"
 ],
 "Show password": [
  null,
  "显示密码"
 ],
 "Show relationships": [
  null,
  "显示关系"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Shutdown": [
  null,
  "关机"
 ],
 "Since": [
  null,
  "自从"
 ],
 "Single rank": [
  null,
  "单 rank"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Slot": [
  null,
  "插槽"
 ],
 "Sockets": [
  null,
  "套接字"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "基于软件的临时解决方案可以帮助防止 CPU 安全问题。这些缓解方案会对性能有一定影响。改变这些设置可能会存在风险。"
 ],
 "Space-saving computer": [
  null,
  "节省空间的计算机"
 ],
 "Specific time": [
  null,
  "指定时间"
 ],
 "Speed": [
  null,
  "速度"
 ],
 "Start": [
  null,
  "启动"
 ],
 "Start and enable": [
  null,
  "开始并启用"
 ],
 "Start service": [
  null,
  "启动服务"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "显示指定日期及以后的条目。"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "显示指定日期及以前的条目。"
 ],
 "State": [
  null,
  "状态"
 ],
 "Static": [
  null,
  "静态"
 ],
 "Status": [
  null,
  "状态"
 ],
 "Stick PC": [
  null,
  "PC 棒"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stop and disable": [
  null,
  "停止并禁用"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Strong password": [
  null,
  "强密码"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Sub-Chassis": [
  null,
  "子机箱"
 ],
 "Sub-Notebook": [
  null,
  "子笔记本"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "订阅 systemd 信号失败：$0"
 ],
 "Successfully copied to clipboard": [
  null,
  "成功复制到剪贴板"
 ],
 "Sundays": [
  null,
  "周日"
 ],
 "Synchronized": [
  null,
  "已同步"
 ],
 "Synchronized with $0": [
  null,
  "与 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步"
 ],
 "System": [
  null,
  "系统"
 ],
 "System information": [
  null,
  "系统信息"
 ],
 "System time": [
  null,
  "系统时间"
 ],
 "Systemd units": [
  null,
  "Systemd 单元"
 ],
 "Tablet": [
  null,
  "平板"
 ],
 "Targets": [
  null,
  "目标"
 ],
 "Terminal": [
  null,
  "终端"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "登陆的用户没有权限查看系统改变"
 ],
 "The passwords do not match.": [
  null,
  "密码不匹配。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "服务器拒绝使用任何支持的方式来验证。"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "用户 $0 没有权限修改 cpu 安全缓解方案设置"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "用户 $0 不允许修改加密策略"
 ],
 "This field cannot be empty": [
  null,
  "该字段不能为空"
 ],
 "This may take a while": [
  null,
  "这可能需要一些时间"
 ],
 "This system is using a custom profile": [
  null,
  "该系统正在使用自定义的配置集"
 ],
 "This system is using the recommended profile": [
  null,
  "该系统正在使用推荐的配置集"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "这个工具配置 SELinux 策略，帮助理解和解决策略违规。"
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "这个工具配置系统，以将内核崩溃转储写入磁盘。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具从正在运行的系统中生成配置和诊断信息的存档。出于记录或跟踪目的，存档可能被存储在本地或集中存储，或者被发送到技术支持代表、开发人员或系统管理员，以帮助技术故障查找和调试。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本地存储，如文件系统、LVM2 卷组和 NFS 挂载。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 和 Firewalld 管理网络，如绑定、网桥、团队、VLAN 和防火墙等。NetworkManager 与 Ubuntu 的默认 systemd-networkd 和 Debian 的 ifupdown 脚本不兼容。"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "该单元没有设计为需要明确启用。"
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "这将添加一个 '_BOOT_ID=' 匹配项。 如果未指定，则将显示来自当前引导的日志。 在没有指定 ID 时，正偏移将从日志开始查找启动，而等于或小于零的偏移将从日志末尾开始查找启动。因此，1 表示日志中第一次引导（按时间顺序排列），2 为第二个，以此类推；-0 是最后一次引导，-1 是最后一次引导前的一个，以此类推。"
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "这将添加 '_SYSTEMD_UNIT='、'COREDUMP_UNIT=' 和 'UNIT=' 匹配项，以查找给定单元的所有可能消息。可以包含以逗号分隔的多个单元。 "
 ],
 "Thursdays": [
  null,
  "周四"
 ],
 "Time": [
  null,
  "时间"
 ],
 "Time zone": [
  null,
  "时区"
 ],
 "Timer creation failed": [
  null,
  "计时器创建失败"
 ],
 "Timer deletion failed": [
  null,
  "计时器删除失败"
 ],
 "Timers": [
  null,
  "计时器"
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Toggle filters": [
  null,
  "切换过滤器"
 ],
 "Too much data": [
  null,
  "太多数据"
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transient": [
  null,
  "短暂的"
 ],
 "Trigger": [
  null,
  "触发器"
 ],
 "Triggered by": [
  null,
  "触发于"
 ],
 "Triggers": [
  null,
  "触发器"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在尝试与 $0 同步"
 ],
 "Tuesdays": [
  null,
  "周二"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned 启动失败"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned 是一个监控您的系统并优化某些工作负载性能的服务。Tuned 的核心是配置集（profile），使用它为不同的用例调整您的系统。"
 ],
 "Tuned is not available": [
  null,
  "Tuned 不可用"
 ],
 "Tuned is not running": [
  null,
  "Tuned 未运行"
 ],
 "Tuned is off": [
  null,
  "Tuned 已关闭"
 ],
 "Type": [
  null,
  "类型"
 ],
 "Type to filter": [
  null,
  "输入内容来过滤"
 ],
 "Unit": [
  null,
  "单元"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Unpin unit": [
  null,
  "未固定单元"
 ],
 "Until": [
  null,
  "直到"
 ],
 "Untrusted host": [
  null,
  "不可信的主机"
 ],
 "Updating status...": [
  null,
  "更新状态 ..."
 ],
 "Usage": [
  null,
  "用法"
 ],
 "User": [
  null,
  "用户"
 ],
 "Validating address": [
  null,
  "验证地址"
 ],
 "Vendor": [
  null,
  "厂商"
 ],
 "Version": [
  null,
  "版本"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "View all services": [
  null,
  "查看所有服务"
 ],
 "View automation script": [
  null,
  "查看自动化脚本"
 ],
 "View hardware details": [
  null,
  "查看硬件详细信息"
 ],
 "View login history": [
  null,
  "查看登录历史记录"
 ],
 "View metrics and history": [
  null,
  "查看指标和历史记录"
 ],
 "View report": [
  null,
  "查看报告"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "查看内存信息需要管理访问权限。"
 ],
 "Visit firewall": [
  null,
  "访问防火墙"
 ],
 "Waiting for input…": [
  null,
  "等待输入…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Waiting to start…": [
  null,
  "等待开始…"
 ],
 "Wanted by": [
  null,
  "需要于"
 ],
 "Wants": [
  null,
  "需要"
 ],
 "Warning and above": [
  null,
  "Warning 及更高级别"
 ],
 "Weak password": [
  null,
  "弱密码"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux 服务器的 Web 控制台"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web 控制台正运行于限制访问模式。"
 ],
 "Wednesdays": [
  null,
  "周三"
 ],
 "Weekly": [
  null,
  "每周"
 ],
 "Weeks": [
  null,
  "周"
 ],
 "White": [
  null,
  "白"
 ],
 "Yearly": [
  null,
  "每年"
 ],
 "Yes": [
  null,
  "是"
 ],
 "You may try to load older entries.": [
  null,
  "您可以尝试加载较早的条目。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的浏览器不允许从上下文菜单中进行粘贴，您可以使用 Shift+Insert。"
 ],
 "Your session has been terminated.": [
  null,
  "会话被终止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "会话超时。请重新登录。"
 ],
 "Zone": [
  null,
  "区域"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "active": [
  null,
  "激活"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "列出 SSH 主机密钥失败: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "inconsistent": [
  null,
  "不一致"
 ],
 "journalctl manpage": [
  null,
  "journalctl 手册页"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "空"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU"
 ],
 "password quality": [
  null,
  "密码质量"
 ],
 "recommended": [
  null,
  "推荐"
 ],
 "running $0": [
  null,
  "运行中 $0"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "unknown": [
  null,
  "未知"
 ],
 "dialog-title\u0004Domain": [
  null,
  "域"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "加入域"
 ],
 "from <host>\u0004from $0": [
  null,
  "来自 $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "来自 $1 上的 $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "在 $0 上"
 ]
});
