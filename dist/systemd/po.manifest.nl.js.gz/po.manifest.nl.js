cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Systeeminstellingen configureren"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Logs": [
  null,
  "Logboeken"
 ],
 "Managing services": [
  null,
  "Services beheren"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "Overview": [
  null,
  "Overzicht"
 ],
 "Reviewing logs": [
  null,
  "Logboeken bekijken"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "asset-tag"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "opstart"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "commando"
 ],
 "console": [
  null,
  "console"
 ],
 "coredump": [
  null,
  "core dump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "crash"
 ],
 "date": [
  null,
  "datum"
 ],
 "debug": [
  null,
  "debug"
 ],
 "dimm": [
  null,
  "dim"
 ],
 "disable": [
  null,
  "uitschakelen"
 ],
 "disks": [
  null,
  "schijven"
 ],
 "domain": [
  null,
  "domein"
 ],
 "enable": [
  null,
  "inschakelen"
 ],
 "error": [
  null,
  "fout"
 ],
 "graphs": [
  null,
  "grafieken"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "geschiedenis"
 ],
 "host": [
  null,
  "host"
 ],
 "journal": [
  null,
  "logboek"
 ],
 "machine": [
  null,
  "machine"
 ],
 "mask": [
  null,
  "masker"
 ],
 "memory": [
  null,
  "geheugen"
 ],
 "metrics": [
  null,
  "metriek"
 ],
 "mitigation": [
  null,
  "matiging"
 ],
 "network": [
  null,
  "netwerk"
 ],
 "operating system": [
  null,
  "besturingssysteem"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "pad"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "performance"
 ],
 "power": [
  null,
  "vermogen"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "herstarten"
 ],
 "serial": [
  null,
  "serieel"
 ],
 "service": [
  null,
  "service"
 ],
 "shell": [
  null,
  "shell"
 ],
 "shut": [
  null,
  "afsluiten"
 ],
 "socket": [
  null,
  "socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "doel"
 ],
 "time": [
  null,
  "tijd"
 ],
 "timer": [
  null,
  "timer"
 ],
 "unit": [
  null,
  "unit"
 ],
 "unmask": [
  null,
  "ontmaskeren"
 ],
 "version": [
  null,
  "versie"
 ],
 "warning": [
  null,
  "waarschuwing"
 ]
});
