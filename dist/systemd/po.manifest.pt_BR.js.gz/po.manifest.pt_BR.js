cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do Kernel"
 ],
 "Logs": [
  null,
  "Logs"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "Overview": [
  null,
  "Visão geral"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "asset tag": [
  null,
  ""
 ],
 "boot": [
  null,
  "inicialização"
 ],
 "command": [
  null,
  "comando"
 ],
 "console": [
  null,
  "console"
 ],
 "coredump": [
  null,
  ""
 ],
 "crash": [
  null,
  ""
 ],
 "date": [
  null,
  "data"
 ],
 "debug": [
  null,
  "depuração"
 ],
 "dimm": [
  null,
  ""
 ],
 "disable": [
  null,
  "desabilitado"
 ],
 "disks": [
  null,
  "discos"
 ],
 "domain": [
  null,
  ""
 ],
 "enable": [
  null,
  ""
 ],
 "error": [
  null,
  "erro"
 ],
 "graphs": [
  null,
  ""
 ],
 "history": [
  null,
  "histórico"
 ],
 "host": [
  null,
  "host"
 ],
 "journal": [
  null,
  ""
 ],
 "machine": [
  null,
  ""
 ],
 "mask": [
  null,
  ""
 ],
 "memory": [
  null,
  "memória"
 ],
 "metrics": [
  null,
  "métricas"
 ],
 "mitigation": [
  null,
  "mitigação"
 ],
 "network": [
  null,
  "rede"
 ],
 "operating system": [
  null,
  "sistema operacional"
 ],
 "os": [
  null,
  ""
 ],
 "path": [
  null,
  ""
 ],
 "pcp": [
  null,
  ""
 ],
 "power": [
  null,
  ""
 ],
 "restart": [
  null,
  ""
 ],
 "serial": [
  null,
  ""
 ],
 "service": [
  null,
  ""
 ],
 "shell": [
  null,
  ""
 ],
 "shut": [
  null,
  ""
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  ""
 ],
 "timer": [
  null,
  ""
 ],
 "unit": [
  null,
  ""
 ],
 "warning": [
  null,
  "aviso"
 ]
});
