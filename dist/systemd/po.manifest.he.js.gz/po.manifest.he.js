cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "Configuring system settings": [
  null,
  "הגדרות המערכת מוגדרות"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Logs": [
  null,
  "יומנים"
 ],
 "Managing services": [
  null,
  "ניהול שירותים"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "Overview": [
  null,
  "סקירה"
 ],
 "Reviewing logs": [
  null,
  "היומנים נסקרים"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "שירותים"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Terminal": [
  null,
  "מסוף"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "תג נכס"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "עלייה"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "פקודה"
 ],
 "console": [
  null,
  "מסוף"
 ],
 "coredump": [
  null,
  "היטל ליבה"
 ],
 "cpu": [
  null,
  "מעבד"
 ],
 "crash": [
  null,
  "קריסה"
 ],
 "date": [
  null,
  "תאריך"
 ],
 "debug": [
  null,
  "ניפוי שגיאות"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "השבתה"
 ],
 "disks": [
  null,
  "כוננים"
 ],
 "domain": [
  null,
  "שם תחום"
 ],
 "enable": [
  null,
  "הפעלה"
 ],
 "error": [
  null,
  "שגיאה"
 ],
 "graphs": [
  null,
  "תרשימים"
 ],
 "hardware": [
  null,
  "חומרה"
 ],
 "history": [
  null,
  "היסטוריה"
 ],
 "host": [
  null,
  "מארח"
 ],
 "journal": [
  null,
  "ז׳ורנל"
 ],
 "machine": [
  null,
  "מכונה"
 ],
 "mask": [
  null,
  "מסכה"
 ],
 "memory": [
  null,
  "זיכרון"
 ],
 "metrics": [
  null,
  "מדדים"
 ],
 "mitigation": [
  null,
  "אפחות"
 ],
 "network": [
  null,
  "רשת"
 ],
 "operating system": [
  null,
  "מערכת הפעלה"
 ],
 "os": [
  null,
  "מערכת הפעלה"
 ],
 "path": [
  null,
  "נתיב"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "ביצועים"
 ],
 "power": [
  null,
  "חשמל"
 ],
 "ram": [
  null,
  "זיכרון"
 ],
 "restart": [
  null,
  "הפעלה מחדש"
 ],
 "serial": [
  null,
  "טורי"
 ],
 "service": [
  null,
  "שירות"
 ],
 "shell": [
  null,
  "מעטפת"
 ],
 "shut": [
  null,
  "לסגור"
 ],
 "socket": [
  null,
  "שקע"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "יעד"
 ],
 "time": [
  null,
  "זמן"
 ],
 "timer": [
  null,
  "קוצב זמן"
 ],
 "unit": [
  null,
  "יחידה"
 ],
 "unmask": [
  null,
  "הסרת מיסוך"
 ],
 "version": [
  null,
  "גרסה"
 ],
 "warning": [
  null,
  "אזהרה"
 ]
});
