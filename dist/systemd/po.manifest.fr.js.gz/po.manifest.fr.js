cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Modification des paramètres système"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Logs": [
  null,
  "Journaux"
 ],
 "Managing services": [
  null,
  "Gestion des services"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "Overview": [
  null,
  "Aperçu"
 ],
 "Reviewing logs": [
  null,
  "Révision des journaux"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "Étiquette d’actif"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "boot"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "commande"
 ],
 "console": [
  null,
  "console"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "processeur"
 ],
 "crash": [
  null,
  "plantage"
 ],
 "date": [
  null,
  "date"
 ],
 "debug": [
  null,
  "déboguer"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "désactiver"
 ],
 "disks": [
  null,
  "disques"
 ],
 "domain": [
  null,
  "domaine"
 ],
 "enable": [
  null,
  "activer"
 ],
 "error": [
  null,
  "erreur"
 ],
 "graphs": [
  null,
  "graphiques"
 ],
 "hardware": [
  null,
  "matériel"
 ],
 "history": [
  null,
  "historique"
 ],
 "host": [
  null,
  "hôte"
 ],
 "journal": [
  null,
  "journal"
 ],
 "machine": [
  null,
  "machine"
 ],
 "mask": [
  null,
  "masque"
 ],
 "memory": [
  null,
  "mémoire"
 ],
 "metrics": [
  null,
  "métriques"
 ],
 "mitigation": [
  null,
  "mitigation"
 ],
 "network": [
  null,
  "réseau"
 ],
 "operating system": [
  null,
  "système d’exploitation"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "chemin"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "performance"
 ],
 "power": [
  null,
  "puissance"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "redémarrer"
 ],
 "serial": [
  null,
  "série"
 ],
 "service": [
  null,
  "service"
 ],
 "shell": [
  null,
  "shell"
 ],
 "shut": [
  null,
  "fermer"
 ],
 "socket": [
  null,
  "socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cible"
 ],
 "time": [
  null,
  "heure"
 ],
 "timer": [
  null,
  "minuteur"
 ],
 "unit": [
  null,
  "unité"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "version": [
  null,
  "version"
 ],
 "warning": [
  null,
  "avertissement"
 ]
});
