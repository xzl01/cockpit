cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "სისტემის პარამეტრების მორგება"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Logs": [
  null,
  "ჟურნალი"
 ],
 "Managing services": [
  null,
  "სერვისების მართვა"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "Overview": [
  null,
  "გადახედვა"
 ],
 "Reviewing logs": [
  null,
  "ჟურნალის გადახედვა"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "სერვისები"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Terminal": [
  null,
  "ტერმინალი"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "აქტივის ჭდე"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "ჩატვირთვა"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "ბრძანება"
 ],
 "console": [
  null,
  "კონსოლი"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "პროცესორი"
 ],
 "crash": [
  null,
  "ავარია"
 ],
 "date": [
  null,
  "თარიღი"
 ],
 "debug": [
  null,
  "შეცდომების მოძებნა"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "გამორთვა"
 ],
 "disks": [
  null,
  "დისკები"
 ],
 "domain": [
  null,
  "დომენი"
 ],
 "enable": [
  null,
  "ჩართვა"
 ],
 "error": [
  null,
  "შეცდომა"
 ],
 "graphs": [
  null,
  "გრაფიკები"
 ],
 "hardware": [
  null,
  "აპარატურა"
 ],
 "history": [
  null,
  "ისტორია"
 ],
 "host": [
  null,
  "ჰოსტი"
 ],
 "journal": [
  null,
  "ჟურნალი"
 ],
 "machine": [
  null,
  "მანქანა"
 ],
 "mask": [
  null,
  "ნიღაბი"
 ],
 "memory": [
  null,
  "მეხსიერება"
 ],
 "metrics": [
  null,
  "მეტრიკები"
 ],
 "mitigation": [
  null,
  "შემოვლა"
 ],
 "network": [
  null,
  "ქსელი"
 ],
 "operating system": [
  null,
  "ოპერაციული სისტემა"
 ],
 "os": [
  null,
  "ოპერაციული სისტემა"
 ],
 "path": [
  null,
  "ბილიკი"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "წარმადობა"
 ],
 "power": [
  null,
  "კვება"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "რესტარტი"
 ],
 "serial": [
  null,
  "მიმდევრობითი"
 ],
 "service": [
  null,
  "სერვისი"
 ],
 "shell": [
  null,
  "გარსი"
 ],
 "shut": [
  null,
  "გათიშვა"
 ],
 "socket": [
  null,
  "სოკეტი"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "მიზანი"
 ],
 "time": [
  null,
  "დრო"
 ],
 "timer": [
  null,
  "ტაიმერი"
 ],
 "unit": [
  null,
  "მოდული"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "version": [
  null,
  "ვერსია"
 ],
 "warning": [
  null,
  "გაფრთხილება"
 ]
});
