cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Konfigurerar systeminställningar"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Logs": [
  null,
  "Loggar"
 ],
 "Managing services": [
  null,
  "Hantera tjänster"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "Overview": [
  null,
  "Översikt"
 ],
 "Reviewing logs": [
  null,
  "Granska loggar"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Tjänster"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "tillgångstagg"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "start"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "kommando"
 ],
 "console": [
  null,
  "konsol"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "krasch"
 ],
 "date": [
  null,
  "datum"
 ],
 "debug": [
  null,
  "felsök"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "avaktivera"
 ],
 "disks": [
  null,
  "diskar"
 ],
 "domain": [
  null,
  "domän"
 ],
 "enable": [
  null,
  "aktivera"
 ],
 "error": [
  null,
  "fel"
 ],
 "graphs": [
  null,
  "grafer"
 ],
 "hardware": [
  null,
  "hårdvara"
 ],
 "history": [
  null,
  "historik"
 ],
 "host": [
  null,
  "värd"
 ],
 "journal": [
  null,
  "journal"
 ],
 "machine": [
  null,
  "maskin"
 ],
 "mask": [
  null,
  "mask"
 ],
 "memory": [
  null,
  "minne"
 ],
 "metrics": [
  null,
  "mått"
 ],
 "mitigation": [
  null,
  "rättningar"
 ],
 "network": [
  null,
  "nätverk"
 ],
 "operating system": [
  null,
  "operativsystem"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "sökväg"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "prestanda"
 ],
 "power": [
  null,
  "ström"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "starta om"
 ],
 "serial": [
  null,
  "seriell"
 ],
 "service": [
  null,
  "tjänst"
 ],
 "shell": [
  null,
  "skal"
 ],
 "shut": [
  null,
  "stäng"
 ],
 "socket": [
  null,
  "uttag"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "mål"
 ],
 "time": [
  null,
  "tid"
 ],
 "timer": [
  null,
  "timer"
 ],
 "unit": [
  null,
  "enhet"
 ],
 "unmask": [
  null,
  "avmaskera"
 ],
 "version": [
  null,
  "version"
 ],
 "warning": [
  null,
  "varning"
 ]
});
