cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritische Treffer",
  "$0 Treffer, darunter kritische"
 ],
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 exited with code $1": [
  null,
  "$0 mit Code $1 beendet"
 ],
 "$0 failed": [
  null,
  "$0 fehlgeschlagen"
 ],
 "$0 failed login attempt": [
  null,
  "$0 fehlgeschlagene Anmeldung",
  "$0 fehlgeschlagene Anmeldungen"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 important hit": [
  null,
  "$0 wichtiger Treffer",
  "$0 Treffer, darunter wichtige"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mit Signal $1 beendet"
 ],
 "$0 low severity hit": [
  null,
  "$0 wenig wichtiger Treffer",
  "$0 wenig unwichtige Treffer"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "$0 moderate hit": [
  null,
  "$0 Treffer",
  "$0 Treffer, darunter moderate"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 service has failed": [
  null,
  "$0 Dienst ist fehlerhaft",
  "$0 Dienste sind fehlerhaft"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 "$0: crash at $1": [
  null,
  "$0: Absturz bei $1"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "5th": [
  null,
  "5."
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Active since ": [
  null,
  "Aktiviert seit "
 ],
 "Active state": [
  null,
  "Aktiver Status"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "Additional actions": [
  null,
  "Weitere Aktionen"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Mit der Cockpit Web Konsole administrieren"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "After": [
  null,
  "Nach"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Nach dem Verlassen der Domain können sich nur noch Nutzer mit lokalen Zugängen an dieser Maschine anmelden. Dies betrifft auch andere Dienste wie z.B. die DNS Auflösungs Einstellungen und die Liste der vertrauenswürdigen CAs könnte sich ändern."
 ],
 "After system boot": [
  null,
  "Nach dem Systemstart"
 ],
 "Alert and above": [
  null,
  "Alarm und oben"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "All": [
  null,
  "Alle"
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "Allow running (unmask)": [
  null,
  "Ausführung zulassen (unmask)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible Rollendokumentation"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Jede Zeichenkette in den log Nachrichten kann gefiltert werden. Die Zeichenkette kann auch die Form eines herkömmlichen Ausdrucks haben. Filtern nach log Nachrichtenfeldern wird ebenfalls unterstützt. Dies sind durch Leerzeichen getrennte Werte in der Form FELD=WERT, wobei WERT eine durch Kommata getrennte Liste von möglichen Werten sein kann."
 ],
 "Appearance": [
  null,
  "Erscheinungsbild"
 ],
 "Apply and reboot": [
  null,
  "Anwenden und Neustarten"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Neue Policy wird angewendet... Dies kann ein paar Minuten dauern."
 ],
 "Asset tag": [
  null,
  "Asset-Tag"
 ],
 "At minute": [
  null,
  "Bei Minute"
 ],
 "At second": [
  null,
  "Bei Sekunde"
 ],
 "At specific time": [
  null,
  "Zu einer bestimmten Zeit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Privilegierte Aktionen der Cockpit Web-Konsole benötigen Berechtigung"
 ],
 "Automatically starts": [
  null,
  "Startet automatisch"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatische Benutzung zusätzlicher NTP-Server"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "Automation script": [
  null,
  "Automatisierungs-Skript"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS-Datum"
 ],
 "BIOS version": [
  null,
  "BIOS-Version"
 ],
 "Bad": [
  null,
  "Falsch"
 ],
 "Bad setting": [
  null,
  "Falsche Einstellung"
 ],
 "Before": [
  null,
  "Bevor"
 ],
 "Binds to": [
  null,
  "Bindet an"
 ],
 "Black": [
  null,
  "Schwarz"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Boot": [
  null,
  "Booten"
 ],
 "Bound by": [
  null,
  "Gebunden"
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "CPU": [
  null,
  "Prozessor"
 ],
 "CPU security": [
  null,
  "Prozessor-Sicherheit"
 ],
 "CPU security toggles": [
  null,
  "Prozessor-Sicherheits-Schalter"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Es konnten keine Logeinträge für die aktuellen Filtereinstellungen gefunden werden"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Cancel poweroff": [
  null,
  "Herunterfahren abbrechen"
 ],
 "Cancel reboot": [
  null,
  "Neustart abbrechen"
 ],
 "Cannot be enabled": [
  null,
  "Kann nicht aktiviert werden"
 ],
 "Cannot forward login credentials": [
  null,
  "Anmeldeinformationen können nicht weitergeleitet werden"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Kann keiner Domäne beitreten, da realmd auf diesem System nicht installiert ist."
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Change cryptographic policy": [
  null,
  "Kryptografische Richtlinie ändern"
 ],
 "Change host name": [
  null,
  "Rechnernamen ändern"
 ],
 "Change performance profile": [
  null,
  "Leistungsprofil ändern"
 ],
 "Change profile": [
  null,
  "Profil ändern"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "Class": [
  null,
  "Klasse"
 ],
 "Clear 'Failed to start'": [
  null,
  "'Starten Fehlgeschlagen' zurücksetzen"
 ],
 "Clear all filters": [
  null,
  "Alle Filter entfernen"
 ],
 "Client software": [
  null,
  "Client software"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit Konfiguration von NetworkManager und Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit konnte den angegebenen Host nicht erreichen."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ist ein Server Manager zur einfachen Verwaltung Ihrer Linux Server via Web Browser. Ein Wechsel zwischen dem Terminal und der Weboberfläche ist kein Problem. Ein Service, der via Cockpit gestartet wurde, kann im Terminal beendet werden. Genauso können Fehler, welche im Terminal vorkommen, im Cockpit Journal angezeigt werden."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ist mit der Software auf dem System nicht kompatibel."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ist auf dem System nicht installiert."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ist perfekt für neue Systemadministratoren, da es ihnen auf einfache Weise ermöglicht, simple Aufgaben wie Speicherverwaltung, Journal / Logfile Analyse oder das Starten und Stoppen von Diensten durchzuführen. Sie können gleichzeitig mehrere Server überwachen und verwalten. Fügen Sie weitere Maschinen mit einem Klick hinzu und Ihre Maschinen schauen zu ihren Kumpels."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Sammeln und Packen von Diagnose und Support Daten"
 ],
 "Collect kernel crash dumps": [
  null,
  "Sammeln von Kernel-Absturz-Auszügen"
 ],
 "Command": [
  null,
  "Befehl"
 ],
 "Command not found": [
  null,
  "Befehl nicht gefunden"
 ],
 "Communication with tuned has failed": [
  null,
  "Kommunikation mit tuned schlug fehl"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Bedingung $0=$1 wurde nicht erfüllt"
 ],
 "Condition failed": [
  null,
  "Bedingung fehlgeschlagen"
 ],
 "Configuration": [
  null,
  "Konfiguration"
 ],
 "Confirm deletion of $0": [
  null,
  "Löschen von $0 bestätigen"
 ],
 "Conflicted by": [
  null,
  "Konflikt von"
 ],
 "Conflicts": [
  null,
  "Konflikte"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Verbindung zum dbus fehlgeschlagen: $0"
 ],
 "Connection has timed out.": [
  null,
  "Zeitüberschreitung bei der Verbindung."
 ],
 "Consists of": [
  null,
  "Besteht aus"
 ],
 "Contacted domain": [
  null,
  "Kontaktierte Domain"
 ],
 "Controller": [
  null,
  "Controller"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Crash reporting": [
  null,
  "Absturz melden"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Create new task file with this content.": [
  null,
  "Neue Task-Datei mit diesem Inhalt erstellen."
 ],
 "Create timer": [
  null,
  "Timer erstellen"
 ],
 "Critical and above": [
  null,
  "Kritisch und höher"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografische Richtlinien sind ein Systembestandteil, der die kryptografischen Kern-Subsysteme konfiguriert. Dabei deckt er das TLS, IPSec, SSH, DNSSec und Kerberos Protokoll ab."
 ],
 "Cryptographic policy": [
  null,
  "Kryptografische Richtlinie"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Die kryptografische Richtlinie ist inkonsistent"
 ],
 "Ctrl+Insert": [
  null,
  "Strg+Einfügen"
 ],
 "Current boot": [
  null,
  "Aktueller Boot"
 ],
 "Custom cryptographic policy": [
  null,
  "Benutzerdefinierte kryptografische Richtlinie"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "STANDARD mit SHA-1 Signatur erlaubt."
 ],
 "Daily": [
  null,
  "Täglich"
 ],
 "Dark": [
  null,
  "Dunkel"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Datumsangaben sollten im Format JJJJ-MM-TT hh:mm:ss sein. Alternativ werden auch die Begriffe 'gestern', 'heute', 'morgen' verstanden. 'Now' bezieht sich auf die aktuelle Zeit. Es können auch relative Zeiten angegeben werden mit den Vorzeichen '-' oder '+'"
 ],
 "Debug and above": [
  null,
  "Debug und höher"
 ],
 "Decrease by one": [
  null,
  "Um eins verringern"
 ],
 "Default": [
  null,
  "Standard"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Delay must be a number": [
  null,
  "Verzögerung muss eine Zahl sein"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Deletion will remove the following files:": [
  null,
  "Beim Löschen werden die folgenden Dateien entfernt:"
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Simultanes Multithreading deaktivieren"
 ],
 "Disable tuned": [
  null,
  "Tuned deaktivieren"
 ],
 "Disabled": [
  null,
  "Deaktiviert"
 ],
 "Disallow running (mask)": [
  null,
  "Verbiete die Ausführung (mask)"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "Does not automatically start": [
  null,
  "Nicht automatisch starten"
 ],
 "Domain": [
  null,
  "Domain"
 ],
 "Domain address": [
  null,
  "Domänenadressen"
 ],
 "Domain administrator name": [
  null,
  "Name des Domain-Administrators"
 ],
 "Domain administrator password": [
  null,
  "Passwort des Domain-Administrators"
 ],
 "Domain could not be contacted": [
  null,
  "Die Domäne konnte nicht kontaktiert werden"
 ],
 "Domain is not supported": [
  null,
  "Domäne wird nicht unterstützt"
 ],
 "Don't repeat": [
  null,
  "Nicht wiederholen"
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd bearbeiten"
 ],
 "Edit motd": [
  null,
  "motd bearbeiten"
 ],
 "Embedded PC": [
  null,
  "Embedded PC"
 ],
 "Enabled": [
  null,
  "Aktiviert"
 ],
 "Entry at $0": [
  null,
  "Eintrag bei $0"
 ],
 "Error": [
  null,
  "Fehler"
 ],
 "Error and above": [
  null,
  "Fehler und höher"
 ],
 "Error message": [
  null,
  "Fehlermeldung"
 ],
 "Excellent password": [
  null,
  "Perfektes Passwort"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Extended information": [
  null,
  "Erweiterte Informationen"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS wurde nicht richtig aktiviert"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS mit weiteren Einschränkungen der Common Criteria."
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "Failed to disable tuned": [
  null,
  "Fehler beim Deaktivieren"
 ],
 "Failed to disable tuned profile": [
  null,
  "Deaktivierung des tuned-Profils ist fehlgeschlagen"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0 konnte nicht in firewalld aktiviert werden"
 ],
 "Failed to enable tuned": [
  null,
  "Tuned konnte nicht aktiviert werden"
 ],
 "Failed to fetch logs": [
  null,
  "Protokolle konnten nicht abgerufen werden"
 ],
 "Failed to load unit": [
  null,
  "Laden der Einheit fehlgeschlagen"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Änderungen in /etc/motd konnten nicht gespeichert werden"
 ],
 "Failed to start": [
  null,
  "Starten fehlgeschlagen"
 ],
 "Failed to switch profile": [
  null,
  "Profil konnte nicht gewechselt werden"
 ],
 "File state": [
  null,
  "Dateistatus"
 ],
 "Filter by name or description": [
  null,
  "Filtere nach Name oder Beschreibung"
 ],
 "Filters": [
  null,
  "Filter"
 ],
 "Font size": [
  null,
  "Schriftgröße"
 ],
 "Forbidden from running": [
  null,
  "Ausführen verboten"
 ],
 "Frame number": [
  null,
  "Framezahl"
 ],
 "Free-form search": [
  null,
  "Freitext-Suche"
 ],
 "Fridays": [
  null,
  "Freitags"
 ],
 "General": [
  null,
  "Allgemein"
 ],
 "Generated": [
  null,
  "Generiert"
 ],
 "Go to $0": [
  null,
  "Gehe zu $0"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Hardware information": [
  null,
  "Hardware-Informationen"
 ],
 "Health": [
  null,
  "Meldungen"
 ],
 "Help": [
  null,
  "Hilfe"
 ],
 "Hierarchy ID": [
  null,
  "Hierachie ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Höhere Interoperabilität auf Kosten einer größeren Angriffsfläche."
 ],
 "Host key is incorrect": [
  null,
  "Host-Schlüssel ist falsch"
 ],
 "Hostname": [
  null,
  "Hostname"
 ],
 "Hourly": [
  null,
  "Stündlich"
 ],
 "Hours": [
  null,
  "Stunde"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Kennung"
 ],
 "Increase by one": [
  null,
  "Um eins erhöhen"
 ],
 "Indirect": [
  null,
  "Indirekt"
 ],
 "Info and above": [
  null,
  "Info und höher"
 ],
 "Insights: ": [
  null,
  "Einblicke: "
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "Installing $0": [
  null,
  "$0 wird installiert"
 ],
 "Internal error": [
  null,
  "Interner Fehler"
 ],
 "Invalid": [
  null,
  "Ungültig"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid file permissions": [
  null,
  "Ungültige Dateiberechtigungen"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Join": [
  null,
  "Beitreten"
 ],
 "Join domain": [
  null,
  "Einer Domain beitreten"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Zum Beitritt einer Domäne wird realmd benötigt"
 ],
 "Joining this domain is not supported": [
  null,
  "Der Beitritt zu dieser Domain wird nicht unterstützt"
 ],
 "Joins namespace of": [
  null,
  "Tritt dem Namespace Of bei"
 ],
 "Journal": [
  null,
  "Tagebuch"
 ],
 "Journal entry": [
  null,
  "Journal-Eintrag"
 ],
 "Journal entry not found": [
  null,
  "Journal-Eintrag nicht gefunden"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "ALTLAST mit Active-Directory-Interoperabilität."
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last 24 hours": [
  null,
  "Letzte 24 Stunden"
 ],
 "Last 7 days": [
  null,
  "Letzte 7 Tage"
 ],
 "Last successful login:": [
  null,
  "Letzte erfolgreiche Anmeldung:"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Leave $0": [
  null,
  "$0 verlassen"
 ],
 "Leave domain": [
  null,
  "Domäne verlassen"
 ],
 "Light": [
  null,
  "Leicht"
 ],
 "Limits": [
  null,
  "Einschränkungen"
 ],
 "Linked": [
  null,
  "Verbunden"
 ],
 "Listen": [
  null,
  "Lauschen"
 ],
 "Listing units": [
  null,
  "Auflisten der Einheiten"
 ],
 "Listing units failed: $0": [
  null,
  "Auflisten der Einheiten fehlgeschlagen: $0"
 ],
 "Load earlier entries": [
  null,
  "Frühere Einträge laden"
 ],
 "Loading earlier entries": [
  null,
  "Frühere Einträge werden geladen"
 ],
 "Loading keys...": [
  null,
  "Schlüssel werden geladen ..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Laden von SSH-Schlüsseln fehlgeschlagen"
 ],
 "Loading of units failed": [
  null,
  "Laden der Einheiten fehlgeschlagen"
 ],
 "Loading system modifications...": [
  null,
  "System-Änderungen laden..."
 ],
 "Loading unit failed": [
  null,
  "Laden der Einheit fehlgeschlagen"
 ],
 "Loading...": [
  null,
  "Lade..."
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "Login failed": [
  null,
  "Anmeldung fehlgeschlagen"
 ],
 "Login format": [
  null,
  "Login format"
 ],
 "Logs": [
  null,
  "Protokolle"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "Machine ID": [
  null,
  "Maschinen-ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "SSH-Fingerabdrücke auf diesem Rechner"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Maintenance": [
  null,
  "Wartung"
 ],
 "Manage storage": [
  null,
  "Speicher verwalten"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Mask service": [
  null,
  "Dienst maskieren"
 ],
 "Masked": [
  null,
  "Maskiert"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Der Maskierungsdienst verhindert die Ausführung aller abhängigen Einheiten. Dies kann größere Auswirkung haben als vorhergesehen. Bitte bestätigen Sie, dass Sie diese Einheit maskieren wollen."
 ],
 "Memory": [
  null,
  "Speicher"
 ],
 "Memory technology": [
  null,
  "Speicher-Technologie"
 ],
 "Merged": [
  null,
  "Zusammengeführt"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minute muss eine Zahl zwischen 0 und 59 sein"
 ],
 "Minutely": [
  null,
  "Minütlich"
 ],
 "Minutes": [
  null,
  "Minuten"
 ],
 "Mitigations": [
  null,
  "Milderungen"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Mondays": [
  null,
  "Montags"
 ],
 "Monthly": [
  null,
  "Monatlich"
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "No": [
  null,
  "Nein"
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "No host keys found.": [
  null,
  "Es wurden keine Host-Schlüssel gefunden."
 ],
 "No log entries": [
  null,
  "Keine Protokolleinträge"
 ],
 "No logs found": [
  null,
  "Keine Protokolle gefunden"
 ],
 "No matching results": [
  null,
  "Keine passenden Ergebnisse"
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Keine Ergebnisse entsprechen den Filterkriterien. Löschen Sie alle Filter, um die Ergebnisse anzuzeigen."
 ],
 "No rule hits": [
  null,
  "Keine Treffer in Regelwerk"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "No system modifications": [
  null,
  "Keine Systemänderungen"
 ],
 "None": [
  null,
  "Kein"
 ],
 "Not a valid private key": [
  null,
  "Ungültiger privater Schlüssel"
 ],
 "Not connected to Insights": [
  null,
  "Nicht mit Insights verbunden"
 ],
 "Not found": [
  null,
  "Nicht gefunden"
 ],
 "Not permitted to configure realms": [
  null,
  "Keine Berechtigung Realms zu konfigurieren"
 ],
 "Not permitted to perform this action.": [
  null,
  "Diese Aktion darf nicht ausgeführt werden."
 ],
 "Not running": [
  null,
  "Läuft nicht"
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Note": [
  null,
  "Hinweis"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Notice and above": [
  null,
  "Hinweis und höher"
 ],
 "Occurrences": [
  null,
  "Vorkommnisse"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "On failure": [
  null,
  "Bei einem Ausfall"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Wenn Cockpit installiert ist, aktivieren Sie es mit \"systemctl enable --now cockpit.socket\"."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Nur Alphabete, Zahlen,:, _,. , @ , - sind erlaubt"
 ],
 "Only emergency": [
  null,
  "Nur Notfall"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Beim Booten im FIPS-Modus nur zugelassene und erlaubte Algorithmen verwenden."
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "Overview": [
  null,
  "Überblick"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "Part of": [
  null,
  "Teil von"
 ],
 "Password is not acceptable": [
  null,
  "Das Passwort kann nicht akzeptiert werden"
 ],
 "Password is too weak": [
  null,
  "Das gewählte Passwort ist zu schwach"
 ],
 "Password not accepted": [
  null,
  "Passwort wurde nicht akzeptiert"
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Paste error": [
  null,
  "Fehler beim Einfügen"
 ],
 "Path": [
  null,
  "Pfad"
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "Paths": [
  null,
  "Pfade"
 ],
 "Pause": [
  null,
  "Pause"
 ],
 "Performance profile": [
  null,
  "Leistungsprofil"
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Pin unit": [
  null,
  "Einheit festlegen"
 ],
 "Pinned unit": [
  null,
  "Festgelegte Einheit"
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "Pretty host name": [
  null,
  "Anzeige-Rechnername"
 ],
 "Previous boot": [
  null,
  "Vorheriger Bootvorgang"
 ],
 "Priority": [
  null,
  "Priorität"
 ],
 "Problem details": [
  null,
  "Problemdetails"
 ],
 "Problem info": [
  null,
  "Problem Info"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Die Aufforderung über ssh-add ist abgelaufen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Die Aufforderung über ssh-keygen ist abgelaufen"
 ],
 "Propagates reload to": [
  null,
  "Propagiert reload to"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Schützt vor kurzfristig zu erwartenden Angriffen auf Kosten der Interoperabilität."
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Rank": [
  null,
  "Rang"
 ],
 "Read more...": [
  null,
  "Mehr lesen..."
 ],
 "Read-only": [
  null,
  "Nur-lesen"
 ],
 "Real host name": [
  null,
  "Echter Rechnername"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Ein echter Hostname darf nur Kleinbuchstaben, Ziffern, Bindestriche und Punkte enthalten (mit ausgefüllten Unterdomänen)."
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Der tatsächliche Hostname darf höchstens 64 Zeichen umfassen"
 ],
 "Reapply and reboot": [
  null,
  "Erneut anwenden und neu starten"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Empfohlene, sichere Einstellungen für aktuelle Bedrohungsmodelle."
 ],
 "Reload": [
  null,
  "Neu Laden"
 ],
 "Reload propagated from": [
  null,
  "Propagiert von neu laden"
 ],
 "Reloading": [
  null,
  "Wird neu geladen"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Removing $0": [
  null,
  "Entfernen $0"
 ],
 "Repeat": [
  null,
  "Wiederholen"
 ],
 "Repeat monthly": [
  null,
  "Monatlich wiederholen"
 ],
 "Repeat weekly": [
  null,
  "Wöchentlich wiederholen"
 ],
 "Report": [
  null,
  "Melden"
 ],
 "Report to ABRT Analytics": [
  null,
  "Zu ABRT Analytics senden"
 ],
 "Reported; no links available": [
  null,
  "Gemeldet; keine Links verfügbar"
 ],
 "Reporting failed": [
  null,
  "Meldung fehlgeschlagen"
 ],
 "Reporting was canceled": [
  null,
  "Meldung wurde abgebrochen"
 ],
 "Reports:": [
  null,
  "Berichte:"
 ],
 "Required by": [
  null,
  "Benötigt von"
 ],
 "Required by ": [
  null,
  "Benötigt von "
 ],
 "Requires": [
  null,
  "Erfordert"
 ],
 "Requires administration access to edit": [
  null,
  "Benötigt Administrator-Zugriff zum bearbeiten"
 ],
 "Requisite": [
  null,
  "Requisit"
 ],
 "Requisite of": [
  null,
  "Erfordernis von"
 ],
 "Reset": [
  null,
  "Zurücksetzen"
 ],
 "Restart": [
  null,
  "Neustarten"
 ],
 "Resume": [
  null,
  "Fortfahren"
 ],
 "Review cryptographic policy": [
  null,
  "Überprüfung der Verschlüsselungsrichtlinie"
 ],
 "Run at": [
  null,
  "Ausführen um"
 ],
 "Run on": [
  null,
  "Ausführen auf"
 ],
 "Running": [
  null,
  "Läuft"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "Samstags"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Save and reboot": [
  null,
  "Sichern und Neustarten"
 ],
 "Save changes": [
  null,
  "Änderungen speichern"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Planmäßiges Ausschalten um $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Planmäßiger Neustart um $0"
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Search": [
  null,
  "Suche"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Sekunde muss eine Zahl zwischen 0 und 59 sein"
 ],
 "Seconds": [
  null,
  "Sekunden"
 ],
 "Secure shell keys": [
  null,
  "SSH-Schlüssel"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Sicherheitsverstärkte Linuxkonfiguration und Problemlösung"
 ],
 "Select a identifier": [
  null,
  "Einen Bezeichner auswählen"
 ],
 "Send": [
  null,
  "Senden"
 ],
 "Server has closed the connection.": [
  null,
  "Der Server hat die Verbindung beendet."
 ],
 "Server software": [
  null,
  "Server-Software"
 ],
 "Service logs": [
  null,
  "Serviceprotokolle"
 ],
 "Services": [
  null,
  "Dienste"
 ],
 "Set hostname": [
  null,
  "Hostname setzen"
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Einfügen"
 ],
 "Show all threads": [
  null,
  "Alle Threads anzeigen"
 ],
 "Show fingerprints": [
  null,
  "Fingerabdrücke anzeigen"
 ],
 "Show messages containing given string.": [
  null,
  "Meldungen mit der angegebenen Zeichenkette anzeigen."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Meldungen für die angegebene systemd-Einheit anzeigen."
 ],
 "Show messages from a specific boot.": [
  null,
  "Anzeige der Meldungen eines speziellen Bootvorgangs."
 ],
 "Show more relationships": [
  null,
  "Weitere Beziehungen anzeigen"
 ],
 "Show relationships": [
  null,
  "Beziehungen anzeigen"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Shutdown": [
  null,
  "Herunterfahren"
 ],
 "Since": [
  null,
  "Seit"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Softwarebasierte Umgehungen helfen, CPU-Sicherheitsprobleme zu vermeiden. Diese Abhilfemaßnahmen haben den Nebeneffekt, dass sie die Leistung verringern. Das Ändern dieser Einstellungen erfolgt auf eigene Gefahr."
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Speed": [
  null,
  "Geschwindigkeit"
 ],
 "Start": [
  null,
  "Starten"
 ],
 "Start and enable": [
  null,
  "Starten und aktivieren"
 ],
 "Start service": [
  null,
  "Dienst starten"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Start der Anzeige von Einträgen, die am oder nach dem angegebenen Datum liegen."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Start der Anzeige von Einträgen, die am oder vor dem angegebenen Datum liegen."
 ],
 "State": [
  null,
  "Status"
 ],
 "Static": [
  null,
  "Statisch"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Stoppen"
 ],
 "Stop and disable": [
  null,
  "Anhalten und deaktivieren"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Stub": [
  null,
  "Kontrollabschnitt"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Das Abonnieren von systemd-Signalen ist fehlgeschlagen: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Erfolgreich in die Zwischenablage kopiert"
 ],
 "Sundays": [
  null,
  "Sonntags"
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "System": [
  null,
  "System"
 ],
 "System information": [
  null,
  "Systeminformationen"
 ],
 "System time": [
  null,
  "Systemzeit"
 ],
 "Systemd units": [
  null,
  "Systemd Unit"
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "Targets": [
  null,
  "Ziele"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Der angemeldete Benutzer ist nicht berechtigt, Systemänderungen einzusehen"
 ],
 "The passwords do not match.": [
  null,
  "Die Passwörter stimmen nicht überein."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Der Server hat die Authentifizierung mit allen unterstützten Methoden abgelehnt."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Der Benutzer $0 ist nicht berechtigt, die CPU-Sicherheitsmaßnahmen zu ändern"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Der Benutzer $0 ist nicht berechtigt, kryptografische Richtlinien zu ändern"
 ],
 "This field cannot be empty": [
  null,
  "Dieses Feld darf nicht leer sein"
 ],
 "This may take a while": [
  null,
  "Dies kann eine Weile dauern"
 ],
 "This system is using a custom profile": [
  null,
  "Dieses System benutzt ein benutzerdefiniertes Profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Dieses System benutzt das empfohlene Profil"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dieses Tool konfiguriert die SELinux Policy und hilft dabei Verletzungen der Policy zu verstehen und aufzulösen."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Dieses Tool konfiguriert das System zum Schreiben von Kernel Absturz Auszügen auf Datenträger."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dieses Tool generiert ein Archiv der Konfiguration und Diagnoseinformation des laufenden Systems.Das Archiv kann lokal oder zentral abgespeichert werden zum Zweck der Archivierung oder Nachverfolgung oder kann an den Technischen Support, Entwickler oder Systemadministratoren gesendet werden, um bei der Fehlersuche oder Debugging zu helfen."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dieses Tool verwaltet den lokalen Speicher, wie etwa Dateisysteme, LVM2 Volume Gruppen und NFS Einhängepunkte."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dieses Tool verwaltet die Netzwerkumgebung wie etwa Bindungen, Bridges, Teams, VLANs und Firewalls durch den NetworkManager und Firewalld. Der NetworkManager ist inkompatibel mit dem Ubuntus Standard systemd-networkd und Debians ifupdown Scipts."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Dieses Gerät kann nicht explizit aktiviert werden."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Damit wird eine Übereinstimmung für '_BOOT_ID=' hinzugefügt. Wird nichts angegeben, werden die Protokolle für den aktuellen Bootvorgang angezeigt. Wird die Boot-ID nicht angegeben, werden bei einem positiven Offset die Boote ab dem Anfang des Journals angezeigt, bei einem Offset gleich oder kleiner als Null werden die Boote ab dem Ende des Journals angezeigt. So bedeutet 1 den ersten im Journal gefundenen Boot in chronologischer Reihenfolge, 2 den zweiten usw., während -0 der letzte Boot ist, -1 der vorletzte Boot usw."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Dies fügt Übereinstimmungen für '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' und 'UNIT=' hinzu, um alle möglichen Meldungen für die angegebene Einheit zu finden. Kann mehrere durch Komma getrennte Einheiten enthalten. "
 ],
 "Thursdays": [
  null,
  "Donnerstags"
 ],
 "Time": [
  null,
  "Zeit"
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "Timer creation failed": [
  null,
  "Timer-Erstellung fehlgeschlagen"
 ],
 "Timer deletion failed": [
  null,
  "Timer-Löschung fehlgeschlagen"
 ],
 "Timers": [
  null,
  "Timer"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Toggle filters": [
  null,
  "Filter umschalten"
 ],
 "Too much data": [
  null,
  "Zu viele Daten"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Transient": [
  null,
  "Vorübergehend"
 ],
 "Trigger": [
  null,
  "Auslöser"
 ],
 "Triggered by": [
  null,
  "Ausgelöst durch"
 ],
 "Triggers": [
  null,
  "Löst aus"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit {{Server}} zu synchronisieren"
 ],
 "Tuesdays": [
  null,
  "Dienstags"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned konnte nicht gestartet werden"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned ist ein Dienst, der Ihr System überwacht und die Leistung unter bestimmten Arbeitsbelastungen optimiert. Das Herzstück von Tuned sind Profile, die Ihr System für verschiedene Anwendungsfälle abstimmen."
 ],
 "Tuned is not available": [
  null,
  "Tuned ist nicht verfügbar"
 ],
 "Tuned is not running": [
  null,
  "Tuned läuft nicht"
 ],
 "Tuned is off": [
  null,
  "Tuned ist ausgeschaltet"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type to filter": [
  null,
  "Zum Filtern tippen"
 ],
 "Unit": [
  null,
  "Einheit"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Until": [
  null,
  "Bis"
 ],
 "Untrusted host": [
  null,
  "Nicht vertrauenswürdiger Host"
 ],
 "Updating status...": [
  null,
  "Update Status..."
 ],
 "Usage": [
  null,
  "Nutzung"
 ],
 "User": [
  null,
  "Benutzer"
 ],
 "Validating address": [
  null,
  "Validiere Adresse"
 ],
 "Vendor": [
  null,
  "Anbieter"
 ],
 "Version": [
  null,
  "Version"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "View all services": [
  null,
  "Alle Dienste ansehen"
 ],
 "View automation script": [
  null,
  "Automatisierungs-Script anzeigen"
 ],
 "View hardware details": [
  null,
  "Hardware-Details anzeigen"
 ],
 "View login history": [
  null,
  "Anmeldeverlauf ansehen"
 ],
 "View metrics and history": [
  null,
  "Metriken und Verlauf ansehen"
 ],
 "View report": [
  null,
  "Bericht ansehen"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Zum Ansehen der Speicherinformationen ist ein administrativer Zugriff erforderlich."
 ],
 "Visit firewall": [
  null,
  "Firewall besuchen"
 ],
 "Waiting for input…": [
  null,
  "Warte auf Eingabe…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Waiting to start…": [
  null,
  "Warte auf den Start. . ."
 ],
 "Wanted by": [
  null,
  "Gesucht von"
 ],
 "Wants": [
  null,
  "Will"
 ],
 "Warning and above": [
  null,
  "Warnung und höher"
 ],
 "Web Console for Linux servers": [
  null,
  "Webkonsole für Linux-Server"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Die Webkonsole läuft mit limitierten Berechtigungen."
 ],
 "Wednesdays": [
  null,
  "Mittwochs"
 ],
 "Weekly": [
  null,
  "Wöchentlich"
 ],
 "Weeks": [
  null,
  "Wochen"
 ],
 "White": [
  null,
  "Weiß"
 ],
 "Yearly": [
  null,
  "Jährlich"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You may try to load older entries.": [
  null,
  "Wollen sie probieren alte Einträge zu laden."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Ihr Browser lässt das Einfügen über das Kontextmenü nicht zu. Sie können Umschalt+Einfügen verwenden."
 ],
 "Your session has been terminated.": [
  null,
  "Ihre Sitzung wurde beendet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Die Session ist abgelaufen. Bitte neu einloggen."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "active": [
  null,
  "Aktiv"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "Kann SSH-Hostschlüssel nicht anzeigen: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "inconsistent": [
  null,
  "inkonsistent"
 ],
 "journalctl manpage": [
  null,
  "journalctl manpage"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "kein"
 ],
 "of $0 CPU": [
  null,
  "von $0 CPU",
  "von $0 CPUs"
 ],
 "password quality": [
  null,
  "Passwortqualität"
 ],
 "recommended": [
  null,
  "empfohlen"
 ],
 "running $0": [
  null,
  "$0 wird ausgeführt"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "unknown": [
  null,
  "unbekannt"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domäne"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Einer Domäne beitreten"
 ],
 "from <host>\u0004from $0": [
  null,
  "von $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "von $0 auf $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "auf $0"
 ]
});
