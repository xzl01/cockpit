cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 risultato critico",
  "$0 risultati, inclusi critici"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "$0 failed login attempt": [
  null,
  "$0 tentativo di accesso fallito",
  "$0 tentativi di accesso falliti"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 important hit": [
  null,
  "$0 risultato importante",
  "$0 risultati, inclusi importanti"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "$0 key changed": [
  null,
  "Chiave $0 modificata"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 risultato di bassa severità",
  "$0 risultati, inclusi bassa gravità"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "$0 moderate hit": [
  null,
  "$0 risultato moderato",
  "$0 risultati, inclusi moderati"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 service has failed": [
  null,
  "$0 servizio ha fallito",
  "$0 servizi hanno fallito"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "$0: crash at $1": [
  null,
  "$0: crash a $1"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "10th": [
  null,
  "10°"
 ],
 "11th": [
  null,
  "11°"
 ],
 "12th": [
  null,
  "12°"
 ],
 "13th": [
  null,
  "13°"
 ],
 "14th": [
  null,
  "14°"
 ],
 "15th": [
  null,
  "15°"
 ],
 "16th": [
  null,
  "16°"
 ],
 "17th": [
  null,
  "17°"
 ],
 "18th": [
  null,
  "18°"
 ],
 "19th": [
  null,
  "19°"
 ],
 "1st": [
  null,
  "1°"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "20th": [
  null,
  "20°"
 ],
 "21th": [
  null,
  "21esimo"
 ],
 "22th": [
  null,
  "22esimo"
 ],
 "23th": [
  null,
  "23esimo"
 ],
 "24th": [
  null,
  "24°"
 ],
 "25th": [
  null,
  "25°"
 ],
 "26th": [
  null,
  "26°"
 ],
 "27th": [
  null,
  "27°"
 ],
 "28th": [
  null,
  "28°"
 ],
 "29th": [
  null,
  "29°"
 ],
 "2nd": [
  null,
  "2°"
 ],
 "30th": [
  null,
  "30°"
 ],
 "31st": [
  null,
  "31°"
 ],
 "3rd": [
  null,
  "3°"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "4th": [
  null,
  "4°"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "5th": [
  null,
  "5°"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "6th": [
  null,
  "6°"
 ],
 "7th": [
  null,
  "7°"
 ],
 "8th": [
  null,
  "8°"
 ],
 "9th": [
  null,
  "9°"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Una versione compatibile di Cockpit non è installata su $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Una nuova chiave SSH in $0 verrà creata per $1 su $2 e sarà aggiunta al file $3 di $4 su $5."
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Active since ": [
  null,
  "Attivo dal "
 ],
 "Active state": [
  null,
  "Stato attivo"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "Additional actions": [
  null,
  "Azioni aggiuntive"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "After": [
  null,
  "Dopo"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Dopo aver lasciato il dominio, solo gli utenti con credenziali locali potranno accedere a questa macchina. Ciò può influire anche su altri servizi poiché le impostazioni della risoluzione DNS e l'elenco delle CA affidabili potrebbero cambiare."
 ],
 "After system boot": [
  null,
  "Dopo l'avvio del sistema"
 ],
 "Alert and above": [
  null,
  "Allarme e oltre"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "All": [
  null,
  "Tutti"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Allow running (unmask)": [
  null,
  "Consenti esecuzione (unmask)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Qualsiasi stringa di testo nei messaggi di registro può essere filtrata. La stringa può anche essere sotto forma di un'espressione regolare. Supporta anche il filtraggio in base ai campi del registro dei messaggi. Questi sono valori separati da spazi, nella forma CAMPO=VALORE, dove il valore può essere un elenco di valori possibili separati da virgole."
 ],
 "Appearance": [
  null,
  "Aspetto"
 ],
 "Apply and reboot": [
  null,
  "Applica e riavvia"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Applicazione di una nuova politica... L'operazione potrebbe richiedere alcuni minuti."
 ],
 "Asset tag": [
  null,
  "Tag asset"
 ],
 "At minute": [
  null,
  "Al minuto"
 ],
 "At second": [
  null,
  "Al secondo"
 ],
 "At specific time": [
  null,
  "In un momento specifico"
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ],
 "Authorize SSH key": [
  null,
  "Autorizza chiave SSH"
 ],
 "Automatically starts": [
  null,
  "Si avvia automaticamente"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Data del BIOS"
 ],
 "BIOS version": [
  null,
  "Versione del BIOS"
 ],
 "Bad": [
  null,
  "Male"
 ],
 "Bad setting": [
  null,
  "Impostazione errata"
 ],
 "Before": [
  null,
  "Prima"
 ],
 "Binds to": [
  null,
  "Si lega a"
 ],
 "Black": [
  null,
  "Nero"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Boot": [
  null,
  "Boot"
 ],
 "Bound by": [
  null,
  "Legato da"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "Sicurezza CPU"
 ],
 "CPU security toggles": [
  null,
  "Impostazioni di Sicurezza della CPU"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Non è possibile trovare alcun log utilizzando l'attuale combinazione di filtri."
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cancel poweroff": [
  null,
  "Annulla spegnimento"
 ],
 "Cancel reboot": [
  null,
  "Annulla il riavvio"
 ],
 "Cannot be enabled": [
  null,
  "Non può essere abilitato"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Impossibile accedere a un dominio perché realmd non è disponibile su questo sistema"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "Change": [
  null,
  "Cambia"
 ],
 "Change cryptographic policy": [
  null,
  "Cambia la politica di crittografia"
 ],
 "Change host name": [
  null,
  "Cambia nome host"
 ],
 "Change performance profile": [
  null,
  "Modifica del profilo performance"
 ],
 "Change profile": [
  null,
  "Cambia profilo"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "La modifica delle chiavi sono di solito il risultato di una reinstallazione del sistema. Tuttavia, una modifica inaspettata può indicare un tentativo di intercettazione da parte di un soggetto terzo."
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "Class": [
  null,
  "Classe"
 ],
 "Clear 'Failed to start'": [
  null,
  "Cancella 'Impossibile avviare'"
 ],
 "Clear all filters": [
  null,
  "Cancella tutti i filtri"
 ],
 "Client software": [
  null,
  "Software Client"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit non è installato"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Command not found": [
  null,
  "Comando non trovato"
 ],
 "Communication with tuned has failed": [
  null,
  "Comunicazione con tuned non riuscita"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Condizione $0=$1 non soddisfatta"
 ],
 "Condition failed": [
  null,
  "Condizione non riuscita"
 ],
 "Configuration": [
  null,
  "Configurazione"
 ],
 "Confirm deletion of $0": [
  null,
  "Conferma la cancellazione di $0"
 ],
 "Confirm key password": [
  null,
  "Conferma la password chiave"
 ],
 "Conflicted by": [
  null,
  "Conflitto da"
 ],
 "Conflicts": [
  null,
  "Conflitti"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Connessione a dbus non riuscita: $0"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Consists of": [
  null,
  "Consiste di"
 ],
 "Contacted domain": [
  null,
  "Dominio contattato"
 ],
 "Controller": [
  null,
  "Controllo"
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Copied": [
  null,
  "Copiato"
 ],
 "Copy": [
  null,
  "Copia"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Crash reporting": [
  null,
  "Segnalazione di arresti anomali"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crea una nuova chiave SSH e autorizzala"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Create timer": [
  null,
  "Creare timer"
 ],
 "Critical and above": [
  null,
  "Critico e superiore"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Cryptographic Policies è un componente di sistema che configura i sottosistemi crittografici di base, coprendo i protocolli TLS, IPSec, SSH, DNSSec e Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "policy di crittografia"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "La policy di crittografia è incoerente"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Boot corrente"
 ],
 "Custom cryptographic policy": [
  null,
  "Policy di crittografia personalizzata"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT con verifica della firma SHA-1 consentita."
 ],
 "Daily": [
  null,
  "Giornaliero"
 ],
 "Dark": [
  null,
  "Scuro"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Le specifiche della data devono essere nel formato AAAA-MM-GG hh:mm:ss. In alternativa si intendono le stringhe 'yesterday', 'today', 'tomorrow'. 'now' si riferisce all'ora corrente. Infine, possono essere specificati tempi relativi, preceduti da '-' o '+'"
 ],
 "Debug and above": [
  null,
  "Debug e superiore"
 ],
 "Decrease by one": [
  null,
  "Diminuisci di uno"
 ],
 "Default": [
  null,
  "Predefinito"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Delay must be a number": [
  null,
  "Il ritardo deve essere un numero"
 ],
 "Delete": [
  null,
  "Cancella"
 ],
 "Deletion will remove the following files:": [
  null,
  "L'eliminazione rimuoverà i seguenti file:"
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Disabilita il multithreading simultaneo"
 ],
 "Disable tuned": [
  null,
  "Disabilita tuned"
 ],
 "Disabled": [
  null,
  "Disabilitato"
 ],
 "Disallow running (mask)": [
  null,
  "Non consentire l'esecuzione (mask)"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "Does not automatically start": [
  null,
  "Non si avvia automaticamente"
 ],
 "Domain": [
  null,
  "Dominio"
 ],
 "Domain address": [
  null,
  "Indirizzo del dominio"
 ],
 "Domain administrator name": [
  null,
  "Nome dell'amministratore di dominio"
 ],
 "Domain administrator password": [
  null,
  "Password dell'amministratore di dominio"
 ],
 "Domain could not be contacted": [
  null,
  "Il dominio non può essere contattato"
 ],
 "Domain is not supported": [
  null,
  "Il dominio non è supportato"
 ],
 "Don't repeat": [
  null,
  "Non ripetere"
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit /etc/motd": [
  null,
  "Modifica /etc/motd"
 ],
 "Edit motd": [
  null,
  "Modifica motd"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Enabled": [
  null,
  "Attivato"
 ],
 "Entry at $0": [
  null,
  "Voce a $0"
 ],
 "Error": [
  null,
  "Errore"
 ],
 "Error and above": [
  null,
  "Errore e superiore"
 ],
 "Error message": [
  null,
  "Messaggio di errore"
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Extended information": [
  null,
  "Informazioni estese"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS non è abilitato correttamente"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS con ulteriori restrizioni dei Criteri Comuni."
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "Failed to disable tuned": [
  null,
  "Impossibile disabilitare tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Impossibile disabilitare il profilo tuned"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Impossibile abilitare tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Impossibile recuperare i logs"
 ],
 "Failed to load unit": [
  null,
  "Impossibile carica l'unità"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Impossibile salvare le modifiche in /etc/motd"
 ],
 "Failed to start": [
  null,
  "Impossibile avviare"
 ],
 "Failed to switch profile": [
  null,
  "Impossibile cambiare profilo"
 ],
 "File state": [
  null,
  "Stato file"
 ],
 "Filter by name or description": [
  null,
  "Filtra per nome o descrizione"
 ],
 "Filters": [
  null,
  "Filtri"
 ],
 "Font size": [
  null,
  "Dimensione font"
 ],
 "Forbidden from running": [
  null,
  "Esecuzione non autorizzata"
 ],
 "Frame number": [
  null,
  "Numero del frame"
 ],
 "Free-form search": [
  null,
  "Ricerca libera"
 ],
 "Fridays": [
  null,
  "Venerdì"
 ],
 "General": [
  null,
  "Generale"
 ],
 "Generated": [
  null,
  "Generato"
 ],
 "Go to $0": [
  null,
  "Vai a $0"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Hardware information": [
  null,
  "Informazioni hardware"
 ],
 "Health": [
  null,
  "Salute"
 ],
 "Help": [
  null,
  "Aiuto"
 ],
 "Hierarchy ID": [
  null,
  "ID gerarchico"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Maggiore interoperabilità a scapito di una maggiore superficie di attacco."
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "Hostname": [
  null,
  "Nome host"
 ],
 "Hourly": [
  null,
  "Orario"
 ],
 "Hours": [
  null,
  "Ore"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identificativo"
 ],
 "Increase by one": [
  null,
  "Aumenta di uno"
 ],
 "Indirect": [
  null,
  "Indiretto"
 ],
 "Info and above": [
  null,
  "Info e superiore"
 ],
 "Insights: ": [
  null,
  "Approfondimenti: "
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Install realmd support": [
  null,
  "Installa il supporto realmd"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Invalid": [
  null,
  "Non valido"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Join": [
  null,
  "Associa"
 ],
 "Join domain": [
  null,
  "Associa al dominio"
 ],
 "Joining": [
  null,
  "Associazione"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "L'associazione a un dominio richiede l'installazione di realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "L'associane a questo dominio non è supportata"
 ],
 "Joins namespace of": [
  null,
  "Associa al namespace di"
 ],
 "Journal": [
  null,
  "Registro"
 ],
 "Journal entry": [
  null,
  "Voce del registro"
 ],
 "Journal entry not found": [
  null,
  "Voce del registro non trovata"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Key password": [
  null,
  "Password della chiave"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY con interoperabilità ad Active Directory."
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Last 24 hours": [
  null,
  "Ultime 24 ore"
 ],
 "Last 7 days": [
  null,
  "Ultimi 7 giorni"
 ],
 "Last successful login:": [
  null,
  "Ultimo accesso riuscito:"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "Leave $0": [
  null,
  "Lasciare $0"
 ],
 "Leave domain": [
  null,
  "Abbandona dominio"
 ],
 "Light": [
  null,
  "Chiaro"
 ],
 "Limits": [
  null,
  "Limiti"
 ],
 "Linked": [
  null,
  "Collegato"
 ],
 "Listen": [
  null,
  "Ascolta"
 ],
 "Listing units": [
  null,
  "Elencando unità"
 ],
 "Listing units failed: $0": [
  null,
  "Unità elencate fallite: $0"
 ],
 "Load earlier entries": [
  null,
  "Carica voci precedenti"
 ],
 "Loading keys...": [
  null,
  "Caricamento delle chiavi..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Caricamento delle chiavi SSH non riuscito"
 ],
 "Loading of units failed": [
  null,
  "Caricamento delle unità fallito"
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "Loading unit failed": [
  null,
  "Caricamento unità fallito"
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "Log in": [
  null,
  "Accedi"
 ],
 "Log in to $0": [
  null,
  "Entra in $0"
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "Login format": [
  null,
  "Formato di accesso"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "ID macchina"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Impronte digitali delle chiavi SSH della macchina"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Maintenance": [
  null,
  "Manutenzione"
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Mask service": [
  null,
  "Maschera servizio"
 ],
 "Masked": [
  null,
  "Mascherato"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Il mascheramento del servizio impedisce l'avvio di tutte le unità da esso dipendenti. Questo può avere un impatto maggiore del previsto. Conferma di voler mascherare questa unità."
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Memory technology": [
  null,
  "Tecnologia di memoria"
 ],
 "Merged": [
  null,
  "Fuso"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Il minuto deve essere un numero compreso tra 0-59"
 ],
 "Minutely": [
  null,
  "Minuti"
 ],
 "Minutes": [
  null,
  "Minuti"
 ],
 "Mitigations": [
  null,
  "Mitigazioni"
 ],
 "Model": [
  null,
  "Modello"
 ],
 "Mondays": [
  null,
  "Lunedì"
 ],
 "Monthly": [
  null,
  "Mensilmente"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "No": [
  null,
  "No"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "No host keys found.": [
  null,
  "Non sono state trovate chiavi host."
 ],
 "No log entries": [
  null,
  "Nessuna voce nel log"
 ],
 "No logs found": [
  null,
  "Nessun log trovato"
 ],
 "No matching results": [
  null,
  "Nessun risultato corrispondente"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Nessun risultato corrisponde ai criteri del filtro. Cancella tutti i filtri per mostrare i risultati."
 ],
 "No rule hits": [
  null,
  "Nessuna regola trovata"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "None": [
  null,
  "Nessuno"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Not connected to Insights": [
  null,
  "Non connesso a Insights"
 ],
 "Not found": [
  null,
  "Non trovato"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Not running": [
  null,
  "Non in esecuzione"
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Note": [
  null,
  "Note"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Notice and above": [
  null,
  "Notice e oltre"
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "On failure": [
  null,
  "In caso di guasto"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Sono ammessi solo lettere, numeri, : , _ , . , @ ,"
 ],
 "Only emergency": [
  null,
  "Solo emergenza"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Utilizzare solo algoritmi approvati e consentiti durante l'avvio in modalità FIPS."
 ],
 "Other": [
  null,
  "Altro"
 ],
 "Overview": [
  null,
  "Panoramica"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "Part of": [
  null,
  "Parte di"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Path": [
  null,
  "Percorso"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "Paths": [
  null,
  "Percorsi"
 ],
 "Pause": [
  null,
  "Pausa"
 ],
 "Performance profile": [
  null,
  "Profilo delle prestazioni"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Pin unit": [
  null,
  "Unità pinnate"
 ],
 "Pinned unit": [
  null,
  "Unità pinnate"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Pretty host name": [
  null,
  "Nome dell'host grazioso"
 ],
 "Previous boot": [
  null,
  "Avvio precedente"
 ],
 "Priority": [
  null,
  "Priorità"
 ],
 "Problem details": [
  null,
  "Dettagli del problema"
 ],
 "Problem info": [
  null,
  "Informazioni sul problema"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "Propagates reload to": [
  null,
  "Propagati ricarica su"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Protegge dagli attacchi futuri previsti a breve termine a scapito dell'interoperabilità."
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Rank": [
  null,
  "Posizione"
 ],
 "Read more...": [
  null,
  "Leggi di più..."
 ],
 "Read-only": [
  null,
  "Sola lettura"
 ],
 "Real host name": [
  null,
  "Nome dell'host reale"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Il nome host reale può contenere solo caratteri minuscoli, cifre, trattini e punti (con sottodomini popolati)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Il nome host reale deve essere di 64 caratteri o meno"
 ],
 "Reapply and reboot": [
  null,
  "riapplica e riavvia"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Impostazioni consigliate e sicure per gli attuali modelli di minaccia."
 ],
 "Reload": [
  null,
  "Ricarica"
 ],
 "Reload propagated from": [
  null,
  "Ricarica propagato da"
 ],
 "Reloading": [
  null,
  "Ricarica"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Remove": [
  null,
  "Elimina"
 ],
 "Removing $0": [
  null,
  "Rimozione $0"
 ],
 "Repeat": [
  null,
  "Ripeti"
 ],
 "Repeat monthly": [
  null,
  "Ripeti mensilmente"
 ],
 "Repeat weekly": [
  null,
  "Ripeti ogni settimana"
 ],
 "Report": [
  null,
  "Notifica"
 ],
 "Report to ABRT Analytics": [
  null,
  "Segnala ad ABRT Analytics"
 ],
 "Reported; no links available": [
  null,
  "Segnalato; nessun collegamento disponibile"
 ],
 "Reporting failed": [
  null,
  "Segnalazione fallita"
 ],
 "Reporting was canceled": [
  null,
  "La segnalazione è stata annullata"
 ],
 "Reports:": [
  null,
  "Rapporti:"
 ],
 "Required by": [
  null,
  "Richiesto da"
 ],
 "Required by ": [
  null,
  "Richiesto da "
 ],
 "Requires": [
  null,
  "Ha bisogno di"
 ],
 "Requires administration access to edit": [
  null,
  "Richiede accesso amministrativo per la modifica"
 ],
 "Requisite": [
  null,
  "Requisito"
 ],
 "Requisite of": [
  null,
  "Requisito di"
 ],
 "Reset": [
  null,
  "Azzera"
 ],
 "Restart": [
  null,
  "Riavvia"
 ],
 "Resume": [
  null,
  "Riprendi"
 ],
 "Review cryptographic policy": [
  null,
  "Rivedi le policy di crittografia"
 ],
 "Run at": [
  null,
  "Esegui a"
 ],
 "Run on": [
  null,
  "Eseguire in"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Running": [
  null,
  "In esecuzione"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Chiave SSH"
 ],
 "Saturdays": [
  null,
  "Sabati"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Save and reboot": [
  null,
  "Salva e riavvia"
 ],
 "Save changes": [
  null,
  "Salva modifiche"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Spegnimento programmato alle $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Riavvio programmato alle $0"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Search": [
  null,
  "Ricerca"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Il secondo deve essere un numero compreso tra 0-59"
 ],
 "Seconds": [
  null,
  "Secondi"
 ],
 "Secure shell keys": [
  null,
  "Chiavi secure shell"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "Send": [
  null,
  "Invia"
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Server software": [
  null,
  "Software Server"
 ],
 "Service logs": [
  null,
  "Log servizi"
 ],
 "Services": [
  null,
  "Servizi"
 ],
 "Set hostname": [
  null,
  "Imposta il nome host"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Mostra tutti i threads"
 ],
 "Show fingerprints": [
  null,
  "Mostra le impronte digitali"
 ],
 "Show messages containing given string.": [
  null,
  "Mostra i messaggi contenenti una determinata stringa."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Mostra i messaggi per l'unità systemd specificata."
 ],
 "Show messages from a specific boot.": [
  null,
  "Mostra i messaggi da un avvio specifico."
 ],
 "Show more relationships": [
  null,
  "Mostra più relazioni"
 ],
 "Show relationships": [
  null,
  "Mostra relazioni"
 ],
 "Shut down": [
  null,
  "Arresto"
 ],
 "Shutdown": [
  null,
  "Spegni"
 ],
 "Since": [
  null,
  "Da"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Socket"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Soluzioni alternative basate su software aiutano a prevenire problemi di sicurezza della CPU. Queste mitigazioni hanno l'effetto collaterale di ridurre le prestazioni. Modificare queste impostazioni a proprio rischio."
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Speed": [
  null,
  "Velocità"
 ],
 "Start": [
  null,
  "Avvia"
 ],
 "Start and enable": [
  null,
  "Avvia e Abilita"
 ],
 "Start service": [
  null,
  "Avvia il servizio"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Inizia a mostrare le voci a partire dalla data specificata o da una data successiva."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Inizia a mostrare le voci entro e non oltre la data specificata."
 ],
 "State": [
  null,
  "Stato"
 ],
 "Static": [
  null,
  "Statico"
 ],
 "Status": [
  null,
  "Stato"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Ferma"
 ],
 "Stop and disable": [
  null,
  "Ferma e Disabilita"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Stub": [
  null,
  "urtare"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "La sottoscrizione alle segnalazioni di sistemd è fallita"
 ],
 "Successfully copied to clipboard": [
  null,
  "Copiato con successo negli appunti"
 ],
 "Sundays": [
  null,
  "Domeniche"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System information": [
  null,
  "Informazioni di sistema"
 ],
 "System time": [
  null,
  "Ora di sistema"
 ],
 "Systemd units": [
  null,
  "Unità systemd"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Destinazioni"
 ],
 "Terminal": [
  null,
  "Terminale"
 ],
 "The key password can not be empty": [
  null,
  "La password della chiave non può essere vuota"
 ],
 "The key passwords do not match": [
  null,
  "Le password della chiave non corrispondono"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L'impronta digitale risultante è idonea per la condivisione pubblica, email inclusa."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "L'utente $0 non è autorizzato a modificare le mitigazioni di sicurezza della CPU"
 ],
 "This may take a while": [
  null,
  "L'operazione potrebbe richiedere del tempo"
 ],
 "This system is using a custom profile": [
  null,
  "Questo sistema utilizza un profilo personalizzato"
 ],
 "This system is using the recommended profile": [
  null,
  "Questo sistema utilizza il profilo raccomandato"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Questa unità non è stata progettata per essere abilitata esplicitamente."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Questo aggiungerà una corrispondenza per '_BOOT_ID='. Se non specificato verranno mostrati i log per l'avvio corrente. Se l'ID di avvio viene omesso, un offset positivo cercherà gli avvii a partire dall'inizio del journal e un offset uguale o inferiore a zero cercherà gli avvioi a partire dalla fine del journal. Pertanto, 1 indica il primo avvio trovato nel journal in ordine cronologico, 2 il secondo e così via; mentre -0 è l'ultimo avvio, -1 l'avvio prima dell'ultimo e così via."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Questo aggiungerà una corrispondenza per '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' e 'UNIT=' per trovare tutti i messaggi possibili per l'unità data. Può contenere più unità separate da virgola. "
 ],
 "Thursdays": [
  null,
  "Giovedì"
 ],
 "Time": [
  null,
  "Ora"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "Timers": [
  null,
  "Timer"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Per assicurare che la connessione non sia intercettata da un soggetto terzo malelvolo, verifica l'impronta digitale dell'host:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Per verificare un'impronta digitale, esegui su $0 mentre sei fisicamente di fronte alla macchina o attraverso una rete fidata:"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Toggle filters": [
  null,
  "Attiva/disattiva i filtri"
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transient": [
  null,
  "Transitorio"
 ],
 "Triggered by": [
  null,
  "Attivato da"
 ],
 "Triggers": [
  null,
  "Trigger"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Tuesdays": [
  null,
  "Martedì"
 ],
 "Tuned has failed to start": [
  null,
  "Impossibile avviare tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "tuned è un servizio che monitora il tuo sistema e ottimizza le prestazioni sotto alcuni carichi di lavoro. il cuore di tuned sono i profili, che ottimizzano il tuo sistema in casi differenti."
 ],
 "Tuned is not available": [
  null,
  "Tuned non è disponibile"
 ],
 "Tuned is not running": [
  null,
  "Tuned non è in esecuzione"
 ],
 "Tuned is off": [
  null,
  "Tuned è disattivato"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Type to filter": [
  null,
  "Tipo da filtrare"
 ],
 "Unit": [
  null,
  "Unità"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Until": [
  null,
  "Fino a"
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "Updating status...": [
  null,
  "Aggiornamento dello stato..."
 ],
 "Usage": [
  null,
  "Utilizzo"
 ],
 "User": [
  null,
  "Utente"
 ],
 "Validating address": [
  null,
  "Convalida dell'indirizzo"
 ],
 "Vendor": [
  null,
  "Rivenditore"
 ],
 "Version": [
  null,
  "Versione"
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "View hardware details": [
  null,
  "Visualizza i dettagli hardware"
 ],
 "View report": [
  null,
  "Visualizza rapporto"
 ],
 "Waiting for input…": [
  null,
  "In attesa di input…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Waiting to start…": [
  null,
  "In attesa di avvio…"
 ],
 "Wanted by": [
  null,
  "Ricercato da"
 ],
 "Wants": [
  null,
  "Vuole"
 ],
 "Warning and above": [
  null,
  "Avvertenza e superiore"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "Web console is running in limited access mode.": [
  null,
  "La Web Console è in esecuzione in modalità di accesso limitato."
 ],
 "Wednesdays": [
  null,
  "Mercoledì"
 ],
 "Weeks": [
  null,
  "Settimane"
 ],
 "White": [
  null,
  "Bianco"
 ],
 "Yearly": [
  null,
  "Annuale"
 ],
 "Yes": [
  null,
  "Sì"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Collegamento a $0 per la prima volta"
 ],
 "You may try to load older entries.": [
  null,
  "Puoi provare a caricare voci precedenti."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "active": [
  null,
  "attivo"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "impossibile elencare le chiavi host ssh: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "journalctl manpage": [
  null,
  "pagina man di journalctl"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "nessuno"
 ],
 "of $0 CPU": [
  null,
  "di $0 CPU",
  "di $0 CPU"
 ],
 "recommended": [
  null,
  "raccomandato"
 ],
 "running $0": [
  null,
  "$0 in esecuzione"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "unknown": [
  null,
  "sconosciuto"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Dominio"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Entra in un dominio"
 ]
});
