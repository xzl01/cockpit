cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "시스템 설정 구성"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Logs": [
  null,
  "기록"
 ],
 "Managing services": [
  null,
  "서비스 관리"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "Overview": [
  null,
  "개요"
 ],
 "Reviewing logs": [
  null,
  "로그 검토"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "서비스"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Terminal": [
  null,
  "터미널"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "자산 태그"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "부팅"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "명령"
 ],
 "console": [
  null,
  "콘솔"
 ],
 "coredump": [
  null,
  "코어 덤프"
 ],
 "cpu": [
  null,
  "중앙처리장치"
 ],
 "crash": [
  null,
  "충돌"
 ],
 "date": [
  null,
  "날짜"
 ],
 "debug": [
  null,
  "디버그"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "비활성화"
 ],
 "disks": [
  null,
  "디스크"
 ],
 "domain": [
  null,
  "도메인"
 ],
 "enable": [
  null,
  "활성화"
 ],
 "error": [
  null,
  "오류"
 ],
 "graphs": [
  null,
  "그래프"
 ],
 "hardware": [
  null,
  "하드웨어"
 ],
 "history": [
  null,
  "내역"
 ],
 "host": [
  null,
  "호스트"
 ],
 "journal": [
  null,
  "저널"
 ],
 "machine": [
  null,
  "장치"
 ],
 "mask": [
  null,
  "마스크"
 ],
 "memory": [
  null,
  "메모리"
 ],
 "metrics": [
  null,
  "메트릭"
 ],
 "mitigation": [
  null,
  "완화"
 ],
 "network": [
  null,
  "네트워크"
 ],
 "operating system": [
  null,
  "운영 체제"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "경로"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "성능"
 ],
 "power": [
  null,
  "전원"
 ],
 "ram": [
  null,
  "램"
 ],
 "restart": [
  null,
  "재시작"
 ],
 "serial": [
  null,
  "시리얼"
 ],
 "service": [
  null,
  "서비스"
 ],
 "shell": [
  null,
  "쉘"
 ],
 "shut": [
  null,
  "종료"
 ],
 "socket": [
  null,
  "소켓"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "대상"
 ],
 "time": [
  null,
  "시간"
 ],
 "timer": [
  null,
  "타이머"
 ],
 "unit": [
  null,
  "단위"
 ],
 "unmask": [
  null,
  "마스크 해제"
 ],
 "version": [
  null,
  "버전"
 ],
 "warning": [
  null,
  "경고"
 ]
});
