cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "$0 critical hit": [
  null,
  "$0 збіг із критичними",
  "$0 збіги із критичними",
  "$0 збігів із критичними"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "$0 failed login attempt": [
  null,
  "$0 помилкова спроба увійти",
  "$0 помилкових спроби увійти",
  "$0 помилкових спроб увійти"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 important hit": [
  null,
  "$0 збіг із важливими",
  "$0 збіги із важливими",
  "$0 збігів із важливими"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "$0 key changed": [
  null,
  "Змінено ключ $0"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 збіг із низькою важливістю",
  "$0 збіги із низькою важливістю",
  "$0 збігів із низькою важливістю"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "$0 moderate hit": [
  null,
  "$0 збіг зі збігами середньої важливості",
  "$0 збіги зі збігами середньої важливості",
  "$0 збігів зі збігами середньої важливості"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 service has failed": [
  null,
  "Критична помилка $0 служби",
  "Критична помилка $0 служб",
  "Критична помилка $0 служб"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "$0: crash at $1": [
  null,
  "$0: аварія у $1"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "10th": [
  null,
  "10-е"
 ],
 "11th": [
  null,
  "11-е"
 ],
 "12th": [
  null,
  "12-е"
 ],
 "13th": [
  null,
  "13-е"
 ],
 "14th": [
  null,
  "14-е"
 ],
 "15th": [
  null,
  "15-е"
 ],
 "16th": [
  null,
  "16-е"
 ],
 "17th": [
  null,
  "17-е"
 ],
 "18th": [
  null,
  "18-е"
 ],
 "19th": [
  null,
  "19-е"
 ],
 "1st": [
  null,
  "1-е"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "20th": [
  null,
  "20-е"
 ],
 "21th": [
  null,
  "21-е"
 ],
 "22th": [
  null,
  "22-е"
 ],
 "23th": [
  null,
  "23-е"
 ],
 "24th": [
  null,
  "24-е"
 ],
 "25th": [
  null,
  "25-е"
 ],
 "26th": [
  null,
  "26-е"
 ],
 "27th": [
  null,
  "27-е"
 ],
 "28th": [
  null,
  "28-е"
 ],
 "29th": [
  null,
  "29-е"
 ],
 "2nd": [
  null,
  "2-е"
 ],
 "30th": [
  null,
  "30-е"
 ],
 "31st": [
  null,
  "31-е"
 ],
 "3rd": [
  null,
  "3-є"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "4th": [
  null,
  "4-е"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "5th": [
  null,
  "5-е"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "6th": [
  null,
  "6"
 ],
 "7th": [
  null,
  "7"
 ],
 "8th": [
  null,
  "8"
 ],
 "9th": [
  null,
  "9-е"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "На $0 не встановлено сумісної версії Cockpit."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Буде створено новий ключ SSH у $0 для $1 на $2 і його буде додано до файла $3 $4 на $5."
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Acceptable password": [
  null,
  "Прийнятний пароль"
 ],
 "Active since ": [
  null,
  "Активний з "
 ],
 "Active state": [
  null,
  "Активний стан"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "Additional actions": [
  null,
  "Додаткові дії"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Адміністрування за допомогою вебконсолі Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "After": [
  null,
  "Після"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Після полишення цього домену лише користувачі із локальними реєстраційними даними зможуть входити до системи на цій машині. Це також може вплинути на роботу інших служб, оскільки можуть змінитися параметри визначення адрес DNS та список довірених служб сертифікації."
 ],
 "After system boot": [
  null,
  "Після завантаження системи"
 ],
 "Alert and above": [
  null,
  "Тривога і вище"
 ],
 "Alias": [
  null,
  "Псевдонім"
 ],
 "All": [
  null,
  "Всі"
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Allow running (unmask)": [
  null,
  "Дозволити запуск (зняти маску)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документація з ролей Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Будь-який текстовий рядок у журналі можна фільтрувати. Рядок може бути також записано у формі формального виразу. Крім того, передбачено підтримку фільтрування за полями повідомлення журналу. Поля слід вказувати у формі відокремлених комами записів ПОЛЕ=ЗНАЧЕННЯ, де значенням є список відокремлених комами можливих значень."
 ],
 "Appearance": [
  null,
  "Вигляд"
 ],
 "Apply and reboot": [
  null,
  "Застосувати і перезавантажити"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Застосовуємо нові правила… Застосування може тривати декілька хвилин."
 ],
 "Asset tag": [
  null,
  "Мітка активу"
 ],
 "At minute": [
  null,
  "За хвилину"
 ],
 "At second": [
  null,
  "У секунду"
 ],
 "At specific time": [
  null,
  "У вказаний момент часу"
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Щоб отримати доступ до виконання привілейованих завдань за допомогою вебконсолі Cockpit, слід пройти розпізнавання"
 ],
 "Authorize SSH key": [
  null,
  "Уповноважити ключ SSH"
 ],
 "Automatically starts": [
  null,
  "Запускати автоматично"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматично за допомогою додаткових серверів NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Automation script": [
  null,
  "Скрипт автоматизації"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Дата BIOS"
 ],
 "BIOS version": [
  null,
  "Версія BIOS"
 ],
 "Bad": [
  null,
  "Помилковий"
 ],
 "Bad setting": [
  null,
  "Помилковий параметр"
 ],
 "Before": [
  null,
  "До"
 ],
 "Binds to": [
  null,
  "Пов'язано з"
 ],
 "Black": [
  null,
  "Чорний"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Boot": [
  null,
  "Завантаження"
 ],
 "Bound by": [
  null,
  "Пов'язано"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "CPU": [
  null,
  "Процесор"
 ],
 "CPU security": [
  null,
  "Захист процесора"
 ],
 "CPU security toggles": [
  null,
  "Перемикачі захисту процесора"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Не вдалося знайти журналів на основі поточної комбінації фільтрів."
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Cancel poweroff": [
  null,
  "Скасувати вимикання"
 ],
 "Cancel reboot": [
  null,
  "Скасувати перезавантаження"
 ],
 "Cannot be enabled": [
  null,
  "Не може бути увімкнено"
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Неможливо долучитися до домену, оскільки у цій системі немає realmd"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change cryptographic policy": [
  null,
  "Змінити правила шифрування"
 ],
 "Change host name": [
  null,
  "Змінити назву вузла"
 ],
 "Change performance profile": [
  null,
  "Зміна профілю швидкодії"
 ],
 "Change profile": [
  null,
  "Змінити профіль"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Зміна ключів часто є результатом перевстановлення операційної системи. Втім, неочікувана зміна може вказувати на сторонню спробу перехопити дані вашого з'єднання."
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "Class": [
  null,
  "Клас"
 ],
 "Clear 'Failed to start'": [
  null,
  "Вилучити «Не вдалося запустити»"
 ],
 "Clear all filters": [
  null,
  "Зняти усі фільтри"
 ],
 "Client software": [
  null,
  "Клієнтське програмне забезпечення"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Налаштування Cockpit для NetworkManager і Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit — програма для керування сервером, яка полегшує адміністрування ваших серверів під керуванням Linux за допомогою програми для перегляду сторінок інтернету. Ви зможете одночасно використовувати термінал і вебінструмент. Службу, яку було запущено за допомогою Cockpit, можна зупинити за допомогою термінала. І навпаки, якщо трапиться помилка у терміналі, ви побачите її у інтерфейсі журналу Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не встановлено"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit — чудовий інструмент для системних адміністраторів-початківців. За його допомогою вони без проблем впораються із простими завданнями, зокрема адмініструванням сховищ даних, інспектуванням журналів та запуском і зупиненням служб. Ви зможете одночасно стежити за роботою декількох серверів і адмініструвати ці сервери. Просто додайте їх одним клацанням кнопкою миші і ваш комп’ютер сам нагляне за своїми приятелями."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Збирати і пакувати діагностичні дані і дані щодо підтримки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Збирати дампи аварій ядра"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Command not found": [
  null,
  "Команду не знайдено"
 ],
 "Communication with tuned has failed": [
  null,
  "Не вдалося обмінятися даними з tuned"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Умову $0=$1 не виконано"
 ],
 "Condition failed": [
  null,
  "Не виконано умову"
 ],
 "Configuration": [
  null,
  "Налаштування"
 ],
 "Confirm deletion of $0": [
  null,
  "Підтвердьте вилучення $0"
 ],
 "Confirm key password": [
  null,
  "Підтвердження пароля до ключа"
 ],
 "Conflicted by": [
  null,
  "Конфліктує за"
 ],
 "Conflicts": [
  null,
  "Конфліктує"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Не вдалося встановити з'єднання із dbus: $0"
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Consists of": [
  null,
  "Складається з"
 ],
 "Contacted domain": [
  null,
  "Пов'язаний домен"
 ],
 "Controller": [
  null,
  "Контролер"
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Copied": [
  null,
  "Скопійовано"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Crash reporting": [
  null,
  "Звітування щодо аварій"
 ],
 "Create $0": [
  null,
  "Створити $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Створити ключ SSH і уповноважити його"
 ],
 "Create new task file with this content.": [
  null,
  "Створити файл завдання із цим вмістом."
 ],
 "Create timer": [
  null,
  "Створити таймер"
 ],
 "Critical and above": [
  null,
  "Критичні і вище"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "«Правила шифрування» (Crypto Policies) — компонент системи, який налаштовує криптографічні підсистеми, використовуючи протоколи TLS, IPSec, SSH, DNSSec і Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "Правило шифрування"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Правила шифрування є несумісними"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Поточне завантаження"
 ],
 "Custom cryptographic policy": [
  null,
  "Нетипове правило шифрування"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT із дозволеною перевіркою підпису SHA-1."
 ],
 "Daily": [
  null,
  "Щодня"
 ],
 "Dark": [
  null,
  "Темний"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Дату слід вказувати у форматі РРРР-ММ-ДД гг:хх:сс. Крім того, можна використовувати рядки «yesterday» («вчора»), «today» («сьогодні»), «tomorrow» («завтра»). Рядок «now» відповідає поточному моменту часу. Нарешті, можна вказувати відносний час за допомогою префіксів «-» і «+»"
 ],
 "Debug and above": [
  null,
  "Діагностика і вище"
 ],
 "Decrease by one": [
  null,
  "Зменшити на одиницю"
 ],
 "Default": [
  null,
  "Типовий"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Delay must be a number": [
  null,
  "Значенням затримки має бути число"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Deletion will remove the following files:": [
  null,
  "У результаті вилучення буде усунено такі файли:"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Вимкнути багатопотоковість"
 ],
 "Disable tuned": [
  null,
  "Вимкнути tuned"
 ],
 "Disabled": [
  null,
  "Вимкнено"
 ],
 "Disallow running (mask)": [
  null,
  "Заборонити запуск (замаскувати)"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "Does not automatically start": [
  null,
  "Не запускається автоматично"
 ],
 "Domain": [
  null,
  "Домен"
 ],
 "Domain address": [
  null,
  "Адреса домену"
 ],
 "Domain administrator name": [
  null,
  "Ім’я адміністратора домену"
 ],
 "Domain administrator password": [
  null,
  "Пароль адміністратора домену"
 ],
 "Domain could not be contacted": [
  null,
  "Не вдалося встановити зв’язок із доменом"
 ],
 "Domain is not supported": [
  null,
  "Підтримки домену не передбачено"
 ],
 "Don't repeat": [
  null,
  "Не повторювати"
 ],
 "Downloading $0": [
  null,
  "Отримуємо $0"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "Edit /etc/motd": [
  null,
  "Редагувати /etc/motd"
 ],
 "Edit motd": [
  null,
  "Редагувати motd"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Enabled": [
  null,
  "Увімкнено"
 ],
 "Entry at $0": [
  null,
  "Запис у $0"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "Error and above": [
  null,
  "Помилка і вище"
 ],
 "Error message": [
  null,
  "Повідомлення про помилку"
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Extended information": [
  null,
  "Розширена інформація"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS не увімкнено належним чином"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS із подальшими обмеженнями загальних критеріїв."
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "Failed to disable tuned": [
  null,
  "Не вдалося вимкнути tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Не вдалося вимкнути профіль tuned"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Не вдалося увімкнути tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Не вдалося отримати журнал"
 ],
 "Failed to load unit": [
  null,
  "Не вдалося завантажити модуль"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Не вдалося зберегти зміни до /etc/motd"
 ],
 "Failed to start": [
  null,
  "Не вдалося запустити"
 ],
 "Failed to switch profile": [
  null,
  "Не вдалося перемкнути профіль"
 ],
 "File state": [
  null,
  "Стан файла"
 ],
 "Filter by name or description": [
  null,
  "Фільтрувати за назвою або описом"
 ],
 "Filters": [
  null,
  "Фільтри"
 ],
 "Font size": [
  null,
  "Розмір шрифту"
 ],
 "Forbidden from running": [
  null,
  "Заборонено запускати"
 ],
 "Frame number": [
  null,
  "Кількість кадрів"
 ],
 "Free-form search": [
  null,
  "Пошук із довільним критерієм"
 ],
 "Fridays": [
  null,
  "П'ятниці"
 ],
 "General": [
  null,
  "Загальний"
 ],
 "Generated": [
  null,
  "Створений"
 ],
 "Go to $0": [
  null,
  "Перейти до $0"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "Hardware information": [
  null,
  "Дані щодо обладнання"
 ],
 "Health": [
  null,
  "Здоров'я"
 ],
 "Help": [
  null,
  "Довідка"
 ],
 "Hide confirmation password": [
  null,
  "Приховати підтвердження пароля"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "Hierarchy ID": [
  null,
  "Ідентифікатор ієрархії"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Ширші можливості взаємодії за рахунок збільшення простору для можливих атак."
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "Hostname": [
  null,
  "Назва вузла"
 ],
 "Hourly": [
  null,
  "Щогодини"
 ],
 "Hours": [
  null,
  "Години"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "Identifier": [
  null,
  "Ідентифікатор"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Якщо відбиток є відповідним, натисніть «Довіряти і додати вузол». Якщо ж це не так, не встановлюйте з'єднання і повідомте про подію адміністратору."
 ],
 "Increase by one": [
  null,
  "Збільшити на одиницю"
 ],
 "Indirect": [
  null,
  "Опосередкований"
 ],
 "Info and above": [
  null,
  "Інформація і вище"
 ],
 "Insights: ": [
  null,
  "Натяки: "
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Install realmd support": [
  null,
  "Встановити підтримку realmd"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Invalid": [
  null,
  "Некоректний"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Join": [
  null,
  "З'єднати"
 ],
 "Join domain": [
  null,
  "Долучитися до домену"
 ],
 "Joining": [
  null,
  "Долучення"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Для долучення до домену слід встановити realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Підтримки долучення до цього домену не передбачено"
 ],
 "Joins namespace of": [
  null,
  "Долучається до простору назв"
 ],
 "Journal": [
  null,
  "Журнал"
 ],
 "Journal entry": [
  null,
  "Запис журналу"
 ],
 "Journal entry not found": [
  null,
  "Не знайдено запису журналу"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Key password": [
  null,
  "Пароль до ключа"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY із взаємодією з Active Directory."
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Last 24 hours": [
  null,
  "Попередні 24 години"
 ],
 "Last 7 days": [
  null,
  "Попередні 7 днів"
 ],
 "Last successful login:": [
  null,
  "Останній вдалий вхід:"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Leave $0": [
  null,
  "Полишити $0"
 ],
 "Leave domain": [
  null,
  "Полишити домен"
 ],
 "Light": [
  null,
  "Світлий"
 ],
 "Limits": [
  null,
  "Обмеження"
 ],
 "Linked": [
  null,
  "Пов'язаний"
 ],
 "Listen": [
  null,
  "Очікувати"
 ],
 "Listing units": [
  null,
  "Виведення списку модулів"
 ],
 "Listing units failed: $0": [
  null,
  "Не вдалося вивести список модулів: $0"
 ],
 "Load earlier entries": [
  null,
  "Завантажити попередні записи"
 ],
 "Loading keys...": [
  null,
  "Завантаження ключів…"
 ],
 "Loading of SSH keys failed": [
  null,
  "Не вдалося завантажити ключі SSH"
 ],
 "Loading of units failed": [
  null,
  "Не вдалося завантажити модулі"
 ],
 "Loading system modifications...": [
  null,
  "Завантажуємо модифікації системи…"
 ],
 "Loading unit failed": [
  null,
  "Не вдалося завантажити модуль"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "Log in": [
  null,
  "Увійти"
 ],
 "Log in to $0": [
  null,
  "Увійти до $0"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "Login format": [
  null,
  "Формат входу"
 ],
 "Logs": [
  null,
  "Журнали"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "Machine ID": [
  null,
  "Ід. комп’ютера"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Відбитки ключів SSH комп’ютерів"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Maintenance": [
  null,
  "Супровід"
 ],
 "Manage storage": [
  null,
  "Керування сховищем"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Mask service": [
  null,
  "Замаскувати службу"
 ],
 "Masked": [
  null,
  "Замасковано"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Маскування служби забороняє запуск усіх залежних модулів. Це може спричинити значніші наслідки, ніж ви очікуєте. Будь ласка, підтвердьте, що ви хочете замаскувати цей модуль."
 ],
 "Memory": [
  null,
  "Пам'ять"
 ],
 "Memory technology": [
  null,
  "Технологія пам'яті"
 ],
 "Merged": [
  null,
  "Об'єднаний"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Хвилини слід вказувати у форматі числа від 0 до 59"
 ],
 "Minutely": [
  null,
  "За хвилинами"
 ],
 "Minutes": [
  null,
  "Хвилини"
 ],
 "Mitigations": [
  null,
  "Запобіжні заходи"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Mondays": [
  null,
  "Понеділки"
 ],
 "Monthly": [
  null,
  "Щомісяця"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "No": [
  null,
  "Ні"
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "No host keys found.": [
  null,
  "Не знайдено ключів вузлів."
 ],
 "No log entries": [
  null,
  "Немає записів у журналі"
 ],
 "No logs found": [
  null,
  "Журналів не знайдено"
 ],
 "No matching results": [
  null,
  "Нічого не знайдено"
 ],
 "No results found": [
  null,
  "Нічого не знайдено"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Не знайдено нічого, щоб відповідало критерію фільтрування. Зніміть усі фільтри, щоб переглянути результати."
 ],
 "No rule hits": [
  null,
  "Немає збігів з правилами"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "No system modifications": [
  null,
  "Немає модифікацій системи"
 ],
 "None": [
  null,
  "Немає"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Not connected to Insights": [
  null,
  "Не з'єднано із Insights"
 ],
 "Not found": [
  null,
  "Не знайдено"
 ],
 "Not permitted to configure realms": [
  null,
  "Не дозволено налаштовувати області"
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Not running": [
  null,
  "Зупинено"
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Note": [
  null,
  "Примітка"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Notice and above": [
  null,
  "Зауваження і вище"
 ],
 "Occurrences": [
  null,
  "Випадки"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "On failure": [
  null,
  "Якщо помилка"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Після встановлення Cockpit його можна увімкнути за допомогою команди «systemctl enable --now cockpit.socket»."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Можна використовувати лише літери, цифри, : , _ , . , @ , -"
 ],
 "Only emergency": [
  null,
  "Лише критичне"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Використовувати лише затверджені і дозволені алгоритми при завантаженні у режимі FIPS."
 ],
 "Other": [
  null,
  "Інше"
 ],
 "Overview": [
  null,
  "Огляд"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "Part of": [
  null,
  "Частина"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Paste error": [
  null,
  "Помилка вставлення"
 ],
 "Path": [
  null,
  "Шлях"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "Paths": [
  null,
  "Шляхи"
 ],
 "Pause": [
  null,
  "Призупинити"
 ],
 "Performance profile": [
  null,
  "Профіль швидкодії"
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Pin unit": [
  null,
  "Пришпилити модуль"
 ],
 "Pinned unit": [
  null,
  "Пришпилений модуль"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "Pretty host name": [
  null,
  "Зручна назва вузла"
 ],
 "Previous boot": [
  null,
  "Попереднє завантаження"
 ],
 "Priority": [
  null,
  "Пріоритетність"
 ],
 "Problem details": [
  null,
  "Подробиці щодо проблеми"
 ],
 "Problem info": [
  null,
  "Дані щодо проблеми"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "Propagates reload to": [
  null,
  "Поширює перезавантаження на"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Захищає від очікуваних у короткостроковій перспективі атак за рахунок звуження можливостей взаємодії."
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Rank": [
  null,
  "Ранг"
 ],
 "Read more...": [
  null,
  "Докладніше…"
 ],
 "Read-only": [
  null,
  "Лише читання"
 ],
 "Real host name": [
  null,
  "Справжня назва вузла"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Назва справжнього вузла має складатися лише з літер у нижньому регістрі, цифр, дефісів та точок (із заповненими піддоменами)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Назва справжнього вузла має складатися не більше ніж з 64 символів"
 ],
 "Reapply and reboot": [
  null,
  "Повторно застосувати і перезавантажити"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Рекомендовано, безпечні параметри для поточних моделей загроз."
 ],
 "Reload": [
  null,
  "Перезавантажити"
 ],
 "Reload propagated from": [
  null,
  "Поширене перезавантаження з"
 ],
 "Reloading": [
  null,
  "Перезавантаження"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Repeat": [
  null,
  "Повторення"
 ],
 "Repeat monthly": [
  null,
  "Повторювати щомісяця"
 ],
 "Repeat weekly": [
  null,
  "Повторювати щотижня"
 ],
 "Report": [
  null,
  "Звіт"
 ],
 "Report to ABRT Analytics": [
  null,
  "Звітувати до аналітики ABRT"
 ],
 "Reported; no links available": [
  null,
  "Звіт створено; немає доступу до посилань"
 ],
 "Reporting failed": [
  null,
  "Невдале звітування"
 ],
 "Reporting was canceled": [
  null,
  "Звітування було скасовано"
 ],
 "Reports:": [
  null,
  "Звіти:"
 ],
 "Required by": [
  null,
  "Потрібен для"
 ],
 "Required by ": [
  null,
  "Потрібен для "
 ],
 "Requires": [
  null,
  "Потребує"
 ],
 "Requires administration access to edit": [
  null,
  "Потребує адміністративного доступу для редагування"
 ],
 "Requisite": [
  null,
  "Потрібний"
 ],
 "Requisite of": [
  null,
  "Потрібний для"
 ],
 "Reset": [
  null,
  "Скинути"
 ],
 "Restart": [
  null,
  "Перезапустити"
 ],
 "Resume": [
  null,
  "Відновити"
 ],
 "Review cryptographic policy": [
  null,
  "Переглянути правила шифрування"
 ],
 "Row expansion": [
  null,
  "Розгортання рядка"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "Run at": [
  null,
  "Запустити"
 ],
 "Run on": [
  null,
  "Запустити на"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустити цю команду довіреною мережею або фізично на віддаленому комп'ютері:"
 ],
 "Running": [
  null,
  "Працює"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Ключ SSH"
 ],
 "SSH key login": [
  null,
  "Вхід за ключем SSH"
 ],
 "Saturdays": [
  null,
  "Суботи"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Save and reboot": [
  null,
  "Зберегти і перезавантажити"
 ],
 "Save changes": [
  null,
  "Зберегти зміни"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Заплановане вимикання о $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Заплановане перезавантаження о $0"
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Search": [
  null,
  "Пошук"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Секунди слід вказувати у форматі числа від 0 до 59"
 ],
 "Seconds": [
  null,
  "Секунди"
 ],
 "Secure shell keys": [
  null,
  "Ключі SSH"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Налаштування Security Enhanced Linux та усування вад"
 ],
 "Send": [
  null,
  "Надіслати"
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "Server software": [
  null,
  "Програмне забезпечення сервера"
 ],
 "Service logs": [
  null,
  "Журнали служб"
 ],
 "Services": [
  null,
  "Служби"
 ],
 "Set hostname": [
  null,
  "Встановити назву вузла"
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Shell script": [
  null,
  "Скрипт оболонки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Показати усі потоки"
 ],
 "Show confirmation password": [
  null,
  "Показати підтвердження пароля"
 ],
 "Show fingerprints": [
  null,
  "Показати відбитки"
 ],
 "Show messages containing given string.": [
  null,
  "Показати повідомлення, які містять вказаний рядок."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Показати повідомлення для вказаного модуля systemd."
 ],
 "Show messages from a specific boot.": [
  null,
  "Показати повідомлення з вказаного завантаження."
 ],
 "Show more relationships": [
  null,
  "Показати більше зв'язків"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Show relationships": [
  null,
  "Показати зв'язки"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Shutdown": [
  null,
  "Вимкнути"
 ],
 "Since": [
  null,
  "З"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "Slot": [
  null,
  "Слот"
 ],
 "Sockets": [
  null,
  "Сокети"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Програмні заходи допомагають усунути проблеми із захистом процесора. Ці заходи мають побіжний ефект — зниження швидкодії. Змінюйте ці параметри, лише якщо повністю усвідомлюєте наслідки."
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Speed": [
  null,
  "Швидкість"
 ],
 "Start": [
  null,
  "Почати"
 ],
 "Start and enable": [
  null,
  "Запустити і увімкнути"
 ],
 "Start service": [
  null,
  "Запустити службу"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Почати показ записів, дата яких є рівною вказаній або новішою за неї."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Показати показ записів, дата яких є рівною вказаній або старішою за неї."
 ],
 "State": [
  null,
  "Стан"
 ],
 "Static": [
  null,
  "Статичний"
 ],
 "Status": [
  null,
  "Стан"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "Stop": [
  null,
  "Зупинити"
 ],
 "Stop and disable": [
  null,
  "Зупинити і вимкнути"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Strong password": [
  null,
  "Складний пароль"
 ],
 "Stub": [
  null,
  "Затичка"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Не вдалося підписатися на сигнали systemd: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Успішно скопійовано до буфера обміну"
 ],
 "Sundays": [
  null,
  "Неділі"
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "System": [
  null,
  "Система"
 ],
 "System information": [
  null,
  "Інформація про систему"
 ],
 "System time": [
  null,
  "Системний час"
 ],
 "Systemd units": [
  null,
  "Модулі systemd"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Targets": [
  null,
  "Призначення"
 ],
 "Terminal": [
  null,
  "Термінал"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Ключ SSH $0 $1 на $2 буде додано до файла $3 $4 на $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Ключ SSH $0 буде доступним протягом решти сеансу і також буде доступним для входу на інші вузли."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено паролем, а на вузлі заборонено вхід без пароля. Буль ласка, вкажіть пароль до ключа у $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено. Ви можете увійти або за допомогою пароль до вашого облікового запису або вказавши пароль до ключа у $1."
 ],
 "The fingerprint should match:": [
  null,
  "Відбиток має збігатися:"
 ],
 "The key password can not be empty": [
  null,
  "Пароль до ключа не може бути порожнім"
 ],
 "The key passwords do not match": [
  null,
  "Паролі до ключа не збігаються"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Користувач, який увійшов до системи, не має права переглядати модифікації системи"
 ],
 "The password can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Відбиток-результат можна поширювати у спосіб із загальним доступом, зокрема електронною поштою."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Відбиток-результат можна поширювати відкритими способами, включно із електронною поштою. Якщо ви просите когось виконати перевірку для вас, вони можуть надсилати результати за допомогою будь-якого способу."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Користувачу $0 заборонено змінювати заходи захисту процесора"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Користувачеві $0 заборонено змінювати правила шифрування"
 ],
 "This field cannot be empty": [
  null,
  "Вміст цього поля не може бути порожнім"
 ],
 "This may take a while": [
  null,
  "Зачекайте"
 ],
 "This system is using a custom profile": [
  null,
  "Ця система використовує нетиповий профіль"
 ],
 "This system is using the recommended profile": [
  null,
  "Ця система використовує рекомендований профіль"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Цей інструмент налаштовує правила SELinux і може допомогти зрозуміти та усунути порушення правил."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Цей інструмент налаштовує систему на запис дампів аварій ядра. Передбачено підтримку призначень дампу «local» (диск), «ssh» та «nfs»."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Цей інструмент створюдє архів даних щодо налаштувань та діагностики для запущеної системи. Архів може бути збережено локально або централізовано з метою журналювання або стеження або надіслано до представників технічної підтримки, розробників або адміністраторів системи, щоб допомогти з пошуком технічних проблем та діагностикою."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Цей інструмент керує локальним сховищем даних, зокрема файловими системами, групами томів LVM2 та монтуваннями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Цей інструмент керує можливостями роботи у мережі, зокрема зв'язками, містками, командами, віртуальними LAN та брандмауерами, за допомогою NetworkManager і Firewalld. NetworkManager є несумісним із типовим для Ubuntu systemd-networkd та скриптами ifupdown Debian."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Цей модуль не створено для вмикання явним чином."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Це додасть відповідність «_BOOT_ID=». Якщо не вказано, буде показано журнал поточного завантаження. Якщо не вказано ідентифікатор завантаження, додатний відступ призводитиме до пошуку завантажень від початку журналу, а нульовий або від'ємний відступ призводитиме до пошуку завантажень починаючи від кінця журналу. Отже, 1 означає перше завантаження, яке буде знайдено у журналі у хронологічному порядку, 2 — друге завантаження тощо; а -0 — останнє завантаження, -1 — завантаження перед останнім тощо."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Це додасть відповідність «_SYSTEMD_UNIT=», «COREDUMP_UNIT=» та «UNIT=» для пошуку усіх можливих повідомлень для вказаного модуля. Запис може містити декілька записів модулів, які слід відокремлювати комами. "
 ],
 "Thursdays": [
  null,
  "Четверги"
 ],
 "Time": [
  null,
  "Час"
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "Timer creation failed": [
  null,
  "Не вдалося створити таймер"
 ],
 "Timer deletion failed": [
  null,
  "Не вдалося вилучити таймер"
 ],
 "Timers": [
  null,
  "Таймери"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Щоб переконатися, що дані вашого з'єднання не буде перехоплено зловмисниками, будь ласка, підтвердьте відбиток ключа вузла:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Щоб перевірити відбиток, віддайте вказану нижче команду для $0 під час безпосередньої роботи на комп'ютері або з використанням надійної мережі:"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Toggle filters": [
  null,
  "Перемкнути фільтри"
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Transient": [
  null,
  "Проміжний"
 ],
 "Trigger": [
  null,
  "Перемикач"
 ],
 "Triggered by": [
  null,
  "Причина вмикання"
 ],
 "Triggers": [
  null,
  "Умовні зміни"
 ],
 "Trust and add host": [
  null,
  "Довіряти і додати вузол"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "Tuesdays": [
  null,
  "Вівторки"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned не вдалося запустити"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned — служба, яка стежить за вашою системою і оптимізує швидкодію за певних умов навантаження. Ядром Tuned є профілі, які налаштовують вашу систему для різних умов користування."
 ],
 "Tuned is not available": [
  null,
  "Tuned недоступна"
 ],
 "Tuned is not running": [
  null,
  "Tuned не запущено"
 ],
 "Tuned is off": [
  null,
  "Tuned вимкнено"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Type to filter": [
  null,
  "Введіть щось для фільтрування"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не вдалося увійти до $0 за допомогою розпізнавання за ключем SSH. Будь ласка, вкажіть пароль."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не вдалося увійти до $0. Вузол не приймає входу за паролем або будь-яким з ваших ключів SSH."
 ],
 "Unit": [
  null,
  "Модуль"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Unknown host: $0": [
  null,
  "Невідомий вузол: $0"
 ],
 "Unpin unit": [
  null,
  "Відшпилити модуль"
 ],
 "Until": [
  null,
  "До"
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Up since": [
  null,
  "Працює з"
 ],
 "Updating status...": [
  null,
  "Оновлюємо стан…"
 ],
 "Usage": [
  null,
  "Використання"
 ],
 "User": [
  null,
  "Користувач"
 ],
 "Validating address": [
  null,
  "Перевіряємо чинність адреси"
 ],
 "Vendor": [
  null,
  "Постачальник"
 ],
 "Verify fingerprint": [
  null,
  "Перевірити відбиток"
 ],
 "Version": [
  null,
  "Версія"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "View all services": [
  null,
  "Переглянути усі служби"
 ],
 "View automation script": [
  null,
  "Переглянути скрипт автоматизації"
 ],
 "View hardware details": [
  null,
  "Переглянути параметри обладнання"
 ],
 "View login history": [
  null,
  "Переглянути журнал входів"
 ],
 "View metrics and history": [
  null,
  "Переглянути метрику і журнал"
 ],
 "View report": [
  null,
  "Переглянути звіт"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Перегляд даних щодо пам'яті потребує адміністративного доступу."
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Waiting for input…": [
  null,
  "Очікуємо на вхідні дані…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Waiting to start…": [
  null,
  "Очікуємо на запуск…"
 ],
 "Wanted by": [
  null,
  "Бажаний для"
 ],
 "Wants": [
  null,
  "Бажає"
 ],
 "Warning and above": [
  null,
  "Попередження і вище"
 ],
 "Weak password": [
  null,
  "Простий пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Вебконсоль для серверів під керуванням Linux"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Вебконсоль працює у режимі обмеженого доступу."
 ],
 "Wednesdays": [
  null,
  "Середи"
 ],
 "Weekly": [
  null,
  "Щотижня"
 ],
 "Weeks": [
  null,
  "Тижні"
 ],
 "White": [
  null,
  "Білий"
 ],
 "Yearly": [
  null,
  "Щорічно"
 ],
 "Yes": [
  null,
  "Так"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Ви вперше встановлюєте з'єднання із $0."
 ],
 "You may try to load older entries.": [
  null,
  "Ви можете спробувати завантажити старіші записи."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "У вашій програмі для перегляду не передбачено можливості вставлення з контекстного меню. Ви можете скористатися для вставлення комбінацією Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "active": [
  null,
  "активний"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "не вдалося побудувати список ключів SSH вузла: $0"
 ],
 "in less than a minute": [
  null,
  "за менше, ніж хвилину"
 ],
 "inconsistent": [
  null,
  "несумісний"
 ],
 "journalctl manpage": [
  null,
  "сторінка підручника з journalctl"
 ],
 "less than a minute ago": [
  null,
  "менш, ніж хвилину тому"
 ],
 "none": [
  null,
  "немає"
 ],
 "of $0 CPU": [
  null,
  "з $0 процесора",
  "з $0 процесорів",
  "з $0 процесорів"
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "recommended": [
  null,
  "найліпший"
 ],
 "running $0": [
  null,
  "запущено $0"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "unknown": [
  null,
  "невідомо"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Домен"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Долучитися до домену"
 ],
 "from <host>\u0004from $0": [
  null,
  "з $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "з $0 на $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "на $0"
 ]
});
