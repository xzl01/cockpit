cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 impacto crítico",
  "$0 impactos, incluyendo impactos críticos"
 ],
 "$0 day": [
  null,
  "$0 día",
  "$0 días"
 ],
 "$0 exited with code $1": [
  null,
  "$0 finalizó con el código $1"
 ],
 "$0 failed": [
  null,
  "$0 falló"
 ],
 "$0 failed login attempt": [
  null,
  "$0 intento de inicio de sesión fallido",
  "$0 intentos de inicio de sesión fallidos"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 important hit": [
  null,
  "$0 impacto importante",
  "$0 impactos, incluyendo impactos importantes"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 no está disponible en ningún repositorio."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminado con señal $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 impacto poco grave",
  "$0 impactos poco graves"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 moderate hit": [
  null,
  "$0 impacto moderado",
  "$0 impactos, incluyendo impactos moderados"
 ],
 "$0 month": [
  null,
  "$0 mes",
  "$0 meses"
 ],
 "$0 service has failed": [
  null,
  "$0 servicio ha fallado",
  "$0 servicios han fallado"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "Se instalará: $0."
 ],
 "$0 year": [
  null,
  "$0 año",
  "$0 años"
 ],
 "$0: crash at $1": [
  null,
  "$0: falló a los $1"
 ],
 "1 day": [
  null,
  "1 día"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "10th": [
  null,
  "10"
 ],
 "11th": [
  null,
  "11"
 ],
 "12th": [
  null,
  "12"
 ],
 "13th": [
  null,
  "13"
 ],
 "14th": [
  null,
  "14"
 ],
 "15th": [
  null,
  "15"
 ],
 "16th": [
  null,
  "16"
 ],
 "17th": [
  null,
  "17"
 ],
 "18th": [
  null,
  "18"
 ],
 "19th": [
  null,
  "19"
 ],
 "1st": [
  null,
  "1"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "20th": [
  null,
  "20"
 ],
 "21th": [
  null,
  "21"
 ],
 "22th": [
  null,
  "22"
 ],
 "23th": [
  null,
  "23"
 ],
 "24th": [
  null,
  "24"
 ],
 "25th": [
  null,
  "25"
 ],
 "26th": [
  null,
  "26"
 ],
 "27th": [
  null,
  "27"
 ],
 "28th": [
  null,
  "28"
 ],
 "29th": [
  null,
  "29"
 ],
 "2nd": [
  null,
  "2"
 ],
 "30th": [
  null,
  "30"
 ],
 "31st": [
  null,
  "31"
 ],
 "3rd": [
  null,
  "3"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "4th": [
  null,
  "4"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "5th": [
  null,
  "5"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "6th": [
  null,
  "6"
 ],
 "7th": [
  null,
  "7"
 ],
 "8th": [
  null,
  "8"
 ],
 "9th": [
  null,
  "9"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Acceptable password": [
  null,
  "Contraseña aceptable"
 ],
 "Active since ": [
  null,
  "Activo desde "
 ],
 "Active state": [
  null,
  "Estado de actividad"
 ],
 "Add": [
  null,
  "Añadir"
 ],
 "Add $0": [
  null,
  "Añadir $0"
 ],
 "Additional actions": [
  null,
  "Acciones adicionales"
 ],
 "Additional packages:": [
  null,
  "Paquetes adicionales:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrando con la consola Web de Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzado"
 ],
 "After": [
  null,
  "Después"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Después de sacarlo del dominio, solo los usuarios con credenciales locales pueden ver los registros de esta máquina. Esto puede que afecte a otros servicios como la configuración de resolución de DNS y el listado de las CA de confianza."
 ],
 "After system boot": [
  null,
  "Después de que el sistema arranque"
 ],
 "Alert and above": [
  null,
  "Alerta y superior"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "All": [
  null,
  "Todo"
 ],
 "All-in-one": [
  null,
  "Todo en uno"
 ],
 "Allow running (unmask)": [
  null,
  "Permitir su ejecución (desenmascarar)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentación de los roles de Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Se puede filtrar cualquier cadena de texto en los mensajes de los registros. La cadena también puede tener forma de expresión regular. También admite el filtrado por campos de registro de mensajes. Estos son valores separados por espacios, en forma CAMPO = VALOR, donde el valor puede ser una lista de valores posibles separados por comas."
 ],
 "Appearance": [
  null,
  "Apariencia"
 ],
 "Apply and reboot": [
  null,
  "Aplicar y reiniciar"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Aplicando la nueva política... Esto puede tardar unos minutos."
 ],
 "Asset tag": [
  null,
  "Etiqueta de propiedad"
 ],
 "At minute": [
  null,
  "Al minuto"
 ],
 "At second": [
  null,
  "Al segundo"
 ],
 "At specific time": [
  null,
  "A una hora específica"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Se requiere autenticación para elevar privilegios y realizar tareas de administración en la consola Web de Cockpit"
 ],
 "Automatically starts": [
  null,
  "Se ejecuta automáticamente"
 ],
 "Automatically using NTP": [
  null,
  "Utilizando NTP de forma automática"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP adicionales"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automatización"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Fecha de la BIOS"
 ],
 "BIOS version": [
  null,
  "Versión de la BIOS"
 ],
 "Bad": [
  null,
  "Malo"
 ],
 "Bad setting": [
  null,
  "Configuración incorrecta"
 ],
 "Before": [
  null,
  "Antes"
 ],
 "Binds to": [
  null,
  "Asociado a"
 ],
 "Black": [
  null,
  "Negro"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chasis tipo blade"
 ],
 "Boot": [
  null,
  "Arranque"
 ],
 "Bound by": [
  null,
  "Balanceado por"
 ],
 "Bus expansion chassis": [
  null,
  "Chasis de expansión de bus"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "Seguridad de CPU"
 ],
 "CPU security toggles": [
  null,
  "Configuración de seguridad de la CPU"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "No se pudo encontrar ningún registro mediante la combinación de filtros actuales."
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cancel poweroff": [
  null,
  "Cancelar apagado"
 ],
 "Cancel reboot": [
  null,
  "Cancelar reinicio"
 ],
 "Cannot be enabled": [
  null,
  "No se puede activar"
 ],
 "Cannot forward login credentials": [
  null,
  "No se pueden transferir los datos de acceso"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "No se puede unir a un dominio porque el realmd no está disponible en este sistema"
 ],
 "Cannot schedule event in the past": [
  null,
  "No se puede planificar un evento ocurrido en el pasado"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Change cryptographic policy": [
  null,
  "Cambiar políticas de criptografía"
 ],
 "Change host name": [
  null,
  "Cambiar el nombre del anfitrión"
 ],
 "Change performance profile": [
  null,
  "Cambiar el perfil de rendimiento"
 ],
 "Change profile": [
  null,
  "Cambiar el perfil"
 ],
 "Change system time": [
  null,
  "Cambiar la hora del sistema"
 ],
 "Checking installed software": [
  null,
  "Comprobando el software instalado"
 ],
 "Class": [
  null,
  "Clase"
 ],
 "Clear 'Failed to start'": [
  null,
  "Borrar 'Falló al iniciar'"
 ],
 "Clear all filters": [
  null,
  "Limpiar todos los filtros"
 ],
 "Client software": [
  null,
  "Cliente de software"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuración en Cockpit de NetworkManager y Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit no se pudo conectar con el anfitrión especificado."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit es un gestor de servidores que facilita la administración de servidores Linux a través de un navegador web. Es posible alternar entre el portal web y la consola sin problemas. Un servicio que haya empezado por Cockpit se puede parar desde la terminal. Asimismo, si se produce un error en el terminal, podrá verlo en la bitácora de Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit no es compatible con el software del sistema."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit no está instalado en el sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit es ideal para administradores de sistemas nóveles, ya que permite realizar con sencillez tareas como gestionar almacenamiento, inspeccionar bitácoras e iniciar y detener servicios. Puede monitorizar y administrar varios servidores a la vez. Tan solo añádalos con solo pulsar un botón y sus máquinas se encargarán del resto."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Recoger y empaquetar datos de diagnóstico y soporte"
 ],
 "Collect kernel crash dumps": [
  null,
  "Recoger volcados de colapso del kernel"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Command not found": [
  null,
  "Comando no encontrado"
 ],
 "Communication with tuned has failed": [
  null,
  "Falló la comunicación con el servicio tuned"
 ],
 "Compact PCI": [
  null,
  "PCI compacto"
 ],
 "Condition $0=$1 was not met": [
  null,
  "La condición $0=$1 no se cumple"
 ],
 "Condition failed": [
  null,
  "Condición fallida"
 ],
 "Configuration": [
  null,
  "Configuración"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirme la eliminación de $0"
 ],
 "Conflicted by": [
  null,
  "En conflicto por"
 ],
 "Conflicts": [
  null,
  "Conflictos"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Falló la conexión con dbus: $0"
 ],
 "Connection has timed out.": [
  null,
  "La conexión ha caducado."
 ],
 "Consists of": [
  null,
  "Consiste en"
 ],
 "Contacted domain": [
  null,
  "Contactado con el dominio"
 ],
 "Controller": [
  null,
  "Controlador"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar al portapapeles"
 ],
 "Crash reporting": [
  null,
  "Reporte de colapso"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Create new task file with this content.": [
  null,
  "Crear un archivo de tarea con este contenido."
 ],
 "Create timer": [
  null,
  "Crear un temporizador"
 ],
 "Critical and above": [
  null,
  "Crítico y superior"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Las políticas de criptografía son un componente del sistema que configura los principales subsistemas criptográficos, cubriendo los protocolos TLS, IPSec, SSH, DNSSec y Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "Políticas de criptografía"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Las políticas de criptografía seleccionadas son inconsistentes"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Arranque actual"
 ],
 "Custom cryptographic policy": [
  null,
  "Política de criptografía personalizada"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT con posibilidad de verificación de firmas SHA-1."
 ],
 "Daily": [
  null,
  "A diario"
 ],
 "Dark": [
  null,
  "Oscuro"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Las especificaciones de fecha deberían estar en formato YYYY-MM-DD hh:mm:ss. De igual manera, las cadenas 'yesterday', 'today', 'tomorrow' también se entienden. 'now' se refiere al tiempo actual. Finalmente, se pueden especificar tiempos relativos con prefijo '-','+'"
 ],
 "Debug and above": [
  null,
  "Debug y superior"
 ],
 "Decrease by one": [
  null,
  "Disminuir en uno"
 ],
 "Default": [
  null,
  "Predeterminado"
 ],
 "Delay": [
  null,
  "Retardo"
 ],
 "Delay must be a number": [
  null,
  "El retardo debe ser númerico"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Deletion will remove the following files:": [
  null,
  "El proceso eliminará los siguientes archivos:"
 ],
 "Description": [
  null,
  "Descripción"
 ],
 "Desktop": [
  null,
  "Escritorio"
 ],
 "Detachable": [
  null,
  "Desmontable"
 ],
 "Details": [
  null,
  "Detalles"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Deshabilitar el multi-hilo simultáneo"
 ],
 "Disable tuned": [
  null,
  "Deshabilitar tuned"
 ],
 "Disabled": [
  null,
  "Deshabilitado"
 ],
 "Disallow running (mask)": [
  null,
  "No permite ejecutar (máscara)"
 ],
 "Docking station": [
  null,
  "Estación de acoplamiento"
 ],
 "Does not automatically start": [
  null,
  "No se inicia automáticamente en el inicio"
 ],
 "Domain": [
  null,
  "Dominio"
 ],
 "Domain address": [
  null,
  "Dirección de dominio"
 ],
 "Domain administrator name": [
  null,
  "Nombre del administrador del dominio"
 ],
 "Domain administrator password": [
  null,
  "Contraseña del administrador del dominio"
 ],
 "Domain could not be contacted": [
  null,
  "No se pudo contactar con el dominio"
 ],
 "Domain is not supported": [
  null,
  "El dominio no está soportado"
 ],
 "Don't repeat": [
  null,
  "No repetir"
 ],
 "Downloading $0": [
  null,
  "Descargando $0"
 ],
 "Dual rank": [
  null,
  "Rango dual"
 ],
 "Edit /etc/motd": [
  null,
  "Editar /etc/motd"
 ],
 "Edit motd": [
  null,
  "Editar motd"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Entry at $0": [
  null,
  "Entrada en $0"
 ],
 "Error": [
  null,
  "Error"
 ],
 "Error and above": [
  null,
  "Error y superior"
 ],
 "Error message": [
  null,
  "Mensaje de error"
 ],
 "Excellent password": [
  null,
  "Contraseña excelente"
 ],
 "Expansion chassis": [
  null,
  "Chasis de expansión"
 ],
 "Extended information": [
  null,
  "Información extendida"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS no está activado adecuadamente"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS con restricciones Common Criteria."
 ],
 "Failed to change password": [
  null,
  "Error al cambiar contraseña"
 ],
 "Failed to disable tuned": [
  null,
  "Falló la desactivación del servicio tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Fallo al desactivar el perfil de tuned"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Fallo al habilitar $0 en firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Falló la habilitación de tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Fallo al obtener los registros"
 ],
 "Failed to load unit": [
  null,
  "Fallo al cargar la unidad"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Fallo al guardar los cambios en /etc/motd"
 ],
 "Failed to start": [
  null,
  "Falló al iniciar"
 ],
 "Failed to switch profile": [
  null,
  "Falló el cambio de perfil"
 ],
 "File state": [
  null,
  "Estado del archivo de unidad"
 ],
 "Filter by name or description": [
  null,
  "Filtrar por nombre o descripción"
 ],
 "Filters": [
  null,
  "Filtros"
 ],
 "Font size": [
  null,
  "Tamaño de la fuente"
 ],
 "Forbidden from running": [
  null,
  "Prohibido ejecutarlo"
 ],
 "Frame number": [
  null,
  "Número del frame"
 ],
 "Free-form search": [
  null,
  "Búsqueda libre"
 ],
 "Fridays": [
  null,
  "Los viernes"
 ],
 "General": [
  null,
  "General"
 ],
 "Generated": [
  null,
  "Generado"
 ],
 "Go to $0": [
  null,
  "Ir a $0"
 ],
 "Go to now": [
  null,
  "Ir a ahora"
 ],
 "Handheld": [
  null,
  "Dispositivo de mano"
 ],
 "Hardware information": [
  null,
  "Información del hardware"
 ],
 "Health": [
  null,
  "Salud"
 ],
 "Help": [
  null,
  "Ayuda"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar contraseña de confirmación"
 ],
 "Hide password": [
  null,
  "Ocultar contraseña"
 ],
 "Hierarchy ID": [
  null,
  "ID de jerarquía"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Mayor interoperabilidad a costa de una mayor superficie de ataque."
 ],
 "Host key is incorrect": [
  null,
  "La tecla del anfitrión es incorrecta"
 ],
 "Hostname": [
  null,
  "Nombre del anfitrión"
 ],
 "Hourly": [
  null,
  "Cada hora"
 ],
 "Hours": [
  null,
  "Horas"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identificador"
 ],
 "Increase by one": [
  null,
  "Incrementar en uno"
 ],
 "Indirect": [
  null,
  "Indirecto"
 ],
 "Info and above": [
  null,
  "Informativo y superior"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install realmd support": [
  null,
  "Instale soporte para realmd"
 ],
 "Install software": [
  null,
  "Instalar software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Internal error": [
  null,
  "Error interno"
 ],
 "Invalid": [
  null,
  "No válido"
 ],
 "Invalid date format": [
  null,
  "Formato de fecha inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de fecha y hora inválidos"
 ],
 "Invalid file permissions": [
  null,
  "Permisos de archivo invalidos"
 ],
 "Invalid time format": [
  null,
  "Formato de hora inválido"
 ],
 "Invalid timezone": [
  null,
  "Zona horaria no válida"
 ],
 "IoT gateway": [
  null,
  "Pasarela IoT"
 ],
 "Join": [
  null,
  "Unirse"
 ],
 "Join domain": [
  null,
  "Unirse a un dominio"
 ],
 "Joining": [
  null,
  "Uniéndose"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Para unirse a un dominio debe instalar realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "No puede unirse a este dominio porque no está soportado"
 ],
 "Joins namespace of": [
  null,
  "Se une a un espacio de nombres de"
 ],
 "Journal": [
  null,
  "Bitácora"
 ],
 "Journal entry": [
  null,
  "Bitácora de entradas"
 ],
 "Journal entry not found": [
  null,
  "Entrada de bitácora no encontrada"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY con interoperabilidad con Active Directory."
 ],
 "Laptop": [
  null,
  "Portátil"
 ],
 "Last 24 hours": [
  null,
  "Últimas 24 horas"
 ],
 "Last 7 days": [
  null,
  "Últimos 7 días"
 ],
 "Last successful login:": [
  null,
  "Último inicio de sesión correcto:"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "Leave $0": [
  null,
  "Abandonar $0"
 ],
 "Leave domain": [
  null,
  "Abandonar el dominio"
 ],
 "Light": [
  null,
  "Claro"
 ],
 "Limits": [
  null,
  "Límites"
 ],
 "Linked": [
  null,
  "Vinculado"
 ],
 "Listen": [
  null,
  "Escuchando"
 ],
 "Listing units": [
  null,
  "Listando unidades"
 ],
 "Listing units failed: $0": [
  null,
  "Fallo al listar unidades: $0"
 ],
 "Load earlier entries": [
  null,
  "Cargar entradas anteriores"
 ],
 "Loading earlier entries": [
  null,
  "Cargando entradas anteriores"
 ],
 "Loading keys...": [
  null,
  "Cargando claves..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Fallo al cargar las claves SSH"
 ],
 "Loading of units failed": [
  null,
  "Fallo al cargar las unidades"
 ],
 "Loading system modifications...": [
  null,
  "Cargando modificaciones del sistema..."
 ],
 "Loading unit failed": [
  null,
  "Fallo al cargar la unidad"
 ],
 "Loading...": [
  null,
  "Cargando..."
 ],
 "Log messages": [
  null,
  "Mensajes de registro"
 ],
 "Login failed": [
  null,
  "Inicio de sesión fallido"
 ],
 "Login format": [
  null,
  "Formato de acceso"
 ],
 "Logs": [
  null,
  "Registros"
 ],
 "Low profile desktop": [
  null,
  "Perfil bajo de escritorio"
 ],
 "Lunch box": [
  null,
  "Caja de almuerzo"
 ],
 "Machine ID": [
  null,
  "Id. de máquina"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Huellas de clave SSH de la máquina"
 ],
 "Main server chassis": [
  null,
  "Chasis del servidor principal"
 ],
 "Maintenance": [
  null,
  "Modo de mantenimiento"
 ],
 "Manage storage": [
  null,
  "Gestionar el almacenamiento"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Mask service": [
  null,
  "Enmascarar un servicio"
 ],
 "Masked": [
  null,
  "Enmascarado"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Enmascarando un servicio para prevenir que todas las unidades dependan de su ejecución. Esto puede tener un impacto mayor de los previsto. Por favor confirme que quiere enmascarar esta unidad."
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Memory technology": [
  null,
  "Tecnología de la memoria"
 ],
 "Merged": [
  null,
  "Fusionado"
 ],
 "Message to logged in users": [
  null,
  "Mensaje para usuarios activos"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "El minuto debe ser un número comprendido entre 0 y 59"
 ],
 "Minutely": [
  null,
  "Cada minuto"
 ],
 "Minutes": [
  null,
  "Minutos"
 ],
 "Mitigations": [
  null,
  "Mitigaciones"
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Mondays": [
  null,
  "Los lunes"
 ],
 "Monthly": [
  null,
  "Mensualmente"
 ],
 "Multi-system chassis": [
  null,
  "Chasis multisistema"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Need at least one NTP server": [
  null,
  "Se requiere al menos un servidor NTP"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "New password was not accepted": [
  null,
  "No se aceptó la nueva contraseña"
 ],
 "No": [
  null,
  "No"
 ],
 "No delay": [
  null,
  "Sin retardo"
 ],
 "No host keys found.": [
  null,
  "No se encontró ninguna clave de anfitrión."
 ],
 "No log entries": [
  null,
  "No hay entradas de registro"
 ],
 "No logs found": [
  null,
  "No se encontraron registros"
 ],
 "No matching results": [
  null,
  "No se encontraron resultados"
 ],
 "No results found": [
  null,
  "No se encontraron resultados"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "No se obtuvieron resultados según el criterio de búsqueda. Limpie todos los filtros para mostrar los resultados."
 ],
 "No rule hits": [
  null,
  "Sin impactos"
 ],
 "No such file or directory": [
  null,
  "No existe el archivo o directorio"
 ],
 "No system modifications": [
  null,
  "No hay modificaciones para el sistema"
 ],
 "None": [
  null,
  "Ninguno"
 ],
 "Not a valid private key": [
  null,
  "No es una clave privada válida"
 ],
 "Not connected to Insights": [
  null,
  "No se ha conectado a Insights"
 ],
 "Not found": [
  null,
  "No se ha encontrado"
 ],
 "Not permitted to configure realms": [
  null,
  "Sin permisos para configurar realms"
 ],
 "Not permitted to perform this action.": [
  null,
  "No está permitido llevar a cabo esta acción."
 ],
 "Not running": [
  null,
  "No está ejecutándose"
 ],
 "Not synchronized": [
  null,
  "No está sincronizado"
 ],
 "Note": [
  null,
  "Nota"
 ],
 "Notebook": [
  null,
  "Portátil"
 ],
 "Notice and above": [
  null,
  "Notice y superior"
 ],
 "Occurrences": [
  null,
  "Ocurrencias"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Old password not accepted": [
  null,
  "No se aceptó la contraseña vieja"
 ],
 "On failure": [
  null,
  "En caso de fallo"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una vez que se instale Cockpit, habilítelo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Solo se permiten caracteres alfanuméricos y _ , : , . , @ , -"
 ],
 "Only emergency": [
  null,
  "Solo en caso de emergencia"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Sólo se usan determinados algoritmos aprobados y permitidos cuando se arranca en modo FIPS."
 ],
 "Other": [
  null,
  "Otro"
 ],
 "Overview": [
  null,
  "Visión global"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "Part of": [
  null,
  "Parte de"
 ],
 "Password is not acceptable": [
  null,
  "La contraseña no es válida"
 ],
 "Password is too weak": [
  null,
  "La contraseña es muy débil"
 ],
 "Password not accepted": [
  null,
  "Contraseña no válida"
 ],
 "Paste": [
  null,
  "Pegar"
 ],
 "Paste error": [
  null,
  "Error al pegar"
 ],
 "Path": [
  null,
  "Ruta"
 ],
 "Path to file": [
  null,
  "Ruta al fichero"
 ],
 "Paths": [
  null,
  "Rutas"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Performance profile": [
  null,
  "Perfil de rendimiento"
 ],
 "Peripheral chassis": [
  null,
  "Chasis periférico"
 ],
 "Pick date": [
  null,
  "Selecciona una fecha"
 ],
 "Pin unit": [
  null,
  "Fijar unidad"
 ],
 "Pinned unit": [
  null,
  "Unidad fijada"
 ],
 "Pizza box": [
  null,
  "Caja de pizza"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Pretty host name": [
  null,
  "Nombre bonito del anfitrión"
 ],
 "Previous boot": [
  null,
  "Arranque previo"
 ],
 "Priority": [
  null,
  "Prioridad"
 ],
 "Problem details": [
  null,
  "Detalles del problema"
 ],
 "Problem info": [
  null,
  "Información del problema"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Ha expirado el tiempo de ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Se ha agotado el tiempo de espera para ssh-keygen"
 ],
 "Propagates reload to": [
  null,
  "Propagar la recargar de"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Protege de ataques anticipados en el futuro a corto plazo a costa de una menor interoperabilidad."
 ],
 "RAID chassis": [
  null,
  "Chasis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chasis montado en rack"
 ],
 "Rank": [
  null,
  "Posición"
 ],
 "Read more...": [
  null,
  "Leer más..."
 ],
 "Read-only": [
  null,
  "Solo lectura"
 ],
 "Real host name": [
  null,
  "Nombre real del anfitrión"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "El nombre real del anfitrión solo puede contener caracteres en minúscula, dígitos, guiones y puntos (con subdominios poblados)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "El nombre real del anfitrión debe tener 64 caracteres o menos"
 ],
 "Reapply and reboot": [
  null,
  "Aplicar y reiniciar"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Recomendado, ajustes seguros para los modelos de ataque actuales."
 ],
 "Reload": [
  null,
  "Recargar"
 ],
 "Reload propagated from": [
  null,
  "Recargar la propagación desde"
 ],
 "Reloading": [
  null,
  "Recargando"
 ],
 "Removals:": [
  null,
  "Borrados:"
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "Removing $0": [
  null,
  "Eliminando $0"
 ],
 "Repeat": [
  null,
  "Repetir"
 ],
 "Repeat monthly": [
  null,
  "Repetir mensualmente"
 ],
 "Repeat weekly": [
  null,
  "Repetir cada semana"
 ],
 "Report": [
  null,
  "Informe"
 ],
 "Report to ABRT Analytics": [
  null,
  "Informar a ABRT Analytics"
 ],
 "Reported; no links available": [
  null,
  "Informado; no hay enlaces disponibles"
 ],
 "Reporting failed": [
  null,
  "Fallo al crear el informe"
 ],
 "Reporting was canceled": [
  null,
  "El informe fue cancelado"
 ],
 "Reports:": [
  null,
  "Informes:"
 ],
 "Required by": [
  null,
  "Requerido por"
 ],
 "Required by ": [
  null,
  "Requerido por "
 ],
 "Requires": [
  null,
  "Requiere"
 ],
 "Requires administration access to edit": [
  null,
  "Es necesario tener permisos de acceso administrativi para editar"
 ],
 "Requisite": [
  null,
  "Requisito"
 ],
 "Requisite of": [
  null,
  "Requisito de"
 ],
 "Reset": [
  null,
  "Reiniciar"
 ],
 "Restart": [
  null,
  "Reiniciar"
 ],
 "Resume": [
  null,
  "Reanudar"
 ],
 "Review cryptographic policy": [
  null,
  "Revisar las políticas de criptografía"
 ],
 "Run at": [
  null,
  "Ejecutar a las"
 ],
 "Run on": [
  null,
  "Ejecutar cada"
 ],
 "Running": [
  null,
  "Ejecutando"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "Los sábados"
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "Save and reboot": [
  null,
  "Guardar y reiniciar"
 ],
 "Save changes": [
  null,
  "Guardar cambios"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Apagado programado a las $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Reinicio programado el $0"
 ],
 "Sealed-case PC": [
  null,
  "PC de caja sellada"
 ],
 "Search": [
  null,
  "Buscar"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "El segundo debe ser un número comprendido entre 0 y 59"
 ],
 "Seconds": [
  null,
  "Segundos"
 ],
 "Secure shell keys": [
  null,
  "Claves de Secure Shell"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuración de Security Enhanced Linux y resolución de problemas"
 ],
 "Select a identifier": [
  null,
  "Seleccionar un identificador"
 ],
 "Send": [
  null,
  "Enviar"
 ],
 "Server has closed the connection.": [
  null,
  "El servidor ha cerrado la conexión."
 ],
 "Server software": [
  null,
  "Software de servidor"
 ],
 "Service logs": [
  null,
  "Bitácoras del servicio"
 ],
 "Services": [
  null,
  "Servicios"
 ],
 "Set hostname": [
  null,
  "Establecer un nombre de anfitrión"
 ],
 "Set time": [
  null,
  "Establecer la hora"
 ],
 "Shell script": [
  null,
  "Script de shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Mostrar todos los hilos"
 ],
 "Show confirmation password": [
  null,
  "Mostrar contraseña de confirmación"
 ],
 "Show fingerprints": [
  null,
  "Mostrar las huellas dactilares"
 ],
 "Show messages containing given string.": [
  null,
  "Mostrar mensajes que contengan una cadena dada."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Mostrar mensajes para la unidad de systemd especificada."
 ],
 "Show messages from a specific boot.": [
  null,
  "Mostrar mensajes de un arranque específico."
 ],
 "Show more relationships": [
  null,
  "Mostrar más relaciones"
 ],
 "Show password": [
  null,
  "Mostrar contraseña"
 ],
 "Show relationships": [
  null,
  "Mostrar relaciones"
 ],
 "Shut down": [
  null,
  "Apagar"
 ],
 "Shutdown": [
  null,
  "Apagar"
 ],
 "Since": [
  null,
  "Desde"
 ],
 "Single rank": [
  null,
  "Rango único"
 ],
 "Size": [
  null,
  "Tamaño"
 ],
 "Slot": [
  null,
  "Compartimento"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Las soluciones alternativas basadas en software ayudan a evitar problemas de seguridad de la CPU. Estas mitigaciones tienen el efecto secundario de reducir el rendimiento. Cambie estas configuraciones bajo su propio riesgo."
 ],
 "Space-saving computer": [
  null,
  "Ordenador compacto"
 ],
 "Specific time": [
  null,
  "Hora específica"
 ],
 "Speed": [
  null,
  "Velocidad"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Start and enable": [
  null,
  "Empezar y activar"
 ],
 "Start service": [
  null,
  "Iniciar servicio"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Comenzar a mostrar entradas desde la fecha especificada a la más reciente, incluyéndola."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Comenzar a mostrar entradas desde la fecha especificada a la más antigua, incluyéndola."
 ],
 "State": [
  null,
  "Estado"
 ],
 "Static": [
  null,
  "Estático"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Stick PC": [
  null,
  "PC USB"
 ],
 "Stop": [
  null,
  "Detener"
 ],
 "Stop and disable": [
  null,
  "Parar y desactivar"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Strong password": [
  null,
  "Contraseña fuerte"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Sub-Chassis": [
  null,
  "Sub Chasis"
 ],
 "Sub-Notebook": [
  null,
  "Subportátil"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Falló la suscripción a las señales de systemd: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Copiado al portapapeles con éxito"
 ],
 "Sundays": [
  null,
  "Los domingos"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System information": [
  null,
  "Información del sistema"
 ],
 "System time": [
  null,
  "Hora del sistema"
 ],
 "Systemd units": [
  null,
  "Unidades de systemd"
 ],
 "Tablet": [
  null,
  "Tableta"
 ],
 "Targets": [
  null,
  "Objetivos"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "El usuario autenticado no tiene permisos para ver las modificaciones del sistema"
 ],
 "The passwords do not match.": [
  null,
  "Las contraseñas no coinciden."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "El servido rehusó autenticar usando los métodos soportados."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "El usuario $0 tiene permisos para cambiar las mitigaciones de seguridad de la CPU"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "El usuario $0 no tiene permisos para modificar las políticas de criptografía"
 ],
 "This field cannot be empty": [
  null,
  "Este campo no puede estar vacío"
 ],
 "This may take a while": [
  null,
  "Esto llevará un tiempo"
 ],
 "This system is using a custom profile": [
  null,
  "El sistema utiliza un perfil personalizado"
 ],
 "This system is using the recommended profile": [
  null,
  "El sistema utiliza el perfil recomendado"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta herramienta configura la política de SELinux y puede ayudarle a comprender y resolver infracciones de la política."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Esta herramienta configura el sistema para que escriba en disco los volcados de colapso del kernel."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta herramienta genera un archivo de configuración e información de diagnóstico del sistema en ejecución. El archivo puede ser almacenado localmente o centralmente para propósitos de registro o seguimiento, o puede ser enviado a representantes de soporte técnico, desarrolladores o administradores de sistemas para asistir con la detección de fallos y su corrección."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta herramienta gestiona el almacenamiento local, como sistemas de archivos, grupos de volúmenes LVM2 y montajes NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta herramienta gestiona la configuración de red como agrupaciones, puentes, grupos, las VLAN y cortafuegos usando NetworkManager y Firewalld. NetworkManager es incompatible con systemd-networkd habilitado por defecto en Ubuntu y con los scripts de ifupdown de Debian."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Esta unidad no está diseñada para que se habilite de forma explícita."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Esto añadirá una entrada para '_BOOT_ID=' en la búsqueda. Si no se especifica se mostrarán los registros del arranque actual. Si se omite el ID del arranque, un valor positivo se usará para buscar arranques desde el comienzo del registro, y un valor menor o igual que cero buscará los arranques desde el final del registro. Por ello, 1 significa el primer arranque encontrado en el registro por orden cronológico, 2 el segundo y así; mientras que -0 es el último arranque, -1 el anterior y así."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Esto añadirá entradas para '_SYSTEMD_UNIT', 'COREDUMP_UNIT=' y 'UNIT=' en la búsqueda para encontrar todos los mensajes posibles de dicha unidad. Se pueden añadir más unidades separadas por coma. "
 ],
 "Thursdays": [
  null,
  "Los jueves"
 ],
 "Time": [
  null,
  "Hora"
 ],
 "Time zone": [
  null,
  "Huso horario"
 ],
 "Timer creation failed": [
  null,
  "Fallo en la creación del temporizador"
 ],
 "Timer deletion failed": [
  null,
  "Fallo en la eliminación del temporizador"
 ],
 "Timers": [
  null,
  "Temporizadores"
 ],
 "Toggle date picker": [
  null,
  "Alternar el selector de fecha"
 ],
 "Toggle filters": [
  null,
  "Alternar filtros"
 ],
 "Too much data": [
  null,
  "Demasiados datos"
 ],
 "Total size: $0": [
  null,
  "Tamaño total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Transient": [
  null,
  "Transitorio"
 ],
 "Trigger": [
  null,
  "Disparador"
 ],
 "Triggered by": [
  null,
  "Desencadenado por"
 ],
 "Triggers": [
  null,
  "Disparadores"
 ],
 "Trying to synchronize with $0": [
  null,
  "Intentando sincronizar con $0"
 ],
 "Tuesdays": [
  null,
  "Los martes"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned ha fallado al iniciar"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned es un servicio que monitoriza su sistema y optimiza el rendimiendo ante ciertas cargas de trabajo. El núcleo de Tuned son los perfiles, que ecualizan su sistema para distintos tipos de necesidades."
 ],
 "Tuned is not available": [
  null,
  "Tuned no está disponible"
 ],
 "Tuned is not running": [
  null,
  "Tuned no se está ejecutando"
 ],
 "Tuned is off": [
  null,
  "Tuned está apagado"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Type to filter": [
  null,
  "Escribe para filtrar"
 ],
 "Unit": [
  null,
  "Unidad"
 ],
 "Unknown": [
  null,
  "Desconocido"
 ],
 "Unpin unit": [
  null,
  "Desfijar unidad"
 ],
 "Until": [
  null,
  "Hasta"
 ],
 "Untrusted host": [
  null,
  "Anfitrión no seguro"
 ],
 "Updating status...": [
  null,
  "Actualizando el estado..."
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "User": [
  null,
  "Usuario"
 ],
 "Validating address": [
  null,
  "Validando dirección"
 ],
 "Vendor": [
  null,
  "Proveedor"
 ],
 "Version": [
  null,
  "Versión"
 ],
 "View all logs": [
  null,
  "Ver todos los registros"
 ],
 "View all services": [
  null,
  "Mostrar todos los servicios"
 ],
 "View automation script": [
  null,
  "Ver el script de automatización"
 ],
 "View hardware details": [
  null,
  "Ver los detalles del hardware"
 ],
 "View login history": [
  null,
  "Ver el historial de inicios de sesión"
 ],
 "View metrics and history": [
  null,
  "Ver métricas e histórico"
 ],
 "View report": [
  null,
  "Ver el informe"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Necesita acceso administrativo para ver información sobre la memoria."
 ],
 "Visit firewall": [
  null,
  "Ir al cortafuegos"
 ],
 "Waiting for input…": [
  null,
  "Esperando por una entrada de datos…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Esperando a que finalicen otras operaciones de gestión de software"
 ],
 "Waiting to start…": [
  null,
  "Esperando para arrancar…"
 ],
 "Wanted by": [
  null,
  "Buscado por"
 ],
 "Wants": [
  null,
  "Quiere"
 ],
 "Warning and above": [
  null,
  "Aviso y superior"
 ],
 "Weak password": [
  null,
  "Contraseña débil"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web para servidores Linux"
 ],
 "Web console is running in limited access mode.": [
  null,
  "La consola Web está en modo de acceso limitado."
 ],
 "Wednesdays": [
  null,
  "Los miércoles"
 ],
 "Weekly": [
  null,
  "Semanalmente"
 ],
 "Weeks": [
  null,
  "Semanas"
 ],
 "White": [
  null,
  "Blanco"
 ],
 "Yearly": [
  null,
  "Anualmente"
 ],
 "Yes": [
  null,
  "Sí"
 ],
 "You may try to load older entries.": [
  null,
  "Intente cargar entradas antiguas."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tu navegador no admite pegar desde el menú contextual. Puedes usar Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Su sesión se ha terminado."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Su sesión ha expirado. Por favor inicie sesión otra vez."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[datos binarios]"
 ],
 "[no data]": [
  null,
  "[no hay datos]"
 ],
 "active": [
  null,
  "activo"
 ],
 "edit": [
  null,
  "editar"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "no se pudo mostrar las claves ssh del anfitrión: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "inconsistent": [
  null,
  "inconsistente"
 ],
 "journalctl manpage": [
  null,
  "Página de manual de journalctl"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "ninguno"
 ],
 "of $0 CPU": [
  null,
  "de $0 CPU",
  "de $0 núcleos de CPU"
 ],
 "password quality": [
  null,
  "calidad de la contraseña"
 ],
 "recommended": [
  null,
  "recomendado"
 ],
 "running $0": [
  null,
  "ejecutando $0"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ],
 "unknown": [
  null,
  "desconocido"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Dominio"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Unirse a un dominio"
 ],
 "from <host>\u0004from $0": [
  null,
  "desde $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "desde $0 en $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "desde $1"
 ]
});
