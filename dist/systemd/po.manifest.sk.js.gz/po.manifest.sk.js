cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Aplikujem nastavenia systému"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Logs": [
  null,
  "Záznamy udalostí"
 ],
 "Managing services": [
  null,
  "Správa služieb"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "Overview": [
  null,
  "Prehľad"
 ],
 "Reviewing logs": [
  null,
  "Kontrolujem záznamy udalostí"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "Inventárny štítok"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "boot"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "Príkaz"
 ],
 "console": [
  null,
  "konzola"
 ],
 "coredump": [
  null,
  "výpis jadra"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "crash": [
  null,
  "pád"
 ],
 "date": [
  null,
  "dátum"
 ],
 "debug": [
  null,
  "ladenie"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "vypnúť"
 ],
 "disks": [
  null,
  "disky"
 ],
 "domain": [
  null,
  "Doména"
 ],
 "enable": [
  null,
  "povoliť"
 ],
 "error": [
  null,
  "Chyba"
 ],
 "graphs": [
  null,
  "grafy"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "história"
 ],
 "host": [
  null,
  "stroj"
 ],
 "journal": [
  null,
  "žurnál"
 ],
 "machine": [
  null,
  "stroj"
 ],
 "mask": [
  null,
  "maska"
 ],
 "memory": [
  null,
  "pamäť"
 ],
 "metrics": [
  null,
  "metriky"
 ],
 "mitigation": [
  null,
  "zmiernenie"
 ],
 "network": [
  null,
  "sieť"
 ],
 "operating system": [
  null,
  "Operačný systém"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "umiestnenie"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "výkon"
 ],
 "power": [
  null,
  "napájanie"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "reštartovať"
 ],
 "serial": [
  null,
  "sériové"
 ],
 "service": [
  null,
  "služba"
 ],
 "shell": [
  null,
  "shell"
 ],
 "shut": [
  null,
  "vypnúť"
 ],
 "socket": [
  null,
  "soket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cieľ"
 ],
 "time": [
  null,
  "čas"
 ],
 "timer": [
  null,
  "časovač"
 ],
 "unit": [
  null,
  "jednotka"
 ],
 "unmask": [
  null,
  "odmaskovať"
 ],
 "version": [
  null,
  "Verzia"
 ],
 "warning": [
  null,
  "varovanie"
 ]
});
