cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "「重大な影響」を含む $0 件が該当"
 ],
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 exited with code $1": [
  null,
  "$0 がコード $1 で終了しました"
 ],
 "$0 failed": [
  null,
  "$0 が失敗しました"
 ],
 "$0 failed login attempt": [
  null,
  "$0 がログインの試行に失敗しました"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 important hit": [
  null,
  "「重要な影響」を含む $0 件が該当"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 key changed": [
  null,
  "$0 キーが変更されました"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 がシグナル $1 で終了しました"
 ],
 "$0 low severity hit": [
  null,
  "「低度の影響」を含む $0 件が該当"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "$0 moderate hit": [
  null,
  "「中程度の影響」を含む $0 件が該当"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 service has failed": [
  null,
  "失敗したサービスの数 ($0)"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0: crash at $1": [
  null,
  "$0: $1 でクラッシュ"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "10th": [
  null,
  "10 日"
 ],
 "11th": [
  null,
  "11 日"
 ],
 "12th": [
  null,
  "12 日"
 ],
 "13th": [
  null,
  "13 日"
 ],
 "14th": [
  null,
  "14 日"
 ],
 "15th": [
  null,
  "15 日"
 ],
 "16th": [
  null,
  "16 日"
 ],
 "17th": [
  null,
  "17 日"
 ],
 "18th": [
  null,
  "18 日"
 ],
 "19th": [
  null,
  "19 日"
 ],
 "1st": [
  null,
  "1 日"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "20th": [
  null,
  "20 日"
 ],
 "21th": [
  null,
  "21 日"
 ],
 "22th": [
  null,
  "22 日"
 ],
 "23th": [
  null,
  "23 日"
 ],
 "24th": [
  null,
  "24 日"
 ],
 "25th": [
  null,
  "25 日"
 ],
 "26th": [
  null,
  "26 日"
 ],
 "27th": [
  null,
  "27 日"
 ],
 "28th": [
  null,
  "28 日"
 ],
 "29th": [
  null,
  "29 日"
 ],
 "2nd": [
  null,
  "2 日"
 ],
 "30th": [
  null,
  "30 日"
 ],
 "31st": [
  null,
  "31 日"
 ],
 "3rd": [
  null,
  "3 日"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "4th": [
  null,
  "4 日"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "5th": [
  null,
  "5 日"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "6th": [
  null,
  "6 日"
 ],
 "7th": [
  null,
  "7 日"
 ],
 "8th": [
  null,
  "8 日"
 ],
 "9th": [
  null,
  "9 日"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Cockpit の互換バージョンが $0 にインストールされていません。"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 で新しい SSH キーが $2 の $1 用に作成され、$5 上の $3 の $3 ファイルに追加されました。"
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Acceptable password": [
  null,
  "受け入れられるパスワード"
 ],
 "Active since ": [
  null,
  "アクティブになった日時 "
 ],
 "Active state": [
  null,
  "アクティブ状態"
 ],
 "Add": [
  null,
  "追加"
 ],
 "Add $0": [
  null,
  "$0 の追加"
 ],
 "Additional actions": [
  null,
  "その他の動作"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの管理"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "After": [
  null,
  "後"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "ドメインの終了後は、ローカル認証情報を持つユーザーだけが、このマシンにログインできます。DNS 解決設定および信頼される CA の一覧が変更する可能性があるため、他のサービスにも影響を及ぼす場合があります。"
 ],
 "After system boot": [
  null,
  "システムブート後"
 ],
 "Alert and above": [
  null,
  "アラート以上のレベル"
 ],
 "Alias": [
  null,
  "エイリアス"
 ],
 "All": [
  null,
  "すべて"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Allow running (unmask)": [
  null,
  "実行を許可 (マスク解除)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible ロールのドキュメント"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "ログメッセージのテキスト文字列はフィルターでフィルタリングできます。文字列は、正規表現の形式でも指定できます。また、メッセージログフィールドによるフィルタリングもサポートできます。これらは、FIELD=VALUE の形式でスペースで区切った値は、使用できる値のカンマ区切りのリストになります。"
 ],
 "Appearance": [
  null,
  "外観"
 ],
 "Apply and reboot": [
  null,
  "適用して再起動する"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "新しいポリシーを適用しています... これには数分かかる場合があります。"
 ],
 "Asset tag": [
  null,
  "アセットタグ"
 ],
 "At minute": [
  null,
  "分"
 ],
 "At second": [
  null,
  "秒"
 ],
 "At specific time": [
  null,
  "特定の時間"
 ],
 "Authentication": [
  null,
  "認証"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの特権タスクの実行には、認証が必要です"
 ],
 "Authorize SSH key": [
  null,
  "SSH キーの認証"
 ],
 "Automatically starts": [
  null,
  "自動起動"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using additional NTP servers": [
  null,
  "追加の NTP サーバーを自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "Automation script": [
  null,
  "オートメーションスクリプト"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS の日付"
 ],
 "BIOS version": [
  null,
  "BIOS のバージョン"
 ],
 "Bad": [
  null,
  "正しくない"
 ],
 "Bad setting": [
  null,
  "正しくない設定"
 ],
 "Before": [
  null,
  "前"
 ],
 "Binds to": [
  null,
  "バインドする"
 ],
 "Black": [
  null,
  "黒"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Boot": [
  null,
  "ブート"
 ],
 "Bound by": [
  null,
  "バインドされた"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU セキュリティー"
 ],
 "CPU security toggles": [
  null,
  "CPU セキュリティートグル"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "現在のフィルターの組み合わせを使用して、ログを見つけることができません。"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Cancel poweroff": [
  null,
  "電源オフの取り消し"
 ],
 "Cancel reboot": [
  null,
  "再起動の取り消し"
 ],
 "Cannot be enabled": [
  null,
  "有効にできません"
 ],
 "Cannot forward login credentials": [
  null,
  "ログインのクレデンシャルをフォワードできません"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "realmd がこのシステムで利用できないため、ドメインに参加できません"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change cryptographic policy": [
  null,
  "暗号化ポリシーの変更"
 ],
 "Change host name": [
  null,
  "ホスト名の変更"
 ],
 "Change performance profile": [
  null,
  "パフォーマンスプロファイルの変更"
 ],
 "Change profile": [
  null,
  "プロファイルの変更"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "キーを変更すると、オペレーティングシステムを再インストールすることになることが多くあります。ただし、予期しない変更により接続の傍受が試行される場合もあります。"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Class": [
  null,
  "クラス"
 ],
 "Clear 'Failed to start'": [
  null,
  "'起動に失敗' を消去"
 ],
 "Clear all filters": [
  null,
  "すべてのフィルターの消去"
 ],
 "Client software": [
  null,
  "クライアントソフトウェア"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit の NetworkManager と Firewalld の設定"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit は該当するホストに接続できませんでした。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit は、Web ブラウザーで Linux サーバーを簡単に管理できるサーバーマネージャーです。端末と Web ツールを区別せずに使用できます。Cockpit で起動されたサービスは端末で停止できます。同様に、端末でエラーが発生した場合は、そのエラーを Cockpit ジャーナルインターフェースで確認できます。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit にはシステム上のそのソフトウェアとの互換性がありません。"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit はインストールされていません"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit はシステムにインストールされていません。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit は経験が少ないシステム管理者に最適です。これらのシステム管理者はストレージの管理、ジャーナルの検査、サービスの起動および停止などの単純なタスクを簡単に実行できるようになります。また、複数のサーバーを同時に監視および管理できます。これらのサーバーはクリックするだけで追加できます。追加後に、ご使用のマシンは他のマシンを管理するようになります。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "診断およびサポートデータの収集とパッケージ化"
 ],
 "Collect kernel crash dumps": [
  null,
  "カーネルクラッシュダンプの収集"
 ],
 "Command": [
  null,
  "コマンド"
 ],
 "Command not found": [
  null,
  "コマンドが見つかりません"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned との通信に失敗しました"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Condition $0=$1 was not met": [
  null,
  "条件 $0=$1 を満たしていませんでした"
 ],
 "Condition failed": [
  null,
  "条件が満たされませんでした"
 ],
 "Configuration": [
  null,
  "設定"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 の削除を確定する"
 ],
 "Confirm key password": [
  null,
  "キーパスワードの確認"
 ],
 "Conflicted by": [
  null,
  "競合する"
 ],
 "Conflicts": [
  null,
  "競合"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "dbus への接続に失敗しました: $0"
 ],
 "Connection has timed out.": [
  null,
  "接続がタイムアウトしました。"
 ],
 "Consists of": [
  null,
  "構成するもの"
 ],
 "Contacted domain": [
  null,
  "接続されたドメイン"
 ],
 "Controller": [
  null,
  "コントローラー"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Copied": [
  null,
  "コピー済み"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Crash reporting": [
  null,
  "クラッシュの報告"
 ],
 "Create $0": [
  null,
  "$0 を作成"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "新しい SSH キーを作成して承認します"
 ],
 "Create new task file with this content.": [
  null,
  "このコンテンツで新しいタスクファイルを作成します。"
 ],
 "Create timer": [
  null,
  "タイマーの作成"
 ],
 "Critical and above": [
  null,
  "重大以上のレベル"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "暗号化ポリシーは、TLS、IPSec、SSH、DNSSec、および Kerberos プロトコルに対応するコア暗号化サブシステムを設定するシステムコンポーネントです。"
 ],
 "Cryptographic policy": [
  null,
  "暗号化ポリシー"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "暗号化ポリシーに一貫性がありません"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "現在の起動"
 ],
 "Custom cryptographic policy": [
  null,
  "カスタム暗号化ポリシー"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "SHA-1 署名検証があるデフォルトは使用できます。"
 ],
 "Daily": [
  null,
  "毎日"
 ],
 "Dark": [
  null,
  "ダーク"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "日付の指定は、YYYY-MM-DD hh:mm:ss の形式にする必要があります。'yesterday'、'today'、'tomorrow' という文字列も認識されます。'now' は現在の時刻を指します。相対時間も指定できます。その場合は '-' または '+' を先頭に付けます"
 ],
 "Debug and above": [
  null,
  "デバッグ以上のレベル"
 ],
 "Decrease by one": [
  null,
  "1 つ減らす"
 ],
 "Default": [
  null,
  "デフォルト"
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Delay must be a number": [
  null,
  "遅延は数字である必要があります"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Deletion will remove the following files:": [
  null,
  "削除すると、以下のファイルが削除されます:"
 ],
 "Description": [
  null,
  "説明"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "Details": [
  null,
  "詳細"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Disable simultaneous multithreading": [
  null,
  "同時マルチスレッディングの無効化"
 ],
 "Disable tuned": [
  null,
  "tuned の無効化"
 ],
 "Disabled": [
  null,
  "無効"
 ],
 "Disallow running (mask)": [
  null,
  "実行を禁止 (マスク)"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "Does not automatically start": [
  null,
  "自動起動しません"
 ],
 "Domain": [
  null,
  "ドメイン"
 ],
 "Domain address": [
  null,
  "ドメインアドレス"
 ],
 "Domain administrator name": [
  null,
  "ドメイン管理者名"
 ],
 "Domain administrator password": [
  null,
  "ドメイン管理者パスワード"
 ],
 "Domain could not be contacted": [
  null,
  "ドメイン に接続できませんでした"
 ],
 "Domain is not supported": [
  null,
  "ドメインはサポートされません"
 ],
 "Don't repeat": [
  null,
  "繰り返さない"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd を編集する"
 ],
 "Edit motd": [
  null,
  "motd を編集する"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Enabled": [
  null,
  "有効"
 ],
 "Entry at $0": [
  null,
  "$0 のエントリー"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "Error and above": [
  null,
  "エラー以上のレベル"
 ],
 "Error message": [
  null,
  "エラーメッセージ"
 ],
 "Excellent password": [
  null,
  "優れたパスワード"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Extended information": [
  null,
  "拡張情報"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS が適切に有効化されていません"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "さらにコモンクライテリアの制限がある FIPS。"
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "Failed to disable tuned": [
  null,
  "tuned の無効化に失敗しました"
 ],
 "Failed to disable tuned profile": [
  null,
  "tuned プロファイルの無効化に失敗しました"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld での $0 の有効化に失敗しました"
 ],
 "Failed to enable tuned": [
  null,
  "tuned の有効化に失敗しました"
 ],
 "Failed to fetch logs": [
  null,
  "ログの取得に失敗しました"
 ],
 "Failed to load unit": [
  null,
  "ユニットのロードに失敗しました"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "変更を /etc/motd に保存できませんでした"
 ],
 "Failed to start": [
  null,
  "起動に失敗"
 ],
 "Failed to switch profile": [
  null,
  "プロファイルの切り替えに失敗しました"
 ],
 "File state": [
  null,
  "ファイル状態"
 ],
 "Filter by name or description": [
  null,
  "名前または説明による絞り込み"
 ],
 "Filters": [
  null,
  "フィルター"
 ],
 "Font size": [
  null,
  "フォントのサイズ"
 ],
 "Forbidden from running": [
  null,
  "実行が禁止されています"
 ],
 "Frame number": [
  null,
  "フレーム番号"
 ],
 "Free-form search": [
  null,
  "フリーフォーム検索"
 ],
 "Fridays": [
  null,
  "毎週金曜日"
 ],
 "General": [
  null,
  "全般"
 ],
 "Generated": [
  null,
  "生成しました"
 ],
 "Go to $0": [
  null,
  "$0 に移動"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "Hardware information": [
  null,
  "ハードウェア情報"
 ],
 "Health": [
  null,
  "ヘルス"
 ],
 "Help": [
  null,
  "ヘルプ"
 ],
 "Hide confirmation password": [
  null,
  "確認パスワードの非表示"
 ],
 "Hide password": [
  null,
  "パスワードの非表示"
 ],
 "Hierarchy ID": [
  null,
  "階層 ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "攻撃対象が増えるという代償を払ってでも、相互運用性を高めます。"
 ],
 "Host key is incorrect": [
  null,
  "ホスト鍵が正しくありません"
 ],
 "Hostname": [
  null,
  "ホスト名"
 ],
 "Hourly": [
  null,
  "1 時間ごと"
 ],
 "Hours": [
  null,
  "時"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "識別子"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "フィンガープリントが一致している場合は、'ホストを信頼して追加' をクリックします。一致していない場合は、接続せずに管理者にお問い合わせください。"
 ],
 "Increase by one": [
  null,
  "1 つ増やす"
 ],
 "Indirect": [
  null,
  "間接"
 ],
 "Info and above": [
  null,
  "情報以上のレベル"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install realmd support": [
  null,
  "realmd サポートをインストールする"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Internal error": [
  null,
  "内部エラー"
 ],
 "Invalid": [
  null,
  "無効"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid file permissions": [
  null,
  "無効なファイルパーミッション"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Join": [
  null,
  "参加"
 ],
 "Join domain": [
  null,
  "ドメイン参加"
 ],
 "Joining": [
  null,
  "参加する"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "ドメインに参加するには、realmd のインストールが必要です"
 ],
 "Joining this domain is not supported": [
  null,
  "このドメインの参加はサポートされていません"
 ],
 "Joins namespace of": [
  null,
  "名前空間に参加"
 ],
 "Journal": [
  null,
  "ジャーナル"
 ],
 "Journal entry": [
  null,
  "ジャーナルエントリー"
 ],
 "Journal entry not found": [
  null,
  "ジャーナルエントリーが見つかりません"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Key password": [
  null,
  "キーパスワード"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "Active Directory との相互運用性があるレガシー。"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Last 24 hours": [
  null,
  "過去 24 時間"
 ],
 "Last 7 days": [
  null,
  "過去 7 日間"
 ],
 "Last successful login:": [
  null,
  "最後の正常ログイン:"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Leave $0": [
  null,
  "$0 の脱退"
 ],
 "Leave domain": [
  null,
  "ドメインの脱退"
 ],
 "Light": [
  null,
  "ライト"
 ],
 "Limits": [
  null,
  "制限"
 ],
 "Linked": [
  null,
  "リンク済み"
 ],
 "Listen": [
  null,
  "リッスン"
 ],
 "Listing units": [
  null,
  "ユニットの一覧表示"
 ],
 "Listing units failed: $0": [
  null,
  "ユニットの一覧表示に失敗しました: $0"
 ],
 "Load earlier entries": [
  null,
  "以前のエントリーのロード"
 ],
 "Loading keys...": [
  null,
  "キーをロード中..."
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH キーの読み込みに失敗しました"
 ],
 "Loading of units failed": [
  null,
  "ユニットの読み込みに失敗しました"
 ],
 "Loading system modifications...": [
  null,
  "システム変更をロード中..."
 ],
 "Loading unit failed": [
  null,
  "ユニットのロードに失敗しました"
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "Log in": [
  null,
  "ログイン"
 ],
 "Log in to $0": [
  null,
  "$0 へのログイン"
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "Login failed": [
  null,
  "ログインが失敗しました"
 ],
 "Login format": [
  null,
  "ログインフォーマット"
 ],
 "Logs": [
  null,
  "ログ"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Lunch box": [
  null,
  "ランチボックス"
 ],
 "Machine ID": [
  null,
  "マシン ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "マシンSSH 鍵フィンガープリント"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Maintenance": [
  null,
  "メンテナンス"
 ],
 "Manage storage": [
  null,
  "ストレージの管理"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Mask service": [
  null,
  "サービスのマスク"
 ],
 "Masked": [
  null,
  "マスク"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "サービスをマスクすると、すべての依存するユニットが実行されなくなります。大きな影響が及ぶ可能性があります。このユニットをマスクすることを確認してください。"
 ],
 "Memory": [
  null,
  "メモリ"
 ],
 "Memory technology": [
  null,
  "メモリーテクノロジー"
 ],
 "Merged": [
  null,
  "マージ済み"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "分は 0〜59 の数字である必要があります"
 ],
 "Minutely": [
  null,
  "1 分間隔"
 ],
 "Minutes": [
  null,
  "分"
 ],
 "Mitigations": [
  null,
  "緩和"
 ],
 "Model": [
  null,
  "モデル"
 ],
 "Mondays": [
  null,
  "毎週月曜日"
 ],
 "Monthly": [
  null,
  "毎月"
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "No": [
  null,
  "いいえ"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "No host keys found.": [
  null,
  "ホストキーが見つかりません。"
 ],
 "No log entries": [
  null,
  "ログエントリーなし"
 ],
 "No logs found": [
  null,
  "ログが見つかりません"
 ],
 "No matching results": [
  null,
  "一致する結果はありません"
 ],
 "No results found": [
  null,
  "結果が見つかりません"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "絞り込みの基準と一致する結果がありません。結果を見るためには全ての絞り込み基準を解除してください。"
 ],
 "No rule hits": [
  null,
  "ルールヒットなし"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "No system modifications": [
  null,
  "システム変更がありません"
 ],
 "None": [
  null,
  "なし"
 ],
 "Not a valid private key": [
  null,
  "有効な秘密鍵ではありません"
 ],
 "Not connected to Insights": [
  null,
  "Insights に接続されていません"
 ],
 "Not found": [
  null,
  "見つかりません"
 ],
 "Not permitted to configure realms": [
  null,
  "レルムの設定が許可されていません"
 ],
 "Not permitted to perform this action.": [
  null,
  "この動作を実行する権限がありません。"
 ],
 "Not running": [
  null,
  "未実行"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Note": [
  null,
  "注記"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Notice and above": [
  null,
  "注意以上のレベル"
 ],
 "Occurrences": [
  null,
  "発生"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "On failure": [
  null,
  "障害発生時"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit がインストールされたら、\"systemctl enable --now cockpit.socket\" コマンドで有効にします。"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "アルファベット、数字、:、 _ 、.、@、- のみを使用できます"
 ],
 "Only emergency": [
  null,
  "緊急のみ"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS モードで起動する場合は、承認および許可されたアルゴリズムのみを使用してください。"
 ],
 "Other": [
  null,
  "その他"
 ],
 "Overview": [
  null,
  "概要"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "Part of": [
  null,
  "一部"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Password is not acceptable": [
  null,
  "パスワードは受け入れられません"
 ],
 "Password is too weak": [
  null,
  "パスワードが弱すぎます"
 ],
 "Password not accepted": [
  null,
  "パスワードは受け入れられません"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Paste error": [
  null,
  "貼り付けエラー"
 ],
 "Path": [
  null,
  "パス"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "Paths": [
  null,
  "パス"
 ],
 "Pause": [
  null,
  "一時停止"
 ],
 "Performance profile": [
  null,
  "パフォーマンスプロファイル"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Pin unit": [
  null,
  "ユニットを固定する"
 ],
 "Pinned unit": [
  null,
  "固定されたユニット"
 ],
 "Pizza box": [
  null,
  "ピザ箱"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Pretty host name": [
  null,
  "プリティホスト名"
 ],
 "Previous boot": [
  null,
  "以前のブート"
 ],
 "Priority": [
  null,
  "優先度"
 ],
 "Problem details": [
  null,
  "問題の詳細"
 ],
 "Problem info": [
  null,
  "問題の情報"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add によるプロンプトがタイムアウトしました"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen によるプロンプトがタイムアウトしました"
 ],
 "Propagates reload to": [
  null,
  "再ロード先を伝搬"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "相互運用性を犠牲にして、近い将来に予想される攻撃から保護します。"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Rank": [
  null,
  "ランク"
 ],
 "Read more...": [
  null,
  "さらに読む..."
 ],
 "Read-only": [
  null,
  "読み取り専用"
 ],
 "Real host name": [
  null,
  "実際のホスト名"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "実際のホスト名には小文字、数字、ダッシュ、およびピリオドのみを使用できます (入力されたサブドメインを含む)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "実際のホスト名は 64 文字以下である必要があります"
 ],
 "Reapply and reboot": [
  null,
  "再適用して再起動する"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "現在の脅威モデルに推奨される安全な設定。"
 ],
 "Reload": [
  null,
  "再ロード"
 ],
 "Reload propagated from": [
  null,
  "伝搬元を再ロード"
 ],
 "Reloading": [
  null,
  "リロード中"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Repeat": [
  null,
  "繰り返し"
 ],
 "Repeat monthly": [
  null,
  "毎月繰り返す"
 ],
 "Repeat weekly": [
  null,
  "毎週繰り返す"
 ],
 "Report": [
  null,
  "レポート"
 ],
 "Report to ABRT Analytics": [
  null,
  "ABRT アナリティクスへ報告します"
 ],
 "Reported; no links available": [
  null,
  "報告済み、利用可能なリンクはありません"
 ],
 "Reporting failed": [
  null,
  "報告に失敗しました"
 ],
 "Reporting was canceled": [
  null,
  "報告はキャンセルされました"
 ],
 "Reports:": [
  null,
  "レポート:"
 ],
 "Required by": [
  null,
  "必要とされる"
 ],
 "Required by ": [
  null,
  "以下により必要 "
 ],
 "Requires": [
  null,
  "必須"
 ],
 "Requires administration access to edit": [
  null,
  "編集には管理者アクセスが必要"
 ],
 "Requisite": [
  null,
  "必須"
 ],
 "Requisite of": [
  null,
  "必須の"
 ],
 "Reset": [
  null,
  "リセット"
 ],
 "Restart": [
  null,
  "再起動"
 ],
 "Resume": [
  null,
  "再開"
 ],
 "Review cryptographic policy": [
  null,
  "暗号化ポリシーを確認する"
 ],
 "Row expansion": [
  null,
  "行の拡張"
 ],
 "Row select": [
  null,
  "行の選択"
 ],
 "Run at": [
  null,
  "実行時刻"
 ],
 "Run on": [
  null,
  "以下で実行"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "信頼できるネットワーク経由で、またはリモートマシンで直接、次のコマンドを実行します:"
 ],
 "Running": [
  null,
  "実行中"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH キー"
 ],
 "SSH key login": [
  null,
  "SSH 鍵ログイン"
 ],
 "Saturdays": [
  null,
  "毎週土曜日"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save and reboot": [
  null,
  "保存および再起動"
 ],
 "Save changes": [
  null,
  "変更の保存"
 ],
 "Scheduled poweroff at $0": [
  null,
  "電源オフが $0 に予定されています"
 ],
 "Scheduled reboot at $0": [
  null,
  "再起動が $0 に予定されています"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Search": [
  null,
  "検索"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "秒は 0〜59 の数字でなければなりません"
 ],
 "Seconds": [
  null,
  "秒"
 ],
 "Secure shell keys": [
  null,
  "Secure shell キー"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux の設定とトラブルシューティング"
 ],
 "Send": [
  null,
  "送信"
 ],
 "Server has closed the connection.": [
  null,
  "サーバーの接続が終了しました。"
 ],
 "Server software": [
  null,
  "サーバーソフトウェア"
 ],
 "Service logs": [
  null,
  "サービスログ"
 ],
 "Services": [
  null,
  "サービス"
 ],
 "Set hostname": [
  null,
  "ホスト名を設定します"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Shell script": [
  null,
  "シェルスクリプト"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "すべてのスレッドの表示"
 ],
 "Show confirmation password": [
  null,
  "確認パスワードの表示"
 ],
 "Show fingerprints": [
  null,
  "フィンガープリントの表示"
 ],
 "Show messages containing given string.": [
  null,
  "与えられた文字列が含まれるメッセージを表示します。"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "指定した systemd ユニットのメッセージを表示します。"
 ],
 "Show messages from a specific boot.": [
  null,
  "特定のブートのメッセージを表示します。"
 ],
 "Show more relationships": [
  null,
  "その他の関係の表示"
 ],
 "Show password": [
  null,
  "パスワードを表示する"
 ],
 "Show relationships": [
  null,
  "関係の表示"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Shutdown": [
  null,
  "シャットダウン"
 ],
 "Since": [
  null,
  "フィルター開始時刻"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Size": [
  null,
  "サイズ"
 ],
 "Slot": [
  null,
  "スロット"
 ],
 "Sockets": [
  null,
  "ソケット"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "ソフトウェアベースの回避策により、CPU セキュリティー問題を回避します。これらの緩和策にはパフォーマンスの低下という副次的な影響があります。リスクをご理解の上、これらの設定を変更してください。"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Speed": [
  null,
  "速度"
 ],
 "Start": [
  null,
  "起動"
 ],
 "Start and enable": [
  null,
  "起動と有効化"
 ],
 "Start service": [
  null,
  "サービスの起動"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "指定の日付以降のエントリーまたは新しいエントリーを表示します。"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "指定の日付以前のエントリーまたはそれ以前のエントリーを表示します。"
 ],
 "State": [
  null,
  "状態"
 ],
 "Static": [
  null,
  "静的"
 ],
 "Status": [
  null,
  "ステータス"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stop and disable": [
  null,
  "停止と無効化"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Strong password": [
  null,
  "強固なパスワード"
 ],
 "Stub": [
  null,
  "スタブ"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd シグナルへのサブスクライブに失敗しました: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "クリップボードへのコピーに成功しました"
 ],
 "Sundays": [
  null,
  "毎週日曜日"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "System": [
  null,
  "システム"
 ],
 "System information": [
  null,
  "システム情報"
 ],
 "System time": [
  null,
  "システム時間"
 ],
 "Systemd units": [
  null,
  "システム単位"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "Targets": [
  null,
  "ターゲット"
 ],
 "Terminal": [
  null,
  "端末"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 の $1 の SSH キー $0 は、$5 上の $4 の $3 ファイルに追加されます。"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH キー $0 はセッションの残りの時間に利用できるようになり、他のホストにもログインできるようになります。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーはパスワードで保護され、パスワードによるログインを許可しません。$1 にキーのパスワードを指定してください。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーは保護されています。ログインパスワードでログインするか、$1 で鍵のパスワードを提供することでログインできます。"
 ],
 "The fingerprint should match:": [
  null,
  "フィンガープリントは次のものと一致する必要があります:"
 ],
 "The key password can not be empty": [
  null,
  "キーのパスワードは空にすることはできません"
 ],
 "The key passwords do not match": [
  null,
  "キーのパスワードが一致しません"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ログインしているユーザーには、システム変更を表示する権限がありません"
 ],
 "The password can not be empty": [
  null,
  "パスワードは空にできません"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "作成されたフィンガープリントは、電子メールを含むパブリックメソッドを介して共有すると問題ありません。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成されたフィンガープリントは、メールなどのパブリックな方法で共有しても問題ありません。他の人に検証を依頼した場合、その人は任意の方法で結果を送信できます。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "サーバーはサポートされた方法を使用した認証を拒否しました。"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "ユーザー $0 は、cpu セキュリティー緩和の変更を許可されていません"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "ユーザー $0 は、暗号化ポリシーの変更を許可されていません"
 ],
 "This field cannot be empty": [
  null,
  "このフィールドは必須の項目です"
 ],
 "This may take a while": [
  null,
  "これにはしばらく時間がかかることがあります"
 ],
 "This system is using a custom profile": [
  null,
  "このシステムはカスタムプロファイルを使用しています"
 ],
 "This system is using the recommended profile": [
  null,
  "このシステムは推奨プロファイルを使用しています"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "このツールは、SELinux ポリシーを設定します。また、ポリシー違反の把握と解決に役立ちます。"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "このツールは、システムがカーネルクラッシュダンプを書き込むように設定します。\"local\"（ディスク）、\"ssh\"、および \"nfs\" をターゲットとしてサポートしています。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "このツールは、実行中のシステムから設定および診断情報のアーカイブを生成します。アーカイブは、記録や追跡の目的でローカルまたは一元的に保存することも、技術的な障害の発見やデバッグを支援するためにテクニカルサポート担当者、開発者、システム管理者に送信することもできます。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "このツールは、ファイルシステム、LVM2 ボリュームグループ、NFS マウントなどのローカルストレージを管理します。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "このツールは、NetworkManager と Firewalld を使用して、ボンディング、ブリッジ、チーム、VLAN、ファイアウォールなどのネットワーク設定を管理します。NetworkManager は、Ubuntu のデフォルトの systemd-networkd および Debian の ifupdown スクリプトと互換性がありません。"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "このユニットは明示的に有効にするよう設計されていません。"
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "これにより、_BOOT_ID=' 一致を追加します。指定のない場合は、現在のブートのログが表示されます。ブート ID を省略すると、正のオフセットはジャーナルの開始からブートを探します。また、ゼロまたはゼロ未満のオフセットは、ジャーナルの最後からブートを探します。したがって、1 は時系列順でジャーナルで見つかった最初のブートを意味し、2 は 2 番目のブートを意味します (以下、同様)。また、-0 は最後のブート、-1 は最後の前のブートとなります。"
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "これにより、'_SYSTEMD_UNIT='、'COREDUMP_UNIT='、'UNIT=' と一致させ、指定のユニットに対する考えられるメッセージをすべて特定します。複数のユニットをコンマで区切ることができます。 "
 ],
 "Thursdays": [
  null,
  "毎週木曜日"
 ],
 "Time": [
  null,
  "時間"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "Timer creation failed": [
  null,
  "タイマーの作成に失敗しました"
 ],
 "Timer deletion failed": [
  null,
  "タイマーの削除に失敗しました"
 ],
 "Timers": [
  null,
  "タイマー"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "悪意のあるサードパーティーによって接続がインターセプトされないようにするには、ホストキーフィンガープリントを確認してください:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "フィンガープリントを確認するには、マシン上に物理的に置かれるか、信頼できるネットワークを介して $0 で次のコマンドを実行します:"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Toggle filters": [
  null,
  "フィルターの切り替え"
 ],
 "Too much data": [
  null,
  "データが多すぎます"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Transient": [
  null,
  "一時的"
 ],
 "Trigger": [
  null,
  "トリガー"
 ],
 "Triggered by": [
  null,
  "トリガー元"
 ],
 "Triggers": [
  null,
  "トリガー"
 ],
 "Trust and add host": [
  null,
  "ホストを信頼して追加"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "Tuesdays": [
  null,
  "毎週火曜日"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned の起動に失敗しました"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned は、システムを監視し、特定のワークロードでパフォーマンスを最適化するサービスです。Tuned のコアは、さまざまなユースケースに合わせてシステムを調整するプロファイルです。"
 ],
 "Tuned is not available": [
  null,
  "Tuned が利用できません"
 ],
 "Tuned is not running": [
  null,
  "Tuned 未実行"
 ],
 "Tuned is off": [
  null,
  "Tuned がオフです"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Type to filter": [
  null,
  "フィルターのために入力"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 鍵認証を使用して $0 にログインできません。パスワードを入力してください。"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 にログインできません。ホストが、パスワードログインまたは SSH キーを受け付けていません。"
 ],
 "Unit": [
  null,
  "ユニット"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unknown host: $0": [
  null,
  "不明なホスト: $0"
 ],
 "Unpin unit": [
  null,
  "ユニットの固定を解除する"
 ],
 "Until": [
  null,
  "フィルター終了時刻"
 ],
 "Untrusted host": [
  null,
  "信用できないホスト"
 ],
 "Up since": [
  null,
  "起動時間:"
 ],
 "Updating status...": [
  null,
  "ステータスを更新中..."
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "User": [
  null,
  "ユーザー"
 ],
 "Validating address": [
  null,
  "アドレスの検証"
 ],
 "Vendor": [
  null,
  "ベンダー"
 ],
 "Verify fingerprint": [
  null,
  "フィンガープリントの検証"
 ],
 "Version": [
  null,
  "バージョン"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "View all services": [
  null,
  "すべてのサービスの表示"
 ],
 "View automation script": [
  null,
  "オートメーションスクリプトの表示"
 ],
 "View hardware details": [
  null,
  "ハードウェアの詳細の表示"
 ],
 "View login history": [
  null,
  "ログイン履歴の表示"
 ],
 "View metrics and history": [
  null,
  "メトリックスおよび履歴の表示"
 ],
 "View report": [
  null,
  "レポートの表示"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "メモリー情報を表示するには、管理アクセスが必要です。"
 ],
 "Visit firewall": [
  null,
  "ファイアウォールへのアクセス"
 ],
 "Waiting for input…": [
  null,
  "入力を待機中…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Waiting to start…": [
  null,
  "開始を待機中…"
 ],
 "Wanted by": [
  null,
  "以下で必要"
 ],
 "Wants": [
  null,
  "必要"
 ],
 "Warning and above": [
  null,
  "警告以上のレベル"
 ],
 "Weak password": [
  null,
  "脆弱なパスワード"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux サーバー用 Web コンソール"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web コンソールが制限付きアクセスモードで実行されています。"
 ],
 "Wednesdays": [
  null,
  "毎週水曜日"
 ],
 "Weekly": [
  null,
  "毎週"
 ],
 "Weeks": [
  null,
  "週"
 ],
 "White": [
  null,
  "白"
 ],
 "Yearly": [
  null,
  "毎年"
 ],
 "Yes": [
  null,
  "はい"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "初めて $0 に接続しています。"
 ],
 "You may try to load older entries.": [
  null,
  "古いエントリーのロードを試行することができます。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "お使いのブラウザーでは、コンテキストメニューからの貼り付けが許可されていません。Shift+Insert を使用できます。"
 ],
 "Your session has been terminated.": [
  null,
  "セッションが終了しました。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "セッションの有効期限が切れました。再度ログインしてください。"
 ],
 "Zone": [
  null,
  "ゾーン"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "active": [
  null,
  "アクティブ"
 ],
 "edit": [
  null,
  "編集"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh ホスト鍵の一覧表示に失敗しました: $0"
 ],
 "in less than a minute": [
  null,
  "一分以内"
 ],
 "inconsistent": [
  null,
  "一貫性がない"
 ],
 "journalctl manpage": [
  null,
  "journalctl man ページ"
 ],
 "less than a minute ago": [
  null,
  "一分以内"
 ],
 "none": [
  null,
  "なし"
 ],
 "of $0 CPU": [
  null,
  "CPU 数 ($0)"
 ],
 "password quality": [
  null,
  "パスワードの強度"
 ],
 "recommended": [
  null,
  "推奨"
 ],
 "running $0": [
  null,
  "実行中 $0"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "unknown": [
  null,
  "不明"
 ],
 "dialog-title\u0004Domain": [
  null,
  "ドメイン"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "ドメインへの参加"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0 から"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$1 の $0 から"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0 上"
 ]
});
