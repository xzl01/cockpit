cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 règle critique atteinte",
  "$0 règles atteintes, incluant celles critiques"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 exited with code $1": [
  null,
  "$0 quitté avec le code $1"
 ],
 "$0 failed": [
  null,
  "$0 échoué"
 ],
 "$0 failed login attempt": [
  null,
  "$0 échec de la tentative de connexion",
  "$0 échec des tentatives de connexion"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 important hit": [
  null,
  "$0 règle importante atteinte",
  "$0 règles atteintes, incluant celles importantes"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun référentiel."
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 killed avec un signal $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 règle peu sévère atteinte",
  "$0 règles peu sévères atteintes"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "$0 moderate hit": [
  null,
  "$0 règle modérée atteinte",
  "$0 règles atteintes, incluant celles modérées"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 service has failed": [
  null,
  "$0 service a échoué",
  "$0 services ont échoué"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "$0: crash at $1": [
  null,
  "$0 : plantage à $1"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "1 minute": [
  null,
  "1 minute"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "10th": [
  null,
  "10ème"
 ],
 "11th": [
  null,
  "11ème"
 ],
 "12th": [
  null,
  "12ème"
 ],
 "13th": [
  null,
  "13ème"
 ],
 "14th": [
  null,
  "14ème"
 ],
 "15th": [
  null,
  "15ème"
 ],
 "16th": [
  null,
  "16ème"
 ],
 "17th": [
  null,
  "17ème"
 ],
 "18th": [
  null,
  "18ème"
 ],
 "19th": [
  null,
  "19ème"
 ],
 "1st": [
  null,
  "1er"
 ],
 "20 minutes": [
  null,
  "20 minutes"
 ],
 "20th": [
  null,
  "20ème"
 ],
 "21th": [
  null,
  "21e"
 ],
 "22th": [
  null,
  "22e"
 ],
 "23th": [
  null,
  "23e"
 ],
 "24th": [
  null,
  "24ème"
 ],
 "25th": [
  null,
  "25ème"
 ],
 "26th": [
  null,
  "26ème"
 ],
 "27th": [
  null,
  "27ème"
 ],
 "28th": [
  null,
  "28ème"
 ],
 "29th": [
  null,
  "29ème"
 ],
 "2nd": [
  null,
  "2ème"
 ],
 "30th": [
  null,
  "30ème"
 ],
 "31st": [
  null,
  "31ème"
 ],
 "3rd": [
  null,
  "3ème"
 ],
 "40 minutes": [
  null,
  "40 minutes"
 ],
 "4th": [
  null,
  "4ème"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "5th": [
  null,
  "5ème"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "60 minutes": [
  null,
  "60 minutes"
 ],
 "6th": [
  null,
  "6ème"
 ],
 "7th": [
  null,
  "7ème"
 ],
 "8th": [
  null,
  "8ème"
 ],
 "9th": [
  null,
  "9ème"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Une version compatible de Cockpit n’est pas installée sur $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Une nouvelle clé SSH à $0 sera créée pour $1 sur $2 et elle sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Acceptable password": [
  null,
  "Mot de passe acceptable"
 ],
 "Active since ": [
  null,
  "Actif depuis "
 ],
 "Active state": [
  null,
  "État actif"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "Additional actions": [
  null,
  "Actions supplémenaires"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration avec la console web de Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "After": [
  null,
  "Après"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Une fois le domaine quitté, seuls les utilisateurs disposant d’identifiants locaux pourront se connecter à cette machine. Cela peut également affecter d’autres services tels que les paramètres de résolution DNS. La liste des autorités de certification approuvées peut, en outre, changer."
 ],
 "After system boot": [
  null,
  "Après le démarrage du système"
 ],
 "Alert and above": [
  null,
  "Alerte et au-dessus"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "All": [
  null,
  "Tout"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Allow running (unmask)": [
  null,
  "Autoriser l’exécution (unmask)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentation des rôles Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Toute chaîne de texte dans les messages des journaux peut être filtrée. La chaîne peut également être sous la forme d’une expression régulière. Supporte également le filtrage par les champs du journal des messages. Il s’agit de valeurs séparées par des espaces, sous la forme FIELD=VALUE, où valeur peut être une liste de valeurs possibles séparées par des virgules."
 ],
 "Appearance": [
  null,
  "Apparence"
 ],
 "Apply and reboot": [
  null,
  "Appliquer et redémarrer"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Application de la nouvelle stratégie… Cette opération peut prendre plusieurs minutes."
 ],
 "Asset tag": [
  null,
  "Étiquette d’inventaire"
 ],
 "At minute": [
  null,
  "À la minute"
 ],
 "At second": [
  null,
  "À la seconde"
 ],
 "At specific time": [
  null,
  "À un moment précis"
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Une authentification est nécessaire pour effectuer les tâches privilégiées dans la console web Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autoriser la clé SSH"
 ],
 "Automatically starts": [
  null,
  "Démarre automatiquement"
 ],
 "Automatically using NTP": [
  null,
  "Utiliser automatiquement NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilisation automatique de serveurs NTP supplémentaires"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utiliser automatiquement des serveurs NTP spécifiques"
 ],
 "Automation script": [
  null,
  "Script d’automatisation"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Date du BIOS"
 ],
 "BIOS version": [
  null,
  "Version du BIOS"
 ],
 "Bad": [
  null,
  "Érroné"
 ],
 "Bad setting": [
  null,
  "Mauvais réglage"
 ],
 "Before": [
  null,
  "Avant"
 ],
 "Binds to": [
  null,
  "Liaison vers"
 ],
 "Black": [
  null,
  "Noir"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Boot": [
  null,
  "Amorçage"
 ],
 "Bound by": [
  null,
  "Liés par"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "Sécurité du CPU"
 ],
 "CPU security toggles": [
  null,
  "Paramètres de sécurité du CPU"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Impossible de trouver des journaux en utilisant la combinaison actuelle de filtres."
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Cancel poweroff": [
  null,
  "Annuler la mise hors tension"
 ],
 "Cancel reboot": [
  null,
  "Annuler le redémarrage"
 ],
 "Cannot be enabled": [
  null,
  "Ne peut pas être activé"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossible de transférer les identifiants de connexion"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Impossible de joindre un domaine, car realmd n’est pas disponible sur votre système"
 ],
 "Cannot schedule event in the past": [
  null,
  "Impossible de planifier un événement dans le passé"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Change cryptographic policy": [
  null,
  "Changer de politique de cryptographie"
 ],
 "Change host name": [
  null,
  "Modifier le nom d’hôte"
 ],
 "Change performance profile": [
  null,
  "Modifier le profil de performance"
 ],
 "Change profile": [
  null,
  "Modifier le profil"
 ],
 "Change system time": [
  null,
  "Modifier l’heure du système"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "Class": [
  null,
  "Classe"
 ],
 "Clear 'Failed to start'": [
  null,
  "Effacer « Échec du démarrage »"
 ],
 "Clear all filters": [
  null,
  "Supprimer tous les filtres"
 ],
 "Client software": [
  null,
  "Logiciel client"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuration du cockpit de NetworkManager et Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit n’a pas pu contacter l’hôte indiqué."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit n’est pas compatible avec le logiciel sur le système."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit n’est pas installé"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit n’est pas installé sur le système."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Collecte et regroupement des données de diagnostic et d'assistance"
 ],
 "Collect kernel crash dumps": [
  null,
  "Collecter les vidages de mémoire sur incidents du noyau"
 ],
 "Command": [
  null,
  "Commander"
 ],
 "Command not found": [
  null,
  "Commande introuvable"
 ],
 "Communication with tuned has failed": [
  null,
  "La communication avec tuned a échoué"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Condition $0=$1 was not met": [
  null,
  "La condition $0 = $1 n’a pas été remplie"
 ],
 "Condition failed": [
  null,
  "Condition non remplie"
 ],
 "Configuration": [
  null,
  "Configuration"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmer la suppression de $0"
 ],
 "Confirm key password": [
  null,
  "Confirmer le mot de passe de la clé"
 ],
 "Conflicted by": [
  null,
  "Conflit avec"
 ],
 "Conflicts": [
  null,
  "Conflits"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "La connexion à dbus a échoué : $0"
 ],
 "Connection has timed out.": [
  null,
  "La connexion a expiré."
 ],
 "Consists of": [
  null,
  "Comprend"
 ],
 "Contacted domain": [
  null,
  "Domaine contacté"
 ],
 "Controller": [
  null,
  "Contrôleur"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copié"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Crash reporting": [
  null,
  "Rapport d’incident"
 ],
 "Create $0": [
  null,
  "Créer $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Créer une nouvelle clé SSH et l’autoriser"
 ],
 "Create new task file with this content.": [
  null,
  "Créez un nouveau fichier de tâches avec ce contenu."
 ],
 "Create timer": [
  null,
  "Créer Timer"
 ],
 "Critical and above": [
  null,
  "Critique et au-dessus"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Les « Stratégies de chiffrement » sont un composant système qui configure les sous-systèmes de cryptographie. Il couvre les protocoles TLS, IPSec, SSH, DNSSec, et Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "Politique de cryptographie"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "La politique de cryptographie est incohérente"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Inser"
 ],
 "Current boot": [
  null,
  "Démarrage actuel"
 ],
 "Custom cryptographic policy": [
  null,
  "Politique de cryptographie personnalisée"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAUT avec vérification de la signature SHA-1 autorisée."
 ],
 "Daily": [
  null,
  "Tous les jours"
 ],
 "Dark": [
  null,
  "Sombre"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Les spécifications de date doivent être au format AAAA-MM-JJ hh:mm:ss. Alternativement, les chaînes « hier », « aujourd’hui », « demain » sont bien comprises. « maintenant » fait référence à l’heure actuellement. Enfin, des temps relatifs peuvent être spécifiés, précédés de « - » ou « + »"
 ],
 "Debug and above": [
  null,
  "Débogage et au-dessus"
 ],
 "Decrease by one": [
  null,
  "Diminution par un"
 ],
 "Default": [
  null,
  "Par défaut"
 ],
 "Delay": [
  null,
  "Retard"
 ],
 "Delay must be a number": [
  null,
  "Le retard doit correspondre à un nombre"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Deletion will remove the following files:": [
  null,
  "La suppression supprimera les fichiers suivants :"
 ],
 "Description": [
  null,
  "Description"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "Details": [
  null,
  "Détails"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Désactiver le multithreading simultané"
 ],
 "Disable tuned": [
  null,
  "Désactiver tuned"
 ],
 "Disabled": [
  null,
  "Désactivé"
 ],
 "Disallow running (mask)": [
  null,
  "Empêcher l’exécution (mask)"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "Does not automatically start": [
  null,
  "Ne démarre pas automatiquement"
 ],
 "Domain": [
  null,
  "Domaine"
 ],
 "Domain address": [
  null,
  "Adresse de domaine"
 ],
 "Domain administrator name": [
  null,
  "Nom de l’administrateur du domaine"
 ],
 "Domain administrator password": [
  null,
  "Mot de passe administrateur du domaine"
 ],
 "Domain could not be contacted": [
  null,
  "Le domaine n’a pas pu être contacté"
 ],
 "Domain is not supported": [
  null,
  "Le domaine n’est pas pris en charge"
 ],
 "Don't repeat": [
  null,
  "Ne pas répéter"
 ],
 "Downloading $0": [
  null,
  "Téléchargement de $0"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "Edit /etc/motd": [
  null,
  "Editer /etc/motd"
 ],
 "Edit motd": [
  null,
  "Modifier motd"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Enabled": [
  null,
  "Activée"
 ],
 "Entry at $0": [
  null,
  "Entrée à $0"
 ],
 "Error": [
  null,
  "Erreur"
 ],
 "Error and above": [
  null,
  "Erreur et au-dessus"
 ],
 "Error message": [
  null,
  "Message d’erreur"
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Extended information": [
  null,
  "Informations complémentaires"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS n’est pas correctement activé"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS avec des restrictions supplémentaires liées aux critères communs."
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "Failed to disable tuned": [
  null,
  "Échec de la désactivation de « tuned »"
 ],
 "Failed to disable tuned profile": [
  null,
  "Échec de la désactivation du profil « tuned »"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Échec de l’activation de « tuned »"
 ],
 "Failed to fetch logs": [
  null,
  "Echec de la récupération des journaux"
 ],
 "Failed to load unit": [
  null,
  "Échec du chargement de l'unité"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Impossible d’enregistrer les modifications dans /etc/motd"
 ],
 "Failed to start": [
  null,
  "Échec du démarrage"
 ],
 "Failed to switch profile": [
  null,
  "Échec du changement de profil"
 ],
 "File state": [
  null,
  "État du fichier"
 ],
 "Filter by name or description": [
  null,
  "Filtrer par nom ou description"
 ],
 "Filters": [
  null,
  "Filtres"
 ],
 "Font size": [
  null,
  "Taille de police"
 ],
 "Forbidden from running": [
  null,
  "Non autorisé à exécuter"
 ],
 "Frame number": [
  null,
  "Numéro de cadre"
 ],
 "Free-form search": [
  null,
  "Recherche en forme libre"
 ],
 "Fridays": [
  null,
  "Vendredis"
 ],
 "General": [
  null,
  "Général"
 ],
 "Generated": [
  null,
  "Généré"
 ],
 "Go to $0": [
  null,
  "Aller à $0"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "Hardware information": [
  null,
  "Informations sur le matériel"
 ],
 "Health": [
  null,
  "Santé"
 ],
 "Help": [
  null,
  "Aide"
 ],
 "Hide confirmation password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe."
 ],
 "Hierarchy ID": [
  null,
  "ID de la hiérarchie"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Une meilleure interopérabilité au prix d’une surface d’attaque accrue."
 ],
 "Host key is incorrect": [
  null,
  "La clé de l’hôte est incorrecte"
 ],
 "Hostname": [
  null,
  "Nom d’hôte"
 ],
 "Hourly": [
  null,
  "Toutes les heures"
 ],
 "Hours": [
  null,
  "Heures"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identifiant"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et ajouter l'hôte ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "Increase by one": [
  null,
  "Augmentation d’un"
 ],
 "Indirect": [
  null,
  "Indirect"
 ],
 "Info and above": [
  null,
  "Info et au-dessus"
 ],
 "Insights: ": [
  null,
  "Aperçus : "
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install realmd support": [
  null,
  "Installer le support realmd"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Internal error": [
  null,
  "Erreur interne"
 ],
 "Invalid": [
  null,
  "Invalide"
 ],
 "Invalid date format": [
  null,
  "Format de date non valide"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de date non valide et format d’heure non valide"
 ],
 "Invalid file permissions": [
  null,
  "Les autorisations de fichier ne sont pas valides"
 ],
 "Invalid time format": [
  null,
  "Format d’heure non valide"
 ],
 "Invalid timezone": [
  null,
  "Fuseau horaire incorrect"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Join": [
  null,
  "Joindre"
 ],
 "Join domain": [
  null,
  "Joindre un domaine"
 ],
 "Joining": [
  null,
  "Rejoindre"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Rejoindre un domaine nécessite l’installation de realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Rejoindre ce domaine n’est pas pris en charge"
 ],
 "Joins namespace of": [
  null,
  "Rejoint l’espace de noms de"
 ],
 "Journal": [
  null,
  "Journal"
 ],
 "Journal entry": [
  null,
  "Entrée de journal"
 ],
 "Journal entry not found": [
  null,
  "Entrée de journal non trouvée"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Key password": [
  null,
  "Mot de passe clé"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY avec interopérabilité Active Directory."
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Last 24 hours": [
  null,
  "Dernières 24 heures"
 ],
 "Last 7 days": [
  null,
  "Les 7 derniers jours"
 ],
 "Last successful login:": [
  null,
  "Dernière connexion réussie :"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Leave $0": [
  null,
  "Laissez $0"
 ],
 "Leave domain": [
  null,
  "Quitter le domaine"
 ],
 "Light": [
  null,
  "Clair"
 ],
 "Limits": [
  null,
  "Limites"
 ],
 "Linked": [
  null,
  "Lié"
 ],
 "Listen": [
  null,
  "Écouter"
 ],
 "Listing units": [
  null,
  "Lister les unités"
 ],
 "Listing units failed: $0": [
  null,
  "L’énumération des unités a échoué : $0"
 ],
 "Load earlier entries": [
  null,
  "Charger les entrées précédentes"
 ],
 "Loading keys...": [
  null,
  "Chargement des clés..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Le chargement des clés SSH a échoué"
 ],
 "Loading of units failed": [
  null,
  "Le chargement des unités a échoué"
 ],
 "Loading system modifications...": [
  null,
  "Chargement des modifications système..."
 ],
 "Loading unit failed": [
  null,
  "Échec du chargement de l'unité"
 ],
 "Loading...": [
  null,
  "Chargement..."
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Log in to $0": [
  null,
  "Connectez-vous à $0"
 ],
 "Log messages": [
  null,
  "Enregistrer les messages"
 ],
 "Login failed": [
  null,
  "Échec de la connexion"
 ],
 "Login format": [
  null,
  "Format de connexion"
 ],
 "Logs": [
  null,
  "Journaux"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Machine ID": [
  null,
  "ID machine"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Empreintes des clés SSH de la machine"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Maintenance": [
  null,
  "Maintenance"
 ],
 "Manage storage": [
  null,
  "Gérer le stockage"
 ],
 "Manually": [
  null,
  "Manuellement"
 ],
 "Mask service": [
  null,
  "Service Masque"
 ],
 "Masked": [
  null,
  "Masqué"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Le service Masque empêche toutes les unités dépendantes d’être exécutées. Cela peut avoir un plus gros impact que prévu. Veuillez confirmer que vous souhaitez masquer cette unité."
 ],
 "Memory": [
  null,
  "Mémoire"
 ],
 "Memory technology": [
  null,
  "Technologie de mémoire"
 ],
 "Merged": [
  null,
  "Fusionné"
 ],
 "Message to logged in users": [
  null,
  "Message aux utilisateurs connectés"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minute doit correspondre à un nombre entre 0-59"
 ],
 "Minutely": [
  null,
  "Minutieusement"
 ],
 "Minutes": [
  null,
  "Minutes"
 ],
 "Mitigations": [
  null,
  "Mitigations"
 ],
 "Model": [
  null,
  "Modèle"
 ],
 "Mondays": [
  null,
  "lundis"
 ],
 "Monthly": [
  null,
  "Mensuel"
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "NTP server": [
  null,
  "Serveur NTP"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Need at least one NTP server": [
  null,
  "Besoin d’au moins un serveur NTP"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "No": [
  null,
  "Non"
 ],
 "No delay": [
  null,
  "Aucun délai"
 ],
 "No host keys found.": [
  null,
  "Aucune clé d’hôte trouvée."
 ],
 "No log entries": [
  null,
  "Aucune entrée de journal"
 ],
 "No logs found": [
  null,
  "Aucun journal trouvé"
 ],
 "No matching results": [
  null,
  "Aucun résultat correspondant n’a été trouvé"
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Aucun résultat correspondant aux critères de filtrage n’a été trouvé. Effacez tous les filtres pour afficher les résultats."
 ],
 "No rule hits": [
  null,
  "Aucune règle atteinte"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "No system modifications": [
  null,
  "Aucune modification système"
 ],
 "None": [
  null,
  "Aucun"
 ],
 "Not a valid private key": [
  null,
  "Clé privée non valide"
 ],
 "Not connected to Insights": [
  null,
  "Non connecté à Insights"
 ],
 "Not found": [
  null,
  "Non trouvé"
 ],
 "Not permitted to configure realms": [
  null,
  "Non autorisé à configurer les domaines"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non autorisé à effectuer cette action."
 ],
 "Not running": [
  null,
  "Pas en cours d’exécution"
 ],
 "Not synchronized": [
  null,
  "Non synchronisé"
 ],
 "Note": [
  null,
  "Note"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Notice and above": [
  null,
  "Notification et au-dessus"
 ],
 "Occurrences": [
  null,
  "Occurrences"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "On failure": [
  null,
  "En cas d’échec"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Seuls les caractères alphabétiques, les nombres,:, _,. , @ , - sont autorisés"
 ],
 "Only emergency": [
  null,
  "Urgences uniquement"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "N’utiliser que des algorithmes approuvés et autorisés lors du démarrage en mode FIPS."
 ],
 "Other": [
  null,
  "Autre"
 ],
 "Overview": [
  null,
  "Aperçu"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "Part of": [
  null,
  "Partie de"
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Password not accepted": [
  null,
  "Mot de passe non accepté"
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Paste error": [
  null,
  "Erreur de collage"
 ],
 "Path": [
  null,
  "Chemin"
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "Paths": [
  null,
  "Chemins"
 ],
 "Pause": [
  null,
  "Suspendre"
 ],
 "Performance profile": [
  null,
  "Profil de performance"
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Pin unit": [
  null,
  "Unité Pin"
 ],
 "Pinned unit": [
  null,
  "Unité épinglée"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "Pretty host name": [
  null,
  "Nom d’hôte pretty"
 ],
 "Previous boot": [
  null,
  "Démarrage précédent"
 ],
 "Priority": [
  null,
  "Priorité"
 ],
 "Problem details": [
  null,
  "Détails du problème"
 ],
 "Problem info": [
  null,
  "Informations sur le problème"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "L’invite via ssh-add a expiré"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "L’invite via ssh-keygen a expiré"
 ],
 "Propagates reload to": [
  null,
  "Recharger Propagation jusqu’à"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Protège contre les attaques anticipées à court terme au détriment de l’interopérabilité."
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Rank": [
  null,
  "Rang"
 ],
 "Read more...": [
  null,
  "En savoir plus..."
 ],
 "Read-only": [
  null,
  "Lecture seule"
 ],
 "Real host name": [
  null,
  "Nom d’hôte réel"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Le nom d’hôte réel ne peut contenir que des caractères minuscules, des chiffres, des tirets et des points (avec des sous-domaines remplis)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Le nom d’hôte réel doit comporter 64 caractères ou moins"
 ],
 "Reapply and reboot": [
  null,
  "Appliquer à nouveau et redémarrer"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Recommandé, paramètres de sécurité pour les modèles actuels de menace."
 ],
 "Reload": [
  null,
  "Recharger"
 ],
 "Reload propagated from": [
  null,
  "Recharger Propagation à partir de"
 ],
 "Reloading": [
  null,
  "Rechargement"
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Repeat": [
  null,
  "Répéter"
 ],
 "Repeat monthly": [
  null,
  "Répéter chaque mois"
 ],
 "Repeat weekly": [
  null,
  "Répéter chaque semaine"
 ],
 "Report": [
  null,
  "Signaler"
 ],
 "Report to ABRT Analytics": [
  null,
  "Rapport à ABRT Analytics"
 ],
 "Reported; no links available": [
  null,
  "Signalé ; aucun lien disponible"
 ],
 "Reporting failed": [
  null,
  "Échec de la déclaration"
 ],
 "Reporting was canceled": [
  null,
  "La déclaration a été annulée"
 ],
 "Reports:": [
  null,
  "Rapports :"
 ],
 "Required by": [
  null,
  "Requis par"
 ],
 "Required by ": [
  null,
  "Requis par "
 ],
 "Requires": [
  null,
  "Nécessite"
 ],
 "Requires administration access to edit": [
  null,
  "Nécessite un accès administrateur pour pouvoir modifier"
 ],
 "Requisite": [
  null,
  "Conditions requises"
 ],
 "Requisite of": [
  null,
  "Requis par"
 ],
 "Reset": [
  null,
  "Réinitialiser"
 ],
 "Restart": [
  null,
  "Redémarrer"
 ],
 "Resume": [
  null,
  "Reprendre"
 ],
 "Review cryptographic policy": [
  null,
  "Examiner la politique de cryptographie"
 ],
 "Row expansion": [
  null,
  "Agrandissement de ligne"
 ],
 "Row select": [
  null,
  "Sélection de ligne"
 ],
 "Run at": [
  null,
  "Exécuter à"
 ],
 "Run on": [
  null,
  "Exécuter sur"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Exécutez cette commande sur un réseau de confiance ou en la tapant physiquement sur la machine distante :"
 ],
 "Running": [
  null,
  "En cours"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clé SSH"
 ],
 "SSH key login": [
  null,
  "Connexion par clé SSH"
 ],
 "Saturdays": [
  null,
  "Samedis"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Save and reboot": [
  null,
  "Enregistrer et redémarrer"
 ],
 "Save changes": [
  null,
  "Enregistrer les modifications"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Mise hors tension programmée à $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Redémarrage programmé à $0"
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Search": [
  null,
  "Recherche"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Seconde doit correspondre à un nombre entre 0-59"
 ],
 "Seconds": [
  null,
  "Secondes"
 ],
 "Secure shell keys": [
  null,
  "Clés Secure Shell"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuration et dépannage de Linux avec renforcement de la sécurité"
 ],
 "Send": [
  null,
  "Envoyer"
 ],
 "Server has closed the connection.": [
  null,
  "Le serveur a fermé la connexion."
 ],
 "Server software": [
  null,
  "Logiciels du serveur"
 ],
 "Service logs": [
  null,
  "Journaux de service"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Set hostname": [
  null,
  "Définir le nom d’hôte"
 ],
 "Set time": [
  null,
  "Régler l’heure"
 ],
 "Shell script": [
  null,
  "Script shell"
 ],
 "Shift+Insert": [
  null,
  "Maj+Inser"
 ],
 "Show all threads": [
  null,
  "Afficher tous les fils de discussion"
 ],
 "Show confirmation password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Show fingerprints": [
  null,
  "Afficher les empreintes"
 ],
 "Show messages containing given string.": [
  null,
  "Afficher les messages contenant une chaîne donnée."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Afficher les messages de l’unité systemd spécifiée."
 ],
 "Show messages from a specific boot.": [
  null,
  "Afficher les messages d’un démarrage spécifique."
 ],
 "Show more relationships": [
  null,
  "Afficher plus de relations"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Show relationships": [
  null,
  "Afficher les relations"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Shutdown": [
  null,
  "Éteindre"
 ],
 "Since": [
  null,
  "Depuis"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "Slot": [
  null,
  "Emplacement"
 ],
 "Sockets": [
  null,
  "Prises"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Les contournements logiciels aident à éviter les problèmes de sécurité du processeur. Ces mitigations on pour effet de bord de réduire les performances. Modifiez ces paramètres à vos risques et périls."
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Specific time": [
  null,
  "Temps spécifique"
 ],
 "Speed": [
  null,
  "Vitesse"
 ],
 "Start": [
  null,
  "Démarrer"
 ],
 "Start and enable": [
  null,
  "Démarrer et activer"
 ],
 "Start service": [
  null,
  "Démarrer le service"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Commencez à afficher les entrées à la date spécifiée ou plus récente que celle-ci."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Commencez à afficher les entrées au plus tard à la date spécifiée."
 ],
 "State": [
  null,
  "État"
 ],
 "Static": [
  null,
  "Statique"
 ],
 "Status": [
  null,
  "État"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Arrêter"
 ],
 "Stop and disable": [
  null,
  "Arrêter et désactiver"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Strong password": [
  null,
  "Mot de passe fort"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "L’abonnement aux signaux de systemd a échoué : $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Copié avec succès dans le presse-papiers"
 ],
 "Sundays": [
  null,
  "Dimanches"
 ],
 "Synchronized": [
  null,
  "Synchronisé"
 ],
 "Synchronized with $0": [
  null,
  "Synchronisé avec $0"
 ],
 "Synchronizing": [
  null,
  "Synchronisation"
 ],
 "System": [
  null,
  "Système"
 ],
 "System information": [
  null,
  "Informations sur le système"
 ],
 "System time": [
  null,
  "Heure système"
 ],
 "Systemd units": [
  null,
  "Unités Systemd"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "Targets": [
  null,
  "Cibles"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clé SSH $0 de $1 sur $2 sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clé SSH $0 sera disponible pour le reste de la session et sera également disponible pour la connexion à d’autres hôtes."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée par un mot de passe, et l’hôte ne permet pas de se connecter avec un mot de passe. Veuillez fournir le mot de passe de la clé à $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée. Vous pouvez vous connecter avec votre mot de passe de connexion ou en fournissant le mot de passe de la clé à $1."
 ],
 "The fingerprint should match:": [
  null,
  "Les empreintes doivent correspondre :"
 ],
 "The key password can not be empty": [
  null,
  "Le mot de passe de la clé ne peut pas être vide"
 ],
 "The key passwords do not match": [
  null,
  "Les mots de passe sont différents"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les modifications système"
 ],
 "The password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'empreinte qui en découle peut être partagée publiquement par e-mail ou autre sans risque. Si vous demandez à quelqu'un d'autre de faire la vérification pour vous, cette personne peut vous envoyer les résultats par n'importe quel biais."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Le serveur a refusé d’authentifier en utilisant des méthodes prises en charge."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "L’utilisateur $0 n’est pas autorisé à changer les mitigations de sécurité pour le CPU"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "L’utilisateur $0 n’est pas autorisé à modifier les stratégies de chiffrement"
 ],
 "This field cannot be empty": [
  null,
  "Ce champ ne peut pas être vide"
 ],
 "This may take a while": [
  null,
  "Cela peut prendre un peu de temps"
 ],
 "This system is using a custom profile": [
  null,
  "Ce système utilise un profil personnalisé"
 ],
 "This system is using the recommended profile": [
  null,
  "Ce système utilise le profil recommandé"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Cet outil configure la politique SELinux et peut aider à comprendre et à résoudre les violations de la politique."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Cet outil configure le système pour qu'il écrive les vidages de mémoire sur incidents du noyau. Il prend en charge les cibles \"local\" (disque), \"ssh\" et \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Cet outil génère une archive des informations de configuration et de diagnostic du système en cours d'exécution. Ces archives peuvent être stockées localement ou centralement à des fins d'enregistrement ou de suivi, ou être envoyées aux représentants du support technique, aux développeurs ou aux administrateurs système pour les aider dans la recherche d'erreurs techniques et le débogage."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Cet outil gère le stockage local, tel que les systèmes de fichiers, les groupes de volumes LVM2 et les montages NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Cet outil gère les réseaux tels que les liens, les ponts, les équipes, les VLAN et les pare-feu en utilisant NetworkManager et Firewalld. NetworkManager est incompatible avec les scripts par défaut systemd-networkd d'Ubuntu et ifupdown de Debian."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Cette unité n’est pas conçue pour être activée explicitement."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Cela ajoutera une correspondance pour « _BOOT_ID= ». S’ils ne sont pas spécifiés, les journaux du démarrage en cours seront affichés. Si l’ID de démarrage est omis, un décalage positif recherchera les amorçages à partir du début du journal, et un décalage égal ou inférieur à zéro recherchera les démarrages à partir de la fin du journal. Ainsi, « 1 » indique le premier amorçage trouvé dans le journal dans l’ordre chronologique, « 2 » le second et ainsi de suite ; tandis que « -0 » est le dernier démarrage, « -1 » le démarrage l’avant-dernier, et ainsi de suite."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Cela ajoutera une correspondance pour « _SYSTEMD_UNIT= », « COREDUMP_UNIT= » et « UNIT= » pour trouver tous les messages possibles pour l’unité donnée. Peut contenir plus d’unités séparées par une virgule. "
 ],
 "Thursdays": [
  null,
  "Jeudis"
 ],
 "Time": [
  null,
  "Temps"
 ],
 "Time zone": [
  null,
  "Fuseau horaire"
 ],
 "Timer creation failed": [
  null,
  "Échec création minuteur"
 ],
 "Timer deletion failed": [
  null,
  "La suppression de la minuterie a échoué"
 ],
 "Timers": [
  null,
  "Minuteurs"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Toggle filters": [
  null,
  "Basculer les filtres"
 ],
 "Too much data": [
  null,
  "Trop de données"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transient": [
  null,
  "Transitoire"
 ],
 "Trigger": [
  null,
  "Déclencheur"
 ],
 "Triggered by": [
  null,
  "Déclenché par"
 ],
 "Triggers": [
  null,
  "Déclencheurs"
 ],
 "Trust and add host": [
  null,
  "Faire confiance à l'hôte et l'ajouter"
 ],
 "Trying to synchronize with $0": [
  null,
  "Synchronisation avec $0 en cours d'essai"
 ],
 "Tuesdays": [
  null,
  "Mardis"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned n’a pas pu démarrer"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned est un service qui surveille votre système et optimise les performances sous certaines charges de travail. Le cœur de Tuned est constitué de profils, qui permettent de régler votre système pour différents cas d’utilisation."
 ],
 "Tuned is not available": [
  null,
  "Tuned n’est pas disponible"
 ],
 "Tuned is not running": [
  null,
  "Tuned n'est pas en cours d'exécution"
 ],
 "Tuned is off": [
  null,
  "Tuned est désactivé"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Type to filter": [
  null,
  "Tapez pour filtrer"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossible de se connecter à $0 en utilisant l'authentification par clé SSH. Veuillez fournir le mot de passe."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossible de se connecter à $0. L’hôte n’accepte pas le mot de passe de connexion ou l’une de vos clés SSH."
 ],
 "Unit": [
  null,
  "Unité"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Unknown host: $0": [
  null,
  "Hôte inconnu : $0"
 ],
 "Unpin unit": [
  null,
  "Débrocher l'unité"
 ],
 "Until": [
  null,
  "Jusqu’à"
 ],
 "Untrusted host": [
  null,
  "Hôte non sécurisé"
 ],
 "Up since": [
  null,
  "Allumé depuis"
 ],
 "Updating status...": [
  null,
  "Mise à jour du l'état..."
 ],
 "Usage": [
  null,
  "Utilisation"
 ],
 "User": [
  null,
  "Utilisateur"
 ],
 "Validating address": [
  null,
  "Validation de l’adresse"
 ],
 "Vendor": [
  null,
  "Fournisseur"
 ],
 "Verify fingerprint": [
  null,
  "Vérifier l'empreinte digitale"
 ],
 "Version": [
  null,
  "Version"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "View all services": [
  null,
  "Voir tous les services"
 ],
 "View automation script": [
  null,
  "Afficher le script d’automation"
 ],
 "View hardware details": [
  null,
  "Voir les détails du matériel"
 ],
 "View login history": [
  null,
  "Afficher l’historique des connexions"
 ],
 "View metrics and history": [
  null,
  "Voir les métriques et l’historique"
 ],
 "View report": [
  null,
  "Voir le rapport"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "La visualisation des informations sur la mémoire nécessite un accès administratif."
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Waiting for input…": [
  null,
  "En attente d’informations…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Waiting to start…": [
  null,
  "En attendant de commencer…"
 ],
 "Wanted by": [
  null,
  "Recherché par"
 ],
 "Wants": [
  null,
  "Recherches"
 ],
 "Warning and above": [
  null,
  "Avertissement et au-dessus"
 ],
 "Weak password": [
  null,
  "Mot de passe faible"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "Web console is running in limited access mode.": [
  null,
  "La console Web est exécutée en mode accès limité."
 ],
 "Wednesdays": [
  null,
  "Mercredis"
 ],
 "Weekly": [
  null,
  "Hebdomadaire"
 ],
 "Weeks": [
  null,
  "Semaines"
 ],
 "White": [
  null,
  "Blanc"
 ],
 "Yearly": [
  null,
  "Annuel"
 ],
 "Yes": [
  null,
  "Oui"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ],
 "You may try to load older entries.": [
  null,
  "Vous pouvez essayer de charger des entrées plus anciennes."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Votre navigateur n’autorise pas le collage à partir du menu contextuel. Vous pouvez utiliser Maj+Insérer."
 ],
 "Your session has been terminated.": [
  null,
  "Votre session a été interrompue."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Votre session a expiré. Veuillez vous reconnecter."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "active": [
  null,
  "actif"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "échec de listage des clés de l’hôte SSH : $0"
 ],
 "in less than a minute": [
  null,
  "dans moins d'une minute"
 ],
 "inconsistent": [
  null,
  "Incohérent"
 ],
 "journalctl manpage": [
  null,
  "page man de journalctl"
 ],
 "less than a minute ago": [
  null,
  "il y a moins d'une minute"
 ],
 "none": [
  null,
  "aucun"
 ],
 "of $0 CPU": [
  null,
  "de $0 CPU",
  "de $0 CPUs"
 ],
 "password quality": [
  null,
  "qualité mot de passe"
 ],
 "recommended": [
  null,
  "conseillé"
 ],
 "running $0": [
  null,
  "$0 en cours d’exécution"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "unknown": [
  null,
  "inconnu"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domaine"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Rejoignez un domaine"
 ],
 "from <host>\u0004from $0": [
  null,
  "de $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "de $0 sur $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "sur $0"
 ]
});
