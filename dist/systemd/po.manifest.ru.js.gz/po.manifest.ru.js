cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Настройка параметров системы"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Logs": [
  null,
  "Журналы"
 ],
 "Managing services": [
  null,
  "Управление службами"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "Overview": [
  null,
  "Обзор"
 ],
 "Reviewing logs": [
  null,
  "Просмотр журналов"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Службы"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Terminal": [
  null,
  "Терминал"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "тег актива"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "загрузка"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "команда"
 ],
 "console": [
  null,
  "консоль"
 ],
 "coredump": [
  null,
  "дамп ядра"
 ],
 "cpu": [
  null,
  "процессор"
 ],
 "crash": [
  null,
  "сбой"
 ],
 "date": [
  null,
  "дата"
 ],
 "debug": [
  null,
  "отладка"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "отключить"
 ],
 "disks": [
  null,
  "диски"
 ],
 "domain": [
  null,
  "домен"
 ],
 "enable": [
  null,
  "включить"
 ],
 "error": [
  null,
  "ошибка"
 ],
 "graphs": [
  null,
  "графики"
 ],
 "hardware": [
  null,
  "оборудование"
 ],
 "history": [
  null,
  "история"
 ],
 "host": [
  null,
  "узел"
 ],
 "journal": [
  null,
  "журнал"
 ],
 "machine": [
  null,
  "компьютер"
 ],
 "mask": [
  null,
  "маска"
 ],
 "memory": [
  null,
  "память"
 ],
 "metrics": [
  null,
  "метрики"
 ],
 "mitigation": [
  null,
  "защита"
 ],
 "network": [
  null,
  "сеть"
 ],
 "operating system": [
  null,
  "операционная система"
 ],
 "os": [
  null,
  "ОС"
 ],
 "path": [
  null,
  "путь"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "производительность"
 ],
 "power": [
  null,
  "питание"
 ],
 "ram": [
  null,
  "ОЗУ"
 ],
 "restart": [
  null,
  "перезапустить"
 ],
 "serial": [
  null,
  "последовательный"
 ],
 "service": [
  null,
  "служба"
 ],
 "shell": [
  null,
  "оболочка"
 ],
 "shut": [
  null,
  "закрывать"
 ],
 "socket": [
  null,
  "socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "цель"
 ],
 "time": [
  null,
  "время"
 ],
 "timer": [
  null,
  "таймер"
 ],
 "unit": [
  null,
  "блок"
 ],
 "unmask": [
  null,
  "снять маску"
 ],
 "version": [
  null,
  "версия"
 ],
 "warning": [
  null,
  "предупреждение"
 ]
});
