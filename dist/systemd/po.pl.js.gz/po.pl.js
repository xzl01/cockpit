cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 trafienie krytyczne",
  "$0 trafienia, w tym krytyczne",
  "$0 trafień, w tym krytyczne"
 ],
 "$0 day": [
  null,
  "$0 dzień",
  "$0 dni",
  "$0 dni"
 ],
 "$0 exited with code $1": [
  null,
  "$0 zakończyło działanie z kodem $1"
 ],
 "$0 failed": [
  null,
  "$0 się nie powiodło"
 ],
 "$0 failed login attempt": [
  null,
  "$0 próba zalogowania zakończona niepowodzeniem",
  "$0 próby zalogowania zakończone niepowodzeniem",
  "$0 prób zalogowania zakończonych niepowodzeniem"
 ],
 "$0 hour": [
  null,
  "$0 godzina",
  "$0 godziny",
  "$0 godzin"
 ],
 "$0 important hit": [
  null,
  "$0 ważne trafienie",
  "$0 trafienia, w tym ważne",
  "$0 trafień, w tym ważne"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie jest dostępne w żadnym repozytorium."
 ],
 "$0 key changed": [
  null,
  "Zmieniono klucz $0"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 zostało zakończone z sygnałem $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 trafienie o niskiej ważności",
  "$0 trafienia o niskiej ważności",
  "$0 trafień o niskiej ważności"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 moderate hit": [
  null,
  "$0 trafienie o umiarkowanej ważności",
  "$0 trafienia, w tym o umiarkowanej ważności",
  "$0 trafień, w tym o umiarkowanej ważności"
 ],
 "$0 month": [
  null,
  "$0 miesiąc",
  "$0 miesiące",
  "$0 miesięcy"
 ],
 "$0 service has failed": [
  null,
  "$0 usługa się nie powiodła",
  "$0 usługi się nie powiodły",
  "$0 usług się nie powiodło"
 ],
 "$0 week": [
  null,
  "$0 tydzień",
  "$0 tygodnie",
  "$0 tygodni"
 ],
 "$0 will be installed.": [
  null,
  "$0 zostanie zainstalowane."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 lata",
  "$0 lat"
 ],
 "$0: crash at $1": [
  null,
  "$0: awaria o $1"
 ],
 "1 day": [
  null,
  "1 dzień"
 ],
 "1 hour": [
  null,
  "1 godzina"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 tydzień"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "5th": [
  null,
  "5."
 ],
 "6 hours": [
  null,
  "6 godzin"
 ],
 "60 minutes": [
  null,
  "Godzina"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie zainstalowano zgodnej wersji Cockpit."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Nowy klucz SSH w $0 zostanie utworzony dla użytkownika $1 na komputerze $2 i zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "Absent": [
  null,
  "Nieobecne"
 ],
 "Active since ": [
  null,
  "Aktywna od "
 ],
 "Active state": [
  null,
  "Aktywny stan"
 ],
 "Add": [
  null,
  "Dodaj"
 ],
 "Add $0": [
  null,
  "Dodaj $0"
 ],
 "Additional actions": [
  null,
  "Dodatkowe działania"
 ],
 "Additional packages:": [
  null,
  "Dodatkowe pakiety:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administracja za pomocą konsoli internetowej Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Zaawansowane TCA"
 ],
 "After": [
  null,
  "Po"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Po opuszczeniu domeny, tylko użytkownicy z lokalnymi danymi uwierzytelniania będą mogli zalogować się do tego komputera. Może to mieć wpływ także na inne usługi, ponieważ ustawienia rozwiązywania DNS i listy zaufanych CA mogą ulec zmianie."
 ],
 "After system boot": [
  null,
  "Po uruchomieniu systemu"
 ],
 "Alert and above": [
  null,
  "Alarmy i powyżej"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "All": [
  null,
  "Wszystkie"
 ],
 "All-in-one": [
  null,
  "Wszystko w jednym"
 ],
 "Allow running (unmask)": [
  null,
  "Zezwolenie na uruchamianie (odmaskowanie)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentacja ról Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Można filtrować dowolny ciąg tekstowy w komunikatach dziennika. Ciąg może być także w formie wyrażenia regularnego. Obsługiwane jest także filtrowanie według pól komunikatu dziennika. Są to wartości rozdzielone spacjami w formie POLE=WARTOŚĆ, gdzie wartość może być listą możliwych wartości rozdzielonych przecinkami."
 ],
 "Appearance": [
  null,
  "Wygląd"
 ],
 "Apply and reboot": [
  null,
  "Zastosuj i uruchom ponownie"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Zastosowywanie nowych zasad… Może to zająć kilka minut."
 ],
 "Asset tag": [
  null,
  "Etykieta zasobu"
 ],
 "At minute": [
  null,
  "O minucie"
 ],
 "At second": [
  null,
  "O sekundzie"
 ],
 "At specific time": [
  null,
  "O podanym czasie"
 ],
 "Authentication": [
  null,
  "Uwierzytelnienie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Wymagane jest uwierzytelnienie, aby wykonać zadania wymagające uprawnień za pomocą konsoli internetowej Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Upoważnij klucz SSH"
 ],
 "Automatically starts": [
  null,
  "Automatycznie się uruchamia"
 ],
 "Automatically using NTP": [
  null,
  "Automatycznie za pomocą NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatycznie za pomocą dodatkowych serwerów NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatycznie za pomocą podanych serwerów NTP"
 ],
 "Automation script": [
  null,
  "Skrypt automatyzacji"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Data BIOS-u"
 ],
 "BIOS version": [
  null,
  "Wersja BIOS-u"
 ],
 "Bad": [
  null,
  "Błędne"
 ],
 "Bad setting": [
  null,
  "Błędne ustawienie"
 ],
 "Before": [
  null,
  "Przed"
 ],
 "Binds to": [
  null,
  "Dowiązuje do"
 ],
 "Black": [
  null,
  "Czarny"
 ],
 "Blade": [
  null,
  "Kasetowy"
 ],
 "Blade enclosure": [
  null,
  "Obudowa kasetowa"
 ],
 "Boot": [
  null,
  "Uruchomienie"
 ],
 "Bound by": [
  null,
  "Dowiązane przez"
 ],
 "Bus expansion chassis": [
  null,
  "Obudowa rozszerzenia magistrali"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "CPU security": [
  null,
  "Zabezpieczenia procesora"
 ],
 "CPU security toggles": [
  null,
  "Przełączniki zabezpieczeń procesora"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Nie można odnaleźć żadnych dzienników za pomocą obecnego połączenia filtrów."
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Cancel poweroff": [
  null,
  "Anuluj wyłączenie komputera"
 ],
 "Cancel reboot": [
  null,
  "Anuluj ponowne uruchomienie"
 ],
 "Cannot be enabled": [
  null,
  "Nie można włączyć"
 ],
 "Cannot forward login credentials": [
  null,
  "Nie można przekazać danych uwierzytelniania logowania"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Nie można dołączyć do domeny, ponieważ usługa realmd nie jest dostępna w tym systemie"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie można planować zdarzeń w przeszłości"
 ],
 "Change": [
  null,
  "Zmień"
 ],
 "Change cryptographic policy": [
  null,
  "Zmień zasady kryptograficzne"
 ],
 "Change host name": [
  null,
  "Zmień nazwę komputera"
 ],
 "Change performance profile": [
  null,
  "Zmień profil wydajności"
 ],
 "Change profile": [
  null,
  "Zmień profil"
 ],
 "Change system time": [
  null,
  "Zmień czas systemu"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmienione klucze są często wynikiem przeinstalowania systemu operacyjnego. Nieoczekiwana zmiana może jednak wskazywać na próbę przechwycenia połączenia przez stronę trzecią."
 ],
 "Checking installed software": [
  null,
  "Sprawdzanie zainstalowanego oprogramowania"
 ],
 "Class": [
  null,
  "Klasa"
 ],
 "Clear 'Failed to start'": [
  null,
  "Wyczyść „Uruchomienie się nie powiodło”"
 ],
 "Clear all filters": [
  null,
  "Wyczyść wszystkie filtry"
 ],
 "Client software": [
  null,
  "Oprogramowanie klienta"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfiguracja usług NetworkManager i firewalld w programie Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nie może skontaktować się z podanym komputerem."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit to menedżer serwerów ułatwiający administrowanie serwerów Linux przez przeglądarkę WWW. Można z łatwością przechodzić między terminalem a narzędziami WWW. Usługa uruchomiona za pomocą Cockpit może zostać zatrzymana za pomocą terminala. Jeśli błąd wystąpi w terminalu, to można go zobaczyć w interfejsie dziennika Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie jest zgodny z oprogramowaniem w systemie."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie jest zainstalowany"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie jest zainstalowany w systemie."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit jest idealny dla nowych administratorów, umożliwiając łatwe wykonywanie prostych zadań, takich jak administracja urządzeniami do przechowywania danych, badanie dzienników oraz uruchamianie i zatrzymywanie usług. Można monitorować i administrować wiele serwerów w tym samym czasie. Wystarczy dodać je pojedynczym kliknięciem."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zbieranie i pakowanie danych diagnostycznych i wsparcia"
 ],
 "Collect kernel crash dumps": [
  null,
  "Zbieranie zrzutów awarii jądra"
 ],
 "Command": [
  null,
  "Polecenie"
 ],
 "Command not found": [
  null,
  "Nie odnaleziono polecenia"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikacja z tuned się nie powiodła"
 ],
 "Compact PCI": [
  null,
  "Kompaktowe PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Warunek $0=$1 nie został spełniony"
 ],
 "Condition failed": [
  null,
  "Warunek się nie powiódł"
 ],
 "Configuration": [
  null,
  "Konfiguracja"
 ],
 "Confirm deletion of $0": [
  null,
  "Potwierdź usunięcie $0"
 ],
 "Confirm key password": [
  null,
  "Potwierdź hasło klucza"
 ],
 "Conflicted by": [
  null,
  "W konflikcie z"
 ],
 "Conflicts": [
  null,
  "Powoduje konflikt z"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Połączenie z usługą D-Bus się nie powiodło: $0"
 ],
 "Connection has timed out.": [
  null,
  "Połączenie przekroczyło czas oczekiwania."
 ],
 "Consists of": [
  null,
  "Składa się z"
 ],
 "Contacted domain": [
  null,
  "Skontaktowana domena"
 ],
 "Controller": [
  null,
  "Kontroler"
 ],
 "Convertible": [
  null,
  "2 w jednym"
 ],
 "Copied": [
  null,
  "Skopiowano"
 ],
 "Copy": [
  null,
  "Skopiuj"
 ],
 "Copy to clipboard": [
  null,
  "Skopiuj do schowka"
 ],
 "Crash reporting": [
  null,
  "Zgłaszanie awarii"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Utwórz nowy klucz SSH i go upoważnij"
 ],
 "Create new task file with this content.": [
  null,
  "Utwórz nowy plik zadania o tej treści."
 ],
 "Create timer": [
  null,
  "Utwórz licznik"
 ],
 "Critical and above": [
  null,
  "Krytyczne i powyżej"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Zasady kryptograficzne to składnik systemu konfigurujący główne podsystemy kryptograficzne, w tym protokoły TLS, IPSec, SSH, DNSSec i Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "Zasady kryptograficzne"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Zasady kryptograficzne są niespójne"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Obecne uruchomienie"
 ],
 "Custom cryptographic policy": [
  null,
  "Niestandardowe zasady kryptograficzne"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "„Domyślne” z dozwoloną weryfikacją podpisów SHA-1."
 ],
 "Daily": [
  null,
  "Codziennie"
 ],
 "Dark": [
  null,
  "Ciemny"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Określenia dat powinny być w formacie RRRR-MM-DD gg:mm:ss. Dodatkowo obsługiwane są ciągi „yesterday” (wczoraj), „today” (dzisiaj) i „tomorrow” (jutro). „now” odnosi się do obecnego czasu. Można także podać czas względny za pomocą przedrostka „-” lub „+”."
 ],
 "Debug and above": [
  null,
  "Debugowania i powyżej"
 ],
 "Decrease by one": [
  null,
  "Zmniejsz o jedną jednostkę"
 ],
 "Default": [
  null,
  "Domyślne"
 ],
 "Delay": [
  null,
  "Opóźnienie"
 ],
 "Delay must be a number": [
  null,
  "Opóźnienie musi być liczbą"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Deletion will remove the following files:": [
  null,
  "Usunięcie usunie te pliki:"
 ],
 "Description": [
  null,
  "Opis"
 ],
 "Desktop": [
  null,
  "Komputer stacjonarny"
 ],
 "Detachable": [
  null,
  "Odłączalny"
 ],
 "Details": [
  null,
  "Szczegóły"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Wyłącz wielowątkowość współbieżną"
 ],
 "Disable tuned": [
  null,
  "Wyłącz tuned"
 ],
 "Disabled": [
  null,
  "Wyłączone"
 ],
 "Disallow running (mask)": [
  null,
  "Bez zezwolenia na uruchamianie (zamaskowanie)"
 ],
 "Docking station": [
  null,
  "Stacja dokująca"
 ],
 "Does not automatically start": [
  null,
  "Nie uruchamia się automatycznie"
 ],
 "Domain": [
  null,
  "Domena"
 ],
 "Domain address": [
  null,
  "Adres domeny"
 ],
 "Domain administrator name": [
  null,
  "Nazwa administratora domeny"
 ],
 "Domain administrator password": [
  null,
  "Hasło administratora domeny"
 ],
 "Domain could not be contacted": [
  null,
  "Nie można skontaktować się z domeną"
 ],
 "Domain is not supported": [
  null,
  "Domena jest nieobsługiwana"
 ],
 "Don't repeat": [
  null,
  "Bez powtarzania"
 ],
 "Downloading $0": [
  null,
  "Pobieranie $0"
 ],
 "Dual rank": [
  null,
  "Podwójny stopień"
 ],
 "Edit /etc/motd": [
  null,
  "Modyfikuj /etc/motd"
 ],
 "Edit motd": [
  null,
  "Modyfikuj motd"
 ],
 "Embedded PC": [
  null,
  "Komputer osadzony"
 ],
 "Enabled": [
  null,
  "Włączone"
 ],
 "Entry at $0": [
  null,
  "Wpis o $0"
 ],
 "Error": [
  null,
  "Błąd"
 ],
 "Error and above": [
  null,
  "Błędy i powyżej"
 ],
 "Error message": [
  null,
  "Komunikat o błędzie"
 ],
 "Excellent password": [
  null,
  "Doskonałe hasło"
 ],
 "Expansion chassis": [
  null,
  "Obudowa rozszerzenia"
 ],
 "Extended information": [
  null,
  "Rozszerzone informacje"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS nie jest poprawnie włączone"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS z dalszymi ograniczeniami Common Criteria."
 ],
 "Failed to change password": [
  null,
  "Zmiana hasła się nie powiodła"
 ],
 "Failed to disable tuned": [
  null,
  "Wyłączenie tuned się nie powiodło"
 ],
 "Failed to disable tuned profile": [
  null,
  "Wyłączenie profilu tuned się nie powiodło"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Włączenie $0 w usłudze firewalld się nie powiodło"
 ],
 "Failed to enable tuned": [
  null,
  "Włączenie tuned się nie powiodło"
 ],
 "Failed to fetch logs": [
  null,
  "Pobranie dzienników się nie powiodło"
 ],
 "Failed to load unit": [
  null,
  "Wczytanie jednostki się nie powiodło"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Zapisanie zmian w /etc/motd się nie powiodło"
 ],
 "Failed to start": [
  null,
  "Uruchomienie się nie powiodło"
 ],
 "Failed to switch profile": [
  null,
  "Przełączenie profilu się nie powiodło"
 ],
 "File state": [
  null,
  "Stan pliku"
 ],
 "Filter by name or description": [
  null,
  "Filtrowanie według nazwy lub opisu"
 ],
 "Filters": [
  null,
  "Filtry"
 ],
 "Font size": [
  null,
  "Rozmiar czcionki"
 ],
 "Forbidden from running": [
  null,
  "Zabronione uruchamianie"
 ],
 "Frame number": [
  null,
  "Numer klatki"
 ],
 "Free-form search": [
  null,
  "Wyszukiwanie dowolnego tekstu"
 ],
 "Fridays": [
  null,
  "piątki"
 ],
 "General": [
  null,
  "Ogólne"
 ],
 "Generated": [
  null,
  "Utworzone"
 ],
 "Go to $0": [
  null,
  "Przejdź do $0"
 ],
 "Go to now": [
  null,
  "Przejdź teraz"
 ],
 "Handheld": [
  null,
  "Przenośny"
 ],
 "Hardware information": [
  null,
  "Informacje o sprzęcie"
 ],
 "Health": [
  null,
  "Stan"
 ],
 "Help": [
  null,
  "Pomoc"
 ],
 "Hierarchy ID": [
  null,
  "Identyfikator hierarchii"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Wyższa interoperacyjność kosztem zwiększonej płaszczyźnie ataku."
 ],
 "Host key is incorrect": [
  null,
  "Klucz komputera jest niepoprawny"
 ],
 "Hostname": [
  null,
  "Nazwa komputera"
 ],
 "Hourly": [
  null,
  "Co godzinę"
 ],
 "Hours": [
  null,
  "Godziny"
 ],
 "ID": [
  null,
  "Identyfikator"
 ],
 "Identifier": [
  null,
  "Identyfikator"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jeśli odcisk się zgadza, należy kliknąć „Zaufaj i dodaj komputer”. W przeciwnym przypadku nie należy się łączyć i należy skontaktować się z administratorem."
 ],
 "Increase by one": [
  null,
  "Zwiększ o jedną jednostkę"
 ],
 "Indirect": [
  null,
  "Niebezpośrednie"
 ],
 "Info and above": [
  null,
  "Informacje i powyżej"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "Zainstaluj"
 ],
 "Install realmd support": [
  null,
  "Zainstaluj obsługę realmd"
 ],
 "Install software": [
  null,
  "Zainstaluj oprogramowanie"
 ],
 "Installing $0": [
  null,
  "Instalowanie $0"
 ],
 "Internal error": [
  null,
  "Wewnętrzny błąd"
 ],
 "Invalid": [
  null,
  "Nieprawidłowe"
 ],
 "Invalid date format": [
  null,
  "Nieprawidłowy format daty"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Nieprawidłowy format daty i nieprawidłowy format czasu"
 ],
 "Invalid file permissions": [
  null,
  "Nieprawidłowe uprawnienia pliku"
 ],
 "Invalid time format": [
  null,
  "Nieprawidłowy format czasu"
 ],
 "Invalid timezone": [
  null,
  "Nieprawidłowa strefa czasowa"
 ],
 "IoT gateway": [
  null,
  "Brama IoT"
 ],
 "Join": [
  null,
  "Dołącz"
 ],
 "Join domain": [
  null,
  "Dołącz do domeny"
 ],
 "Joining": [
  null,
  "Dołączanie"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Dołączenie do domeny wymaga instalacji usługi realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Dołączenie do tej domeny jest nieobsługiwane"
 ],
 "Joins namespace of": [
  null,
  "Dołącza do przestrzeni nazw"
 ],
 "Journal": [
  null,
  "Dziennik"
 ],
 "Journal entry": [
  null,
  "Wpis dziennika"
 ],
 "Journal entry not found": [
  null,
  "Nie odnaleziono wpisu dziennika"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Key password": [
  null,
  "Hasło klucza"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "„Przestarzałe” z interoperacyjnością z Active Directory."
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last 24 hours": [
  null,
  "Ostatni dzień"
 ],
 "Last 7 days": [
  null,
  "Ostatni tydzień"
 ],
 "Last successful login:": [
  null,
  "Ostatnie udane logowanie:"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "Leave $0": [
  null,
  "Opuść $0"
 ],
 "Leave domain": [
  null,
  "Opuść domenę"
 ],
 "Light": [
  null,
  "Jasny"
 ],
 "Limits": [
  null,
  "Ograniczenia"
 ],
 "Linked": [
  null,
  "Powiązane"
 ],
 "Listen": [
  null,
  "Nasłuchiwanie"
 ],
 "Listing units": [
  null,
  "Wyświetlanie jednostek"
 ],
 "Listing units failed: $0": [
  null,
  "Wyświetlenie jednostek się nie powiodło: $0"
 ],
 "Load earlier entries": [
  null,
  "Wczytaj wcześniejsze wpisy"
 ],
 "Loading keys...": [
  null,
  "Wczytywanie kluczy…"
 ],
 "Loading of SSH keys failed": [
  null,
  "Wczytanie kluczy SSH się nie powiodło"
 ],
 "Loading of units failed": [
  null,
  "Wczytanie jednostek się nie powiodło"
 ],
 "Loading system modifications...": [
  null,
  "Wczytywanie modyfikacji systemu…"
 ],
 "Loading unit failed": [
  null,
  "Wczytanie jednostki się nie powiodło"
 ],
 "Loading...": [
  null,
  "Wczytywanie…"
 ],
 "Log in": [
  null,
  "Zaloguj"
 ],
 "Log in to $0": [
  null,
  "Zaloguj się na $0"
 ],
 "Log messages": [
  null,
  "Komunikaty dziennika"
 ],
 "Login failed": [
  null,
  "Logowanie się nie powiodło"
 ],
 "Login format": [
  null,
  "Format logowania"
 ],
 "Logs": [
  null,
  "Dzienniki"
 ],
 "Low profile desktop": [
  null,
  "Komputer stacjonarny o mniejszym rozmiarze"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "Identyfikator komputera"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Odciski kluczy SSH komputera"
 ],
 "Main server chassis": [
  null,
  "Główna obudowa serwera"
 ],
 "Maintenance": [
  null,
  "Konserwacja"
 ],
 "Manage storage": [
  null,
  "Zarządzanie urządzeniami do przechowywania danych"
 ],
 "Manually": [
  null,
  "Ręcznie"
 ],
 "Mask service": [
  null,
  "Zamaskuj usługę"
 ],
 "Masked": [
  null,
  "Zamaskowana"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Zamaskowanie usługi uniemożliwia uruchomienie wszystkich zależnych usług. Może to mieć większy efekt, niż się wydaje. Proszę potwierdzić, że ta jednostka ma zostać zamaskowana."
 ],
 "Memory": [
  null,
  "Pamięć"
 ],
 "Memory technology": [
  null,
  "Technologia pamięci"
 ],
 "Merged": [
  null,
  "Połączone"
 ],
 "Message to logged in users": [
  null,
  "Wiadomość do zalogowanych użytkowników"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minuta musi być liczbą między 0 a 59"
 ],
 "Minutely": [
  null,
  "Co minutę"
 ],
 "Minutes": [
  null,
  "Minuty"
 ],
 "Mitigations": [
  null,
  "Poprawki zmniejszające ryzyko"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Mondays": [
  null,
  "poniedziałki"
 ],
 "Monthly": [
  null,
  "Co miesiąc"
 ],
 "Multi-system chassis": [
  null,
  "Obudowa dla wielu komputerów"
 ],
 "NTP server": [
  null,
  "Serwer NTP"
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Need at least one NTP server": [
  null,
  "Wymagany jest co najmniej jeden serwer NTP"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "New password was not accepted": [
  null,
  "Nie przyjęto nowego hasła"
 ],
 "No": [
  null,
  "Nie"
 ],
 "No delay": [
  null,
  "Brak opóźnienia"
 ],
 "No host keys found.": [
  null,
  "Nie odnaleziono kluczy komputera."
 ],
 "No log entries": [
  null,
  "Brak wpisów dziennika"
 ],
 "No logs found": [
  null,
  "Nie odnaleziono dzienników"
 ],
 "No matching results": [
  null,
  "Brak wyników"
 ],
 "No results found": [
  null,
  "Brak wyników"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Brak wyników pasujących do filtru. Należy wyczyścić wszystkie filtry, aby wyświetlić wyniki."
 ],
 "No rule hits": [
  null,
  "Brak trafień"
 ],
 "No such file or directory": [
  null,
  "Nie ma takiego pliku lub katalogu"
 ],
 "No system modifications": [
  null,
  "Brak modyfikacji systemu"
 ],
 "None": [
  null,
  "Brak"
 ],
 "Not a valid private key": [
  null,
  "Nieprawidłowy klucz prywatny"
 ],
 "Not connected to Insights": [
  null,
  "Nie połączono z Insights"
 ],
 "Not found": [
  null,
  "Nie odnaleziono"
 ],
 "Not permitted to configure realms": [
  null,
  "Brak zezwolenia na konfigurowanie obszarów"
 ],
 "Not permitted to perform this action.": [
  null,
  "Brak uprawnień do wykonania tego działania."
 ],
 "Not running": [
  null,
  "Niedziałające"
 ],
 "Not synchronized": [
  null,
  "Niesynchronizowane"
 ],
 "Note": [
  null,
  "Uwaga"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Uwagi i powyżej"
 ],
 "Occurrences": [
  null,
  "Wystąpienia"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Nie przyjęto poprzedniego hasła"
 ],
 "On failure": [
  null,
  "Podczas niepowodzenia"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Po zainstalowaniu programu Cockpit należy go włączyć za pomocą polecenia „systemctl enable --now cockpit.socket”."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Dozwolone są tylko litery, liczby i znaki „:”, „_”, „.”, „@”, „-”"
 ],
 "Only emergency": [
  null,
  "Tylko awaryjne"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Użycie tylko zatwierdzonych i dozwolonych algorytmów podczas uruchamiania w trybie FIPS."
 ],
 "Other": [
  null,
  "Inne"
 ],
 "Overview": [
  null,
  "Przegląd"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "Usługa PackageKit uległa awarii"
 ],
 "Part of": [
  null,
  "Część"
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Password is not acceptable": [
  null,
  "Hasło jest do przyjęcia"
 ],
 "Password is too weak": [
  null,
  "Hasło jest za słabe"
 ],
 "Password not accepted": [
  null,
  "Nie przyjęto hasła"
 ],
 "Paste": [
  null,
  "Wklej"
 ],
 "Paste error": [
  null,
  "Błąd wklejania"
 ],
 "Path": [
  null,
  "Ścieżka"
 ],
 "Path to file": [
  null,
  "Ścieżka do pliku"
 ],
 "Paths": [
  null,
  "Ścieżki"
 ],
 "Pause": [
  null,
  "Wstrzymaj"
 ],
 "Performance profile": [
  null,
  "Profil wydajności"
 ],
 "Peripheral chassis": [
  null,
  "Obudowa peryferyjna"
 ],
 "Pick date": [
  null,
  "Wybierz datę"
 ],
 "Pin unit": [
  null,
  "Przypnij jednostkę"
 ],
 "Pinned unit": [
  null,
  "Przypięta jednostka"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Portable": [
  null,
  "Przenośne"
 ],
 "Present": [
  null,
  "Obecne"
 ],
 "Pretty host name": [
  null,
  "Czytelna nazwa komputera"
 ],
 "Previous boot": [
  null,
  "Poprzednie uruchomienie"
 ],
 "Priority": [
  null,
  "Priorytet"
 ],
 "Problem details": [
  null,
  "Informacje o problemie"
 ],
 "Problem info": [
  null,
  "Informacje o problemie"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Pytanie przez ssh-add przekroczyło czas oczekiwania"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Pytanie przez ssh-keygen przekroczyło czas oczekiwania"
 ],
 "Propagates reload to": [
  null,
  "Wysyła ponowne wczytanie do"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Chroni przed atakami spodziewanymi w niedalekiej przyszłości kosztem interoperacyjności."
 ],
 "RAID chassis": [
  null,
  "Obudowa RAID"
 ],
 "Rack mount chassis": [
  null,
  "Obudowa do montowania w szafie"
 ],
 "Rank": [
  null,
  "Stopień"
 ],
 "Read more...": [
  null,
  "Więcej informacji…"
 ],
 "Read-only": [
  null,
  "Tylko do odczytu"
 ],
 "Real host name": [
  null,
  "Prawdziwa nazwa komputera"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Prawdziwa nazwa komputera może zawierać tylko małe litery, cyfry, myślniki i kropki (z zaludnionymi poddomenami)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Prawdziwa nazwa komputera może mieć co najwyżej 64 znaki"
 ],
 "Reapply and reboot": [
  null,
  "Zastosuj jeszcze raz i uruchom ponownie"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Zalecane, bezpieczne ustawienia wobec obecnych modeli zagrożeń."
 ],
 "Reload": [
  null,
  "Wczytaj ponownie"
 ],
 "Reload propagated from": [
  null,
  "Odebrano ponowne wczytanie z"
 ],
 "Reloading": [
  null,
  "Wczytywanie ponownie"
 ],
 "Removals:": [
  null,
  "Usuwane:"
 ],
 "Remove": [
  null,
  "Usuń"
 ],
 "Removing $0": [
  null,
  "Usuwanie $0"
 ],
 "Repeat": [
  null,
  "Powtarzanie"
 ],
 "Repeat monthly": [
  null,
  "Powtarzanie co miesiąc"
 ],
 "Repeat weekly": [
  null,
  "Powtarzanie co tydzień"
 ],
 "Report": [
  null,
  "Zgłoś"
 ],
 "Report to ABRT Analytics": [
  null,
  "Zgłoś do ABRT Analytics"
 ],
 "Reported; no links available": [
  null,
  "Zgłoszono, brak dostępnych odnośników"
 ],
 "Reporting failed": [
  null,
  "Zgłoszenie się nie powiodło"
 ],
 "Reporting was canceled": [
  null,
  "Zgłaszanie zostało anulowane"
 ],
 "Reports:": [
  null,
  "Zgłoszenia:"
 ],
 "Required by": [
  null,
  "Wymagane przez"
 ],
 "Required by ": [
  null,
  "Wymagane przez "
 ],
 "Requires": [
  null,
  "Wymaga"
 ],
 "Requires administration access to edit": [
  null,
  "Modyfikacja wymaga dostępu administratora"
 ],
 "Requisite": [
  null,
  "Potrzebne"
 ],
 "Requisite of": [
  null,
  "Potrzebne dla"
 ],
 "Reset": [
  null,
  "Przywróć"
 ],
 "Restart": [
  null,
  "Uruchom ponownie"
 ],
 "Resume": [
  null,
  "Wznów"
 ],
 "Review cryptographic policy": [
  null,
  "Przejrzyj zasady kryptograficzne"
 ],
 "Run at": [
  null,
  "Uruchom o"
 ],
 "Run on": [
  null,
  "Uruchom w dniu"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Należy wykonać to polecenie przez zaufaną sieć lub fizycznie na zdalnym komputerze:"
 ],
 "Running": [
  null,
  "Działające"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Klucz SSH"
 ],
 "Saturdays": [
  null,
  "soboty"
 ],
 "Save": [
  null,
  "Zapisz"
 ],
 "Save and reboot": [
  null,
  "Zapisz i uruchom ponownie"
 ],
 "Save changes": [
  null,
  "Zapisz zmiany"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Zaplanowane wyłączenie komputera: $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Zaplanowane ponowne uruchomienie: $0"
 ],
 "Sealed-case PC": [
  null,
  "Sealed-case PC"
 ],
 "Search": [
  null,
  "Szukaj"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Sekunda musi być liczbą między 0 a 59"
 ],
 "Seconds": [
  null,
  "Sekundy"
 ],
 "Secure shell keys": [
  null,
  "Klucze SSH"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfiguracja i rozwiązywanie błędów z SELinuksem"
 ],
 "Send": [
  null,
  "Wyślij"
 ],
 "Server has closed the connection.": [
  null,
  "Serwer zamknął połączenie."
 ],
 "Server software": [
  null,
  "Oprogramowanie serwera"
 ],
 "Service logs": [
  null,
  "Dzienniki serwera"
 ],
 "Services": [
  null,
  "Usługi"
 ],
 "Set hostname": [
  null,
  "Ustaw nazwę komputera"
 ],
 "Set time": [
  null,
  "Ustaw czas"
 ],
 "Shell script": [
  null,
  "Skrypt powłoki"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Wyświetl wszystkie wątki"
 ],
 "Show fingerprints": [
  null,
  "Wyświetl odciski"
 ],
 "Show messages containing given string.": [
  null,
  "Wyświetla komunikaty zawierające podany ciąg."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Wyświetla komunikaty dla podanej jednostki systemd."
 ],
 "Show messages from a specific boot.": [
  null,
  "Wyświetla komunikaty z podanego uruchomienia."
 ],
 "Show more relationships": [
  null,
  "Więcej związków"
 ],
 "Show relationships": [
  null,
  "Związki"
 ],
 "Shut down": [
  null,
  "Wyłącz"
 ],
 "Shutdown": [
  null,
  "Wyłącz"
 ],
 "Since": [
  null,
  "Od"
 ],
 "Single rank": [
  null,
  "Pojedynczy stopień"
 ],
 "Size": [
  null,
  "Rozmiar"
 ],
 "Slot": [
  null,
  "Gniazdo"
 ],
 "Sockets": [
  null,
  "Gniazda"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Programowe obejścia błędów pomagają uniknąć problemów bezpieczeństwa procesora. Ich efektem ubocznym jest zmniejszenie wydajności. Należy zmieniać te ustawienia na własne ryzyko."
 ],
 "Space-saving computer": [
  null,
  "Komputer oszczędzający miejsce"
 ],
 "Specific time": [
  null,
  "Podany czas"
 ],
 "Speed": [
  null,
  "Prędkość"
 ],
 "Start": [
  null,
  "Rozpocznij"
 ],
 "Start and enable": [
  null,
  "Uruchom i włącz"
 ],
 "Start service": [
  null,
  "Uruchom usługę"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Wyświetlanie wpisów z podanego dnia lub nowszych."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Wyświetlanie wpisów z podanego dnia lub starszych."
 ],
 "State": [
  null,
  "Stan"
 ],
 "Static": [
  null,
  "Statyczne"
 ],
 "Status": [
  null,
  "Stan"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Zatrzymaj"
 ],
 "Stop and disable": [
  null,
  "Zatrzymaj i wyłącz"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Stub": [
  null,
  "Pozostałość"
 ],
 "Sub-Chassis": [
  null,
  "Obudowa podrzędna"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Subskrypcja sygnałów systemd się nie powiodła: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Pomyślnie skopiowano do schowka"
 ],
 "Sundays": [
  null,
  "niedziele"
 ],
 "Synchronized": [
  null,
  "Synchronizowane"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizowane z $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizowanie"
 ],
 "System": [
  null,
  "System"
 ],
 "System information": [
  null,
  "Informacje o systemie"
 ],
 "System time": [
  null,
  "Czas systemowy"
 ],
 "Systemd units": [
  null,
  "Jednostki systemd"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Cele"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Klucz SSH $0 użytkownika $1 na komputerze $2 zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Klucz SSH $0 stanie się dostępny przez pozostały czas sesji i będzie dostępny do logowania także na innych komputerach."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony hasłem, ale komputer nie zezwala na logowanie za pomocą hasła. Proszę podać hasło klucza w $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony. Można zalogować się za pomocą hasła logowania lub podając hasło klucza w $1."
 ],
 "The fingerprint should match:": [
  null,
  "Odcisk powinien się zgadzać:"
 ],
 "The key password can not be empty": [
  null,
  "Hasło klucza nie może być puste"
 ],
 "The key passwords do not match": [
  null,
  "Hasła klucza się nie zgadzają"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Zalogowany użytkownik nie ma zezwolenia na wyświetlanie modyfikacji systemu"
 ],
 "The password can not be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail. Jeśli weryfikacja jest wykonywana za użytkownika przez kogoś innego, to ta osoba może wysłać wyniki na dowolny sposób."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serwer odmówił uwierzytelnienia za pomocą wszystkich obsługiwanych metod."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Użytkownik $0 nie ma zezwolenia na zmianę poprawek zabezpieczeń procesora zmniejszających ryzyko"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Użytkownik $0 nie ma zezwolenia na zmianę zasad kryptograficznych"
 ],
 "This field cannot be empty": [
  null,
  "To pole nie może być puste"
 ],
 "This may take a while": [
  null,
  "Może to chwilę zająć"
 ],
 "This system is using a custom profile": [
  null,
  "Ten system używa niestandardowego profilu"
 ],
 "This system is using the recommended profile": [
  null,
  "Ten system używa zalecanego profilu"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "To narzędzie konfiguruje zasady SELinuksa i może pomóc w zrozumieniu i rozwiązywaniu naruszeń zasad."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "To narzędzie tworzy archiwum konfiguracji i informacji diagnostycznych z działającego komputera. Archiwum może być przechowywane lokalnie lub centralnie do celów nagrywania i śledzenia, albo może być wysyłane do przedstawicieli pomocy technicznej, programistów lub administratorów komputera w celu wspomagania znajdowania źródła problemu i debugowania."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "To narzędzie zarządza lokalnymi urządzeniami do przechowywania danych, takimi jak systemy plików, grupy woluminów LVM2 czy punkty montowania NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "To narzędzie zarządza sieciami, takimi jak wiązania, mostki, zespoły, VLAN i zapory sieciowe za pomocą usług NetworkManager i firewalld. Usługa NetworkManager jest niezgodna z domyślnymi skryptami systemd-networkd systemu Ubuntu i ifupdown systemu Debian."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Ta jednostka nie została zaprojektowana do bezpośredniego włączania."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Spowoduje to dodanie dopasowania do „_BOOT_ID=”. Jeśli nie zostanie podane, to zostaną wyświetlone dzienniki dla obecnego uruchomienia. Jeśli identyfikator uruchomienia zostanie pominięty, to dodatnie wyrównanie wyszuka uruchomienia zaczynając od początku zapisów, a równe lub mniejsze niż zero wyrównanie wyszuka uruchomienia zaczynając od końca zapisów. 1 oznacza więc pierwsze uruchomienie odnalezione w zapisach w kolejności chronologicznej, 2 drugie i tak dalej, zaś -0 to ostatnie uruchomienie, -1 przedostatnie uruchomienie i tak dalej."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Spowoduje to dodanie dopasowania do „_SYSTEMD_UNIT=”, „COREDUMP_UNIT=” i „UNIT=”, aby znaleźć wszystkie możliwe komunikaty dla podanej jednostki. Może zawierać więcej jednostek rozdzielonych przecinkami. "
 ],
 "Thursdays": [
  null,
  "czwartki"
 ],
 "Time": [
  null,
  "Czas"
 ],
 "Time zone": [
  null,
  "Strefa czasowa"
 ],
 "Timer creation failed": [
  null,
  "Utworzenie licznika się nie powiodło"
 ],
 "Timer deletion failed": [
  null,
  "Usunięcie licznika się nie powiodło"
 ],
 "Timers": [
  null,
  "Liczniki"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby upewnić się, że połączenie nie jest przechwytywane przez szkodliwą stronę trzecią, proszę zweryfikować odcisk klucza komputera:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Aby zweryfikować odcisk klucza, należy wykonać poniższe polecenie na $0 fizycznie siedząc przy komputerze lub przez zaufaną sieć:"
 ],
 "Toggle date picker": [
  null,
  "Przełącz wybór daty"
 ],
 "Toggle filters": [
  null,
  "Przełącz filtry"
 ],
 "Too much data": [
  null,
  "Za dużo danych"
 ],
 "Total size: $0": [
  null,
  "Całkowity rozmiar: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transient": [
  null,
  "Przejściowe"
 ],
 "Trigger": [
  null,
  "Wyzwalacz"
 ],
 "Triggered by": [
  null,
  "Wyzwalane przez"
 ],
 "Triggers": [
  null,
  "Wyzwalacze"
 ],
 "Trust and add host": [
  null,
  "Zaufaj i dodaj komputer"
 ],
 "Trying to synchronize with $0": [
  null,
  "Próbowanie synchronizacji z $0"
 ],
 "Tuesdays": [
  null,
  "wtorki"
 ],
 "Tuned has failed to start": [
  null,
  "Uruchomienie tuned się nie powiodło"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned to usługa monitorująca komputer i optymalizująca wydajność w pewnych zadaniach. Rdzeniem Tuned są profile, które dostosowują komputer do różnych zastosowań."
 ],
 "Tuned is not available": [
  null,
  "tuned jest niedostępne"
 ],
 "Tuned is not running": [
  null,
  "tuned nie jest uruchomione"
 ],
 "Tuned is off": [
  null,
  "tuned jest wyłączone"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type to filter": [
  null,
  "Filtrowanie"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nie można zalogować się w $0. Komputer nie przyjmuje logowania hasłem ani żadnego z kluczy SSH użytkownika."
 ],
 "Unit": [
  null,
  "Jednostka"
 ],
 "Unknown": [
  null,
  "Nieznane"
 ],
 "Unpin unit": [
  null,
  "Odepnij jednostkę"
 ],
 "Until": [
  null,
  "Do"
 ],
 "Untrusted host": [
  null,
  "Niezaufany komputer"
 ],
 "Updating status...": [
  null,
  "Aktualizowanie stanu…"
 ],
 "Usage": [
  null,
  "Użycie"
 ],
 "User": [
  null,
  "Użytkownik"
 ],
 "Validating address": [
  null,
  "Sprawdzanie poprawności adresu"
 ],
 "Vendor": [
  null,
  "Producent"
 ],
 "Verify fingerprint": [
  null,
  "Zweryfikuj odcisk"
 ],
 "Version": [
  null,
  "Wersja"
 ],
 "View all logs": [
  null,
  "Wszystkie dzienniki"
 ],
 "View all services": [
  null,
  "Wszystkie usługi"
 ],
 "View automation script": [
  null,
  "Wyświetl skrypt automatyzacji"
 ],
 "View hardware details": [
  null,
  "Wyświetl informacje o sprzęcie"
 ],
 "View login history": [
  null,
  "Wyświetl historię logowania"
 ],
 "View metrics and history": [
  null,
  "Wyświetl statystyki i historię"
 ],
 "View report": [
  null,
  "Wyświetl zgłoszenie"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Wyświetlanie informacji o pamięci wymaga dostępu administracyjnego."
 ],
 "Visit firewall": [
  null,
  "Otwórz zaporę sieciową"
 ],
 "Waiting for input…": [
  null,
  "Oczekiwanie na dane…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Oczekiwanie na ukończenie pozostałych działań zarządzania oprogramowaniem"
 ],
 "Waiting to start…": [
  null,
  "Oczekiwanie na rozpoczęcie…"
 ],
 "Wanted by": [
  null,
  "Chciane przez"
 ],
 "Wants": [
  null,
  "Chce"
 ],
 "Warning and above": [
  null,
  "Ostrzeżenia i powyżej"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsola internetowa dla serwerów systemu Linux"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Konsola internetowa działa w trybie ograniczonego dostępu."
 ],
 "Wednesdays": [
  null,
  "środy"
 ],
 "Weekly": [
  null,
  "Co tydzień"
 ],
 "Weeks": [
  null,
  "Tygodnie"
 ],
 "White": [
  null,
  "Biały"
 ],
 "Yearly": [
  null,
  "Co roku"
 ],
 "Yes": [
  null,
  "Tak"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Łączenie z $0 po raz pierwszy."
 ],
 "You may try to load older entries.": [
  null,
  "Można spróbować wczytać starsze wpisy."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Używana przeglądarka nie zezwala na wklejanie z menu kontekstowego. Można użyć klawiszy Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Sesja została zakończona."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesja wygasła. Proszę zalogować się ponownie."
 ],
 "Zone": [
  null,
  "Strefa"
 ],
 "[binary data]": [
  null,
  "[dane binarne]"
 ],
 "[no data]": [
  null,
  "[brak danych]"
 ],
 "active": [
  null,
  "aktywne"
 ],
 "edit": [
  null,
  "modyfikuj"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "wyświetlenie listy kluczy SSH komputera się nie powiodło: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "inconsistent": [
  null,
  "niespójne"
 ],
 "journalctl manpage": [
  null,
  "strona podręcznika journalctl"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "brak"
 ],
 "of $0 CPU": [
  null,
  "$0 procesora",
  "$0 procesorów",
  "$0 procesorów"
 ],
 "password quality": [
  null,
  "jakość hasła"
 ],
 "recommended": [
  null,
  "zalecane"
 ],
 "running $0": [
  null,
  "pod kontrolą $0"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "unknown": [
  null,
  "nieznane"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domena"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Dołącz do domeny"
 ],
 "from <host>\u0004from $0": [
  null,
  "z $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "z $0 na $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "na $0"
 ]
});
