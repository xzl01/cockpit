cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Probíhá nastavení systému"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Logs": [
  null,
  "Záznamy událostí"
 ],
 "Managing services": [
  null,
  "Správa služeb"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "Overview": [
  null,
  "Přehled"
 ],
 "Reviewing logs": [
  null,
  "Vyhodnocování záznamu událostí"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "inventární štítek"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "boot"
 ],
 "cgroups": [
  null,
  "řídící skupiny"
 ],
 "command": [
  null,
  "příkaz"
 ],
 "console": [
  null,
  "konzole"
 ],
 "coredump": [
  null,
  "výpis paměti"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "crash": [
  null,
  "pád"
 ],
 "date": [
  null,
  "datum"
 ],
 "debug": [
  null,
  "ladění"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "vypnout"
 ],
 "disks": [
  null,
  "disky"
 ],
 "domain": [
  null,
  "doména"
 ],
 "enable": [
  null,
  "zapnout"
 ],
 "error": [
  null,
  "chyba"
 ],
 "graphs": [
  null,
  "grafy"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "historie"
 ],
 "host": [
  null,
  "stroj"
 ],
 "journal": [
  null,
  "žurnál"
 ],
 "machine": [
  null,
  "stroj"
 ],
 "mask": [
  null,
  "maska"
 ],
 "memory": [
  null,
  "paměť"
 ],
 "metrics": [
  null,
  "metriky"
 ],
 "mitigation": [
  null,
  "omezení vlivu"
 ],
 "network": [
  null,
  "síť"
 ],
 "operating system": [
  null,
  "operační systém"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "popis umístění"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "výkon"
 ],
 "power": [
  null,
  "napájení"
 ],
 "ram": [
  null,
  "operační paměť"
 ],
 "restart": [
  null,
  "restartovat"
 ],
 "serial": [
  null,
  "sériové"
 ],
 "service": [
  null,
  "služba"
 ],
 "shell": [
  null,
  "shell"
 ],
 "shut": [
  null,
  "vyp"
 ],
 "socket": [
  null,
  "patice"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cíl"
 ],
 "time": [
  null,
  "čas"
 ],
 "timer": [
  null,
  "časovač"
 ],
 "unit": [
  null,
  "jednotka"
 ],
 "unmask": [
  null,
  "zrušit maskování"
 ],
 "version": [
  null,
  "verze"
 ],
 "warning": [
  null,
  "varování"
 ]
});
