cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Configurazione delle impostazioni di sistema"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "Managing services": [
  null,
  "Gestione dei servizi"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "Overview": [
  null,
  "Panoramica"
 ],
 "Reviewing logs": [
  null,
  "Revisione dei log"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Servizi"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Terminal": [
  null,
  "Terminale"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "asset tag"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "avvio"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "comando"
 ],
 "console": [
  null,
  "console"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "crash"
 ],
 "date": [
  null,
  "data"
 ],
 "debug": [
  null,
  "debug"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "disabilita"
 ],
 "disks": [
  null,
  "dischi"
 ],
 "domain": [
  null,
  "dominio"
 ],
 "enable": [
  null,
  "abilita"
 ],
 "error": [
  null,
  "errore"
 ],
 "graphs": [
  null,
  "grafici"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "cronologia"
 ],
 "host": [
  null,
  "host"
 ],
 "journal": [
  null,
  "registro"
 ],
 "machine": [
  null,
  "macchina"
 ],
 "mask": [
  null,
  "maschera"
 ],
 "memory": [
  null,
  "memoria"
 ],
 "metrics": [
  null,
  "metriche"
 ],
 "mitigation": [
  null,
  "mitigazione"
 ],
 "network": [
  null,
  "rete"
 ],
 "operating system": [
  null,
  "sistema operativo"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "percorso"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "power": [
  null,
  "alimentazione"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "riavvia"
 ],
 "serial": [
  null,
  "seriale"
 ],
 "service": [
  null,
  "servizio"
 ],
 "shell": [
  null,
  "shell"
 ],
 "shut": [
  null,
  "shut"
 ],
 "socket": [
  null,
  "socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "destinazione"
 ],
 "time": [
  null,
  "ora"
 ],
 "timer": [
  null,
  "timer"
 ],
 "unit": [
  null,
  "unità"
 ],
 "version": [
  null,
  "versione"
 ],
 "warning": [
  null,
  "avviso"
 ]
});
