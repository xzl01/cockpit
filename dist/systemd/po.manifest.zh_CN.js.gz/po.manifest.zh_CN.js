cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "配置系统设置"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Logs": [
  null,
  "日志"
 ],
 "Managing services": [
  null,
  "管理服务"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "Overview": [
  null,
  "概览"
 ],
 "Reviewing logs": [
  null,
  "回顾日志"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "服务"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Terminal": [
  null,
  "终端"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "资产标签"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "引导"
 ],
 "cgroups": [
  null,
  "用户组"
 ],
 "command": [
  null,
  "命令"
 ],
 "console": [
  null,
  "控制台"
 ],
 "coredump": [
  null,
  "核心转储"
 ],
 "cpu": [
  null,
  "中央处理器"
 ],
 "crash": [
  null,
  "崩溃"
 ],
 "date": [
  null,
  "日期"
 ],
 "debug": [
  null,
  "故障调试"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "禁用"
 ],
 "disks": [
  null,
  "磁盘"
 ],
 "domain": [
  null,
  "域"
 ],
 "enable": [
  null,
  "启用"
 ],
 "error": [
  null,
  "错误"
 ],
 "graphs": [
  null,
  "图表"
 ],
 "hardware": [
  null,
  "硬件"
 ],
 "history": [
  null,
  "历史"
 ],
 "host": [
  null,
  "主机"
 ],
 "journal": [
  null,
  "日志"
 ],
 "machine": [
  null,
  "机器"
 ],
 "mask": [
  null,
  "屏蔽"
 ],
 "memory": [
  null,
  "内存"
 ],
 "metrics": [
  null,
  "指标"
 ],
 "mitigation": [
  null,
  "缓解方案"
 ],
 "network": [
  null,
  "网络"
 ],
 "operating system": [
  null,
  "操作系统"
 ],
 "os": [
  null,
  "操作系统"
 ],
 "path": [
  null,
  "路径"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "性能"
 ],
 "power": [
  null,
  "电源"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "重启"
 ],
 "serial": [
  null,
  "序列"
 ],
 "service": [
  null,
  "服务"
 ],
 "shell": [
  null,
  "shell"
 ],
 "shut": [
  null,
  "关闭"
 ],
 "socket": [
  null,
  "套接口"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "目标"
 ],
 "time": [
  null,
  "时间"
 ],
 "timer": [
  null,
  "计时器"
 ],
 "unit": [
  null,
  "单元"
 ],
 "unmask": [
  null,
  "取消屏蔽"
 ],
 "version": [
  null,
  "版本"
 ],
 "warning": [
  null,
  "警告"
 ]
});
