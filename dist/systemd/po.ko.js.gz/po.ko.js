cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "심각한 영향을 포함 $0 건 해당"
 ],
 "$0 day": [
  null,
  "$0 일"
 ],
 "$0 exited with code $1": [
  null,
  "$0가 코드 $1로 종료됨"
 ],
 "$0 failed": [
  null,
  "$0가 실패"
 ],
 "$0 failed login attempt": [
  null,
  "$0 로그인 시도 실패"
 ],
 "$0 hour": [
  null,
  "$0 시"
 ],
 "$0 important hit": [
  null,
  "중요한 영향을 포함 $0 건 해당"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0는 저장소에서 사용 할 수 없습니다."
 ],
 "$0 key changed": [
  null,
  "$0 키 변경됩니다"
 ],
 "$0 killed with signal $1": [
  null,
  "$1 시그널에 의해 $0가 종료되었습니다"
 ],
 "$0 low severity hit": [
  null,
  "$0 낮은 심각도"
 ],
 "$0 minute": [
  null,
  "$0 분"
 ],
 "$0 moderate hit": [
  null,
  "$0 보통 영향"
 ],
 "$0 month": [
  null,
  "$0 달"
 ],
 "$0 service has failed": [
  null,
  "$0 서비스 실패"
 ],
 "$0 week": [
  null,
  "$0 주"
 ],
 "$0 will be installed.": [
  null,
  "$0가 설치됩니다."
 ],
 "$0 year": [
  null,
  "$0 년"
 ],
 "$0: crash at $1": [
  null,
  "$0: $1에서 충돌"
 ],
 "1 day": [
  null,
  "1 일"
 ],
 "1 hour": [
  null,
  "1시간"
 ],
 "1 minute": [
  null,
  "1 분"
 ],
 "1 week": [
  null,
  "1 주"
 ],
 "10th": [
  null,
  "10일"
 ],
 "11th": [
  null,
  "11일"
 ],
 "12th": [
  null,
  "12일"
 ],
 "13th": [
  null,
  "13일"
 ],
 "14th": [
  null,
  "14일"
 ],
 "15th": [
  null,
  "15일"
 ],
 "16th": [
  null,
  "16일"
 ],
 "17th": [
  null,
  "17일"
 ],
 "18th": [
  null,
  "18일"
 ],
 "19th": [
  null,
  "19일"
 ],
 "1st": [
  null,
  "1일"
 ],
 "20 minutes": [
  null,
  "20분"
 ],
 "20th": [
  null,
  "20일"
 ],
 "21th": [
  null,
  "21일"
 ],
 "22th": [
  null,
  "22일"
 ],
 "23th": [
  null,
  "23일"
 ],
 "24th": [
  null,
  "24일"
 ],
 "25th": [
  null,
  "25일"
 ],
 "26th": [
  null,
  "26일"
 ],
 "27th": [
  null,
  "27일"
 ],
 "28th": [
  null,
  "28일"
 ],
 "29th": [
  null,
  "29일"
 ],
 "2nd": [
  null,
  "2일"
 ],
 "30th": [
  null,
  "30일"
 ],
 "31st": [
  null,
  "31일"
 ],
 "3rd": [
  null,
  "3일"
 ],
 "40 minutes": [
  null,
  "40 분"
 ],
 "4th": [
  null,
  "4일"
 ],
 "5 minutes": [
  null,
  "5분"
 ],
 "5th": [
  null,
  "5일"
 ],
 "6 hours": [
  null,
  "6 시간"
 ],
 "60 minutes": [
  null,
  "60 분"
 ],
 "6th": [
  null,
  "6일"
 ],
 "7th": [
  null,
  "7일"
 ],
 "8th": [
  null,
  "8일"
 ],
 "9th": [
  null,
  "9일"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "호환 가능한 Cockpit 버전이 {{#strong}}에 설치되어 있지 않습니다."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0에서 신규 SSH 키는 $1에서($2에 대해) 생성되고 $3에서 $4에서($5에 대해) 파일에 추가됩니다."
 ],
 "Absent": [
  null,
  "부재"
 ],
 "Acceptable password": [
  null,
  "허용되는 비밀번호"
 ],
 "Active since ": [
  null,
  "이후 활성화 "
 ],
 "Active state": [
  null,
  "활성화 상태"
 ],
 "Add": [
  null,
  "추가"
 ],
 "Add $0": [
  null,
  "$0 추가"
 ],
 "Additional actions": [
  null,
  "추가 동작"
 ],
 "Additional packages:": [
  null,
  "추가 꾸러미 :"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔로 관리"
 ],
 "Advanced TCA": [
  null,
  "고급 TCA"
 ],
 "After": [
  null,
  "이후"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "도메인 종료 후 로컬 인증 정보가 있는 사용자만 시스템에 로그인 할 수 있습니다. 이 경우 DNS 확인 설정 및 신뢰할 수 있는 CA 목록이 변경 될 수 있으므로 다른 서비스에도 영향을 미칠 수 있습니다."
 ],
 "After system boot": [
  null,
  "시스템 부팅 후"
 ],
 "Alert and above": [
  null,
  "경고 이상의 수준"
 ],
 "Alias": [
  null,
  "별명"
 ],
 "All": [
  null,
  "모두"
 ],
 "All-in-one": [
  null,
  "일체형"
 ],
 "Allow running (unmask)": [
  null,
  "실행 허용 (마스크 해제)"
 ],
 "Ansible": [
  null,
  "앤서블"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 역할 문서"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "로그 메시지에서 모든 텍스트 문자열을 필터링 될 수 있습니다. 문자열은 또한 정규식 표현의 형식일 수도 있습니다. 또한 메시지 로그 부분에 의해 필터링을 지원합니다. 이들은 형식 FIELD=VALUE 에서 공백으로 분리된 값이며, 해당 값은 가능한 값의 쉼표로 구분된 목록일 수 있습니다."
 ],
 "Appearance": [
  null,
  "표시형식"
 ],
 "Apply and reboot": [
  null,
  "적용하고 재시작"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "새로운 정책을 적용하고...이는 몇 분 정도 걸릴 수 있습니다."
 ],
 "Asset tag": [
  null,
  "자산 태그"
 ],
 "At minute": [
  null,
  "분에"
 ],
 "At second": [
  null,
  "초"
 ],
 "At specific time": [
  null,
  "특정 시간"
 ],
 "Authentication": [
  null,
  "인증"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔의 권한 작업을 수행하려면 인증이 필요합니다"
 ],
 "Authorize SSH key": [
  null,
  "SSH 키 승인"
 ],
 "Automatically starts": [
  null,
  "자동 시작"
 ],
 "Automatically using NTP": [
  null,
  "자동으로 NTP 사용"
 ],
 "Automatically using additional NTP servers": [
  null,
  "추가 NTP 서버를 자동으로 사용"
 ],
 "Automatically using specific NTP servers": [
  null,
  "특정 NTP 서버를 자동으로 사용"
 ],
 "Automation script": [
  null,
  "자동 스크립트"
 ],
 "BIOS": [
  null,
  "바이오스"
 ],
 "BIOS date": [
  null,
  "바이오스 날짜"
 ],
 "BIOS version": [
  null,
  "바이오스 버전"
 ],
 "Bad": [
  null,
  "나쁨"
 ],
 "Bad setting": [
  null,
  "잘못된 설정"
 ],
 "Before": [
  null,
  "이전"
 ],
 "Binds to": [
  null,
  "바인딩 위치"
 ],
 "Black": [
  null,
  "블랙"
 ],
 "Blade": [
  null,
  "블레이드"
 ],
 "Blade enclosure": [
  null,
  "블레이드 인클로저"
 ],
 "Boot": [
  null,
  "부팅"
 ],
 "Bound by": [
  null,
  "바인딩 기준"
 ],
 "Bus expansion chassis": [
  null,
  "버스 확장 섀시"
 ],
 "CPU": [
  null,
  "중앙처리장치"
 ],
 "CPU security": [
  null,
  "중앙처리장치 보안"
 ],
 "CPU security toggles": [
  null,
  "중앙처리장치 보안 전환"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "현재 필터 조합을 사용하여 기록을 찾을 수 없습니다."
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Cancel poweroff": [
  null,
  "전원 끄기 취소"
 ],
 "Cancel reboot": [
  null,
  "재부팅 취소"
 ],
 "Cannot be enabled": [
  null,
  "활성화할 수 없습니다"
 ],
 "Cannot forward login credentials": [
  null,
  "로그인 정보를 전송할 수 없습니다"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "이 시스템에서 realmd를 사용할 수 없으므로 도메인에 참여할 수 없습니다"
 ],
 "Cannot schedule event in the past": [
  null,
  "이전 이벤트를 예약할 수 없습니다"
 ],
 "Change": [
  null,
  "변경"
 ],
 "Change cryptographic policy": [
  null,
  "암호화 정책을 변경합니다"
 ],
 "Change host name": [
  null,
  "호스트 이름 변경"
 ],
 "Change performance profile": [
  null,
  "성능 프로파일 변경"
 ],
 "Change profile": [
  null,
  "프로파일 변경"
 ],
 "Change system time": [
  null,
  "시스템 시간 변경"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "때때로 운영 체제 재설치로 인해 키가 변경될 수 있습니다. 그러나 예기치 않은 변경은 연결을 가로채는 타사의 시도를 나타낼 수도 있습니다."
 ],
 "Checking installed software": [
  null,
  "설치된 소프트웨어 확인 중"
 ],
 "Class": [
  null,
  "등급"
 ],
 "Clear 'Failed to start'": [
  null,
  "‘시작 실패’ 지우기"
 ],
 "Clear all filters": [
  null,
  "모든 필터 지우기"
 ],
 "Client software": [
  null,
  "클라이언트 소프트웨어"
 ],
 "Close": [
  null,
  "닫기"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 및 Firewalld의 Cockpit 구성"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit을 지정된 호스트에 연결 할 수 없습니다."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit은 웹 브라우저에서 리눅스 서버를 쉽게 관리 할 수 있는 서버 관리자입니다. 터미널과 웹 도구을 구분하지 않고 사용할 수 있습니다. Cockpit에서 시작된 서비스는 터미널을 통해 중지할 수 있습니다. 마찬가지로 터미널에서 오류가 발생한 경우 해당 오류를 Cockpit 저널 연결장치에서 확인 할 수 있습니다."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit은 시스템의 소프트웨어와 호환성이 없습니다."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit이 설치되어 있지 않습니다"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "시스템에 Cockpit이 설치되어 있지 않습니다."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit은 경험이 적은 시스템 관리자에게 적합합니다. 시스템 관리자는 저장장치 관리, 저널 검사, 서비스 시작 및 중지 등의 간단한 작업을 쉽게 수행할 수 있으며 여러 서버를 동시에 모니터링 및 관리 할 수 있습니다. 간단하게 장비를 추가하여 서버를 추가할 수 있으며 추가 후 다른 기기를 관리할 수 있습니다."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "진단 및 지원 자료 수집 및 꾸러미"
 ],
 "Collect kernel crash dumps": [
  null,
  "커널 충돌 덤프 수집"
 ],
 "Command": [
  null,
  "명령"
 ],
 "Command not found": [
  null,
  "명령을 찾을 수 없음"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned와의 통신에 실패했습니다"
 ],
 "Compact PCI": [
  null,
  "PCI 압축"
 ],
 "Condition $0=$1 was not met": [
  null,
  "조건 $0=$1이 충족되지 않았습니다"
 ],
 "Condition failed": [
  null,
  "조건이 충족되지 않았습니다"
 ],
 "Configuration": [
  null,
  "설정"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 삭제를 확인합니다"
 ],
 "Confirm key password": [
  null,
  "키 비밀빈호 확인"
 ],
 "Conflicted by": [
  null,
  "충돌 대상"
 ],
 "Conflicts": [
  null,
  "충돌"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "dbus에 연결하는 데 실패했습니다: $0"
 ],
 "Connection has timed out.": [
  null,
  "연결 시간 초과."
 ],
 "Consists of": [
  null,
  "구성"
 ],
 "Contacted domain": [
  null,
  "연락 된 도메인"
 ],
 "Controller": [
  null,
  "제어기"
 ],
 "Convertible": [
  null,
  "변환 가능"
 ],
 "Copied": [
  null,
  "복사됨"
 ],
 "Copy": [
  null,
  "복사"
 ],
 "Copy to clipboard": [
  null,
  "클립보드로 복사"
 ],
 "Crash reporting": [
  null,
  "크래시 보고"
 ],
 "Create $0": [
  null,
  "$0 생성"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "신규 SSH 키를 생성하고 승인합니다"
 ],
 "Create new task file with this content.": [
  null,
  "이 컨텐츠로 신규 작업 파일을 만듭니다."
 ],
 "Create timer": [
  null,
  "타이머 만들기"
 ],
 "Critical and above": [
  null,
  "중대한 이상 수준"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "암호화 정책은 TLS, IPSec, SSH, DNSSec와 커버러스 통신규약을 포함하는 핵심 암호화 하위 시스템을 구성하는 시스템 구성 요소입니다."
 ],
 "Cryptographic policy": [
  null,
  "암호화 정책"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "암호화 정책이 일관적이지 않습니다"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "현재 부팅"
 ],
 "Custom cryptographic policy": [
  null,
  "사용자 정의 암호화 정책"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "SHA-1 서명 확인이 허용되는 DEFAULT."
 ],
 "Daily": [
  null,
  "매일"
 ],
 "Dark": [
  null,
  "어둡게"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "날짜 상세는 연-월-일 시:분:초 (YYYY-MM-DD hh:mm:ss)형식이어야 합니다. 대안으로 문자열 '어제', '오늘', '내일'로 이해 할 수 있습니다. '지금'은 현재 시간을 나타냅니다. 마지막으로, '-' 또는 '+'를 접두사로 사용하여, 상대 시간으로 지정 할 수 있습니다"
 ],
 "Debug and above": [
  null,
  "디버그 이상의 수준"
 ],
 "Decrease by one": [
  null,
  "1 씩 감소"
 ],
 "Default": [
  null,
  "기본"
 ],
 "Delay": [
  null,
  "지연"
 ],
 "Delay must be a number": [
  null,
  "지연은 숫자여야 합니다"
 ],
 "Delete": [
  null,
  "삭제"
 ],
 "Deletion will remove the following files:": [
  null,
  "삭제시 다음 파일을 제거합니다:"
 ],
 "Description": [
  null,
  "설명"
 ],
 "Desktop": [
  null,
  "데스크탑"
 ],
 "Detachable": [
  null,
  "분리 가능"
 ],
 "Details": [
  null,
  "상세정보"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Disable simultaneous multithreading": [
  null,
  "동시 멀티스레딩 비활성화"
 ],
 "Disable tuned": [
  null,
  "tuned 비활성화"
 ],
 "Disabled": [
  null,
  "사용 안함"
 ],
 "Disallow running (mask)": [
  null,
  "실행 할 수 없음 (마스크)"
 ],
 "Docking station": [
  null,
  "도킹 스테이션"
 ],
 "Does not automatically start": [
  null,
  "자동으로 시작되지 않습니다"
 ],
 "Domain": [
  null,
  "도메인"
 ],
 "Domain address": [
  null,
  "도메인 주소"
 ],
 "Domain administrator name": [
  null,
  "도메인 관리자 이름"
 ],
 "Domain administrator password": [
  null,
  "도메인 관리자 비밀번호"
 ],
 "Domain could not be contacted": [
  null,
  "도메인에 연결할 수 없음"
 ],
 "Domain is not supported": [
  null,
  "도메인이 지원되지 않습니다"
 ],
 "Don't repeat": [
  null,
  "반복 실행하지 않습니다"
 ],
 "Downloading $0": [
  null,
  "$0 내려받기 중"
 ],
 "Dual rank": [
  null,
  "듀얼 랭크"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd 편집"
 ],
 "Edit motd": [
  null,
  "motd 편집"
 ],
 "Embedded PC": [
  null,
  "임베디드 PC"
 ],
 "Enabled": [
  null,
  "사용"
 ],
 "Entry at $0": [
  null,
  "$0에서 항목"
 ],
 "Error": [
  null,
  "오류"
 ],
 "Error and above": [
  null,
  "오류 이상"
 ],
 "Error message": [
  null,
  "오류 메시지"
 ],
 "Excellent password": [
  null,
  "우수한 비밀번호"
 ],
 "Expansion chassis": [
  null,
  "확장 섀시"
 ],
 "Extended information": [
  null,
  "확장 정보"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS는 적절하게 활성화되지 않았습니다"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "추가 공통 기준 제한 사항이 있는 FIPS."
 ],
 "Failed to change password": [
  null,
  "비밀번호 변경 실패"
 ],
 "Failed to disable tuned": [
  null,
  "tuned 비활성화에 실패했습니다"
 ],
 "Failed to disable tuned profile": [
  null,
  "조정된 프로파일 비활성화에 실패함"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "방화벽에서 $0 활성화에 실패"
 ],
 "Failed to enable tuned": [
  null,
  "tuned 활성화에 실패하였습니다"
 ],
 "Failed to fetch logs": [
  null,
  "패치 기록에실패했습니다"
 ],
 "Failed to load unit": [
  null,
  "장치을 적재하는데 실패함"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "/etc/motd에 변경 사항을 저장하지 못했습니다"
 ],
 "Failed to start": [
  null,
  "시작하지 못했습니다"
 ],
 "Failed to switch profile": [
  null,
  "프로파일 전환에 실패했습니다"
 ],
 "File state": [
  null,
  "파일 상태"
 ],
 "Filter by name or description": [
  null,
  "이름 또는 설명에 따라 필터링"
 ],
 "Filters": [
  null,
  "필터"
 ],
 "Font size": [
  null,
  "글꼴 크기"
 ],
 "Forbidden from running": [
  null,
  "실행 금지"
 ],
 "Frame number": [
  null,
  "프레임 번호"
 ],
 "Free-form search": [
  null,
  "자유-형식 검색"
 ],
 "Fridays": [
  null,
  "금요일"
 ],
 "General": [
  null,
  "일반"
 ],
 "Generated": [
  null,
  "생성됨"
 ],
 "Go to $0": [
  null,
  "$0로 이동"
 ],
 "Go to now": [
  null,
  "지금 바로 가기"
 ],
 "Handheld": [
  null,
  "휴대용"
 ],
 "Hardware information": [
  null,
  "하드웨어 정보"
 ],
 "Health": [
  null,
  "상태"
 ],
 "Help": [
  null,
  "도움말"
 ],
 "Hide confirmation password": [
  null,
  "확인 비밀번호 숨기기"
 ],
 "Hide password": [
  null,
  "비밀번호 숨기기"
 ],
 "Hierarchy ID": [
  null,
  "계층 ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "증가된 공격 표면을 희생하는 더 높은 상호 운용성."
 ],
 "Host key is incorrect": [
  null,
  "호스트 키가 잘못되었습니다"
 ],
 "Hostname": [
  null,
  "호스트 이름"
 ],
 "Hourly": [
  null,
  "한 시간 마다"
 ],
 "Hours": [
  null,
  "시"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "식별자"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "만약 지문이 일치하면, '키 ' 호스트 신뢰 및 추가'를 눌러주세요. 그렇지 않다면, 연결하지 않고 관리자에게 문의하세요."
 ],
 "Increase by one": [
  null,
  "1 씩 증가"
 ],
 "Indirect": [
  null,
  "간접"
 ],
 "Info and above": [
  null,
  "정보 이상의 수준"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "설치"
 ],
 "Install realmd support": [
  null,
  "realmd 지원 설치"
 ],
 "Install software": [
  null,
  "소프트웨어 설치"
 ],
 "Installing $0": [
  null,
  "$0 설치 중"
 ],
 "Internal error": [
  null,
  "내부 오류"
 ],
 "Invalid": [
  null,
  "유효하지 않음"
 ],
 "Invalid date format": [
  null,
  "잘못된 날짜 형식"
 ],
 "Invalid date format and invalid time format": [
  null,
  "잘못된 날짜 형식 및 잘못된 시간 형식"
 ],
 "Invalid file permissions": [
  null,
  "잘못된 파일 권한"
 ],
 "Invalid time format": [
  null,
  "잘못된 시간 형식"
 ],
 "Invalid timezone": [
  null,
  "잘못된 시간대"
 ],
 "IoT gateway": [
  null,
  "IoT 게이트웨이"
 ],
 "Join": [
  null,
  "참가"
 ],
 "Join domain": [
  null,
  "도메인 가입"
 ],
 "Joining": [
  null,
  "참가하기"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "도메인에 가입하려면 realmd를 설치해야 합니다"
 ],
 "Joining this domain is not supported": [
  null,
  "도메인 가입이 지원되지 않습니다"
 ],
 "Joins namespace of": [
  null,
  "네임스페이스에 참여"
 ],
 "Journal": [
  null,
  "저널"
 ],
 "Journal entry": [
  null,
  "저널 항목"
 ],
 "Journal entry not found": [
  null,
  "저널 항목를 찾을 수 없습니다"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Key password": [
  null,
  "키 비밀번호"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "동적 디렉토리 상호 운영성을 갖는 레거시."
 ],
 "Laptop": [
  null,
  "랩탑"
 ],
 "Last 24 hours": [
  null,
  "지난 24 시간"
 ],
 "Last 7 days": [
  null,
  "지난 7일"
 ],
 "Last successful login:": [
  null,
  "마지막으로 성공한 로그인:"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "Leave $0": [
  null,
  "$0 나가기"
 ],
 "Leave domain": [
  null,
  "도메인 나가기"
 ],
 "Light": [
  null,
  "밝게"
 ],
 "Limits": [
  null,
  "제한"
 ],
 "Linked": [
  null,
  "연결됨"
 ],
 "Listen": [
  null,
  "경청하다"
 ],
 "Listing units": [
  null,
  "단위 나열"
 ],
 "Listing units failed: $0": [
  null,
  "단위 나열에 실패함: $0"
 ],
 "Load earlier entries": [
  null,
  "이전 항목 적재"
 ],
 "Loading keys...": [
  null,
  "키 적재 중..."
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH 키 로드에 실패했습니다"
 ],
 "Loading of units failed": [
  null,
  "단위 로드에 실패했습니다"
 ],
 "Loading system modifications...": [
  null,
  "시스템 수정 적재 중..."
 ],
 "Loading unit failed": [
  null,
  "장치 적재에 실패함"
 ],
 "Loading...": [
  null,
  "적재 중..."
 ],
 "Log in": [
  null,
  "로그인"
 ],
 "Log in to $0": [
  null,
  "$0에 로그인"
 ],
 "Log messages": [
  null,
  "로그 메세지"
 ],
 "Login failed": [
  null,
  "로그인 실패"
 ],
 "Login format": [
  null,
  "로그인 형식"
 ],
 "Logs": [
  null,
  "기록"
 ],
 "Low profile desktop": [
  null,
  "낮은 프로파일 데스크탑"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Machine ID": [
  null,
  "장치 ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "장비 SSH 키 지문"
 ],
 "Main server chassis": [
  null,
  "메인 서버 섀시"
 ],
 "Maintenance": [
  null,
  "유지 관리"
 ],
 "Manage storage": [
  null,
  "관리 저장소"
 ],
 "Manually": [
  null,
  "수동"
 ],
 "Mask service": [
  null,
  "마스크 서비스"
 ],
 "Masked": [
  null,
  "마스크 설정되었습니다"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "마스크 서비스는 모든 종속 장치가 실행되지 않도록합니다. 이는 예상보다 큰 영향을 미칠 수 있습니다. 이 장치에 마스크를 설정할 지 확인하십시오."
 ],
 "Memory": [
  null,
  "메모리"
 ],
 "Memory technology": [
  null,
  "메모리 기술"
 ],
 "Merged": [
  null,
  "병합됨"
 ],
 "Message to logged in users": [
  null,
  "로그인한 사용자에게 보내는 메세지"
 ],
 "Mini PC": [
  null,
  "미니 PC"
 ],
 "Mini tower": [
  null,
  "미니 타워"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "분은 0-59 사이의 값이어야 합니다"
 ],
 "Minutely": [
  null,
  "분"
 ],
 "Minutes": [
  null,
  "분"
 ],
 "Mitigations": [
  null,
  "완화 방법"
 ],
 "Model": [
  null,
  "모델"
 ],
 "Mondays": [
  null,
  "월요일"
 ],
 "Monthly": [
  null,
  "월간"
 ],
 "Multi-system chassis": [
  null,
  "멀티 시스템 섀시"
 ],
 "NTP server": [
  null,
  "NTP 서버"
 ],
 "Name": [
  null,
  "이름"
 ],
 "Need at least one NTP server": [
  null,
  "최소 하나의 NTP 서버가 필요합니다"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "New password was not accepted": [
  null,
  "신규 비밀번호가 허용되지 않습니다"
 ],
 "No": [
  null,
  "아니오"
 ],
 "No delay": [
  null,
  "지연 없음"
 ],
 "No host keys found.": [
  null,
  "호스트 키를 찾을 수 없습니다."
 ],
 "No log entries": [
  null,
  "로그 항목이 없습니다"
 ],
 "No logs found": [
  null,
  "기록을 찾을 수 없음"
 ],
 "No matching results": [
  null,
  "일치하는 결과를 찾을 수 없습니다"
 ],
 "No results found": [
  null,
  "결과를 찾을 수 없습니다"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "필터 기준과 일치하는 결과가 없습니다. 결과를 표시하려면 모든 필터를 지우십시오."
 ],
 "No rule hits": [
  null,
  "규칙 히트 없음"
 ],
 "No such file or directory": [
  null,
  "이러한 파일 또는 디렉토리가 없습니다"
 ],
 "No system modifications": [
  null,
  "시스템 수정 없음"
 ],
 "None": [
  null,
  "없음"
 ],
 "Not a valid private key": [
  null,
  "유효한 개인 키가 없습니다"
 ],
 "Not connected to Insights": [
  null,
  "Insights 에 연결되어 있지 않습니다"
 ],
 "Not found": [
  null,
  "찾을 수 없습니다"
 ],
 "Not permitted to configure realms": [
  null,
  "영역 구성을 허용하지 않습니다"
 ],
 "Not permitted to perform this action.": [
  null,
  "이 작업을 실행할 수 있는 권한이 없습니다."
 ],
 "Not running": [
  null,
  "미동작"
 ],
 "Not synchronized": [
  null,
  "동기화 되어 있지 않습니다"
 ],
 "Note": [
  null,
  "알림"
 ],
 "Notebook": [
  null,
  "노트북"
 ],
 "Notice and above": [
  null,
  "알림 이상의 수준"
 ],
 "Occurrences": [
  null,
  "발생"
 ],
 "Ok": [
  null,
  "확인"
 ],
 "Old password not accepted": [
  null,
  "이전 비밀번호가 허용되지 않습니다"
 ],
 "On failure": [
  null,
  "실패한 경우"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit이 설치되면 \"systemctl enable --now cockpit.socket\"을 사용하여 이를 활성화합니다."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "알파벳, 숫자, : , _ , . , @ , - 만 사용 할 수 있습니다"
 ],
 "Only emergency": [
  null,
  "긴급 상황에서만"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS 방식으로 부팅 할 때에 승인되고 허용된 알고리즘만 사용하세요."
 ],
 "Other": [
  null,
  "기타"
 ],
 "Overview": [
  null,
  "개요"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit가 충돌했습니다"
 ],
 "Part of": [
  null,
  "일부분"
 ],
 "Password": [
  null,
  "비밀번호"
 ],
 "Password is not acceptable": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Password is too weak": [
  null,
  "비밀번호가 너무 취약합니다"
 ],
 "Password not accepted": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Paste": [
  null,
  "붙여넣기"
 ],
 "Paste error": [
  null,
  "붙임 오류"
 ],
 "Path": [
  null,
  "경로"
 ],
 "Path to file": [
  null,
  "파일의 경로"
 ],
 "Paths": [
  null,
  "경로"
 ],
 "Pause": [
  null,
  "일시정지"
 ],
 "Performance profile": [
  null,
  "성능 프로파일"
 ],
 "Peripheral chassis": [
  null,
  "주변 장치 섀시"
 ],
 "Pick date": [
  null,
  "날짜 선택"
 ],
 "Pin unit": [
  null,
  "고정 단위"
 ],
 "Pinned unit": [
  null,
  "고정된 단위"
 ],
 "Pizza box": [
  null,
  "피자 박스"
 ],
 "Portable": [
  null,
  "이동식"
 ],
 "Present": [
  null,
  "존재"
 ],
 "Pretty host name": [
  null,
  "지정 호스트 이름"
 ],
 "Previous boot": [
  null,
  "이전 재시작"
 ],
 "Priority": [
  null,
  "우선순위"
 ],
 "Problem details": [
  null,
  "문제 상세 정보"
 ],
 "Problem info": [
  null,
  "문제 정보"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add를 통한 메세지 제공 시간이 초과되었습니다"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen을 통한 메세지 제공시간이 초과되었습니다"
 ],
 "Propagates reload to": [
  null,
  "다음 위치에 다시 로드 전파"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "상호 운용성을 희생하며 예상되는 단기-적인 미래 공격으로부터 보호합니다."
 ],
 "RAID chassis": [
  null,
  "레이드 섀시"
 ],
 "Rack mount chassis": [
  null,
  "랙 적재 구조"
 ],
 "Rank": [
  null,
  "순위"
 ],
 "Read more...": [
  null,
  "더 알아보기..."
 ],
 "Read-only": [
  null,
  "읽기 전용"
 ],
 "Real host name": [
  null,
  "실제 호스트 이름"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "실제 호스트 이름에는 소문자, 숫자, 대시, 마침표만 사용할 수 있습니다. (입력된 하위 도메인 포함)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "실제 호스트 이름은 64자 보다 적은 문자로 구성되어야 합니다"
 ],
 "Reapply and reboot": [
  null,
  "다시 적용하고 재시작"
 ],
 "Reboot": [
  null,
  "재시작"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "현재 위협 모델을 위해 권장된 보안 설정."
 ],
 "Reload": [
  null,
  "다시읽기"
 ],
 "Reload propagated from": [
  null,
  "전달 소스를 다시 로드"
 ],
 "Reloading": [
  null,
  "다시 적재 중"
 ],
 "Removals:": [
  null,
  "삭제:"
 ],
 "Remove": [
  null,
  "제거"
 ],
 "Removing $0": [
  null,
  "$0 삭제 중"
 ],
 "Repeat": [
  null,
  "반복"
 ],
 "Repeat monthly": [
  null,
  "매달 반복"
 ],
 "Repeat weekly": [
  null,
  "매주 반복"
 ],
 "Report": [
  null,
  "보고"
 ],
 "Report to ABRT Analytics": [
  null,
  "ABRT 분석에 보고합니다"
 ],
 "Reported; no links available": [
  null,
  "보고되었습니다; 사용 가능한 연결이 없습니다"
 ],
 "Reporting failed": [
  null,
  "보고에 실패했습니다"
 ],
 "Reporting was canceled": [
  null,
  "보고가 취소되었습니다"
 ],
 "Reports:": [
  null,
  "보고서 :"
 ],
 "Required by": [
  null,
  "필요 사항"
 ],
 "Required by ": [
  null,
  "필요 사항 "
 ],
 "Requires": [
  null,
  "요구 사항"
 ],
 "Requires administration access to edit": [
  null,
  "편집하려면 관리 권한이 필요합니다"
 ],
 "Requisite": [
  null,
  "필수 사항"
 ],
 "Requisite of": [
  null,
  "필수 사항"
 ],
 "Reset": [
  null,
  "초기화"
 ],
 "Restart": [
  null,
  "재시작"
 ],
 "Resume": [
  null,
  "다시 시작"
 ],
 "Review cryptographic policy": [
  null,
  "암호화 정책을 검토합니다"
 ],
 "Row expansion": [
  null,
  "행 확장"
 ],
 "Row select": [
  null,
  "행 선택"
 ],
 "Run at": [
  null,
  "다음에서 실행"
 ],
 "Run on": [
  null,
  "다음 실행"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "신뢰하는 네트워크 또는 원격 장비에서 물리적으로 이와 같은 명령을 실행합니다:"
 ],
 "Running": [
  null,
  "작동중"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH 키"
 ],
 "SSH key login": [
  null,
  "SSH 키 로그인"
 ],
 "Saturdays": [
  null,
  "토요일"
 ],
 "Save": [
  null,
  "저장"
 ],
 "Save and reboot": [
  null,
  "저장 및 재시작"
 ],
 "Save changes": [
  null,
  "변경 사항 저장"
 ],
 "Scheduled poweroff at $0": [
  null,
  "$0에 예약된 전원 끄기"
 ],
 "Scheduled reboot at $0": [
  null,
  "$0에서 예정된 재시작"
 ],
 "Sealed-case PC": [
  null,
  "쉴드 케이스 PC"
 ],
 "Search": [
  null,
  "검색"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "초는 0-59 사이의 값이어야 합니다"
 ],
 "Seconds": [
  null,
  "초"
 ],
 "Secure shell keys": [
  null,
  "보안 쉘 키"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "보안이 향상된 리눅스 구성과 문제해결"
 ],
 "Send": [
  null,
  "전송"
 ],
 "Server has closed the connection.": [
  null,
  "서버 연결이 종료되었습니다."
 ],
 "Server software": [
  null,
  "서버 소프트웨어"
 ],
 "Service logs": [
  null,
  "서비스 로그"
 ],
 "Services": [
  null,
  "서비스"
 ],
 "Set hostname": [
  null,
  "호스트 이름 설정"
 ],
 "Set time": [
  null,
  "시간 설정"
 ],
 "Shell script": [
  null,
  "쉘 스크립트"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "모든 스레드 표시"
 ],
 "Show confirmation password": [
  null,
  "비밀번호 확인을 표시합니다"
 ],
 "Show fingerprints": [
  null,
  "지문 표시"
 ],
 "Show messages containing given string.": [
  null,
  "제공된 문자열을 포함하여 메시지를 표시합니다."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "상세한 systemd 단위를 위해 메세지를 표시하기."
 ],
 "Show messages from a specific boot.": [
  null,
  "특정 부팅에서 메세지 표시하기."
 ],
 "Show more relationships": [
  null,
  "더 많은 연관관계를 보여줍니다"
 ],
 "Show password": [
  null,
  "비밀번호 표시"
 ],
 "Show relationships": [
  null,
  "연관관계를 보여줍니다"
 ],
 "Shut down": [
  null,
  "종료"
 ],
 "Shutdown": [
  null,
  "종료"
 ],
 "Since": [
  null,
  "이후"
 ],
 "Single rank": [
  null,
  "단일 등급"
 ],
 "Size": [
  null,
  "크기"
 ],
 "Slot": [
  null,
  "슬롯"
 ],
 "Sockets": [
  null,
  "소켓"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "소프트웨어 기반 완화 방법은 CPU 보안 문제를 예방하는데 도움이 될 수 있습니다. 이러한 완화 옵션은 성능을 저하시키는 부작용이 있습니다. 이러한 부작용을 인지하고 필요에 따라 설정을 변경하십시오."
 ],
 "Space-saving computer": [
  null,
  "공간-절약형 컴퓨터"
 ],
 "Specific time": [
  null,
  "특정 시간"
 ],
 "Speed": [
  null,
  "속도"
 ],
 "Start": [
  null,
  "시작"
 ],
 "Start and enable": [
  null,
  "시작 및 활성화"
 ],
 "Start service": [
  null,
  "서비스 시작"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "항목 표시를 시작하거나 지정된 날짜보다 최신입니다."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "항목 표시를 시작하거나 지정된 날짜보다 오래되었습니다."
 ],
 "State": [
  null,
  "상태"
 ],
 "Static": [
  null,
  "정적"
 ],
 "Status": [
  null,
  "상태"
 ],
 "Stick PC": [
  null,
  "스틱 PC"
 ],
 "Stop": [
  null,
  "중지"
 ],
 "Stop and disable": [
  null,
  "중지 및 비활성화"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Strong password": [
  null,
  "강력한 비밀번호"
 ],
 "Stub": [
  null,
  "스텁"
 ],
 "Sub-Chassis": [
  null,
  "서브 섀시"
 ],
 "Sub-Notebook": [
  null,
  "서브 노트북"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd 신호 구독에 실패했습니다. $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "성공적으로 클립보드로 복사됨"
 ],
 "Sundays": [
  null,
  "일요일"
 ],
 "Synchronized": [
  null,
  "동기화됩니다"
 ],
 "Synchronized with $0": [
  null,
  "$0와 동기화됩니다"
 ],
 "Synchronizing": [
  null,
  "동기화 중"
 ],
 "System": [
  null,
  "시스템"
 ],
 "System information": [
  null,
  "시스템 정보"
 ],
 "System time": [
  null,
  "시스템 시간"
 ],
 "Systemd units": [
  null,
  "Systemd 단위"
 ],
 "Tablet": [
  null,
  "테블릿"
 ],
 "Targets": [
  null,
  "대상"
 ],
 "Terminal": [
  null,
  "터미널"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$1의 SSH 키 $0 ($2에서)는 $4의 $3 ($5에서)파일로 추가됩니다."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 키 $0는 나머지 세션에서 사용 할 수 있고 다른 호스트에 로그인 할 때에도 사용 할 수 있습니다."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0에 로그인하기 위한 SSH 키가 비밀번호에 의해 보호되고 있으며, 그리고 호스트는 비밀번호로 로그인을 허용 하지 않습니다. $1에서 키의 비밀번호를 제공하세요."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0에 로그인하기 위해 SSH 키가 보호되고 있습니다. 당신은 $1에서 자신의 로그인 비밀번호에 의하거나 키의 비밀번호 제공을 통해 로그인 할 수 있습니다.."
 ],
 "The fingerprint should match:": [
  null,
  "지문 표시가 일치해야 합니다:"
 ],
 "The key password can not be empty": [
  null,
  "키 비밀번호를 비워둘 수 없습니다"
 ],
 "The key passwords do not match": [
  null,
  "키 비밀번호가 일치하지 않습니다"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "로그인한 사용자는 시스템 수정 사항을 볼 수 없습니다"
 ],
 "The password can not be empty": [
  null,
  "비밀번호를 비워둘 수 없습니다"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "최종 지문을 전자우편을 포함한 공개적인 방법을 통해 공유 할 수 있습니다."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "결과 지문은 전자우편을 포함하는 공개 방식을 통해 공유되어도 해도 좋습니다. 만약 누군가 당신을 위해 인증하도록 요청하는 경우, 어떤 방식을 사용하든 결과를 전송 할 수 있습니다."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "서버가 지원되는 방법을 사용하여 인증을 거부했습니다."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "사용자 $0는 cpu 보안 완화 변경을 허용하지 않습니다"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "사용자 $0는 암호화 정책을 변경 할 수 없습니다"
 ],
 "This field cannot be empty": [
  null,
  "이 분야를 비워 둘 수 없습니다"
 ],
 "This may take a while": [
  null,
  "시간이 걸릴 수 있습니다"
 ],
 "This system is using a custom profile": [
  null,
  "이 시스템은 사용자 정의 프로파일을 사용하고 있습니다"
 ],
 "This system is using the recommended profile": [
  null,
  "이 시스템은 권장 프로파일을 사용하고 있습니다"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "이와 같은 도구는 SELinux 정책을 구성하고 정책 위반을 이해하고 해결하는데 도움을 줄 수 있습니다."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "이와 같은 도구는 커널 충돌 덤프를 작성하도록 시스템을 구성합니다. 이는 \"로컬\" (디스크), \"ssh\" 및 \"nfs\" 덤프 대상을 지원합니다."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "이와 같은 도구는 동작 중인 시스템에서 구성 및 진단 정보의 아카이브를 생성합니다. 아카이브는 기록 또는 추적 목적으로 로컬 또는 집중적으로 저장되거나 기술적 오류-찾기와 디버깅을 지원하기 위해 기술 지원 담당자, 개발자 또는 시스템 관리자에게 보낼 수 있습니다."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "이와 같은 도구는 파일시스템, LVM2 볼륨 그룹, 그리고 NFS 적재와 같은 로컬 저장소를 관리합니다."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "이와 같은 도구는 NetworkManager 및 Firewalld를 사용하여 bonds, bridges, teams, VLAN과 방화벽과 같은 네트워킹을 관리합니다. NetworkManager는 우분투 기본 systemd-netowrkd 및 데비안의 ifupdown 스크립트와는 호환되지 않습니다."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "이 장치는 명시적으로 사용하도록 설계되어 있지 않습니다."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "이는 '_BOOT_ID='를 위해 일치 항목을 추가합니다. 만약 지정하지 않으면 현재 부팅을 위한 기록(로그)가 표시 될 것입니다. 만약 부트 ID가 생략되었으면, 양수 오프셋은 저널의 시작 부분에서 시작하여 부팅을 조회 할 것이고, 0 보다 같거나 작은 오프셋은 저널의 끝에서 부팅을 조회 할 것입니다. 그러므로, 1은 시간 순서에서 저널에서 발견된 처음 부팅을 의미하고, 2는 두 번째 부팅 등을 의미합니다; 반면 -0은 마지막 부팅이고, -1은 마지막 부팅 전의 부팅입니다."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "이는 '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' 와 'UNIT=' 을 위한 일치를 추가하여 제공된 단위를 위해 모든 가능한 메시지를 찾습니다. 쉼표에 의해 구분된 더 많은 단위를 포함할 수 있습니다. "
 ],
 "Thursdays": [
  null,
  "목요일"
 ],
 "Time": [
  null,
  "시간"
 ],
 "Time zone": [
  null,
  "시간대"
 ],
 "Timer creation failed": [
  null,
  "타이머 생성에 실패했습니다"
 ],
 "Timer deletion failed": [
  null,
  "타이머 삭제가 실패했습니다"
 ],
 "Timers": [
  null,
  "타이머"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "악성의 제3자가 귀하의 연결을 가로채지 않도록 하려면 호스트 키 지문을 확인하십시오:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "지문을 확인하려면 물리적인 장치 또는 신뢰할 수 있는 네트워크를 통해 $0에서 다음을 실행합니다:"
 ],
 "Toggle date picker": [
  null,
  "날짜 선택기 전환"
 ],
 "Toggle filters": [
  null,
  "필터 전환"
 ],
 "Too much data": [
  null,
  "데이터가 너무 많습니다"
 ],
 "Total size: $0": [
  null,
  "전체 크기: $0"
 ],
 "Tower": [
  null,
  "타워"
 ],
 "Transient": [
  null,
  "과도현상"
 ],
 "Trigger": [
  null,
  "트리거"
 ],
 "Triggered by": [
  null,
  "트리거 대상"
 ],
 "Triggers": [
  null,
  "트리거"
 ],
 "Trust and add host": [
  null,
  "호스트 신뢰 및 추가"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0와 동기화를 시도 중입니다"
 ],
 "Tuesdays": [
  null,
  "화요일"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned 시작에 실패했습니다"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned는 시스템을 모니터링하고 특정 워크로드에 대해 성능을 최적화하는 서비스입니다. Tuned의 핵심은 다른 사용 사례에 맞게 시스템을 조정하는 프로파일입니다."
 ],
 "Tuned is not available": [
  null,
  "Tuned를 사용 할 수 없습니다"
 ],
 "Tuned is not running": [
  null,
  "Tuned가 동작되지 않음"
 ],
 "Tuned is off": [
  null,
  "Tuned이 종료되어 있습니다"
 ],
 "Type": [
  null,
  "유형"
 ],
 "Type to filter": [
  null,
  "필터 입력"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 키 인증을 사용하여 $0에 로그인 할 수 없습니다. 비밀번호를 입력하세요."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0에 로그인 할 수 없습니다. 호스트는 비밀번호 로그인 또는 자신의 SSH 키를 허용하지 않습니다."
 ],
 "Unit": [
  null,
  "단위"
 ],
 "Unknown": [
  null,
  "알 수 없음"
 ],
 "Unknown host: $0": [
  null,
  "알 수 없는 호스트: $0"
 ],
 "Unpin unit": [
  null,
  "고정해제 단위"
 ],
 "Until": [
  null,
  "까지"
 ],
 "Untrusted host": [
  null,
  "지원되지 않는 호스트"
 ],
 "Up since": [
  null,
  "이후부터"
 ],
 "Updating status...": [
  null,
  "상태 최신화 중 ..."
 ],
 "Usage": [
  null,
  "사용량"
 ],
 "User": [
  null,
  "사용자"
 ],
 "Validating address": [
  null,
  "주소 확인"
 ],
 "Vendor": [
  null,
  "제조사"
 ],
 "Verify fingerprint": [
  null,
  "지문 검증"
 ],
 "Version": [
  null,
  "버전"
 ],
 "View all logs": [
  null,
  "모든 기록 보기"
 ],
 "View all services": [
  null,
  "모든 서비스 보기"
 ],
 "View automation script": [
  null,
  "자동 스크립트 보기"
 ],
 "View hardware details": [
  null,
  "하드웨어 세부 사항보기"
 ],
 "View login history": [
  null,
  "로그인 내역 보기"
 ],
 "View metrics and history": [
  null,
  "측정 항목과 내역 보기"
 ],
 "View report": [
  null,
  "보고서 보기"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "메모리 정보 보기는 관리자 접근 권한이 필요합니다."
 ],
 "Visit firewall": [
  null,
  "방화벽 방문"
 ],
 "Waiting for input…": [
  null,
  "입력 대기 중…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "다른 소프트웨어 관리 작업이 완료될 때 까지 대기 중"
 ],
 "Waiting to start…": [
  null,
  "시작을 기다리는 중…"
 ],
 "Wanted by": [
  null,
  "필요한 대상"
 ],
 "Wants": [
  null,
  "필요"
 ],
 "Warning and above": [
  null,
  "경고 이상의 수준"
 ],
 "Weak password": [
  null,
  "취약한 비밀번호"
 ],
 "Web Console for Linux servers": [
  null,
  "리눅스 서버를 위한 웹콘솔"
 ],
 "Web console is running in limited access mode.": [
  null,
  "웹 콘솔이 제한된 접근 방식으로 실행 중입니다."
 ],
 "Wednesdays": [
  null,
  "수요일"
 ],
 "Weekly": [
  null,
  "매주"
 ],
 "Weeks": [
  null,
  "주"
 ],
 "White": [
  null,
  "흰색"
 ],
 "Yearly": [
  null,
  "매년"
 ],
 "Yes": [
  null,
  "네"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "처음으로 $0에 연결됩니다."
 ],
 "You may try to load older entries.": [
  null,
  "오래된 항목이 로드될 수 있습니다."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "당신의 검색기는 내용 메뉴에서 붙여넣기를 허용하지 않습니다. Shift+Insert를 사용 할 수 있습니다."
 ],
 "Your session has been terminated.": [
  null,
  "세션이 종료되었습니다."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "세션이 만료되었습니다. 다시 로그인하십시오."
 ],
 "Zone": [
  null,
  "영역"
 ],
 "[binary data]": [
  null,
  "[바이너리 데이터]"
 ],
 "[no data]": [
  null,
  "[데이터 없음]"
 ],
 "active": [
  null,
  "활성"
 ],
 "edit": [
  null,
  "편집"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh 호스트 키를 나열하지 못했습니다: $0"
 ],
 "in less than a minute": [
  null,
  "1분도 안되어"
 ],
 "inconsistent": [
  null,
  "일관성 없음"
 ],
 "journalctl manpage": [
  null,
  "journalctl man 부분"
 ],
 "less than a minute ago": [
  null,
  "1분도 채 지나지 않아"
 ],
 "none": [
  null,
  "없음"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU"
 ],
 "password quality": [
  null,
  "비밀번호 수준"
 ],
 "recommended": [
  null,
  "권장 사항"
 ],
 "running $0": [
  null,
  "$0 실행 중"
 ],
 "show less": [
  null,
  "덜 보기"
 ],
 "show more": [
  null,
  "더 보기"
 ],
 "unknown": [
  null,
  "알 수 없음"
 ],
 "dialog-title\u0004Domain": [
  null,
  "도메인"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "도메인에 가입"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0에서"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$1의 $0에서"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0에서"
 ]
});
