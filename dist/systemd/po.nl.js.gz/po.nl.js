cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritieke treffer",
  "$0 treffers, inclusief de kritieke"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagen"
 ],
 "$0 exited with code $1": [
  null,
  "$0 verlaten met code $1"
 ],
 "$0 failed": [
  null,
  "$0 mislukte"
 ],
 "$0 failed login attempt": [
  null,
  "$0 mislukte inlogpoging",
  "$0 mislukte inlogpogingen"
 ],
 "$0 hour": [
  null,
  "$0 uur",
  "$0 uren"
 ],
 "$0 important hit": [
  null,
  "$0 belangrijke treffer",
  "$0 treffers, inclusief de belangrijke"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 is van geen enkele repository beschikbaar."
 ],
 "$0 key changed": [
  null,
  "$0 sleutel gewijzigd"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 is afgeschoten met signaal $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 treffer met lage ernst",
  "$0 treffers met lage ernst"
 ],
 "$0 minute": [
  null,
  "$0 minuut",
  "$0 minuten"
 ],
 "$0 moderate hit": [
  null,
  "$0 matige treffer",
  "$0 treffers, inclusief de matige"
 ],
 "$0 month": [
  null,
  "$0 maand",
  "$0 maanden"
 ],
 "$0 service has failed": [
  null,
  "$0 service is mislukt",
  "$0 services zijn mislukt"
 ],
 "$0 week": [
  null,
  "$0 week",
  "$0 weken"
 ],
 "$0 will be installed.": [
  null,
  "$0 zal geïnstalleerd worden."
 ],
 "$0 year": [
  null,
  "$0 jaar",
  "$0 jaren"
 ],
 "$0: crash at $1": [
  null,
  "$0: crash op $1"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 uur"
 ],
 "1 minute": [
  null,
  "1 minuut"
 ],
 "1 week": [
  null,
  "1 week"
 ],
 "10th": [
  null,
  "10e"
 ],
 "11th": [
  null,
  "11e"
 ],
 "12th": [
  null,
  "12e"
 ],
 "13th": [
  null,
  "13e"
 ],
 "14th": [
  null,
  "14e"
 ],
 "15th": [
  null,
  "14e"
 ],
 "16th": [
  null,
  "16e"
 ],
 "17th": [
  null,
  "17e"
 ],
 "18th": [
  null,
  "18e"
 ],
 "19th": [
  null,
  "19e"
 ],
 "1st": [
  null,
  "1e"
 ],
 "20 minutes": [
  null,
  "20 minuten"
 ],
 "20th": [
  null,
  "20e"
 ],
 "21th": [
  null,
  "21e"
 ],
 "22th": [
  null,
  "22e"
 ],
 "23th": [
  null,
  "23e"
 ],
 "24th": [
  null,
  "24e"
 ],
 "25th": [
  null,
  "25e"
 ],
 "26th": [
  null,
  "26e"
 ],
 "27th": [
  null,
  "27e"
 ],
 "28th": [
  null,
  "28e"
 ],
 "29th": [
  null,
  "29e"
 ],
 "2nd": [
  null,
  "2e"
 ],
 "30th": [
  null,
  "30e"
 ],
 "31st": [
  null,
  "31e"
 ],
 "3rd": [
  null,
  "3e"
 ],
 "40 minutes": [
  null,
  "40 minuten"
 ],
 "4th": [
  null,
  "4e"
 ],
 "5 minutes": [
  null,
  "5 minuten"
 ],
 "5th": [
  null,
  "5e"
 ],
 "6 hours": [
  null,
  "6 uren"
 ],
 "60 minutes": [
  null,
  "60 minuten"
 ],
 "6th": [
  null,
  "6e"
 ],
 "7th": [
  null,
  "7e"
 ],
 "8th": [
  null,
  "8e"
 ],
 "9th": [
  null,
  "9de"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Er is geen compatibele versie van Cockpit geïnstalleerd op $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Een nieuwe SSH-sleutel op $0 wordt gemaakt voor $1 op $2 en deze wordt toegevoegd aan het $3-bestand van $4 op $5."
 ],
 "Absent": [
  null,
  "Afwezig"
 ],
 "Acceptable password": [
  null,
  "Acceptabel wachtwoord"
 ],
 "Active since ": [
  null,
  "Actief sinds "
 ],
 "Active state": [
  null,
  "Actieve toestand"
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "Add $0": [
  null,
  "Toevoegen $0"
 ],
 "Additional actions": [
  null,
  "Extra acties"
 ],
 "Additional packages:": [
  null,
  "Extra pakketten:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Beheer met Cockpit Web Console"
 ],
 "Advanced TCA": [
  null,
  "Geavanceerde TCA"
 ],
 "After": [
  null,
  "Na"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Na het verlaten van het domein kunnen alleen gebruikers met lokale referenties inloggen op deze machine. Dit kan ook andere services beïnvloeden, aangezien de DNS-resolutie-instellingen en de lijst met vertrouwde CA's kunnen veranderen."
 ],
 "After system boot": [
  null,
  "Na het opstarten van het systeem"
 ],
 "Alert and above": [
  null,
  "Alert en hoger"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "All": [
  null,
  "Alle"
 ],
 "All-in-one": [
  null,
  "Alles in een"
 ],
 "Allow running (unmask)": [
  null,
  "Sta uitvoeren toe (ontmaskeren)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rollen documentatie"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Elke tekenreeks in de logboekberichten kan worden gefilterd. De string kan ook de vorm hebben van een reguliere expressie. Ondersteunt ook filteren op berichtlogboekvelden. Dit zijn door spaties gescheiden waarden, in de vorm FIELD=WAARDE, waarbij de waarde een door komma's gescheiden lijst van mogelijke waarden kan zijn."
 ],
 "Appearance": [
  null,
  "Uiterlijk"
 ],
 "Apply and reboot": [
  null,
  "Toepassen en opnieuw opstarten"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Nieuw beleid toepassen... Dit kan enkele minuten duren."
 ],
 "Asset tag": [
  null,
  "Asset-tag"
 ],
 "At minute": [
  null,
  "Op minuut"
 ],
 "At second": [
  null,
  "Ten tweede"
 ],
 "At specific time": [
  null,
  "Op specifiek tijdstip"
 ],
 "Authentication": [
  null,
  "Authenticatie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Authenticatie is vereist voor het uitvoeren van bevoorrechte taken met de Cockpit Web Console"
 ],
 "Authorize SSH key": [
  null,
  "Autoriseer SSH-sleutel"
 ],
 "Automatically starts": [
  null,
  "Automatisch starten"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch gebruik van NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatisch gebruik van extra NTP servers"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch gebruik van specifieke NTP servers"
 ],
 "Automation script": [
  null,
  "Automatiserings-script"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS datum"
 ],
 "BIOS version": [
  null,
  "BIOS versie"
 ],
 "Bad": [
  null,
  "Slecht"
 ],
 "Bad setting": [
  null,
  "Slechte instelling"
 ],
 "Before": [
  null,
  "Voor"
 ],
 "Binds to": [
  null,
  "Bindt aan"
 ],
 "Black": [
  null,
  "Zwart"
 ],
 "Blade": [
  null,
  "Antenne"
 ],
 "Blade enclosure": [
  null,
  "Antennebehuizing"
 ],
 "Boot": [
  null,
  "Boot"
 ],
 "Bound by": [
  null,
  "Gebonden door"
 ],
 "Bus expansion chassis": [
  null,
  "Busuitbreidingschassis"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU-beveiliging"
 ],
 "CPU security toggles": [
  null,
  "CPU-beveiliging schakelaars"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Kan geen logboeken vinden met de huidige combinatie van filters."
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Cancel poweroff": [
  null,
  "Uitschakelen annuleren"
 ],
 "Cancel reboot": [
  null,
  "Opnieuw starten annuleren"
 ],
 "Cannot be enabled": [
  null,
  "Kan niet worden ingeschakeld"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inloggegevens niet doorsturen"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Kan geen lid worden van een domein omdat realmd niet beschikbaar is op dit systeem"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan evenement niet in het verleden plannen"
 ],
 "Change": [
  null,
  "Verandering"
 ],
 "Change cryptographic policy": [
  null,
  "Wijzig cryptografisch beleid"
 ],
 "Change host name": [
  null,
  "Verander hostnaam"
 ],
 "Change performance profile": [
  null,
  "Verander prestatieprofiel"
 ],
 "Change profile": [
  null,
  "Verander profiel"
 ],
 "Change system time": [
  null,
  "Verander systeemtijd"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Gewijzigde sleutels zijn vaak het resultaat van een herinstallatie van het besturingssysteem. Een onverwachte wijziging kan echter wijzen op een poging van derden om je verbinding te onderscheppen."
 ],
 "Checking installed software": [
  null,
  "Controleren op geïnstalleerde software"
 ],
 "Class": [
  null,
  "Klasse"
 ],
 "Clear 'Failed to start'": [
  null,
  "Wis 'Kan niet starten'"
 ],
 "Clear all filters": [
  null,
  "Wis alle filters"
 ],
 "Client software": [
  null,
  "Cliënt software"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit configuratie van NetworkManager en Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kon geen contact maken met de opgegeven host."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit is een serverbeheerder waarmee je Linux-servers eenvoudig kunt beheren via een webbrowser. Omschakelen tussen de terminal en het webgereedschap is geen probleem. Een service gestart via Cockpit kan via de terminal worden gestopt. Evenzo, als er een fout optreedt in de terminal, kan deze worden gezien in de Cockpit-logboekinterface."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit is niet compatibel met de software op het systeem."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit is niet geïnstalleerd"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit is niet op het systeem geïnstalleerd."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit is perfect voor nieuwe systeembeheerders, waardoor ze eenvoudig eenvoudige taken kunnen uitvoeren, zoals opslagbeheer, het inspecteren van logboeken en het starten en stoppen van services. Je kunt meerdere servers tegelijkertijd bewaken en beheren. Voeg ze gewoon toe met een enkele klik en je machines zullen voor zijn maatjes zorgen."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Verzamel en verpak diagnostische en ondersteuningsdata"
 ],
 "Collect kernel crash dumps": [
  null,
  "Verzamel kernelcrashdumps"
 ],
 "Command": [
  null,
  "Commando"
 ],
 "Command not found": [
  null,
  "Commando niet gevonden"
 ],
 "Communication with tuned has failed": [
  null,
  "Communicatie met tuned is mislukt"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Aan conditie $0=$1 werd niet voldaan"
 ],
 "Condition failed": [
  null,
  "Conditie mislukte"
 ],
 "Configuration": [
  null,
  "Configuratie"
 ],
 "Confirm deletion of $0": [
  null,
  "Bevestig het verwijderen van $0"
 ],
 "Confirm key password": [
  null,
  "Bevestig sleutelwachtwoord"
 ],
 "Conflicted by": [
  null,
  "Conflict met"
 ],
 "Conflicts": [
  null,
  "Conflicten"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Verbinding met dbus mislukte: $0"
 ],
 "Connection has timed out.": [
  null,
  "Er is een time-out opgetreden voor de verbinding."
 ],
 "Consists of": [
  null,
  "Bestaat uit"
 ],
 "Contacted domain": [
  null,
  "Gecontacteerd domein"
 ],
 "Controller": [
  null,
  "Controleur"
 ],
 "Convertible": [
  null,
  "Converteerbaar"
 ],
 "Copied": [
  null,
  "Gekopieerd"
 ],
 "Copy": [
  null,
  "Kopiëren"
 ],
 "Copy to clipboard": [
  null,
  "Kopiëren naar clipboard"
 ],
 "Crash reporting": [
  null,
  "Crashrapportage"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Maak een nieuwe SSH-sleutel en autoriseer deze"
 ],
 "Create new task file with this content.": [
  null,
  "Maak nieuw taakbestand aan met deze inhoud."
 ],
 "Create timer": [
  null,
  "Maak timer aan"
 ],
 "Critical and above": [
  null,
  "Kritiek en hoger"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Crypto-beleid is een systeemcomponent die de belangrijkste cryptografische subsystemen configureert, waaronder de TLS-, IPSec-, SSH-, DNSSec- en Kerberos-protocollen."
 ],
 "Cryptographic policy": [
  null,
  "Cryptografisch beleid"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Crypto-beleid is inconsistent"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Huidige opstartprocedure"
 ],
 "Custom cryptographic policy": [
  null,
  "Aangepast cryptografisch beleid"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "STANDAARD met SHA-1 handtekeningverificatie toegestaan."
 ],
 "Daily": [
  null,
  "Dagelijks"
 ],
 "Dark": [
  null,
  "Donker"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Datumspecificaties moeten het formaat JJJJ-MM-DD uu:mm:ss hebben. Als alternatief worden de strings 'gisteren', 'vandaag', 'morgen' begrepen. 'nu' verwijst naar de huidige tijd. Ten slotte kunnen relatieve tijden worden opgegeven, voorafgegaan door '-' of '+'"
 ],
 "Debug and above": [
  null,
  "Debug en hoger"
 ],
 "Decrease by one": [
  null,
  "Verlaag met één"
 ],
 "Default": [
  null,
  "Standaard"
 ],
 "Delay": [
  null,
  "Vertraging"
 ],
 "Delay must be a number": [
  null,
  "Vertraging moet een getal zijn"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Deletion will remove the following files:": [
  null,
  "Bij verwijderen worden de volgende bestanden verwijderd:"
 ],
 "Description": [
  null,
  "Beschrijving"
 ],
 "Desktop": [
  null,
  "Bureaublad"
 ],
 "Detachable": [
  null,
  "Demonteerbaar"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Gelijktijdige multithreading uitschakelen"
 ],
 "Disable tuned": [
  null,
  "Schakel tuned uit"
 ],
 "Disabled": [
  null,
  "Uitgeschakeld"
 ],
 "Disallow running (mask)": [
  null,
  "Uitvoeren niet toestaan (masker)"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "Does not automatically start": [
  null,
  "Start niet automatisch op"
 ],
 "Domain": [
  null,
  "Domein"
 ],
 "Domain address": [
  null,
  "Domeinadres"
 ],
 "Domain administrator name": [
  null,
  "Domeinbeheerdersnaam"
 ],
 "Domain administrator password": [
  null,
  "Domeinbeheerderswachtwoord"
 ],
 "Domain could not be contacted": [
  null,
  "Er kan geen contact gemaakt worden met domein"
 ],
 "Domain is not supported": [
  null,
  "Domein wordt niet ondersteund"
 ],
 "Don't repeat": [
  null,
  "Niet herhalen"
 ],
 "Downloading $0": [
  null,
  "$0 downloaden"
 ],
 "Dual rank": [
  null,
  "Dubbele rangorde"
 ],
 "Edit /etc/motd": [
  null,
  "Bewerk /etc/motd"
 ],
 "Edit motd": [
  null,
  "Bewerk motd"
 ],
 "Embedded PC": [
  null,
  "Ingebouwde pc"
 ],
 "Enabled": [
  null,
  "Ingeschakeld"
 ],
 "Entry at $0": [
  null,
  "Ingang op $0"
 ],
 "Error": [
  null,
  "Fout"
 ],
 "Error and above": [
  null,
  "Fout en hoger"
 ],
 "Error message": [
  null,
  "Foutbericht"
 ],
 "Excellent password": [
  null,
  "Uitstekend wachtwoord"
 ],
 "Expansion chassis": [
  null,
  "Uitbreidingschassis"
 ],
 "Extended information": [
  null,
  "Uitgebreide informatie"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS is niet correct ingeschakeld"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS met verdere Common Criteria-beperkingen."
 ],
 "Failed to change password": [
  null,
  "Kan wachtwoord niet veranderen"
 ],
 "Failed to disable tuned": [
  null,
  "Kan tuned niet uitzetten"
 ],
 "Failed to disable tuned profile": [
  null,
  "Kan tuned profiel niet uitzetten"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Kan $0 niet inschakelen in firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Kan tuned niet inschakelen"
 ],
 "Failed to fetch logs": [
  null,
  "Kan logboeken niet ophalen"
 ],
 "Failed to load unit": [
  null,
  "Kan unit niet laden"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Kan veranderingen in /etc/motd niet opslaan"
 ],
 "Failed to start": [
  null,
  "Starten mislukt"
 ],
 "Failed to switch profile": [
  null,
  "Kan profiel niet wijzigen"
 ],
 "File state": [
  null,
  "Bestandstatus"
 ],
 "Filter by name or description": [
  null,
  "Filteren op naam of beschrijving"
 ],
 "Filters": [
  null,
  "Filters"
 ],
 "Font size": [
  null,
  "Lettertypegrootte"
 ],
 "Forbidden from running": [
  null,
  "Uitvoeren is verboden"
 ],
 "Frame number": [
  null,
  "Framenummer"
 ],
 "Free-form search": [
  null,
  "Zoeken in vrije vorm"
 ],
 "Fridays": [
  null,
  "vrijdagen"
 ],
 "General": [
  null,
  "Algemeen"
 ],
 "Generated": [
  null,
  "Gegenereerd"
 ],
 "Go to $0": [
  null,
  "Ga naar $0"
 ],
 "Go to now": [
  null,
  "Ga nu naar"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Hardware information": [
  null,
  "Hardware informatie"
 ],
 "Health": [
  null,
  "Gezondheid"
 ],
 "Help": [
  null,
  "Hulp"
 ],
 "Hide confirmation password": [
  null,
  "Bevestigingswachtwoord verbergen"
 ],
 "Hide password": [
  null,
  "Wachtwoord verbergen"
 ],
 "Hierarchy ID": [
  null,
  "Hiërarchie-ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Hogere interoperabiliteit ten koste van een groter aanvalsoppervlak."
 ],
 "Host key is incorrect": [
  null,
  "Hostsleutel is onjuist"
 ],
 "Hostname": [
  null,
  "Hostnaam"
 ],
 "Hourly": [
  null,
  "Elk uur"
 ],
 "Hours": [
  null,
  "Uren"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identificatie"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Als de vingerafdruk overeenkomt, klik dan op 'Vertrouw en host toevoegen'. Verbind anders niet en neem contact op met je beheerder."
 ],
 "Increase by one": [
  null,
  "Verhogen met één"
 ],
 "Indirect": [
  null,
  "Indirect"
 ],
 "Info and above": [
  null,
  "Info en hoger"
 ],
 "Insights: ": [
  null,
  "Inzichten: "
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Install realmd support": [
  null,
  "Installeer realmd-ondersteuning"
 ],
 "Install software": [
  null,
  "Installeer software"
 ],
 "Installing $0": [
  null,
  "$0 installeren"
 ],
 "Internal error": [
  null,
  "Interne fout"
 ],
 "Invalid": [
  null,
  "Ongeldig"
 ],
 "Invalid date format": [
  null,
  "Ongeldige datum"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ongeldige datumnotatie en ongeldige tijdnotatie"
 ],
 "Invalid file permissions": [
  null,
  "Ongeldige bestandsrechten"
 ],
 "Invalid time format": [
  null,
  "Ongeldige tijdnotatie"
 ],
 "Invalid timezone": [
  null,
  "Ongeldige tijdzone"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Join": [
  null,
  "Toetreden"
 ],
 "Join domain": [
  null,
  "Word lid van domein"
 ],
 "Joining": [
  null,
  "Toetreden"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Lid worden van een domein vereist de installatie van realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Deelnemen aan dit domein wordt niet ondersteund"
 ],
 "Joins namespace of": [
  null,
  "Word lid van de naamruimte van"
 ],
 "Journal": [
  null,
  "Logboek"
 ],
 "Journal entry": [
  null,
  "Logboekingang"
 ],
 "Journal entry not found": [
  null,
  "Logboekingang werd niet gevonden"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Key password": [
  null,
  "Sleutelwachtwoord"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY met Active Directory-interoperabiliteit."
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last 24 hours": [
  null,
  "Laatste 24 uur"
 ],
 "Last 7 days": [
  null,
  "Laatste 7 dagen"
 ],
 "Last successful login:": [
  null,
  "Laatste succesvolle aanmelding:"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "Leave $0": [
  null,
  "Verlaat $0"
 ],
 "Leave domain": [
  null,
  "Verlaat domein"
 ],
 "Light": [
  null,
  "Licht"
 ],
 "Limits": [
  null,
  "Grenzen"
 ],
 "Linked": [
  null,
  "Gekoppeld"
 ],
 "Listen": [
  null,
  "Luisteren"
 ],
 "Listing units": [
  null,
  "Eenheden weergeven"
 ],
 "Listing units failed: $0": [
  null,
  "Eenheden weergeven mislukte: $0"
 ],
 "Load earlier entries": [
  null,
  "Laad eerdere ingangen"
 ],
 "Loading keys...": [
  null,
  "Sleutels laden..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Het laden van SSH-sleutels is mislukt"
 ],
 "Loading of units failed": [
  null,
  "Het laden van eenheden mislukte"
 ],
 "Loading system modifications...": [
  null,
  "Systeemwijzigingen laden..."
 ],
 "Loading unit failed": [
  null,
  "Het laden van unit mislukte"
 ],
 "Loading...": [
  null,
  "Laden..."
 ],
 "Log in": [
  null,
  "Inloggen"
 ],
 "Log in to $0": [
  null,
  "Log in op $0"
 ],
 "Log messages": [
  null,
  "Log berichten"
 ],
 "Login failed": [
  null,
  "Inloggen mislukte"
 ],
 "Login format": [
  null,
  "Inlogformaat"
 ],
 "Logs": [
  null,
  "Logboeken"
 ],
 "Low profile desktop": [
  null,
  "Laag profiel bureaublad"
 ],
 "Lunch box": [
  null,
  "Lunchbox"
 ],
 "Machine ID": [
  null,
  "Machine-ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Machine SSH-sleutel vingerafdrukken"
 ],
 "Main server chassis": [
  null,
  "Hoofdserverchassis"
 ],
 "Maintenance": [
  null,
  "Onderhoud"
 ],
 "Manage storage": [
  null,
  "Beheerde opslag"
 ],
 "Manually": [
  null,
  "Handmatig"
 ],
 "Mask service": [
  null,
  "Masker service"
 ],
 "Masked": [
  null,
  "Gemaskeerd"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Service maskeren voorkomt dat alle afhankelijke eenheden worden uitgevoerd. Dit kan een grotere impact hebben dan verwacht. Bevestig dat je deze eenheid wilt maskeren."
 ],
 "Memory": [
  null,
  "Geheugen"
 ],
 "Memory technology": [
  null,
  "Geheugen technologie"
 ],
 "Merged": [
  null,
  "Samengevoegd"
 ],
 "Message to logged in users": [
  null,
  "Bericht aan ingelogde gebruikers"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minuut moet een getal tussen 0-59 zijn"
 ],
 "Minutely": [
  null,
  "Per minuut"
 ],
 "Minutes": [
  null,
  "Minuten"
 ],
 "Mitigations": [
  null,
  "Beperkende factoren"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Mondays": [
  null,
  "maandagen"
 ],
 "Monthly": [
  null,
  "Maandelijks"
 ],
 "Multi-system chassis": [
  null,
  "Chassis met meerdere systemen"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Need at least one NTP server": [
  null,
  "Minimaal één NTP-server nodig"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "New password was not accepted": [
  null,
  "Nieuw wachtwoord is niet geaccepteerd"
 ],
 "No": [
  null,
  "Nee"
 ],
 "No delay": [
  null,
  "Geen vertraging"
 ],
 "No host keys found.": [
  null,
  "Geen hostsleutels gevonden ."
 ],
 "No log entries": [
  null,
  "Geen logboekvermeldingen"
 ],
 "No logs found": [
  null,
  "Geen logs gevonden"
 ],
 "No matching results": [
  null,
  "Geen overeenkomende resultaten"
 ],
 "No results found": [
  null,
  "Geen resultaten gevonden"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Geen resultaten komen overeen met de filtercriteria. Wis alle filters om resultaten weer te geven."
 ],
 "No rule hits": [
  null,
  "Geen regeltreffers"
 ],
 "No such file or directory": [
  null,
  "Bestand of map bestaat niet"
 ],
 "No system modifications": [
  null,
  "Geen systeemwijzigingen"
 ],
 "None": [
  null,
  "Geen"
 ],
 "Not a valid private key": [
  null,
  "Geen geldige privésleutel"
 ],
 "Not connected to Insights": [
  null,
  "Niet verbonden met Insights"
 ],
 "Not found": [
  null,
  "Niet gevonden"
 ],
 "Not permitted to configure realms": [
  null,
  "Het is niet toegestaan om realms te configureren"
 ],
 "Not permitted to perform this action.": [
  null,
  "Niet toegestaan om deze actie uit te voeren."
 ],
 "Not running": [
  null,
  "Niet actief"
 ],
 "Not synchronized": [
  null,
  "Niet gesynchroniseerd"
 ],
 "Note": [
  null,
  "Notitie"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Kennisgeving en hoger"
 ],
 "Occurrences": [
  null,
  "Voorvallen"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Oude wachtwoord niet geaccepteerd"
 ],
 "On failure": [
  null,
  "Bij mislukking"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Nadat Cockpit geïnstalleerd is, schakel je het in met \"systemctl enable --now cockpit.socket\"."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Alleen letters, cijfers, : , _ , . , @ , - zijn toegestaan"
 ],
 "Only emergency": [
  null,
  "Alleen noodgevallen"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Gebruik alleen goedgekeurde en toegestane algoritmen bij het opstarten in FIPS-modus."
 ],
 "Other": [
  null,
  "Andere"
 ],
 "Overview": [
  null,
  "Overzicht"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "Part of": [
  null,
  "Onderdeel van"
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Password is not acceptable": [
  null,
  "Wachtwoord is niet acceptabel"
 ],
 "Password is too weak": [
  null,
  "Wachtwoord is te zwak"
 ],
 "Password not accepted": [
  null,
  "Wachtwoord wordt niet geaccepteerd"
 ],
 "Paste": [
  null,
  "Plakken"
 ],
 "Paste error": [
  null,
  "Plakfout"
 ],
 "Path": [
  null,
  "Pad"
 ],
 "Path to file": [
  null,
  "Pad naar bestand"
 ],
 "Paths": [
  null,
  "Paden"
 ],
 "Pause": [
  null,
  "Pauze"
 ],
 "Performance profile": [
  null,
  "Prestatieprofiel"
 ],
 "Peripheral chassis": [
  null,
  "Randchassis"
 ],
 "Pick date": [
  null,
  "Kies datum"
 ],
 "Pin unit": [
  null,
  "Pin-eenheid"
 ],
 "Pinned unit": [
  null,
  "Vastgezette eenheid"
 ],
 "Pizza box": [
  null,
  "Pizzadoos"
 ],
 "Portable": [
  null,
  "Draagbaar"
 ],
 "Present": [
  null,
  "Aanwezig"
 ],
 "Pretty host name": [
  null,
  "Mooie hostnaam"
 ],
 "Previous boot": [
  null,
  "Vorige opstart"
 ],
 "Priority": [
  null,
  "Prioriteit"
 ],
 "Problem details": [
  null,
  "Probleemdetails"
 ],
 "Problem info": [
  null,
  "Probleem info"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Vragen via ssh-add is verlopen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Vragen ssh-keygen is verlopen"
 ],
 "Propagates reload to": [
  null,
  "Propageren herladen naar"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Beschermt tegen verwachte toekomstige aanvallen op korte termijn ten koste van interoperabiliteit."
 ],
 "RAID chassis": [
  null,
  "RAID-chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rackmontagechassis"
 ],
 "Rank": [
  null,
  "Rang"
 ],
 "Read more...": [
  null,
  "Lees meer..."
 ],
 "Read-only": [
  null,
  "Alleen-lezen"
 ],
 "Real host name": [
  null,
  "Echte hostnaam"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Echte hostnaam mag alleen kleine letters, cijfers, streepjes en punten bevatten (met bevolkte subdomeinen)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Echte hostnaam moet 64 tekens of minder bevatten"
 ],
 "Reapply and reboot": [
  null,
  "Opnieuw toepassen en opnieuw opstarten"
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Aanbevolen, veilige instellingen voor huidige dreigingsmodellen."
 ],
 "Reload": [
  null,
  "Opnieuw laden"
 ],
 "Reload propagated from": [
  null,
  "Opnieuw laden gepropageerd van"
 ],
 "Reloading": [
  null,
  "Opnieuw laden"
 ],
 "Removals:": [
  null,
  "Verwijderingen:"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "Removing $0": [
  null,
  "$0 verwijderen"
 ],
 "Repeat": [
  null,
  "Herhaal"
 ],
 "Repeat monthly": [
  null,
  "Maandelijks herhalen"
 ],
 "Repeat weekly": [
  null,
  "Wekelijks herhalen"
 ],
 "Report": [
  null,
  "Rapport"
 ],
 "Report to ABRT Analytics": [
  null,
  "Rapporteer aan ABRT Analytics"
 ],
 "Reported; no links available": [
  null,
  "Gerapporteerd; geen links beschikbaar"
 ],
 "Reporting failed": [
  null,
  "Rapportage mislukte"
 ],
 "Reporting was canceled": [
  null,
  "Rapportage is geannuleerd"
 ],
 "Reports:": [
  null,
  "Rapporten:"
 ],
 "Required by": [
  null,
  "Vereist door"
 ],
 "Required by ": [
  null,
  "Vereist door "
 ],
 "Requires": [
  null,
  "Vereisten"
 ],
 "Requires administration access to edit": [
  null,
  "Vereist beheerdersrechten om te bewerken"
 ],
 "Requisite": [
  null,
  "Vereiste"
 ],
 "Requisite of": [
  null,
  "Vereiste van"
 ],
 "Reset": [
  null,
  "Reset"
 ],
 "Restart": [
  null,
  "Opnieuw starten"
 ],
 "Resume": [
  null,
  "Samenvatten"
 ],
 "Review cryptographic policy": [
  null,
  "Bekijk cryptografisch beleid"
 ],
 "Run at": [
  null,
  "Uitvoeren op"
 ],
 "Run on": [
  null,
  "Uitvoeren op"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Voer deze opdracht uit via een vertrouwd netwerk of fysiek op de externe machine:"
 ],
 "Running": [
  null,
  "Uitvoeren"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-sleutel"
 ],
 "Saturdays": [
  null,
  "zaterdagen"
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "Save and reboot": [
  null,
  "Opslaan en opnieuw opstarten"
 ],
 "Save changes": [
  null,
  "Sla veranderingen op"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Geplande uitschakeling om $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Geplande herstart om $0"
 ],
 "Sealed-case PC": [
  null,
  "Gesloten PC"
 ],
 "Search": [
  null,
  "Zoeken"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Seconde moet een getal tussen 0-59 zijn"
 ],
 "Seconds": [
  null,
  "Seconden"
 ],
 "Secure shell keys": [
  null,
  "Veilige shell-sleutels"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux configuratie en probleemoplossing"
 ],
 "Send": [
  null,
  "Zenden"
 ],
 "Server has closed the connection.": [
  null,
  "Server heeft de verbinding verbroken."
 ],
 "Server software": [
  null,
  "Server software"
 ],
 "Service logs": [
  null,
  "Servicelogboeken"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Set hostname": [
  null,
  "Stel hostnaam in"
 ],
 "Set time": [
  null,
  "Stel tijd in"
 ],
 "Shell script": [
  null,
  "Shell-script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Toon alle threads"
 ],
 "Show confirmation password": [
  null,
  "Bevestigingswachtwoord tonen"
 ],
 "Show fingerprints": [
  null,
  "Toon vingerafdrukken"
 ],
 "Show messages containing given string.": [
  null,
  "Toon berichten die een gegeven string bevatten."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Toon berichten voor de gespecificeerde systemd unit."
 ],
 "Show messages from a specific boot.": [
  null,
  "Toon berichten van een specifieke boot."
 ],
 "Show more relationships": [
  null,
  "Toon meer relaties"
 ],
 "Show password": [
  null,
  "Wachtwoord tonen"
 ],
 "Show relationships": [
  null,
  "Toon relaties"
 ],
 "Shut down": [
  null,
  "Afsluiten"
 ],
 "Shutdown": [
  null,
  "Afsluiten"
 ],
 "Since": [
  null,
  "Sinds"
 ],
 "Single rank": [
  null,
  "Enkele rang"
 ],
 "Size": [
  null,
  "Grootte"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Op software gebaseerde oplossingen helpen CPU-beveiligingsproblemen te voorkomen. Deze mitigaties hebben als neveneffect dat ze de prestaties verminderen. Wijzig deze instellingen op eigen risico."
 ],
 "Space-saving computer": [
  null,
  "Ruimtebesparende computer"
 ],
 "Specific time": [
  null,
  "Specifieke tijd"
 ],
 "Speed": [
  null,
  "Snelheid"
 ],
 "Start": [
  null,
  "Start"
 ],
 "Start and enable": [
  null,
  "Start en schakel in"
 ],
 "Start service": [
  null,
  "Start service"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Begin met het weergeven van ingangen op of nieuwer dan de opgegeven datum."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Begin met het weergeven van ingangen op of ouder dan de opgegeven datum."
 ],
 "State": [
  null,
  "Toestand"
 ],
 "Static": [
  null,
  "Statisch"
 ],
 "Status": [
  null,
  "Toestand"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Stop"
 ],
 "Stop and disable": [
  null,
  "Stop en schakel uit"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Strong password": [
  null,
  "Sterk wachtwoord"
 ],
 "Stub": [
  null,
  "Stuk"
 ],
 "Sub-Chassis": [
  null,
  "Sub-chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Abonneren op systemd-signalen is mislukt: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Succesvol naar het klembord gekopieerd"
 ],
 "Sundays": [
  null,
  "zondagen"
 ],
 "Synchronized": [
  null,
  "Gesynchroniseerd"
 ],
 "Synchronized with $0": [
  null,
  "Gesynchroniseerd met $0"
 ],
 "Synchronizing": [
  null,
  "Synchroniseren"
 ],
 "System": [
  null,
  "Systeem"
 ],
 "System information": [
  null,
  "Systeeminformatie"
 ],
 "System time": [
  null,
  "Systeemtijd"
 ],
 "Systemd units": [
  null,
  "Systemd units"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Doelen"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "De SSH-sleutel $0 van $1 op $2 zal worden toegevoegd aan het $3 bestand van $4 op $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "De SSH-sleutel $0 zal beschikbaar worden gesteld voor de rest van de sessie en zal ook beschikbaar zijn om in te loggen bij andere hosts."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd met een wachtwoord en de host staat inloggen met een wachtwoord niet toe. Geef het wachtwoord van de sleutel op $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd. Je kunt inloggen met je inlogwachtwoord of door het wachtwoord van de sleutel op te geven op $1."
 ],
 "The fingerprint should match:": [
  null,
  "De vingerafdruk moet overeenkomen met:"
 ],
 "The key password can not be empty": [
  null,
  "Het sleutelwachtwoord mag niet leeg zijn"
 ],
 "The key passwords do not match": [
  null,
  "De sleutelwachtwoorden komen niet overeen"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "De ingelogde gebruiker mag geen systeemwijzigingen bekijken"
 ],
 "The password can not be empty": [
  null,
  "Het wachtwoord mag niet leeg zijn"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "De resulterende vingerafdruk is prima te delen via openbare methoden, inclusief e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "De resulterende vingerafdruk kan prima worden gedeeld via openbare methoden, waaronder e-mail. Als je iemand anders vraagt om de verificatie voor je uit te voeren, kan hij of zij de resultaten op elke gewenste manier verzenden."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "De server weigerde te verifiëren met behulp van ondersteunde methoden."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Het is gebruiker $0 niet toegestaan cpu-beveiligingsmaatregelen te wijzigen"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Het is gebruiker $0 niet toegestaan om crypto-beleid te wijzigen"
 ],
 "This field cannot be empty": [
  null,
  "Dit veld mag niet leeg zijn"
 ],
 "This may take a while": [
  null,
  "Dit kan een tijdje duren"
 ],
 "This system is using a custom profile": [
  null,
  "Dit systeem gebruikt een aangepast profiel"
 ],
 "This system is using the recommended profile": [
  null,
  "Dit systeem gebruikt het aanbevolen profiel"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dit gereedschap configureert het SELinux-beleid en kan helpen bij het begrijpen en oplossen van beleidsschendingen."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dit gereedschap genereert een archief met configuratie- en diagnostische informatie van het draaiende systeem. Het archief kan lokaal of centraal worden opgeslagen voor opname- of trackingsoeleinden of kan worden verzonden naar vertegenwoordigers van de technische ondersteuning, ontwikkelaars of systeembeheerders om te helpen bij het opsporen van technische fouten en het debuggen."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dit gereedschap beheert lokale opslag, zoals bestandssystemen, LVM2-volumegroepen en NFS-koppelingen."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dit gereedschap beheert netwerken zoals bindingen, bruggen, teams, VLAN's en firewalls met behulp van NetworkManager en Firewalld. NetworkManager is niet compatibel met Ubuntu's standaard systemd-networkd en Debian's ifupdown-scripts."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Dit apparaat is niet ontworpen om expliciet te worden ingeschakeld."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Dit voegt een overeenkomst toe voor '_BOOT_ID='. Als dit niet is opgegeven, worden de logboeken voor de huidige boot weergegeven. Als de boot-ID wordt weggelaten, zoekt een positieve offset de boots op vanaf het begin van het journaal, en een offset die gelijk is aan of kleiner is dan nul, zoekt de boots op vanaf het einde van het journaal. Dus 1 betekent de eerste boot die in chronologische volgorde in het journaal wordt gevonden, 2 de tweede enzovoort; terwijl -0 de laatste keer opstarten is, -1 de opstart voor het laatst, enzovoort."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Dit voegt een overeenkomst toe voor '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' en 'UNIT=' om alle mogelijke berichten voor de gegeven eenheid te vinden. Kan meer eenheden bevatten, gescheiden door komma's. "
 ],
 "Thursdays": [
  null,
  "donderdagen"
 ],
 "Time": [
  null,
  "Tijd"
 ],
 "Time zone": [
  null,
  "Tijdzone"
 ],
 "Timer creation failed": [
  null,
  "Het aanmaken van de timer is mislukt"
 ],
 "Timer deletion failed": [
  null,
  "Het verwijderen de timer is mislukt"
 ],
 "Timers": [
  null,
  "Timers"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Controleer de vingerafdruk van de hostsleutel om ervoor te zorgen dat je verbinding niet wordt onderschept door een kwaadwillende derde partij:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Om een vingerafdruk te verifiëren, voer je het volgende uit op $0 terwijl je fysiek achter de machine zit of via een vertrouwd netwerk:"
 ],
 "Toggle date picker": [
  null,
  "Datumkiezer omschakelen"
 ],
 "Toggle filters": [
  null,
  "Schakel filters om"
 ],
 "Too much data": [
  null,
  "Teveel data"
 ],
 "Total size: $0": [
  null,
  "Totale grootte: $0"
 ],
 "Tower": [
  null,
  "Toren"
 ],
 "Transient": [
  null,
  "Kortstondig"
 ],
 "Trigger": [
  null,
  "Trigger"
 ],
 "Triggered by": [
  null,
  "Veroorzaakt door"
 ],
 "Triggers": [
  null,
  "Triggers"
 ],
 "Trust and add host": [
  null,
  "Vertrouw en voeg host toe"
 ],
 "Trying to synchronize with $0": [
  null,
  "Bezig met synchroniseren met $0"
 ],
 "Tuesdays": [
  null,
  "dinsdagen"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned kan niet gestart worden"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned is een service die je systeem bewaakt en de prestaties onder bepaalde werkbelastingen optimaliseert. De kern van Tuned zijn profielen, die je systeem afstemmen op verschillende gebruikssituaties."
 ],
 "Tuned is not available": [
  null,
  "Tuned is niet beschikbaar"
 ],
 "Tuned is not running": [
  null,
  "Tuned is niet actief"
 ],
 "Tuned is off": [
  null,
  "Tuned is uitgeschakeld"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Type to filter": [
  null,
  "Typ om te filteren"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Kan niet inloggen op $0. De host accepteert geen aanmelden met wachtwoord of een van je SSH-sleutels."
 ],
 "Unit": [
  null,
  "Unit"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Unpin unit": [
  null,
  "Eenheid vrijgeven"
 ],
 "Until": [
  null,
  "Tot"
 ],
 "Untrusted host": [
  null,
  "Niet vertrouwde host"
 ],
 "Updating status...": [
  null,
  "Status bijwerken..."
 ],
 "Usage": [
  null,
  "Gebruik"
 ],
 "User": [
  null,
  "Gebruiker"
 ],
 "Validating address": [
  null,
  "Adres valideren"
 ],
 "Vendor": [
  null,
  "Leverancier"
 ],
 "Verify fingerprint": [
  null,
  "Vingerafdruk verifiëren"
 ],
 "Version": [
  null,
  "Versie"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "View all services": [
  null,
  "Bekijk alle services"
 ],
 "View automation script": [
  null,
  "Bekijk automatiseringsscript"
 ],
 "View hardware details": [
  null,
  "Bekijk hardwaredetails"
 ],
 "View login history": [
  null,
  "Bekijk inloggeschiedenis"
 ],
 "View metrics and history": [
  null,
  "Bekijk statistieken en geschiedenis"
 ],
 "View report": [
  null,
  "Bekijk rapport"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Voor het bekijken van geheugeninformatie is beheerderstoegang vereist."
 ],
 "Visit firewall": [
  null,
  "Bezoek firewall"
 ],
 "Waiting for input…": [
  null,
  "Wachten op input…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Wachten tot andere softwarebeheerhandelingen voltooid zijn"
 ],
 "Waiting to start…": [
  null,
  "Wachten om te beginnen…"
 ],
 "Wanted by": [
  null,
  "Gezocht door"
 ],
 "Wants": [
  null,
  "Behoeften"
 ],
 "Warning and above": [
  null,
  "Waarschuwing en hoger"
 ],
 "Weak password": [
  null,
  "Zwak wachtwoord"
 ],
 "Web Console for Linux servers": [
  null,
  "Webconsole voor Linux-servers"
 ],
 "Web console is running in limited access mode.": [
  null,
  "De webconsole wordt uitgevoerd in de beperkte toegang modus."
 ],
 "Wednesdays": [
  null,
  "woensdagen"
 ],
 "Weekly": [
  null,
  "Wekelijks"
 ],
 "Weeks": [
  null,
  "Weken"
 ],
 "White": [
  null,
  "Wit"
 ],
 "Yearly": [
  null,
  "Jaarlijks"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Je maakt voor de eerste keer verbinding met $0."
 ],
 "You may try to load older entries.": [
  null,
  "Je kunt proberen oudere items te laden."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Je browser staat plakken vanuit het contextmenu niet toe. Je kunt Shift+Insert gebruiken."
 ],
 "Your session has been terminated.": [
  null,
  "Je sessie is beëindigd."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Je sessie is verlopen. Log nogmaals in."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "active": [
  null,
  "actief"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "kan ssh-host-sleutels niet vermelden: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "inconsistent": [
  null,
  "inconsequent"
 ],
 "journalctl manpage": [
  null,
  "journalctl manualpagina"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "geen"
 ],
 "of $0 CPU": [
  null,
  "van $0 CPU",
  "van $0 CPU's"
 ],
 "password quality": [
  null,
  "wachtwoordkwaliteit"
 ],
 "recommended": [
  null,
  "aanbevolen"
 ],
 "running $0": [
  null,
  "$0 wordt uitgevoerd"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "unknown": [
  null,
  "onbekend"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domein"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Word lid van een domein"
 ],
 "from <host>\u0004from $0": [
  null,
  "van $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "van $0 op $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "op $0"
 ]
});
