cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "システム設定の変更"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Logs": [
  null,
  "ログ"
 ],
 "Managing services": [
  null,
  "サービス管理"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Overview": [
  null,
  "概要"
 ],
 "Reviewing logs": [
  null,
  "ログのレビュー"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "サービス"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Terminal": [
  null,
  "端末"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "アセットタグ"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "BIOS"
 ],
 "boot": [
  null,
  "ブート"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "コマンド"
 ],
 "console": [
  null,
  "コンソール"
 ],
 "coredump": [
  null,
  "コアダンプ"
 ],
 "cpu": [
  null,
  "CPU"
 ],
 "crash": [
  null,
  "クラッシュ"
 ],
 "date": [
  null,
  "日付"
 ],
 "debug": [
  null,
  "デバッグ"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "無効にする"
 ],
 "disks": [
  null,
  "ディスク"
 ],
 "domain": [
  null,
  "ドメイン"
 ],
 "enable": [
  null,
  "有効にする"
 ],
 "error": [
  null,
  "エラー"
 ],
 "graphs": [
  null,
  "グラフ"
 ],
 "hardware": [
  null,
  "ハードウェア"
 ],
 "history": [
  null,
  "履歴"
 ],
 "host": [
  null,
  "ホスト"
 ],
 "journal": [
  null,
  "ジャーナル"
 ],
 "machine": [
  null,
  "マシン"
 ],
 "mask": [
  null,
  "マスク"
 ],
 "memory": [
  null,
  "メモリー"
 ],
 "metrics": [
  null,
  "メトリックス"
 ],
 "mitigation": [
  null,
  "軽減"
 ],
 "network": [
  null,
  "ネットワーク"
 ],
 "operating system": [
  null,
  "オペレーティングシステム"
 ],
 "os": [
  null,
  "OS"
 ],
 "path": [
  null,
  "パス"
 ],
 "pci": [
  null,
  "PCI"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "パフォーマンス"
 ],
 "power": [
  null,
  "電源"
 ],
 "ram": [
  null,
  "RAM"
 ],
 "restart": [
  null,
  "再起動"
 ],
 "serial": [
  null,
  "シリアル"
 ],
 "service": [
  null,
  "サービス"
 ],
 "shell": [
  null,
  "シェル"
 ],
 "shut": [
  null,
  "シャット"
 ],
 "socket": [
  null,
  "ソケット"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "ターゲット"
 ],
 "time": [
  null,
  "時間"
 ],
 "timer": [
  null,
  "タイマー"
 ],
 "unit": [
  null,
  "単位"
 ],
 "unmask": [
  null,
  "マスク解除"
 ],
 "version": [
  null,
  "バージョン"
 ],
 "warning": [
  null,
  "警告"
 ]
});
