cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "$0 critical hit": [
  null,
  "$0 kritisk treff",
  "$0 treff, inkludert kritiske"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dager"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avsluttet med koden $1"
 ],
 "$0 failed": [
  null,
  "$0 feilet"
 ],
 "$0 hour": [
  null,
  "$0 time",
  "$0 timer"
 ],
 "$0 important hit": [
  null,
  "$0 viktig treff",
  "$0 viktige treff"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 er ikke tilgjengelig fra noe depot."
 ],
 "$0 key changed": [
  null,
  "$0 nøkkel endret"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 drept med signal $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 treff med lav alvorlighetsgrad",
  "$0 treff med lave alvorlighetsgrader"
 ],
 "$0 minute": [
  null,
  "$0 minutt",
  "$0 minutter"
 ],
 "$0 moderate hit": [
  null,
  "$0 moderat treff",
  "$0 moderate treff"
 ],
 "$0 month": [
  null,
  "$0 måned",
  "$0 måneder"
 ],
 "$0 service has failed": [
  null,
  "$0 tjeneste har feilet",
  "$0 tjenester har feilet"
 ],
 "$0 week": [
  null,
  "$0 uke",
  "$0 uker"
 ],
 "$0 will be installed.": [
  null,
  "$0 vil bli installert."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$0: crash at $1": [
  null,
  "$0: krasj på $1"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 time"
 ],
 "1 minute": [
  null,
  "1 minutt"
 ],
 "1 week": [
  null,
  "1 uke"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 minutter"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 minutter"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 minutter"
 ],
 "5th": [
  null,
  "5."
 ],
 "6 hours": [
  null,
  "6 timer"
 ],
 "60 minutes": [
  null,
  "60 minutter"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "Absent": [
  null,
  "Fraværende"
 ],
 "Active since ": [
  null,
  "Aktiv siden "
 ],
 "Add": [
  null,
  "Legg til"
 ],
 "Add $0": [
  null,
  "Legg til $0"
 ],
 "Additional actions": [
  null,
  "Ekstra handlinger"
 ],
 "Additional packages:": [
  null,
  "Ekstra pakker:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrasjon med Cockpit Web konsoll"
 ],
 "Advanced TCA": [
  null,
  "Avansert TCA"
 ],
 "After": [
  null,
  "Etter"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Etter å ha forlatt domenet, er det bare brukere med lokal legitimasjon som kan logge på denne maskinen. Dette kan også påvirke andre tjenester ettersom innstillinger for DNS-oppløsning og listen over klarerte CAer kan endres."
 ],
 "After system boot": [
  null,
  "Etter systemstart"
 ],
 "Alert and above": [
  null,
  "Varsel og over"
 ],
 "Alias": [
  null,
  ""
 ],
 "All": [
  null,
  "Alle"
 ],
 "All-in-one": [
  null,
  "Alt i ett"
 ],
 "Allow running (unmask)": [
  null,
  "Tillat å kjøre (umaskert)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible roller dokumentasjon"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  ""
 ],
 "Appearance": [
  null,
  "Utseende"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  ""
 ],
 "Asset tag": [
  null,
  "Eiendomsmerke"
 ],
 "At specific time": [
  null,
  "På et bestemt tidspunkt"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering er nødvendig for å utføre privilegerte oppgaver med Cockpit Web konsoll"
 ],
 "Automatically starts": [
  null,
  "Starter automatisk"
 ],
 "Automatically using NTP": [
  null,
  "Automatisk med bruk av NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisk med bruk av spesifikke NTP servere"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS dato"
 ],
 "BIOS version": [
  null,
  "BIOS versjon"
 ],
 "Before": [
  null,
  "Før"
 ],
 "Binds to": [
  null,
  "Binder seg til"
 ],
 "Black": [
  null,
  "Svart"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Blad-kabinett"
 ],
 "Boot": [
  null,
  ""
 ],
 "Bound by": [
  null,
  "Bundet av"
 ],
 "Bus expansion chassis": [
  null,
  ""
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU-sikkerhet"
 ],
 "CPU security toggles": [
  null,
  ""
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Finner ingen logger med den nåværende kombinasjonen av filtre."
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cancel poweroff": [
  null,
  ""
 ],
 "Cannot be enabled": [
  null,
  "Kan ikke aktiveres"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan ikke videresende påloggingsinformasjonen"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Kan ikke bli med i et domene fordi realmd ikke er tilgjengelig på dette systemet"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan ikke tidsplanlegge hendelse i fortiden"
 ],
 "Change": [
  null,
  "Endre"
 ],
 "Change host name": [
  null,
  "Endre vertsnavn"
 ],
 "Change performance profile": [
  null,
  "Endre ytelsesprofil"
 ],
 "Change profile": [
  null,
  "Endre profil"
 ],
 "Change system time": [
  null,
  "Endre systemtid"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Endrede nøkler er ofte resultatet av reinstallering av operativsystemet. Imidlertid kan en uventet endring indikere et tredjepartsforsøk på å fange opp forbindelsen din."
 ],
 "Checking installed software": [
  null,
  "Kontrollerer installert programvare"
 ],
 "Class": [
  null,
  "Klasse"
 ],
 "Clear 'Failed to start'": [
  null,
  "Fjern 'Kunne ikke starte'"
 ],
 "Clear all filters": [
  null,
  "Fjern alle filtre"
 ],
 "Client software": [
  null,
  "Klient programvare"
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  ""
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunne ikke kontakte den angitte verten."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit er en serveradministrator som gjør det enkelt å administrere Linux-serverne dine via en nettleser. Å bytte mellom terminalen og nettverktøyet er ikke noe problem. En tjeneste startet via Cockpit kan stoppes via terminalen. På samme måte, hvis det oppstår en feil i terminalen, kan den sees i Cockpit journal-grensesnittet."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit er ikke kompatibel med programvaren på systemet."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit er ikke installert"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit er ikke installert på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit er perfekt for nye sysadminer, slik at de enkelt kan utføre enkle oppgaver som lagringsadministrasjon, inspisere journaler og starte og stoppe tjenester. Du kan overvåke og administrere flere servere samtidig. Bare legg dem til med et enkelt klikk, så vil maskinene dine se etter kompisene."
 ],
 "Collect and package diagnostic and support data": [
  null,
  ""
 ],
 "Command": [
  null,
  "Kommando"
 ],
 "Communication with tuned has failed": [
  null,
  "Kommunikasjonen med tuned feilet"
 ],
 "Compact PCI": [
  null,
  ""
 ],
 "Condition $0=$1 was not met": [
  null,
  "Betingelse $0=$1 ble ikke oppfylt"
 ],
 "Condition failed": [
  null,
  "Betingelse feilet"
 ],
 "Configuration": [
  null,
  "Konfigurasjon"
 ],
 "Confirm key password": [
  null,
  "Bekreft nøkkel-passord"
 ],
 "Conflicted by": [
  null,
  ""
 ],
 "Conflicts": [
  null,
  "Konflikter"
 ],
 "Connection has timed out.": [
  null,
  "Tidsavbrudd for tilkoblingen."
 ],
 "Consists of": [
  null,
  "Består av"
 ],
 "Contacted domain": [
  null,
  "Kontaktet domene"
 ],
 "Convertible": [
  null,
  "Konverterbar"
 ],
 "Copied": [
  null,
  ""
 ],
 "Copy": [
  null,
  "Kopier"
 ],
 "Copy to clipboard": [
  null,
  "Kopier til utklippstavle"
 ],
 "Crash reporting": [
  null,
  "Krasjrapportering"
 ],
 "Create new task file with this content.": [
  null,
  "Opprett ny oppgavefil med dette innholdet."
 ],
 "Create timer": [
  null,
  "Lag timer"
 ],
 "Critical and above": [
  null,
  "Kritisk og over"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  ""
 ],
 "Cryptographic policy is inconsistent": [
  null,
  ""
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Nåværende oppstart"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  ""
 ],
 "Daily": [
  null,
  "Daglig"
 ],
 "Dark": [
  null,
  "Mørk"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  ""
 ],
 "Debug and above": [
  null,
  "Debug og over"
 ],
 "Decrease by one": [
  null,
  "Reduser med en"
 ],
 "Default": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Forsinkelse"
 ],
 "Delete": [
  null,
  "Slett"
 ],
 "Deletion will remove the following files:": [
  null,
  ""
 ],
 "Description": [
  null,
  "Beskrivelse"
 ],
 "Desktop": [
  null,
  ""
 ],
 "Detachable": [
  null,
  ""
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Deaktiver samtidig multitråding"
 ],
 "Disable tuned": [
  null,
  "Deaktiver tuned"
 ],
 "Disabled": [
  null,
  "Deaktivert"
 ],
 "Disallow running (mask)": [
  null,
  "Ikke tillat å kjøre (masker)"
 ],
 "Docking station": [
  null,
  "Dokkingstasjon"
 ],
 "Does not automatically start": [
  null,
  "Starter ikke automatisk"
 ],
 "Domain": [
  null,
  "Domene"
 ],
 "Domain address": [
  null,
  "Domene adresse"
 ],
 "Domain administrator name": [
  null,
  "Domene administratornavn"
 ],
 "Domain administrator password": [
  null,
  "Domeneadministrator passord"
 ],
 "Don't repeat": [
  null,
  "Ikke gjenta"
 ],
 "Downloading $0": [
  null,
  "Laster ned $0"
 ],
 "Dual rank": [
  null,
  "Dobbel rangering"
 ],
 "Edit /etc/motd": [
  null,
  "Rediger /etc/motd"
 ],
 "Edit motd": [
  null,
  "Rediger motd"
 ],
 "Embedded PC": [
  null,
  "Innebygd PC"
 ],
 "Enabled": [
  null,
  "Aktivert"
 ],
 "Entry at $0": [
  null,
  "Oppføring på $0"
 ],
 "Error": [
  null,
  "Feil"
 ],
 "Error and above": [
  null,
  "Feil og over"
 ],
 "Error message": [
  null,
  "Feilmelding"
 ],
 "Excellent password": [
  null,
  "Utmerket passord"
 ],
 "Expansion chassis": [
  null,
  ""
 ],
 "Extended information": [
  null,
  "Utvidet informasjon"
 ],
 "FIPS is not properly enabled": [
  null,
  ""
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  ""
 ],
 "Failed to change password": [
  null,
  "Kunne ikke endre passord"
 ],
 "Failed to disable tuned": [
  null,
  "Kunne ikke deaktivere tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Kunne ikke aktivere tuned"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Kunne ikke lagre endringene i /etc/motd"
 ],
 "Failed to start": [
  null,
  "Kunne ikke starte"
 ],
 "Failed to switch profile": [
  null,
  "Kunne ikke bytte profil"
 ],
 "Filter by name or description": [
  null,
  "Filtrer etter navn eller beskrivelse"
 ],
 "Font size": [
  null,
  "Skriftstørrelse"
 ],
 "Forbidden from running": [
  null,
  "Forbudt å kjøre"
 ],
 "Frame number": [
  null,
  ""
 ],
 "Fridays": [
  null,
  "Fredager"
 ],
 "General": [
  null,
  "Generelt"
 ],
 "Go to $0": [
  null,
  "Gå til $0"
 ],
 "Go to now": [
  null,
  "Gå til nå"
 ],
 "Handheld": [
  null,
  "Håndholdt"
 ],
 "Hardware information": [
  null,
  "Maskinvareinformasjon"
 ],
 "Health": [
  null,
  "Helse"
 ],
 "Help": [
  null,
  "Hjelp"
 ],
 "Hierarchy ID": [
  null,
  ""
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  ""
 ],
 "Host key is incorrect": [
  null,
  "Vertsnøkkelen er feil"
 ],
 "Hostname": [
  null,
  "Vertsnavn"
 ],
 "Hourly": [
  null,
  "Hver time"
 ],
 "Hours": [
  null,
  "Timer"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identifikator"
 ],
 "Increase by one": [
  null,
  "Øk med en"
 ],
 "Info and above": [
  null,
  "Info og over"
 ],
 "Insights: ": [
  null,
  "Innsikt: "
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install software": [
  null,
  "Installer programvare"
 ],
 "Installing $0": [
  null,
  "Installerer $0"
 ],
 "Internal error": [
  null,
  "Intern feil"
 ],
 "Invalid date format": [
  null,
  "Ugyldig datoformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ugyldig datoformat og ugyldig tidsformat"
 ],
 "Invalid file permissions": [
  null,
  "Ugyldige filtillatelser"
 ],
 "Invalid time format": [
  null,
  "Ugyldig tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Ugyldig tidssone"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Join": [
  null,
  "Bli med"
 ],
 "Join domain": [
  null,
  "Bli med i domene"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Å bli med i et domene krever installasjon av realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Å bli med i dette domenet støttes ikke"
 ],
 "Joins namespace of": [
  null,
  ""
 ],
 "Journal": [
  null,
  "Journal"
 ],
 "Journal entry": [
  null,
  "Journaloppføring"
 ],
 "Journal entry not found": [
  null,
  "Journaloppføring ikke funnet"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Key password": [
  null,
  "Nøkkel-passord"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  ""
 ],
 "Laptop": [
  null,
  ""
 ],
 "Last 24 hours": [
  null,
  "Siste 24 timer"
 ],
 "Last 7 days": [
  null,
  "Siste 7 dager"
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "Leave domain": [
  null,
  "Forlat domene"
 ],
 "Light": [
  null,
  "Lys"
 ],
 "Linked": [
  null,
  ""
 ],
 "Load earlier entries": [
  null,
  "Last tidligere oppføringer"
 ],
 "Loading keys...": [
  null,
  "Laster nøkler..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Lasting av SSH-nøkler feilet"
 ],
 "Loading system modifications...": [
  null,
  "Laster inn systemendringer ..."
 ],
 "Loading...": [
  null,
  "Laster..."
 ],
 "Log in": [
  null,
  "Logg inn"
 ],
 "Log messages": [
  null,
  "Logg meldinger"
 ],
 "Login failed": [
  null,
  "Innlogging feilet"
 ],
 "Login format": [
  null,
  ""
 ],
 "Logs": [
  null,
  "Logger"
 ],
 "Low profile desktop": [
  null,
  ""
 ],
 "Lunch box": [
  null,
  "Lunsjboks"
 ],
 "Machine ID": [
  null,
  "Maskin ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Fingeravtrykk for maskinens SSH-nøkler"
 ],
 "Main server chassis": [
  null,
  ""
 ],
 "Manually": [
  null,
  "Manuelt"
 ],
 "Mask service": [
  null,
  "Masker tjeneste"
 ],
 "Masked": [
  null,
  "Maskert"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Maskering av en tjeneste forhindrer alle avhengige enheter fra å kjøre. Dette kan ha større innvirkning enn forventet. Vennligst bekreft at du vil maskere denne enheten."
 ],
 "Memory": [
  null,
  "Minne"
 ],
 "Memory technology": [
  null,
  "Minneteknologi"
 ],
 "Merged": [
  null,
  ""
 ],
 "Message to logged in users": [
  null,
  "Melding til innloggede brukere"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  ""
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minutt må være et tall mellom 0-59"
 ],
 "Minutes": [
  null,
  "Minutter"
 ],
 "Mitigations": [
  null,
  ""
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Mondays": [
  null,
  "Mandager"
 ],
 "Monthly": [
  null,
  "Månedlig"
 ],
 "Multi-system chassis": [
  null,
  ""
 ],
 "NTP server": [
  null,
  "NTP Server"
 ],
 "Name": [
  null,
  "Navn"
 ],
 "Need at least one NTP server": [
  null,
  "Trenger minst en NTP-server"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "New password was not accepted": [
  null,
  "Nytt passord ble ikke godtatt"
 ],
 "No": [
  null,
  "Nei"
 ],
 "No delay": [
  null,
  "Ingen forsinkelse"
 ],
 "No host keys found.": [
  null,
  "Ingen vertsnøkler funnet."
 ],
 "No log entries": [
  null,
  "Ingen loggoppføringer"
 ],
 "No logs found": [
  null,
  "Ingen logger funnet"
 ],
 "No matching results": [
  null,
  "Ingen samsvarende resultater"
 ],
 "No results found": [
  null,
  "Ingen resultater funnet"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Ingen resultater samsvarer med filterkriteriene. Fjern alle filtre for å vise resultater."
 ],
 "No rule hits": [
  null,
  "Ingen regel treff"
 ],
 "No such file or directory": [
  null,
  "Ingen slik fil eller katalog"
 ],
 "No system modifications": [
  null,
  "Ingen systemendringer"
 ],
 "None": [
  null,
  "Ingen"
 ],
 "Not a valid private key": [
  null,
  "Ikke en gyldig privat nøkkel"
 ],
 "Not connected to Insights": [
  null,
  "Ikke koblet til Insights"
 ],
 "Not found": [
  null,
  "Ikke funnet"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ikke tillatt å utføre denne handlingen."
 ],
 "Not running": [
  null,
  "Kjører ikke"
 ],
 "Not synchronized": [
  null,
  "Ikke synkronisert"
 ],
 "Note": [
  null,
  "Notat"
 ],
 "Notebook": [
  null,
  ""
 ],
 "Notice and above": [
  null,
  "Notis og over"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Gammelt passord aksepteres ikke"
 ],
 "On failure": [
  null,
  "Ved feil"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Når Cockpit er installert, kan den aktiveres med \"systemctl enable --now cockpit.socket\"."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Bare biokstaver, tall,:, _,. , @ , - er tillatt"
 ],
 "Only emergency": [
  null,
  "Bare nødsituasjon"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  ""
 ],
 "Other": [
  null,
  "Annen"
 ],
 "Overview": [
  null,
  "Oversikt"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit krasjet"
 ],
 "Part of": [
  null,
  "Del av"
 ],
 "Password": [
  null,
  "Passord"
 ],
 "Password is not acceptable": [
  null,
  "Passord er ikke akseptabelt"
 ],
 "Password is too weak": [
  null,
  "Passordet er for svakt"
 ],
 "Password not accepted": [
  null,
  "Passord ikke akseptert"
 ],
 "Paste": [
  null,
  "Lim inn"
 ],
 "Path": [
  null,
  "Sti"
 ],
 "Path to file": [
  null,
  "Sti til fil"
 ],
 "Paths": [
  null,
  "Stier"
 ],
 "Pause": [
  null,
  "Pause"
 ],
 "Performance profile": [
  null,
  "Ytelsesprofil"
 ],
 "Peripheral chassis": [
  null,
  "Perifert chassis"
 ],
 "Pick date": [
  null,
  "Velg dato"
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "Pizzaboks"
 ],
 "Portable": [
  null,
  "Bærbar"
 ],
 "Present": [
  null,
  "Til stede"
 ],
 "Pretty host name": [
  null,
  "\"Pent\" vertsnavn"
 ],
 "Previous boot": [
  null,
  "Forrige oppstart"
 ],
 "Priority": [
  null,
  "Prioritet"
 ],
 "Problem details": [
  null,
  "Problemdetaljer"
 ],
 "Problem info": [
  null,
  "Problem info"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Spørring via ssh-add ble tidsavbrutt"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Spørring via ssh-keygen ble tidsavbrutt"
 ],
 "Propagates reload to": [
  null,
  "Videreformidler omlasting til"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "RAID chassis"
 ],
 "Rack mount chassis": [
  null,
  ""
 ],
 "Rank": [
  null,
  ""
 ],
 "Read more...": [
  null,
  "Les mer…"
 ],
 "Read-only": [
  null,
  "Skrivebeskyttet"
 ],
 "Real host name": [
  null,
  "Faktisk vertsnavn"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Faktisk vertsnavn kan bare inneholde små bokstaver, sifre, bindestreker og punktum (med befolket underdomener)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Faktisk vertsnavn må være på 64 tegn eller mindre"
 ],
 "Reboot": [
  null,
  "Omstart"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  ""
 ],
 "Reload": [
  null,
  "Last på nytt"
 ],
 "Reload propagated from": [
  null,
  "Last videreformidlet fra"
 ],
 "Removals:": [
  null,
  ""
 ],
 "Remove": [
  null,
  "Fjern"
 ],
 "Removing $0": [
  null,
  "Fjerner $0"
 ],
 "Repeat": [
  null,
  "Gjenta"
 ],
 "Repeat monthly": [
  null,
  "Gjenta månedlig"
 ],
 "Repeat weekly": [
  null,
  "Gjenta ukentlig"
 ],
 "Report": [
  null,
  "Rapport"
 ],
 "Report to ABRT Analytics": [
  null,
  "Rapporter til ABRT Analytics"
 ],
 "Reported; no links available": [
  null,
  "Rapportert; ingen lenker tilgjengelig"
 ],
 "Reporting failed": [
  null,
  "Rapportering feilet"
 ],
 "Reporting was canceled": [
  null,
  "Rapportering ble kansellert"
 ],
 "Reports:": [
  null,
  "Rapporter:"
 ],
 "Required by": [
  null,
  "Kreves av"
 ],
 "Required by ": [
  null,
  "Kreves av "
 ],
 "Requires": [
  null,
  "Krever"
 ],
 "Requires administration access to edit": [
  null,
  "Krever administrasjonstilgang for å redigere"
 ],
 "Requisite": [
  null,
  "Nødvendig"
 ],
 "Requisite of": [
  null,
  ""
 ],
 "Reset": [
  null,
  "Tilbakestill"
 ],
 "Restart": [
  null,
  "Omstart"
 ],
 "Resume": [
  null,
  "Gjenoppta"
 ],
 "Run at": [
  null,
  ""
 ],
 "Run on": [
  null,
  ""
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Running": [
  null,
  "Kjører"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-nøkkel"
 ],
 "Saturdays": [
  null,
  "Lørdager"
 ],
 "Save": [
  null,
  "Lagre"
 ],
 "Save and reboot": [
  null,
  "Lagre og start på nytt"
 ],
 "Save changes": [
  null,
  "Lagre endringer"
 ],
 "Scheduled poweroff at $0": [
  null,
  ""
 ],
 "Scheduled reboot at $0": [
  null,
  ""
 ],
 "Sealed-case PC": [
  null,
  ""
 ],
 "Search": [
  null,
  "Søk"
 ],
 "Seconds": [
  null,
  "Sekunder"
 ],
 "Secure shell keys": [
  null,
  "Secure Shell nøkler"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Send": [
  null,
  "Send"
 ],
 "Server has closed the connection.": [
  null,
  "Serveren har lukket forbindelsen."
 ],
 "Server software": [
  null,
  "Server programvare"
 ],
 "Service logs": [
  null,
  "Tjenestelogger"
 ],
 "Services": [
  null,
  "Tjenester"
 ],
 "Set hostname": [
  null,
  "Sett vertsnavn"
 ],
 "Set time": [
  null,
  "Sett tid"
 ],
 "Shell script": [
  null,
  "Shell-skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Vis alle tråder"
 ],
 "Show fingerprints": [
  null,
  "Vis fingeravtrykk"
 ],
 "Show messages containing given string.": [
  null,
  ""
 ],
 "Show messages for the specified systemd unit.": [
  null,
  ""
 ],
 "Show messages from a specific boot.": [
  null,
  ""
 ],
 "Show more relationships": [
  null,
  ""
 ],
 "Show relationships": [
  null,
  ""
 ],
 "Shut down": [
  null,
  "Slå av"
 ],
 "Shutdown": [
  null,
  "Slå av"
 ],
 "Since": [
  null,
  ""
 ],
 "Single rank": [
  null,
  ""
 ],
 "Size": [
  null,
  "Størrelse"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  ""
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Programvarebasert løsning hjelper til med å forhindre CPU-sikkerhetsproblemer. Disse begrensningene har bivirkningen at ytelsen reduseres. Endre disse innstillingene på egen risiko."
 ],
 "Space-saving computer": [
  null,
  "Plassbesparende datamaskin"
 ],
 "Specific time": [
  null,
  "Spesifikk tid"
 ],
 "Speed": [
  null,
  "Hastighet"
 ],
 "Start": [
  null,
  "Start"
 ],
 "Start and enable": [
  null,
  "Start og aktiver"
 ],
 "Start service": [
  null,
  "Start tjenesten"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  ""
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  ""
 ],
 "State": [
  null,
  "Tilstand"
 ],
 "Static": [
  null,
  "Statisk"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  ""
 ],
 "Stop": [
  null,
  "Stopp"
 ],
 "Stop and disable": [
  null,
  "Stopp og deaktiver"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Stub": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  ""
 ],
 "Sub-Notebook": [
  null,
  ""
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  ""
 ],
 "Sundays": [
  null,
  "Søndager"
 ],
 "Synchronized": [
  null,
  "Synkronisert"
 ],
 "Synchronized with $0": [
  null,
  "Synkronisert med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserer"
 ],
 "System": [
  null,
  "System"
 ],
 "System information": [
  null,
  "Systeminformasjon"
 ],
 "System time": [
  null,
  "Systemtid"
 ],
 "Systemd units": [
  null,
  "Systemd enheter"
 ],
 "Tablet": [
  null,
  "Nettbrett"
 ],
 "Targets": [
  null,
  "Mål"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The key password can not be empty": [
  null,
  "Nøkkelpassordet kan ikke være tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nøkkelpassordene stemmer ikke overens"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den påloggede brukeren har ikke lov til å se systemendringer"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterende fingeravtrykket er greit å dele via offentlige metoder, inkludert e-post."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serveren nektet å godkjenne ved hjelp av de støttede metodene."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Brukeren $0 har ikke lov til å endre CPU-sikkerhetsreduksjoner"
 ],
 "This field cannot be empty": [
  null,
  "Dette feltet kan ikke være tomt"
 ],
 "This may take a while": [
  null,
  "Dette kan ta en stund"
 ],
 "This system is using a custom profile": [
  null,
  "Dette systemet bruker en tilpasset profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Dette systemet bruker den anbefalte profilen"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  ""
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  ""
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  ""
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  ""
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  ""
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  ""
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  ""
 ],
 "Thursdays": [
  null,
  "Torsdager"
 ],
 "Time": [
  null,
  "Tid"
 ],
 "Time zone": [
  null,
  "Tidssone"
 ],
 "Timer creation failed": [
  null,
  "Oppretting av timer feilet"
 ],
 "Timers": [
  null,
  "Timere"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "For å sikre at forbindelsen din ikke blir fanget opp av en ondsinnet tredjepart, må du verifisere vertsnøkkelens fingeravtrykk:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "For å bekrefte et fingeravtrykk, kjør følgende på $ 0 mens du sitter fysisk ved maskinen eller gjennom et pålitelig nettverk:"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "For mye data"
 ],
 "Total size: $0": [
  null,
  "Total størrelse: $0"
 ],
 "Tower": [
  null,
  ""
 ],
 "Transient": [
  null,
  ""
 ],
 "Triggered by": [
  null,
  "Utløst av"
 ],
 "Triggers": [
  null,
  "Utløsere"
 ],
 "Trust and add host": [
  null,
  ""
 ],
 "Trying to synchronize with $0": [
  null,
  "Prøver å synkronisere med $0"
 ],
 "Tuesdays": [
  null,
  "Tirsdager"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned kunne ikke starte"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned er en tjeneste som overvåker systemet ditt og optimaliserer ytelsen under visse arbeidsbelastninger. Kjernen i Tuned er profiler som justerer systemet ditt for forskjellige brukstilfeller."
 ],
 "Tuned is not available": [
  null,
  "Tuned er ikke tilgjengelig"
 ],
 "Tuned is not running": [
  null,
  "Tuned kjører ikke"
 ],
 "Tuned is off": [
  null,
  "Tuned er av"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Type to filter": [
  null,
  "Skriv for å filtrere"
 ],
 "Unit": [
  null,
  "Enhet"
 ],
 "Unknown": [
  null,
  "Ukjent"
 ],
 "Until": [
  null,
  ""
 ],
 "Untrusted host": [
  null,
  ""
 ],
 "Updating status...": [
  null,
  "Oppdaterer status ..."
 ],
 "Usage": [
  null,
  "Bruk"
 ],
 "User": [
  null,
  "Bruker"
 ],
 "Validating address": [
  null,
  "Validerer adresse"
 ],
 "Vendor": [
  null,
  "Leverandør"
 ],
 "Version": [
  null,
  "Versjon"
 ],
 "View automation script": [
  null,
  "Vis automatiseringsskript"
 ],
 "View hardware details": [
  null,
  "Se maskinvaredetaljer"
 ],
 "View report": [
  null,
  "Vis rapport"
 ],
 "Waiting for input…": [
  null,
  "Venter på input…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Venter på at andre programvareadministrasjons-operasjoner skal fullføres"
 ],
 "Waiting to start…": [
  null,
  "Venter på å starte…"
 ],
 "Wanted by": [
  null,
  "Ønsket av"
 ],
 "Wants": [
  null,
  "Ønsker"
 ],
 "Warning and above": [
  null,
  "Advarsel og over"
 ],
 "Web Console for Linux servers": [
  null,
  "Web konsoll for Linux servere"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web konsoll kjører i begrenset tilgangsmodus."
 ],
 "Wednesdays": [
  null,
  "Onsdager"
 ],
 "Weekly": [
  null,
  "Ukentlig"
 ],
 "Weeks": [
  null,
  "Uker"
 ],
 "White": [
  null,
  "Hvit"
 ],
 "Yearly": [
  null,
  "Årlig"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du kobler til $0 for første gang."
 ],
 "You may try to load older entries.": [
  null,
  "Du kan prøve å laste inn eldre oppføringer."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Økten din er avsluttet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Økten din har utløpt. Vennligst logg inn igjen."
 ],
 "Zone": [
  null,
  ""
 ],
 "[binary data]": [
  null,
  "[binære data]"
 ],
 "[no data]": [
  null,
  "[ingen data]"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "edit": [
  null,
  "rediger"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "kunne ikke liste ssh vertsnøkler: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "journalctl manpage": [
  null,
  "journalctl manpage"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "ingen"
 ],
 "of $0 CPU": [
  null,
  "av $0 CPU",
  "av $0 CPUer"
 ],
 "password quality": [
  null,
  "passordkvalitet"
 ],
 "recommended": [
  null,
  "anbefalt"
 ],
 "running $0": [
  null,
  "kjører $0"
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ],
 "unknown": [
  null,
  "ukjent"
 ]
});
