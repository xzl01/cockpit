cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "$0 critical hit": [
  null,
  "$0 კრიტიკული დარტყმა",
  "$0 დარტყმა, კრიტიკულის ჩათვლით"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 exited with code $1": [
  null,
  "$0-ის გამოსვლის კოდია $1"
 ],
 "$0 failed": [
  null,
  "$0 წარუმატებელია"
 ],
 "$0 failed login attempt": [
  null,
  "შესვლის $0 წარუმატებელი მცდელობა",
  "შესვლის $0 ცალი წარუმატებელი მცდელობა"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 important hit": [
  null,
  "$0 მნიშვნელოვანი მოხვედრა",
  "$0 მოხვედრა, მნიშვნელოვნის ჩათვლით"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 მოკვდა სიგნალით $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 დაბალი სერიოზულობის მოხვედრა",
  "$0 ცალი დაბალი სერიოზულობის მოხვედრა"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "$0 moderate hit": [
  null,
  "$0 საშუალო მოხვედრა",
  "$0 მოხვედრა, საშუალოს ჩათვლით"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 სერვისის შეცდომა",
  "$0 ცალი სერვისის შეცდომა"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "$0: crash at $1": [
  null,
  "$0: ავარია $1-თან"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "10th": [
  null,
  "მეათე"
 ],
 "11th": [
  null,
  "მეთერთმეტე"
 ],
 "12th": [
  null,
  "მეთორმეტე"
 ],
 "13th": [
  null,
  "13-ე"
 ],
 "14th": [
  null,
  "14-ე"
 ],
 "15th": [
  null,
  "15-ე"
 ],
 "16th": [
  null,
  "16-ე"
 ],
 "17th": [
  null,
  "17-ე"
 ],
 "18th": [
  null,
  "18-ე"
 ],
 "19th": [
  null,
  "19-ე"
 ],
 "1st": [
  null,
  "პირველი"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "20th": [
  null,
  "20-ე"
 ],
 "21th": [
  null,
  "21-ე"
 ],
 "22th": [
  null,
  "22-ე"
 ],
 "23th": [
  null,
  "23-ე"
 ],
 "24th": [
  null,
  "24-ე"
 ],
 "25th": [
  null,
  "25-ე"
 ],
 "26th": [
  null,
  "26-ე"
 ],
 "27th": [
  null,
  "27-ე"
 ],
 "28th": [
  null,
  "28-ე"
 ],
 "29th": [
  null,
  "29-ე"
 ],
 "2nd": [
  null,
  "მეორე"
 ],
 "30th": [
  null,
  "30-ე"
 ],
 "31st": [
  null,
  "31-ე"
 ],
 "3rd": [
  null,
  "მესამე"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "4th": [
  null,
  "მეოთხე"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "5th": [
  null,
  "მეხუთე"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "6th": [
  null,
  "მეექვსე"
 ],
 "7th": [
  null,
  "მეშვიდე"
 ],
 "8th": [
  null,
  "მერვე"
 ],
 "9th": [
  null,
  "მეცხრე"
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Acceptable password": [
  null,
  "მისაღები პაროლი"
 ],
 "Active since ": [
  null,
  "აქტიურია "
 ],
 "Active state": [
  null,
  "აქტიური მდგომარეობა"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "Additional actions": [
  null,
  "დამატებითი ქმედებები"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockput ვებ კონსოლით ადმინისტრირება"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "After": [
  null,
  "შემდეგ"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "დომენიდან გამოსვლის შემდეგ ამ მანქანაზე შესვლა შეეძლებათ მხოლოდ ლოკალური ანგარიშების მქონე მომხმარებლებს. ასევე შეიძლება შეფერხებით იმუშაოს სხვა ისეთმა სერვისებმა, როგორიცაა მაგალითად DNS და შეიცვლება სანდო CA-ები."
 ],
 "After system boot": [
  null,
  "სისტემის ჩატვირთვის შემდეგ"
 ],
 "Alert and above": [
  null,
  "გაფრთხილება და უარესები"
 ],
 "Alias": [
  null,
  "მეტსახელი"
 ],
 "All": [
  null,
  "ყველა"
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "Allow running (unmask)": [
  null,
  "გაშვების ნების დართვა (ნიღბის მოხსნა)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-ის როლების დოკუმენტაცია"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "ჟურნალის შეტყობინებებში შესაძლებელია ნებისმიერი სტრიქონის გაფიტვრა. სტრიქონი ასევე შეიძლება მოიძებნოს რეგულარული გამოსახულებებითაც. ასევე არსებობს ჟურნალის ველების მიხედვით გაფილტვრის მხარდაჭერა. წარმოადგენენ ჰარეთი გაყოფილ მნისვნელობებს FIELD=VALUE ფორმაში, სადაც მნიშვნელობები შეიძლება წარმოადგენდეს მძიმით გამოყოფილ შესაძლო მნიშვნელობების სიას."
 ],
 "Appearance": [
  null,
  "გარეგნობა"
 ],
 "Apply and reboot": [
  null,
  "გადატარება და გადატვირთვა"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "ახალი წესების გადატარება... შეიძლება რამდენიმე წუთი დასჭირდეს."
 ],
 "Asset tag": [
  null,
  "აქტივის ჭდე"
 ],
 "At minute": [
  null,
  "1 წთ"
 ],
 "At second": [
  null,
  "წმ"
 ],
 "At specific time": [
  null,
  "მითითებულ დროს"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit ვებ კონსოლში პრივილეგირებული ამოცანების შესასრულებლად საჭიროა ავთენტიკაცია"
 ],
 "Automatically starts": [
  null,
  "ავტომატურად გაეშვება"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using additional NTP servers": [
  null,
  "დამატებითი NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automation script": [
  null,
  "ავტომატიზაციის სკრიპტი"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS-ის თარიღი"
 ],
 "BIOS version": [
  null,
  "BIOS-ის ვერსია"
 ],
 "Bad": [
  null,
  "ცუდი"
 ],
 "Bad setting": [
  null,
  "ცუდი პარამეტრი"
 ],
 "Before": [
  null,
  "წინ"
 ],
 "Binds to": [
  null,
  "ებმება"
 ],
 "Black": [
  null,
  "შავი"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Boot": [
  null,
  "ჩატვირთვა"
 ],
 "Bound by": [
  null,
  "მიბმულია"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU უსაფრთხოება"
 ],
 "CPU security toggles": [
  null,
  "CPU-ის უსაფრთხოების გადამრთველები"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "მიმდინარე ფილტრების კომბინაციის ჟურნალში ჩანაწერების მოძებნა შეუძლებელია."
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Cancel poweroff": [
  null,
  "გამორთვის გაუქმება"
 ],
 "Cancel reboot": [
  null,
  "გადატვირთვის გაუქმება"
 ],
 "Cannot be enabled": [
  null,
  "ვერ ჩაირთვება"
 ],
 "Cannot forward login credentials": [
  null,
  "მომხმარებლისადაპაროლის გადაგზავნის შეცდომა"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "ამ სისტემაზე realmd-ს არარსებობის გამო დომენში ჩართვა შეუძლებელია"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change cryptographic policy": [
  null,
  "კრიპტოგრაფიული პოლიტიკის შეცვლა"
 ],
 "Change host name": [
  null,
  "ჰოსტის სახელის შეცვლა"
 ],
 "Change performance profile": [
  null,
  "წარმადობის პროფილის შეცვლა"
 ],
 "Change profile": [
  null,
  "პროფილის შეცვლა"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "Class": [
  null,
  "კლასი"
 ],
 "Clear 'Failed to start'": [
  null,
  "'გაშვების შეცდომა'-ის გასუფთავება"
 ],
 "Clear all filters": [
  null,
  "ყველა ფილტრის გასუფთავება"
 ],
 "Client software": [
  null,
  "კლიენტი პროგრამა"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager-ის და Firewalld-ის მორგება Cockpit-ით"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit-ს მითითებულ ჰოსტთან დაკავშირება არ შეუძლია ."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit წარმოადგენს სერვერის მმართველს, რომლითაც Linux სერვერების ადმინისტრირება ბრაუზერითაც შეგიძლიათ. ტერმინალსა და ვებ ხელსაწყოს შორის გადართვა პრობლემა არაა. Cockpit-ით გაშვებული სერვისი შეგიძლიათ გააჩეროთ ტერმინალთაც. ასევე, თუ შეცდომა დაფიქსირდება ტერმინალში, მისი ნახვა Cockpit-ის საშუალებითაც შეგიძლიათ."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit-ი შეუთავსებელია თქვენს სერვერზე დაყენებულ პროგრამულ უზრუნველყოფასთან."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit-ი ამ სისტემაზე დაყენებული არაა."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit შესანიშნავია ახალი სისტემური ადმინისტრატორებისთვის. ის მათ საშუალებას აძლევს ადვილად შეასრულონ ისეთი მარტივი ამოცანები, როგორიცაა შენახვის ადმინისტრირება, ჟურნალების შემოწმება და სერვისების დაწყება და გაჩერება. შეგიძლიათ ერთდროულად რამდენიმე სერვერის მონიტორინგი და ადმინისტრირება. უბრალოდ დაამატეთ ისინი ერთი დაწკაპუნებით და თქვენი მანქანები იზრუნებს მის მეგობრებზე."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "მოაგროვეთ დიაგნოსტიკური და მხარდაჭერის მონაცემები"
 ],
 "Collect kernel crash dumps": [
  null,
  "ოპერაციული სისტემის ბირთვის ავარიის დამპები"
 ],
 "Command": [
  null,
  "ბრძანება"
 ],
 "Command not found": [
  null,
  "ბრძანება ნაპოვნი არაა"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned-თან კავშირის შეცდომა"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "პირობა $0=$1 არ შესრულდა"
 ],
 "Condition failed": [
  null,
  "პირობის შეცდომა"
 ],
 "Configuration": [
  null,
  "მორგება"
 ],
 "Confirm deletion of $0": [
  null,
  "დაადასტურეთ $0-ის წაშლა"
 ],
 "Conflicted by": [
  null,
  "კონფლიქტშია"
 ],
 "Conflicts": [
  null,
  "კონფლიქტები"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "dbus-თან დაკავშირების შეცდომა: $0"
 ],
 "Connection has timed out.": [
  null,
  "კავშირის დრო გავიდა."
 ],
 "Consists of": [
  null,
  "შედგება"
 ],
 "Contacted domain": [
  null,
  "დომენთან კავშირი წარმატებულია"
 ],
 "Controller": [
  null,
  "კონტროლერი"
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Copy to clipboard": [
  null,
  "ბაფერში კოპირება"
 ],
 "Crash reporting": [
  null,
  "ავარიის ანგარიში"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Create new task file with this content.": [
  null,
  "ახალი ამოცანის ამ შემცველობით შექმნა."
 ],
 "Create timer": [
  null,
  "ტაიმერის შექმნა"
 ],
 "Critical and above": [
  null,
  "კრიტიკული და ზემოთ"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "კრიპტოგრაფიის წესები წარმოადგენს სისტემურ კომპონენტს, რომელიც ძირითადი კრიპტოგრაფიული ქვესისტემების, TLS/IPSec/SSH/DNNSEC და kerberos-ის კონფიგურაციას უზრუნველყოფს."
 ],
 "Cryptographic policy": [
  null,
  "კრიპტოგრაფიის პოლიტიკა"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "კრიპტოგრაფიის პოლიტიკა არამდგრადია"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "მიმდინარე ჩატვირთვა"
 ],
 "Custom cryptographic policy": [
  null,
  "კრიპტოგრაფიის პოლიტიკის მორგება"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT-ი SHA-1 ხელმოწერის გადამოწმებით დაშვებულია."
 ],
 "Daily": [
  null,
  "დღიურად"
 ],
 "Dark": [
  null,
  "ბლენი"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "თარიღის სპეციფიკაციები უნდა იყოს YYYY-MM-DD ფორმატის სთ:მთ:წ.წ. ალტერნატიულად გაგებულია სტრიქონები \"გუშინ\", \"დღეს\", \"ხვალ\". \"ახლა\" ეხება მიმდინარე დროს. და ბოლოს, შედარებითი დრო შეიძლება იყოს მითითებული, პრეფიქსით '-' ან '+'"
 ],
 "Debug and above": [
  null,
  "გამართვა და ზემოთ"
 ],
 "Decrease by one": [
  null,
  "ერთით შემცირება"
 ],
 "Default": [
  null,
  "ნაგულისხმები"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Delay must be a number": [
  null,
  "დაყოვნება რიცხვი უნდა იყოს"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Deletion will remove the following files:": [
  null,
  "ასევე წაიშლება შემდეგი ფაილები:"
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Disable simultaneous multithreading": [
  null,
  "მრავალნაკადიანობის გამორთვა"
 ],
 "Disable tuned": [
  null,
  "tuned-ის გამორთვა"
 ],
 "Disabled": [
  null,
  "გათიშულია"
 ],
 "Disallow running (mask)": [
  null,
  "გაშვების აკრძალვა (შენიღბვა)"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "Does not automatically start": [
  null,
  "არ გაეშვება ავტომატურად"
 ],
 "Domain": [
  null,
  "დომენი"
 ],
 "Domain address": [
  null,
  "დომენის მისამართი"
 ],
 "Domain administrator name": [
  null,
  "დომენის ადმინისტრატორის სახელი"
 ],
 "Domain administrator password": [
  null,
  "დომენის ადმინისტრატორის პაროლი"
 ],
 "Domain could not be contacted": [
  null,
  "დომენთან კავშირის შეცდომა"
 ],
 "Domain is not supported": [
  null,
  "დომენის მხარდაჭერა არ არსებობს"
 ],
 "Don't repeat": [
  null,
  "არ გაიმეორო"
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd-ის ჩასწორება"
 ],
 "Edit motd": [
  null,
  "motd ფაილის ჩასწორება"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Enabled": [
  null,
  "ჩართულია"
 ],
 "Entry at $0": [
  null,
  "$0-ში ჩაწერა"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "Error and above": [
  null,
  "შეცდომა და ზემოთ"
 ],
 "Error message": [
  null,
  "შეცდომის შეტყობინება"
 ],
 "Excellent password": [
  null,
  "გადასარევი პაროლი"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Extended information": [
  null,
  "გაფართოებული ინფორმაცია"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS-ი სწორად არაა ჩართული"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS დამატებითი საერთო პირობის შეზღუდვებით."
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "Failed to disable tuned": [
  null,
  "tuned-ის გამორთვის შეცდომა"
 ],
 "Failed to disable tuned profile": [
  null,
  "tuned-ის პროფილის გამორთვის შეცდომა"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld-ში $0-ის ჩართვის შეცდომა"
 ],
 "Failed to enable tuned": [
  null,
  "tuned-ის ჩართვის შეცდომა"
 ],
 "Failed to fetch logs": [
  null,
  "ჟურნალის გამოთხოვნის შეცდომა"
 ],
 "Failed to load unit": [
  null,
  "ერთეულის ჩატვირთვის შეცდომა"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "/etc/motd-ში ცვლილებების შეტანის შეცდომა"
 ],
 "Failed to start": [
  null,
  "გაშვების შეცდომა"
 ],
 "Failed to switch profile": [
  null,
  "პროფილის გადართვის შეცდომა"
 ],
 "File state": [
  null,
  "ფაილის მდგომარეობა"
 ],
 "Filter by name or description": [
  null,
  "სახელით ან აღწერით გაფილტვრა"
 ],
 "Filters": [
  null,
  "ფილტრები"
 ],
 "Font size": [
  null,
  "ფონტის ზომა"
 ],
 "Forbidden from running": [
  null,
  "გაშვება აკრძალულია"
 ],
 "Frame number": [
  null,
  "კადრის ნომერი"
 ],
 "Free-form search": [
  null,
  "ძებნის თავისუფალი ფორმა"
 ],
 "Fridays": [
  null,
  "კვირაობით"
 ],
 "General": [
  null,
  "საერთო"
 ],
 "Generated": [
  null,
  "გენერირებული"
 ],
 "Go to $0": [
  null,
  "$0-ზე გადასვლა"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "Hardware information": [
  null,
  "ინფორმაცია აპარატურის შესახებ"
 ],
 "Health": [
  null,
  "ჯანმრთელობა"
 ],
 "Help": [
  null,
  "დახმარება"
 ],
 "Hide confirmation password": [
  null,
  "დადასტურების პაროლის დამალვა"
 ],
 "Hide password": [
  null,
  "პაროლის დამალვა"
 ],
 "Hierarchy ID": [
  null,
  "იერარქიის ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "მაღალი ურთიერთკავშირი შეტევის გაზრდილი ზედაპირის ხარჯზე."
 ],
 "Host key is incorrect": [
  null,
  "ჰოსტის გასაღები არასწორია"
 ],
 "Hostname": [
  null,
  "ჰოსტის სახელი"
 ],
 "Hourly": [
  null,
  "საათობრივ"
 ],
 "Hours": [
  null,
  "საათი"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "იდენტიფიკატორი"
 ],
 "Increase by one": [
  null,
  "ერთით გაზრდა"
 ],
 "Indirect": [
  null,
  "არაპირდაპირი"
 ],
 "Info and above": [
  null,
  "ინფორმაცია და ზემოთ"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Install realmd support": [
  null,
  "Realmd-ის მხარდაჭერის დაყენება"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Internal error": [
  null,
  "შიდა შეცდომა"
 ],
 "Invalid": [
  null,
  "არასწორი"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid file permissions": [
  null,
  "ფაილის არასწორი წვდომები"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Join": [
  null,
  "შეერთება"
 ],
 "Join domain": [
  null,
  "დომენზე დაერთება"
 ],
 "Joining": [
  null,
  "შეერთება"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "დომენში შესასვლელად საჭიროა realmd-ის დაყენება"
 ],
 "Joining this domain is not supported": [
  null,
  "დომენში შესვლის მხარდაჭერა არ არსებობს"
 ],
 "Joins namespace of": [
  null,
  "ზონაში შეერთება"
 ],
 "Journal": [
  null,
  "ჟურნალი"
 ],
 "Journal entry": [
  null,
  "ჟურნალის ელემენტი"
 ],
 "Journal entry not found": [
  null,
  "ჟურნალის ერთეული ნაპოვნი არაა"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY-ი Active Directory-სთან სამუშაოდ."
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Last 24 hours": [
  null,
  "ბოლო 24 საათი"
 ],
 "Last 7 days": [
  null,
  "ბოლო 7 დღე"
 ],
 "Last successful login:": [
  null,
  "ბოლო წარმატებული შესვლა:"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Leave $0": [
  null,
  "$0-დან გასვლა"
 ],
 "Leave domain": [
  null,
  "დომენიდან გასვლა"
 ],
 "Light": [
  null,
  "ღია"
 ],
 "Limits": [
  null,
  "ლიმიტები"
 ],
 "Linked": [
  null,
  "მიბმული"
 ],
 "Listen": [
  null,
  "მოსმენა"
 ],
 "Listing units": [
  null,
  "სერვისების სია"
 ],
 "Listing units failed: $0": [
  null,
  "სერვისების სიის გამოტანის შეცდომა: $0"
 ],
 "Load earlier entries": [
  null,
  "ადრინდელი ელემენტების ჩატვირთვა"
 ],
 "Loading earlier entries": [
  null,
  "ადრინდელი ელემენტების ჩატვირთვა"
 ],
 "Loading keys...": [
  null,
  "გასაღებების ჩატვირთვა..."
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH გასაღებების ჩატვირთვის შეცდომა"
 ],
 "Loading of units failed": [
  null,
  "სერვისების ჩატვირთვის შეცდომა"
 ],
 "Loading system modifications...": [
  null,
  "სისტემის ცვლილებების ჩატვირთვა..."
 ],
 "Loading unit failed": [
  null,
  "სერვისების ჩატვირთვის შეცდომა"
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "Login failed": [
  null,
  "შესვლა წარუმატებელია"
 ],
 "Login format": [
  null,
  "შესვლის ფორმატი"
 ],
 "Logs": [
  null,
  "ჟურნალი"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "მანქანის ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "მანქანის SSH გასაღების ანაბეჭდები"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Maintenance": [
  null,
  "სარემონტო"
 ],
 "Manage storage": [
  null,
  "საცავის მართვა"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Mask service": [
  null,
  "სერვისის დამალვა"
 ],
 "Masked": [
  null,
  "შენიღბული"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "სერვისის შენიღბვა კრძალავს მასზე დამოკიდებული ყველა სერვისის გაშვებას. ამას იმაზე მეტი ეფექტი შეიძლება ჰქონეს, ვიდრე თქვენ გგონიათ. გთხოვთ დაადასტუროთ, რომ გნებავთ ამის გაკეთება."
 ],
 "Memory": [
  null,
  "მეხსიერება"
 ],
 "Memory technology": [
  null,
  "მეხსიერების ტექნოლოგია"
 ],
 "Merged": [
  null,
  "შერწყმული"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "წუთი უნდა იყოს რიცხვი შუალედში 0-59"
 ],
 "Minutely": [
  null,
  "წთ"
 ],
 "Minutes": [
  null,
  "წუთი"
 ],
 "Mitigations": [
  null,
  "დაცვის გეგმები"
 ],
 "Model": [
  null,
  "მოდელი"
 ],
 "Mondays": [
  null,
  "ორშაბათობით"
 ],
 "Monthly": [
  null,
  "თვეში ერთხელ"
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "No": [
  null,
  "არა"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "No host keys found.": [
  null,
  "ჰოსტის გასაღებები ნაპოვნი არაა."
 ],
 "No log entries": [
  null,
  "ჟურნალის ცარიელია"
 ],
 "No logs found": [
  null,
  "ჟურნალი ცარიელია"
 ],
 "No matching results": [
  null,
  "პასუხები არაა"
 ],
 "No results found": [
  null,
  "შედეგები ნაპოვნი არაა"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "თქვენს ფილტრს შედეგები არ აქვს. შედეგების საჩვენებლად გაასუფთავეთ ფილტრები."
 ],
 "No rule hits": [
  null,
  "არ მოხვდა წესებში"
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "No system modifications": [
  null,
  "სისტემა შეცვლილი არაა"
 ],
 "None": [
  null,
  "არცერთი"
 ],
 "Not a valid private key": [
  null,
  "არ წარმოადგენს სწორ პირად გასაღებს"
 ],
 "Not connected to Insights": [
  null,
  "არაა მიერთებული Insights-თან"
 ],
 "Not found": [
  null,
  "ნაპოვნი არაა"
 ],
 "Not permitted to configure realms": [
  null,
  "realm-ების მორგების წვდომა აკრძალულია"
 ],
 "Not permitted to perform this action.": [
  null,
  "არ გაქვთ მითითებული მოქმედების შესასრულებლად საკმარისი წვდომა."
 ],
 "Not running": [
  null,
  "გაშვებული არაა"
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Note": [
  null,
  "არცერთი"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Notice and above": [
  null,
  "გაფრთხილება და ზემოთ"
 ],
 "Occurrences": [
  null,
  "გამოვლენები"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "On failure": [
  null,
  "შეცდომის შემთხვევაში"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "როცა Cockpit-ს დააყენებთ, შეგიძლიათ მისი ჩართვაც, ბრძანებით \"systemctl enable --now cockpit.socket\"."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "დაშვებულია მხოლოდ ლათინური ანბანი, ციფრები, :, _ და @"
 ],
 "Only emergency": [
  null,
  "მხოლოდ გადაუდებელ შემთხვევაში"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS რეჟიმში ჩატვირთვისას მხოლოდ დადასტურებული ალგორითმების გამოყენება."
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "Overview": [
  null,
  "გადახედვა"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "Part of": [
  null,
  "წარმოადგენს ნაწილს"
 ],
 "Password is not acceptable": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Password is too weak": [
  null,
  "პაროლი ძალიან სუსტია"
 ],
 "Password not accepted": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Paste error": [
  null,
  "ჩასმის შეცდომა"
 ],
 "Path": [
  null,
  "ბილიკი"
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "Paths": [
  null,
  "ბილიკი"
 ],
 "Pause": [
  null,
  "პაუზა"
 ],
 "Performance profile": [
  null,
  "წარმადობის პროფილი"
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Pin unit": [
  null,
  "მიჭიკარტება"
 ],
 "Pinned unit": [
  null,
  "მიჭიკარტებული"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "Pretty host name": [
  null,
  "ჰოსტის ლამაზი სახელი"
 ],
 "Previous boot": [
  null,
  "წინა ჩატვირთვა"
 ],
 "Priority": [
  null,
  "პრიორიტეტი"
 ],
 "Problem details": [
  null,
  "პრობლემის დეტალები"
 ],
 "Problem info": [
  null,
  "ინფორმაცია პრობლემის შესახებ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "მოთხოვნას ssh-add-ის გავლით დრო გაუვიდა"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "მოთხოვნას ssh-keygen-ის გავლით დრო გაუვიდა"
 ],
 "Propagates reload to": [
  null,
  "გადატვირთვა გავრცელდება"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "იცავს მოსალოდნელი უახლოესი მომავალი თავდასხმებისგან თავსებადობის ხარჯზე."
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Rank": [
  null,
  "რანგი"
 ],
 "Read more...": [
  null,
  "მეტის წაკითხვა..."
 ],
 "Read-only": [
  null,
  "მხოლოდ წასაკითხად"
 ],
 "Real host name": [
  null,
  "ჰოსტის რეალური სახელი"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "ჰოსტის რეალური სახელი შეიძლება მხოლოდ შეიცავდეს პატარა სიმბოლოებს, ციფრებს, ტირეებს და ჰარეებს"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "ჯოსტის რეალური სახელი 64 სიმბოლოზე დიდი არ უნდა იყოს"
 ],
 "Reapply and reboot": [
  null,
  "თავიდან გადატარება და გადატვირთვა"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "რეკომენდებული, დაცული პარამეტრები მიმდინარე დაცვის მოდელისთვის."
 ],
 "Reload": [
  null,
  "თავიდან ჩატვირთვა"
 ],
 "Reload propagated from": [
  null,
  "გადატვირთვის წყარო"
 ],
 "Reloading": [
  null,
  "თავიდან ჩატვირთვა"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Repeat": [
  null,
  "გამეორება"
 ],
 "Repeat monthly": [
  null,
  "თვეში ერთხელ გამეორება"
 ],
 "Repeat weekly": [
  null,
  "კვირაში ერთხელ გამეორება"
 ],
 "Report": [
  null,
  "ანგარიში"
 ],
 "Report to ABRT Analytics": [
  null,
  "ABRT ანალიტიკისთვის გადაცემა"
 ],
 "Reported; no links available": [
  null,
  "ანგარიში გაგზავნილია; ბმულები მიუწვდომელია"
 ],
 "Reporting failed": [
  null,
  "ანგარიშის გადაგზავნის შეცდომა"
 ],
 "Reporting was canceled": [
  null,
  "ანგარიში გაუქმდა"
 ],
 "Reports:": [
  null,
  "ანგარიშები:"
 ],
 "Required by": [
  null,
  "სჭირდება"
 ],
 "Required by ": [
  null,
  "სჭირდება "
 ],
 "Requires": [
  null,
  "სჭირდება"
 ],
 "Requires administration access to edit": [
  null,
  "ჩასასწორებლად საჭიროა ადმინისტრატორის წვდომა"
 ],
 "Requisite": [
  null,
  "მოთხოვნა"
 ],
 "Requisite of": [
  null,
  "ვის საჭიროებასა წარმოადგენს"
 ],
 "Reset": [
  null,
  "საწყის მნიშვნელობებზე დაბრუნება"
 ],
 "Restart": [
  null,
  "გადატვირთვა"
 ],
 "Resume": [
  null,
  "გაგრძელება"
 ],
 "Review cryptographic policy": [
  null,
  "კრიპტოგრაფიის პოლიტიკის გადახედვა"
 ],
 "Row expansion": [
  null,
  "მწკრივის გაფართოება"
 ],
 "Row select": [
  null,
  "მწკრივის არჩევა"
 ],
 "Run at": [
  null,
  "გაშვების დრო"
 ],
 "Run on": [
  null,
  "გასაშვები პლატფორმა"
 ],
 "Running": [
  null,
  "გაშვებული"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "შაბათობით"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Save and reboot": [
  null,
  "შენახვა და გადატვირთვა"
 ],
 "Save changes": [
  null,
  "ცვლილებების შენახვა"
 ],
 "Scheduled poweroff at $0": [
  null,
  "გათიშვის დროა $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "გადატვირთვის დროა $0"
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Search": [
  null,
  "ძებნა"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "წამი უნდა იყოს რიცხვი შუალედში 0-59"
 ],
 "Seconds": [
  null,
  "წამი"
 ],
 "Secure shell keys": [
  null,
  "SSH-ის გასაღებები"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Linux-ის გაფართოებული უსაფრთხოების (SELinux) მორგება და გამართვა"
 ],
 "Select a identifier": [
  null,
  "აირჩიეთ იდენტიფიკატორი"
 ],
 "Send": [
  null,
  "გაგზავნა"
 ],
 "Server has closed the connection.": [
  null,
  "სერვერმა დახურა კავშირი."
 ],
 "Server software": [
  null,
  "სერვერული პროგრამები"
 ],
 "Service logs": [
  null,
  "სერვერის ჟურნალი"
 ],
 "Services": [
  null,
  "სერვისები"
 ],
 "Set hostname": [
  null,
  "ჰოსტის სახელის დაყენება"
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Shell script": [
  null,
  "გარსის სკრიპტი"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "ყველა ნაკადის ჩვენება"
 ],
 "Show confirmation password": [
  null,
  "დადასტურების პაროლის ჩვენება"
 ],
 "Show fingerprints": [
  null,
  "ანაბეჭდების ჩვენება"
 ],
 "Show messages containing given string.": [
  null,
  "იმ შეტყობინებების ჩვენება, რომლებიც მითითებულ სტრიქონს შეიცავენ."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "system-ის მითითებული სერვისის შეტყობინებების ჩვენება."
 ],
 "Show messages from a specific boot.": [
  null,
  "შეტყობინებების მითითებული ჩატვირთვიდან ჩვენება."
 ],
 "Show more relationships": [
  null,
  "მეტი ნათესაობის ჩვენება"
 ],
 "Show password": [
  null,
  "პაროლის ჩვენება"
 ],
 "Show relationships": [
  null,
  "ურთიერთობების ჩვენება"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Shutdown": [
  null,
  "გამორთვა"
 ],
 "Since": [
  null,
  "საწყისი დრო"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "Slot": [
  null,
  "სლოტი"
 ],
 "Sockets": [
  null,
  "სოკეტები"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "პროცესორის შეცდომების პროგრამულ გასწორებას შეუძლია თავიდან აგარიდოთ მასთან დაკავშირებული პრობლემები. მაგრამ ამ პაჩებს აქვთ გვერდითი ეფექტი - ისინი აგდებენ წარმადობას. ამ პარამეტრის ცვლილების შედეგებზე პასუხს თქვენ აგებთ."
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Speed": [
  null,
  "სიჩქარე"
 ],
 "Start": [
  null,
  "დაწყება"
 ],
 "Start and enable": [
  null,
  "ჩართვა და გაშვება"
 ],
 "Start service": [
  null,
  "სერვისის გაშვება"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "მხოლოდ მითითებული თარიღის შემდეგი შეტყობინებების ჩვენება."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "მხოლოდ მითითებულ თარიღზე ძველი შეტყობინებების ჩვენება."
 ],
 "State": [
  null,
  "მდგომარეობა"
 ],
 "Static": [
  null,
  "სტატიკური"
 ],
 "Status": [
  null,
  "მდგომარეობა"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "გაჩერება"
 ],
 "Stop and disable": [
  null,
  "გაჩერება და გამორთვა"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Strong password": [
  null,
  "ძლიერი პაროლი"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd-ის სიგნალების გამოწერის შეცდომა: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "წარმატებით დაკოპირდა ბუფერში"
 ],
 "Sundays": [
  null,
  "კვირაობით"
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "System": [
  null,
  "სისტემა"
 ],
 "System information": [
  null,
  "ინფორმაცია სისტემის შესახებ"
 ],
 "System time": [
  null,
  "სისტემური დრო"
 ],
 "Systemd units": [
  null,
  "Systemd unit-ები"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "Targets": [
  null,
  "სამიზნეები"
 ],
 "Terminal": [
  null,
  "ტერმინალი"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "შესულ მომხმარებელს არ აქვს სისტემური ცვლილებების ნახვს უფლება"
 ],
 "The passwords do not match.": [
  null,
  "პაროლები არ ემთხვევა."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "სერვერმა ყველა მხარდაჭერილი მეთოდით ავთენტიკაცია უარჰყო."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "მომხმარებელს '$0' არ აქვს უფლება შეცვალოს პროცესორის უსაფრთხოების პროგრამული გადაწყვეტილების პარამეტრები"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "მომხმარებელს '$0' კრიპტოგრაფიის პოლიტიკის შეცვლის უფლება არ აქვს"
 ],
 "This field cannot be empty": [
  null,
  "ველი არ შეიძლება ცარიელი იყოს"
 ],
 "This may take a while": [
  null,
  "საკმაო დრო დასჭირდება"
 ],
 "This system is using a custom profile": [
  null,
  "ეს სისტემა მორგებულ პროფილს იყენებს"
 ],
 "This system is using the recommended profile": [
  null,
  "ეს სისტემა რეკომენდებულ პროფილს იყენებს"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ეს პროგრამა როგორც SELinux-ის პოლიტიკის მორგებაში, ასევე მის ბოლომდე გაგებაში და პოლიტიკის დარღვევის გადაწყვეტაში დაგეხმარებათ."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "ეს პროგრამა სისტემას ბირთვის ავარიის შემთხვევაში დისკზე დამპის ჩაწერის მორგებაში დაგეხმარებათ."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ეს პროგრამა გაშვებული სისტემიდან კონფიგურაცისა და დიაგნოსტიკის მოგროვებაში დაგეხმარებათ. არქივი შეგიძლიათ ლოკალურად შეინახოთ, ან ცენტრალურად, ჩაწერისა და ტრეკინგის მიზნებისთვის, ან შეგიძლიათ გადააგზავნოთ მხარდაჭერის, პროგრამისტებისა და სისტემური ადმინისტრატორების ჯგუფებთან, რათა აპარატურული პრობლემები აღმოაჩინოთ და გადაჭრათ."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ეს პროგრამა ლოკალურ საცავს, როგორიცაა ფაილურ სისტემები, LVM2 ტომის ჯგუფები და NFS მიმაგრებები, მართავს."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ეს პროგრამა მართავს ქსელს. bond ინტერფეისების, ხიდების, ჯგუფური ინტერფეისების, VLAN-ების და ბრანდმაუერების მართვა NetworkManager-ისა და FIrewalld-ის საშუალებით. NetworkManager-ი Ubuntu-ის ნაგულისხმებ systemd-networkd და Debian-ის ifupdown სკრიპტებთან შეუთავსებელია."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "ერთეული პირდაპირი ჩართვისთვის განკუთვნილი არაა."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "დაამატებს თანხვედრას '_BOOT_IID='-თვის. თუ მითითებული არაა, გამოყენებყლი იქნება მიმდინარე ჩატვრთვა. თუ ჩატვირთვის ID გამოტოვებულია, გამოყენებული იქნება დადებითი წანაცვლება ჟურნალის დასაწყისიდან და გამოტანილი იქნება პირველი რამდენიმე ჩანაწერი. ამიტომ, 1 ნიშნავს პირველ ჩატვირთვას, 2 მეორეს და ა.შ. მაგრამ -0 ბოლო ჩატვირთვაა, -1 ბოლოს წინა და ა.შ."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "დაამატებს თანხვედრას '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' და 'UNIT='-თან მითითებული ერთეულის ჟურნალის შეტყობინებებში საძებნად. შეიძლება შეიცავდეს მეტ ერთეულსაც, გამოყოფილს მძიმეებით. "
 ],
 "Thursdays": [
  null,
  "ხუთშაბათობით"
 ],
 "Time": [
  null,
  "დრო"
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "Timer creation failed": [
  null,
  "ტაიმერის შექმნის შეცდომა"
 ],
 "Timer deletion failed": [
  null,
  "ტაიმერის წაშლის შეცდომა"
 ],
 "Timers": [
  null,
  "ტაიმერები"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Toggle filters": [
  null,
  "ფილტრების ჩართ/გამორთ"
 ],
 "Too much data": [
  null,
  "მეტისმეტად ბევრი მონაცემი"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Transient": [
  null,
  "შუალედური"
 ],
 "Trigger": [
  null,
  "ტრიგერი"
 ],
 "Triggered by": [
  null,
  "დამტრიგერებელი"
 ],
 "Triggers": [
  null,
  "ტრიგერები"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "Tuesdays": [
  null,
  "სამშაბათობით"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned-ის გაშვების შეცდომა"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned წარმოადგენს სერვისს, რომელიც უთვალთვალებს თქვენს სისტემას და აოპტიმიზირებს მას ზოგიერთიდატვირთვისთვის. Tuned-ის ბირთვის წარმოადგენს მისი პროფილები, რომლებიც სისტემას სხვადასხვა დატვირთვას ავტომატურად მოარგებს."
 ],
 "Tuned is not available": [
  null,
  "Tuned-ი ხელმიუწვდომელია"
 ],
 "Tuned is not running": [
  null,
  "Tuned-ი გაშვებული არაა"
 ],
 "Tuned is off": [
  null,
  "Tuned გამორთულია"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Type to filter": [
  null,
  "გასაფილტრად აკრიფეთ"
 ],
 "Unit": [
  null,
  "მოწყობილობა"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Unpin unit": [
  null,
  "განჭიკარტება"
 ],
 "Until": [
  null,
  "დასასრულის დრო"
 ],
 "Untrusted host": [
  null,
  "არასანდო ჰოსტი"
 ],
 "Up since": [
  null,
  "აქტიურია საიდან"
 ],
 "Updating status...": [
  null,
  "სტატუსის განახლება..."
 ],
 "Usage": [
  null,
  "გამოყენება"
 ],
 "User": [
  null,
  "მომხმარებელი"
 ],
 "Validating address": [
  null,
  "მისამართის დადასტურება"
 ],
 "Vendor": [
  null,
  "მომწოდებელი"
 ],
 "Version": [
  null,
  "ვერსია"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "View all services": [
  null,
  "ყველა სერვისის ნახვა"
 ],
 "View automation script": [
  null,
  "ავტომატიზაციის სკრიპტის ნახვა"
 ],
 "View hardware details": [
  null,
  "აპარატურის დეტალების ნახვა"
 ],
 "View login history": [
  null,
  "შესვლების ისტორიის ნახვა"
 ],
 "View metrics and history": [
  null,
  "გრაფიკებისა და ისტორიის ნახვა"
 ],
 "View report": [
  null,
  "ანგარიშის ნახვა"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "მეხსიერების ინფორმაციის ნახვას ადმინისტრირების წვდომა სჭირდება."
 ],
 "Visit firewall": [
  null,
  "ბრანდმაუერზე გადასვლა"
 ],
 "Waiting for input…": [
  null,
  "შეყვანის მოლოდინი…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Waiting to start…": [
  null,
  "გაშვების მოლოდინი…"
 ],
 "Wanted by": [
  null,
  "სჭირდება"
 ],
 "Wants": [
  null,
  "უნდა"
 ],
 "Warning and above": [
  null,
  "წინასწარი გაფრთხილებები და ზემოთ"
 ],
 "Weak password": [
  null,
  "სუსტი პაროლი"
 ],
 "Web Console for Linux servers": [
  null,
  "ვებ კონსოლი Linux სერვერებისთვის"
 ],
 "Web console is running in limited access mode.": [
  null,
  "ვებ კონსოლი გაშვებულია შეზღუდული წვდომის რეჟიმში."
 ],
 "Wednesdays": [
  null,
  "ოთხშაბათობით"
 ],
 "Weekly": [
  null,
  "კვირაში ერთხელ"
 ],
 "Weeks": [
  null,
  "კვირა"
 ],
 "White": [
  null,
  "თეთრი"
 ],
 "Yearly": [
  null,
  "წლიურად"
 ],
 "Yes": [
  null,
  "დიახ"
 ],
 "You may try to load older entries.": [
  null,
  "სცადეთ ჩატვირთოთ ძველი ელემენტები."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "თქვენს ბრაუზერს არ გააჩნია კონტექსტური მენიუდან ჩასმის მხარდაჭერა. სცადეთ დააჭიროთ Shift+Insert-ს."
 ],
 "Your session has been terminated.": [
  null,
  "თქვენი სესია გაწყვეტილია."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "სესიის ვადა გასულია. თავიდან შედით."
 ],
 "Zone": [
  null,
  "ზონა"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "active": [
  null,
  "აქტიური"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh-ის ჰოსტის გასაღებების სიის გამოტანის შეცდომა: $0"
 ],
 "in less than a minute": [
  null,
  "წუთზე ნაკლებში"
 ],
 "inconsistent": [
  null,
  "არამდგრადი"
 ],
 "journalctl manpage": [
  null,
  "journalctl-ის მინი-დოკუმენტაცია"
 ],
 "less than a minute ago": [
  null,
  "წუთზე ნაკლების წინ"
 ],
 "none": [
  null,
  "არცერთი"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU-დან",
  "$0 ცალი CPU-დან"
 ],
 "password quality": [
  null,
  "პაროლის ხარისხი"
 ],
 "recommended": [
  null,
  "რეკომენდებულია"
 ],
 "running $0": [
  null,
  "$0-ის გაშვება"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "unknown": [
  null,
  "უცნობი"
 ],
 "dialog-title\u0004Domain": [
  null,
  "დომენი"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "დომენში შესვლა"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0-დან"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$0დან $1-ზე"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0-ზე"
 ]
});
