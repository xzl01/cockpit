cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "פגיעה חמורה אחת",
  "$0 פגיעות, כולל חמורות",
  "$0 פגיעות, כולל חמורות",
  "$0 פגיעות, כולל חמורות"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "$0 failed login attempt": [
  null,
  "ניסיון כניסה שנכשל",
  "שני ניסיונות כניסה שנכשלו",
  "$0 ניסיונות כניסה שנכשלו",
  "$0 ניסיונות כניסה שנכשלו"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 important hit": [
  null,
  "פגיעה חשובה אחת",
  "$0 פגיעות חשובות",
  "$0 פגיעות חשובות",
  "$0 פגיעות חשובות"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 low severity hit": [
  null,
  "פגיעה אחת בדרגת חומרה נמוכה",
  "$0 פגיעות בדרגת חומרה נמוכה",
  "$0 פגיעות בדרגת חומרה נמוכה",
  "$0 פגיעות בדרגת חומרה נמוכה"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "$0 moderate hit": [
  null,
  "פגיעה אחת בינונית",
  "$0 פגיעות, כולל בינוניות",
  "$0 פגיעות, כולל בינוניות",
  "$0 פגיעות, כולל בינוניות"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 service has failed": [
  null,
  "שירות אחד נכשל",
  "$0 שירותים נכשלו",
  "$0 שירותים נכשלו",
  "$0 שירותים נכשלו"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$0: crash at $1": [
  null,
  "$0: קריסה ב־$1"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "10th": [
  null,
  "עשירי"
 ],
 "11th": [
  null,
  "אחד עשר"
 ],
 "12th": [
  null,
  "שניים עשר"
 ],
 "13th": [
  null,
  "שלושה עשר"
 ],
 "14th": [
  null,
  "ארבעה עשר"
 ],
 "15th": [
  null,
  "חמישה עשר"
 ],
 "16th": [
  null,
  "שישה עשר"
 ],
 "17th": [
  null,
  "שבעה עשר"
 ],
 "18th": [
  null,
  "שמונה עשר"
 ],
 "19th": [
  null,
  "תשעה עשר"
 ],
 "1st": [
  null,
  "אחד"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "20th": [
  null,
  "עשרים"
 ],
 "21th": [
  null,
  "עשרים ואחד"
 ],
 "22th": [
  null,
  "עשרים ושניים"
 ],
 "23th": [
  null,
  "עשרים ושלושה"
 ],
 "24th": [
  null,
  "עשרים וארבעה"
 ],
 "25th": [
  null,
  "עשרים וחמישה"
 ],
 "26th": [
  null,
  "עשרים ושישה"
 ],
 "27th": [
  null,
  "עשרים ושבעה"
 ],
 "28th": [
  null,
  "עשרים ושמונה"
 ],
 "29th": [
  null,
  "עשרים ותשעה"
 ],
 "2nd": [
  null,
  "שניים"
 ],
 "30th": [
  null,
  "שלושים"
 ],
 "31st": [
  null,
  "שלושים ואחד"
 ],
 "3rd": [
  null,
  "שלושה"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "4th": [
  null,
  "ארבעה"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "5th": [
  null,
  "חמישה"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "6th": [
  null,
  "שישה"
 ],
 "7th": [
  null,
  "שבעה"
 ],
 "8th": [
  null,
  "שמונה"
 ],
 "9th": [
  null,
  "תשעה"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Active since ": [
  null,
  "פעיל מאז "
 ],
 "Active state": [
  null,
  "מצב פעיל"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "Additional actions": [
  null,
  "פעולות נוספות"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "After": [
  null,
  "אחרי"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "לאחר עזיבת שם התחום, רק משתמשים עם פרטי גישה מקומיים יוכלו להיכנס למכונה הזאת. זה עשוי להשפיע על שירותים אחרים כגון פתרון בעזרת DNS ורשימת רשויות האישורים המהימנות עשויה להשתנות."
 ],
 "After system boot": [
  null,
  "לאחר עליית המערכת"
 ],
 "Alert and above": [
  null,
  "אזעקה ומעלה"
 ],
 "Alias": [
  null,
  "כינוי"
 ],
 "All": [
  null,
  "הכול"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Allow running (unmask)": [
  null,
  "לאפשר הרצה (ביטול מיסוך)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "אפשר לסנן כל מחרוזת טקסט בהודעות שביומנים. המחרוזת יכולה להיות גם בצורת ביטוי רגולרי. יש תמיכה גם בסינון לפי שדות ביומן ההודעות. כאן משתמשים בערכים מופרדים ברווחים בצורה שדה=ערך, כאשר הערך יכול להיות רשימה מופרדת בפסיקים של ערכים אפשריים."
 ],
 "Appearance": [
  null,
  "מראה"
 ],
 "Apply and reboot": [
  null,
  "החלה והפעלה מחדש"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "המדיניות החדשה חלה… עשוי לארוך מספר דקות."
 ],
 "Asset tag": [
  null,
  "תג נכס"
 ],
 "At minute": [
  null,
  "בדקה"
 ],
 "At second": [
  null,
  "בשנייה"
 ],
 "At specific time": [
  null,
  "במועד מסוים"
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "Automatically starts": [
  null,
  "מתחיל אוטומטית"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "תאריך BIOS"
 ],
 "BIOS version": [
  null,
  "גרסת BIOS"
 ],
 "Bad": [
  null,
  "פסול"
 ],
 "Bad setting": [
  null,
  "הגדרה פסולה"
 ],
 "Before": [
  null,
  "לפני"
 ],
 "Binds to": [
  null,
  "מתאגד אל"
 ],
 "Black": [
  null,
  "שחור"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Boot": [
  null,
  "עלייה"
 ],
 "Bound by": [
  null,
  "מאוגד על ידי"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "CPU": [
  null,
  "מעבד"
 ],
 "CPU security": [
  null,
  "אבטחת מעבד"
 ],
 "CPU security toggles": [
  null,
  "מתגי אבטחת מעבד"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "לא ניתן למצוא יומנים עם שילוב המסננים הנוכחי."
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Cancel poweroff": [
  null,
  "ביטול כיבוי"
 ],
 "Cancel reboot": [
  null,
  "ביטול הפעלה מחדש"
 ],
 "Cannot be enabled": [
  null,
  "לא ניתן להפעיל"
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "לא ניתן להצטרף לשם תחום כיוון ש־realmd לא זמין במערכת הזו"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Change cryptographic policy": [
  null,
  "החלפת מדיניות קריפטוגרפית"
 ],
 "Change host name": [
  null,
  "החלפת שם מארח"
 ],
 "Change performance profile": [
  null,
  "החלפת פרופיל ביצועים"
 ],
 "Change profile": [
  null,
  "החלפת פרופיל"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "Class": [
  null,
  "מחלקה"
 ],
 "Clear 'Failed to start'": [
  null,
  "לנקות ‚התחלה נכשלה’"
 ],
 "Clear all filters": [
  null,
  "ניקוי כל המסננים"
 ],
 "Client software": [
  null,
  "תכנה מצד לקוח"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Command": [
  null,
  "פקודה"
 ],
 "Command not found": [
  null,
  "הפקודה לא נמצאה"
 ],
 "Communication with tuned has failed": [
  null,
  "התקשורת עם tuned נכשלה"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Condition $0=$1 was not met": [
  null,
  "התנאי $0=$1 לא התקיים"
 ],
 "Condition failed": [
  null,
  "התנאי נכשל"
 ],
 "Configuration": [
  null,
  "הגדרות"
 ],
 "Confirm deletion of $0": [
  null,
  "אישור המחיקה של $0"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Conflicted by": [
  null,
  "בסתירה עם"
 ],
 "Conflicts": [
  null,
  "סותר"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "החיבור ל־dbus נכשל: $0"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Consists of": [
  null,
  "מורכב מ־"
 ],
 "Contacted domain": [
  null,
  "שם תחום שנוצר אתו קשר"
 ],
 "Controller": [
  null,
  "בקר"
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Crash reporting": [
  null,
  "דיווח על קריסות"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Create timer": [
  null,
  "יצירת מתזמן"
 ],
 "Critical and above": [
  null,
  "חמור ומעלה"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "ערכות מדיניות קריפטוגרפיות הוא רכיב מערכת שמגדיר את המערכות הקריפטוגרפיות של הליבה וחולש על פני פרוטוקולי TLS,‏ IPSec,‏ SSH,‏ DNSSec ו־Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "מדיניות קריפטוגרפית"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "המדיניות הקריפטוגרפית אינה אחידה"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "עלייה נוכחית"
 ],
 "Custom cryptographic policy": [
  null,
  "מדיניות קריפטוגרפית משלך"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "מותר ברירת מחדל עם אימות חתימה SHA-1."
 ],
 "Daily": [
  null,
  "יומי"
 ],
 "Dark": [
  null,
  "כהה"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "הגדרות תאריכים אמורות להיות בתבנית YYYY-MM-DD hh:mm:ss. לחלופין אפשר להשתמש במחרוזות ‚yesterday’ (אתמול), ‚today’ (היום) ו־‚tomorrow’ (מחר). ‚now’ (עכשיו) מתייחס לשעה הנוכחית. בנוסף, אפשר לציין זמן יחסי עם קידומת של ‚-’ או ‚+’"
 ],
 "Debug and above": [
  null,
  "ניפוי שגיאות ומעלה"
 ],
 "Decrease by one": [
  null,
  "להקטין באחד"
 ],
 "Default": [
  null,
  "בררת מחדל"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Delay must be a number": [
  null,
  "השהיה חייבת להיות מספר"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Deletion will remove the following files:": [
  null,
  "מחיקה תסיר את הקבצים הבאים:"
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "Details": [
  null,
  "פרטים"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Disable simultaneous multithreading": [
  null,
  "השבתת ריבוי תהליכים מקבילי"
 ],
 "Disable tuned": [
  null,
  "השבתת tuned"
 ],
 "Disabled": [
  null,
  "מושבת"
 ],
 "Disallow running (mask)": [
  null,
  "לא לאפשר הרצה (מיסוך)"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "Does not automatically start": [
  null,
  "לא מתחיל אוטומטית"
 ],
 "Domain": [
  null,
  "שם תחום"
 ],
 "Domain address": [
  null,
  "כתובת שם תחום"
 ],
 "Domain administrator name": [
  null,
  "שם מנהל שם תחום"
 ],
 "Domain administrator password": [
  null,
  "סיסמת מנהל שם תחום"
 ],
 "Domain could not be contacted": [
  null,
  "לא ניתן ליצור קשר עם שם התחום"
 ],
 "Domain is not supported": [
  null,
  "שם התחום אינו נתמך"
 ],
 "Don't repeat": [
  null,
  "לא לחזור"
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Edit /etc/motd": [
  null,
  "עריכת ‎/etc/motd"
 ],
 "Edit motd": [
  null,
  "עריכת ההודעה היומית"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Enabled": [
  null,
  "מופעל"
 ],
 "Entry at $0": [
  null,
  "רשומה ב־$0"
 ],
 "Error": [
  null,
  "שגיאה"
 ],
 "Error and above": [
  null,
  "שגיאה ומעלה"
 ],
 "Error message": [
  null,
  "הודעת שגיאה"
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Extended information": [
  null,
  "פירוט מורחב"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS לא מופעל כראוי"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS עם מגבלות קריטריונים משותפים נוספות."
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "Failed to disable tuned": [
  null,
  "ההשבתה של tuned נכשלה"
 ],
 "Failed to disable tuned profile": [
  null,
  "השבתת פרופיל ה־tuned נכשלה"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Failed to enable tuned": [
  null,
  "ההפעלה של tuned נכשלה"
 ],
 "Failed to fetch logs": [
  null,
  "משיכת יומנים נכשלה"
 ],
 "Failed to load unit": [
  null,
  "טעינת היחידה נכשלה"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "שמירת השינויים ב־‎/etc/motd נכשלה"
 ],
 "Failed to start": [
  null,
  "ההפעלה נכשלה"
 ],
 "Failed to switch profile": [
  null,
  "החלפת פרופיל נכשלה"
 ],
 "File state": [
  null,
  "מצב הקובץ"
 ],
 "Filter by name or description": [
  null,
  "סינון לפי שם או תיאור"
 ],
 "Filters": [
  null,
  "מסננים"
 ],
 "Font size": [
  null,
  "גודל גופן"
 ],
 "Forbidden from running": [
  null,
  "נאסר עליו לפעול"
 ],
 "Frame number": [
  null,
  "מספר מסגרת"
 ],
 "Free-form search": [
  null,
  "חיפוש חופשי"
 ],
 "Fridays": [
  null,
  "ימי שישי"
 ],
 "General": [
  null,
  "כללי"
 ],
 "Generated": [
  null,
  "נוצר"
 ],
 "Go to $0": [
  null,
  "לעבור אל $0"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Hardware information": [
  null,
  "פרטי חומרה"
 ],
 "Health": [
  null,
  "בריאות"
 ],
 "Help": [
  null,
  "עזרה"
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "Hierarchy ID": [
  null,
  "מזהה היררכיה"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "מרחב תמרון גדול יותר על חשבון חזית פגיעה יותר לתקיפות."
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "Hostname": [
  null,
  "שם מארח"
 ],
 "Hourly": [
  null,
  "שעתי"
 ],
 "Hours": [
  null,
  "שעות"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "Identifier": [
  null,
  "מזהה"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "Increase by one": [
  null,
  "להגדיל באחד"
 ],
 "Indirect": [
  null,
  "עקיף"
 ],
 "Info and above": [
  null,
  "מידע ומעלה"
 ],
 "Insights: ": [
  null,
  "תובנות: "
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Install realmd support": [
  null,
  "התקנת תמיכה ב־realmd"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Invalid": [
  null,
  "שגוי"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Join": [
  null,
  "הצטרפות"
 ],
 "Join domain": [
  null,
  "הצטרפות לשם תחום"
 ],
 "Joining": [
  null,
  "הצטרפות"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "הצטרפות לשם תחום דורש את התקנת realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "אין תמיכה בהצטרפות לשם התחום הזה"
 ],
 "Joins namespace of": [
  null,
  "מצטרף למרחב השם של"
 ],
 "Journal": [
  null,
  "ז׳ורנל"
 ],
 "Journal entry": [
  null,
  "רשומת ז׳ורנל"
 ],
 "Journal entry not found": [
  null,
  "רשומת הז׳ורנל לא נמצאה"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "מיושן עם תאימות מול Active Directory."
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Last 24 hours": [
  null,
  "24 השעות האחרונות"
 ],
 "Last 7 days": [
  null,
  "7 הימים האחרונים"
 ],
 "Last successful login:": [
  null,
  "כניסה אחרונה שהצליחה:"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "Leave $0": [
  null,
  "לעזוב את $0"
 ],
 "Leave domain": [
  null,
  "עזיבת שם התחום"
 ],
 "Light": [
  null,
  "בהירה"
 ],
 "Limits": [
  null,
  "הגבלות"
 ],
 "Linked": [
  null,
  "מקושר"
 ],
 "Listen": [
  null,
  "האזנה"
 ],
 "Listing units": [
  null,
  "היחידות מוצגות"
 ],
 "Listing units failed: $0": [
  null,
  "הצגת היחידות נכשלה: $0"
 ],
 "Load earlier entries": [
  null,
  "טעינת רשומות קודמות"
 ],
 "Loading keys...": [
  null,
  "המפתחות נטענים…"
 ],
 "Loading of SSH keys failed": [
  null,
  "טעינת מפתחות ה־SSH נכשלה"
 ],
 "Loading of units failed": [
  null,
  "טעינת היחידות נכשלה"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "Loading unit failed": [
  null,
  "טעינת היחידה נכשלה"
 ],
 "Loading...": [
  null,
  "בטעינה…"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "Login format": [
  null,
  "תצורת כניסה"
 ],
 "Logs": [
  null,
  "יומנים"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Machine ID": [
  null,
  "מזהה מכונה"
 ],
 "Machine SSH key fingerprints": [
  null,
  "טביעות אצבע מפתח SSH של מכונה"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Maintenance": [
  null,
  "תחזוקה"
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Mask service": [
  null,
  "מיסוך שירות"
 ],
 "Masked": [
  null,
  "ממוסך"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "מיסוך שירות מונע מכל היחידות התלויות לפעול. להגדרה זו עשויה להיות השפעה גדולה מהצפוי. נא לאשר שברצונך למסך את היחידה הזאת."
 ],
 "Memory": [
  null,
  "זיכרון"
 ],
 "Memory technology": [
  null,
  "טכנולוגיית זיכרון"
 ],
 "Merged": [
  null,
  "ממוזגת"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "דקה חייבת להיות מספר בין 0 ל־59"
 ],
 "Minutes": [
  null,
  "דקות"
 ],
 "Mitigations": [
  null,
  "אפחותים"
 ],
 "Model": [
  null,
  "דגם"
 ],
 "Mondays": [
  null,
  "ימי שני"
 ],
 "Monthly": [
  null,
  "חודשי"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "No": [
  null,
  "לא"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "No host keys found.": [
  null,
  "לא נמצאו מפתחות מארחים."
 ],
 "No log entries": [
  null,
  "אין רשומות ביומן"
 ],
 "No logs found": [
  null,
  "לא נמצאו יומנים"
 ],
 "No matching results": [
  null,
  "אין כללים תואמים"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "לא נמצאו תוצאות לתנאי המסנן. יש לנקות את כל המסננים כדי להציג תוצאות."
 ],
 "No rule hits": [
  null,
  "אין פגיעות בכללים"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "None": [
  null,
  "אין"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Not connected to Insights": [
  null,
  "לא מחובר לתובנות"
 ],
 "Not found": [
  null,
  "לא נמצא"
 ],
 "Not permitted to configure realms": [
  null,
  "המשתמש $0 אינו מורשה לשנות מתחמים"
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Not running": [
  null,
  "לא פועל"
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Note": [
  null,
  "הערה"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Notice and above": [
  null,
  "הודעה ומעלה"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "On failure": [
  null,
  "בעת כשל"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "מותר רק אותיות באנגלית, מספרים, : , _ , . , @ , -"
 ],
 "Only emergency": [
  null,
  "חירום בלבד"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "להשתמש רק באלגוריתמים מאושרים ומורשים בעת טעינה במצב FIPS."
 ],
 "Other": [
  null,
  "אחר"
 ],
 "Overview": [
  null,
  "סקירה"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "Part of": [
  null,
  "חלק מתוך"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Path": [
  null,
  "נתיב"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "Paths": [
  null,
  "נתיבים"
 ],
 "Pause": [
  null,
  "השהיה"
 ],
 "Performance profile": [
  null,
  "פרופיל ביצועים"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Pin unit": [
  null,
  "נעיצת יחידה"
 ],
 "Pinned unit": [
  null,
  "יחידה נעוצה"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Pretty host name": [
  null,
  "שם מארח יפה"
 ],
 "Previous boot": [
  null,
  "עלייה קודמת"
 ],
 "Priority": [
  null,
  "עדיפות"
 ],
 "Problem details": [
  null,
  "פרטי הבעיה"
 ],
 "Problem info": [
  null,
  "מידע על הבעיה"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Propagates reload to": [
  null,
  "מפיץ רענון אל"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "מגן מפני התקפות צפויות בעתיד הקרוב על חשבון מרחב תמרון."
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Rank": [
  null,
  "דירוג"
 ],
 "Read more...": [
  null,
  "מידע נוסף…"
 ],
 "Read-only": [
  null,
  "קריאה בלבד"
 ],
 "Real host name": [
  null,
  "שם המארח האמתי"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "שם המארח האמתי יכול להכיל רק אותיות קטנות באנגלית, ספרות, מינוסים ונקודות (עם תת־שמות תחום מאוכלסים)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "אורך שם התחום האמתי חייב להיות קצר מ־64 תווים"
 ],
 "Reapply and reboot": [
  null,
  "החלה חוזרת והפעלה מחדש"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "מומלץ, הגדרות מאובטחות בהתאם לדגמי האיום הנוכחיים."
 ],
 "Reload": [
  null,
  "רענון"
 ],
 "Reload propagated from": [
  null,
  "הטעינה הופצה מהמקור"
 ],
 "Reloading": [
  null,
  "מתבצע רענון"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Repeat": [
  null,
  "לחזור"
 ],
 "Repeat monthly": [
  null,
  "לחזור באופן חודשי"
 ],
 "Repeat weekly": [
  null,
  "לחזור באופן שבועי"
 ],
 "Report": [
  null,
  "דיווח"
 ],
 "Report to ABRT Analytics": [
  null,
  "דיווח לניתוח של ABRT"
 ],
 "Reported; no links available": [
  null,
  "מדווח, אין קישורים זמינים"
 ],
 "Reporting failed": [
  null,
  "הדיווח נכשל"
 ],
 "Reporting was canceled": [
  null,
  "הדיווח בוטל"
 ],
 "Reports:": [
  null,
  "דיווחים:"
 ],
 "Required by": [
  null,
  "נדרש על ידי"
 ],
 "Required by ": [
  null,
  "נדרש על ידי "
 ],
 "Requires": [
  null,
  "דורש"
 ],
 "Requires administration access to edit": [
  null,
  "נדרשת גישה ניהולית כדי לערוך"
 ],
 "Requisite": [
  null,
  "הכרח"
 ],
 "Requisite of": [
  null,
  "הכרח של"
 ],
 "Reset": [
  null,
  "איפוס"
 ],
 "Restart": [
  null,
  "הפעלה מחדש"
 ],
 "Resume": [
  null,
  "המשך"
 ],
 "Run at": [
  null,
  "להריץ בתזמון"
 ],
 "Run on": [
  null,
  "להריץ על"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Running": [
  null,
  "פועל"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "Saturdays": [
  null,
  "שבתות"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Save and reboot": [
  null,
  "שמירה והפעלה מחדש"
 ],
 "Save changes": [
  null,
  "שמירת השינויים"
 ],
 "Scheduled poweroff at $0": [
  null,
  "תוזמן כיבוי ל־$0"
 ],
 "Scheduled reboot at $0": [
  null,
  "תוזמנה הפעלה מחדש ל־$0"
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Search": [
  null,
  "חיפוש"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "שנייה חייבת להיות מספר בין 0 ל־59"
 ],
 "Seconds": [
  null,
  "שניות"
 ],
 "Secure shell keys": [
  null,
  "מפתחות מעטפת מאובטחת"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "Send": [
  null,
  "שליחה"
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Server software": [
  null,
  "התכנה בשרת"
 ],
 "Service logs": [
  null,
  "יומני שירות"
 ],
 "Services": [
  null,
  "שירותים"
 ],
 "Set hostname": [
  null,
  "הגדרת שם מארח"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "להציג את כל התהליכונים"
 ],
 "Show fingerprints": [
  null,
  "הצגת טביעות אצבע"
 ],
 "Show messages containing given string.": [
  null,
  "הצגת הודעות שמכילות את המחרוזת שסופקה."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "הצגת הודעות ליחידת ה־systemd שצוינה."
 ],
 "Show messages from a specific boot.": [
  null,
  "הצגת הודעות לעלייה מסוימת."
 ],
 "Show more relationships": [
  null,
  "הצגת קשרים נוספים"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Show relationships": [
  null,
  "הצגת קשרים"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Shutdown": [
  null,
  "כיבוי"
 ],
 "Since": [
  null,
  "מאז"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Size": [
  null,
  "גודל"
 ],
 "Slot": [
  null,
  "משבצת"
 ],
 "Sockets": [
  null,
  "שקעים"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "מעקפי תכנה מסייעים למנוע תקלות אבטחה במעבד. לאפחותים אלו יש השפעות לוואי בדמות הפחתת ביצועים. שינוי ההגדרות האלו הוא על אחריותך בלבד."
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Speed": [
  null,
  "מהירות"
 ],
 "Start": [
  null,
  "התחלה"
 ],
 "Start and enable": [
  null,
  "התחלה והפעלה"
 ],
 "Start service": [
  null,
  "התחלת שירות"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "להתחיל להציג רשומות בתאריך או לפני התאריך שצוין."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "להתחיל להציג רשומות בתאריך או אחרי התאריך שצוין."
 ],
 "State": [
  null,
  "מצב"
 ],
 "Static": [
  null,
  "סטטי"
 ],
 "Status": [
  null,
  "מצב"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "Stop": [
  null,
  "עצירה"
 ],
 "Stop and disable": [
  null,
  "עצירה והשבתה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Stub": [
  null,
  "בדל (Stub)"
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "הרישום ל־signals (אותות) של systemd נכשל: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "ההעתקה ללוח הגזירים צלחה"
 ],
 "Sundays": [
  null,
  "ימי ראשון"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "System": [
  null,
  "מערכת"
 ],
 "System information": [
  null,
  "פרטי המערכת"
 ],
 "System time": [
  null,
  "שעון המערכת"
 ],
 "Systemd units": [
  null,
  "יחידות Systemd"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Targets": [
  null,
  "יעדים"
 ],
 "Terminal": [
  null,
  "מסוף"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "המשתמש $0 אינו מורשה לשנות את אפחותי אבטחת המעבד"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "המשתמש $0 אינו מורשה להחליף בין ערכות מדיניות קריפטוגרפיות"
 ],
 "This field cannot be empty": [
  null,
  "שדה זה לא יכול להישאר ריק"
 ],
 "This may take a while": [
  null,
  "פעולה זו עשויה לארוך זמן מה"
 ],
 "This system is using a custom profile": [
  null,
  "מערכת זו משתמשת בפרופיל מותאם אישית"
 ],
 "This system is using the recommended profile": [
  null,
  "מערכת זו משתמשת בפרופיל המומלץ"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "יחידה זו לא תוכננה להפעלה באופן מפורש."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "הבחירה באפשרות הזאת תוסיף התאמה ל־‚_BOOT_ID=‎’. אם לא נבחרה האפשרות יופיעו רק שורות התיעוד של הטעינה הנוכחית. אם מזהה הטעינה הושמט, היסט חיובי יחפש את הטעינות מתחילת היומן והיסט שווה או קטן מאפס יחפש טעינות החל מסוף היומן. בהתאם לכך, 1 זאת הטעינה הראשונה שנמצאת ביומן בסדר כרונולוגי, 2 היא השנייה וכן הלאה, בעוד ‎-0 היא הטעינה האחרונה, ‎-1 היא הטעינה לפני האחרונה וכן הלאה."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "פעולה זו תוסיף התאמה לביטויים ‚‎_SYSTEMD_UNIT=‎’,‏ ‚COREDUMP_UNIT=‎’ ו־‚UNIT=‎’ כדי למצוא את כל ההודעות האפשריות ליחידה מסוימת. יכולה להכיל יותר מיחידה אחת אם מפרידים ביניהן בפסיקים. "
 ],
 "Thursdays": [
  null,
  "ימי חמישי"
 ],
 "Time": [
  null,
  "שעה"
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "Timer creation failed": [
  null,
  "יצירת קוצב הזמן נכשלה"
 ],
 "Timer deletion failed": [
  null,
  "מחיקת קוצב הזמן נכשלה"
 ],
 "Timers": [
  null,
  "מתזמנים"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Toggle filters": [
  null,
  "החלפת מצב מסננים"
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Transient": [
  null,
  "זמני"
 ],
 "Trigger": [
  null,
  "הקפצה"
 ],
 "Triggered by": [
  null,
  "מוקפץ על ידי"
 ],
 "Triggers": [
  null,
  "הקפצות"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Tuesdays": [
  null,
  "ימי שלישי"
 ],
 "Tuned has failed to start": [
  null,
  "ההפעלה של Tuned נכשלה"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned הוא שירות שעוקב אחר המערכת שלך וממטב את הביצועים תחת עומסים מסוימים. הליבה של Tuned הם פרופילים, שמכוונים את המערכת שלך למגוון מקרי בוחן."
 ],
 "Tuned is not available": [
  null,
  "Tuned אינו זמין"
 ],
 "Tuned is not running": [
  null,
  "Tuned אינו מופעל"
 ],
 "Tuned is off": [
  null,
  "Tuned כבוי"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Type to filter": [
  null,
  "יש להקליד כדי לסנן"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "Unit": [
  null,
  "יחידה"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Unpin unit": [
  null,
  "שחרור היחידה"
 ],
 "Until": [
  null,
  "עד"
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "Updating status...": [
  null,
  "המצב מתעדכן…"
 ],
 "Usage": [
  null,
  "שימוש"
 ],
 "User": [
  null,
  "משתמש"
 ],
 "Validating address": [
  null,
  "הכתובת מתוקפת"
 ],
 "Vendor": [
  null,
  "ספק"
 ],
 "Version": [
  null,
  "גרסה"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "View all services": [
  null,
  "הצגת כל השירותים"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "View hardware details": [
  null,
  "הצגת פרטי חומרה"
 ],
 "View login history": [
  null,
  "הצגת היסטוריית כניסות למערכת"
 ],
 "View metrics and history": [
  null,
  "הצגת מדדים והיסטוריה"
 ],
 "View report": [
  null,
  "הצגת דוח"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "צפייה בפרטי זיכרון דורשת גישה ניהולית."
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Waiting for input…": [
  null,
  "בהמתנה לקלט…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Waiting to start…": [
  null,
  "בהמתנה להפעלה…"
 ],
 "Wanted by": [
  null,
  "נדרש על ידי"
 ],
 "Wants": [
  null,
  "דורש"
 ],
 "Warning and above": [
  null,
  "אזהרה ומעלה"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "Web console is running in limited access mode.": [
  null,
  "המסוף המקוון מופעל במצב גישה מוגבלת."
 ],
 "Wednesdays": [
  null,
  "ימי רביעי"
 ],
 "Weekly": [
  null,
  "שבועי"
 ],
 "Weeks": [
  null,
  "שבועות"
 ],
 "White": [
  null,
  "לבן"
 ],
 "Yearly": [
  null,
  "שנתי"
 ],
 "Yes": [
  null,
  "כן"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "You may try to load older entries.": [
  null,
  "כדאי לך לנסות לטעון רשומות ישנות יותר."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "active": [
  null,
  "פעיל"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "הצגת מפתחות ה־ssh של המארח נכשלה: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "inconsistent": [
  null,
  "חסר אחידות"
 ],
 "journalctl manpage": [
  null,
  "מדריך השימוש ב־journalctl"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "אין"
 ],
 "of $0 CPU": [
  null,
  "מתוך מעבד אחד",
  "מתוך $0 מעבדים",
  "מתוך $0 מעבדים",
  "מתוך $0 מעבדים"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "recommended": [
  null,
  "מומלץ"
 ],
 "running $0": [
  null,
  "פועל $0"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "unknown": [
  null,
  "לא ידוע"
 ],
 "dialog-title\u0004Domain": [
  null,
  "שם תחום"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "הצטרפות לשם תחום"
 ],
 "from <host>\u0004from $0": [
  null,
  "מ־$0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "מ־$0 על גבי $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "על גבי $0"
 ]
});
