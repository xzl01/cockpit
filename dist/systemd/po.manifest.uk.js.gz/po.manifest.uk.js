cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Налаштовування параметрів системи"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Logs": [
  null,
  "Журнали"
 ],
 "Managing services": [
  null,
  "Керування службами"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "Overview": [
  null,
  "Огляд"
 ],
 "Reviewing logs": [
  null,
  "Перегляд журналів"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Служби"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Terminal": [
  null,
  "Термінал"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "мітка активу"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "завантаження"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "команда"
 ],
 "console": [
  null,
  "консоль"
 ],
 "coredump": [
  null,
  "дамп ядра"
 ],
 "cpu": [
  null,
  "процесор"
 ],
 "crash": [
  null,
  "аварія"
 ],
 "date": [
  null,
  "дата"
 ],
 "debug": [
  null,
  "діагностика"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "вимкнути"
 ],
 "disks": [
  null,
  "диски"
 ],
 "domain": [
  null,
  "домен"
 ],
 "enable": [
  null,
  "увімкнути"
 ],
 "error": [
  null,
  "помилка"
 ],
 "graphs": [
  null,
  "графіки"
 ],
 "hardware": [
  null,
  "обладнання"
 ],
 "history": [
  null,
  "журнал"
 ],
 "host": [
  null,
  "вузол"
 ],
 "journal": [
  null,
  "журнал"
 ],
 "machine": [
  null,
  "машина"
 ],
 "mask": [
  null,
  "маска"
 ],
 "memory": [
  null,
  "пам'ять"
 ],
 "metrics": [
  null,
  "метрика"
 ],
 "mitigation": [
  null,
  "обхід"
 ],
 "network": [
  null,
  "мережа"
 ],
 "operating system": [
  null,
  "операційна система"
 ],
 "os": [
  null,
  "ос"
 ],
 "path": [
  null,
  "шлях"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "швидкодія"
 ],
 "power": [
  null,
  "живлення"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "перезапуск"
 ],
 "serial": [
  null,
  "послідовний"
 ],
 "service": [
  null,
  "служба"
 ],
 "shell": [
  null,
  "оболонка"
 ],
 "shut": [
  null,
  "вимкнути"
 ],
 "socket": [
  null,
  "сокет"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "ціль"
 ],
 "time": [
  null,
  "time"
 ],
 "timer": [
  null,
  "секундомір"
 ],
 "unit": [
  null,
  "модуль"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "version": [
  null,
  "версія"
 ],
 "warning": [
  null,
  "попередження"
 ]
});
