cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritik sonuç",
  "$0 sonuç, kritik olanlar dahil"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 exited with code $1": [
  null,
  "$0, $1 koduyla çıkış yaptı"
 ],
 "$0 failed": [
  null,
  "$0 başarısız oldu"
 ],
 "$0 failed login attempt": [
  null,
  "$0 başarısız oturum açma girişimi",
  "$0 başarısız oturum açma girişimi"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 important hit": [
  null,
  "$0 önemli sonuç",
  "$0 sonuç, önemli olanlar dahil"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "$0 killed with signal $1": [
  null,
  "$0, $1 sinyali ile sonlandırıldı"
 ],
 "$0 low severity hit": [
  null,
  "$0 düşük önem derecesinde sonuç",
  "$0 düşük önem derecesinde sonuç"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "$0 moderate hit": [
  null,
  "$0 orta dereceli sonuç",
  "$0 sonuç, orta dereceli olanlar dahil"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 service has failed": [
  null,
  "$0 hizmet başarısız oldu",
  "$0 hizmet başarısız oldu"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 will be installed.": [
  null,
  "$0 kurulacak."
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "$0: crash at $1": [
  null,
  "$0: $1 tarihinde çökme"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "5th": [
  null,
  "5."
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Acceptable password": [
  null,
  "Kabul edilebilir parola"
 ],
 "Active since ": [
  null,
  "Etkin olma başlangıcı "
 ],
 "Active state": [
  null,
  "Etkin durum"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Add $0": [
  null,
  "$0 ekle"
 ],
 "Additional actions": [
  null,
  "Ek eylemler"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile Yönetim"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "After": [
  null,
  "Sonra"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Etki alanından ayrıldıktan sonra, sadece yerel kimlik bilgilerine sahip kullanıcılar bu makinede oturum açabilecektir. DNS çözümleme ayarları ve güvenilen CA'ların listesi değişebileceğinden, bu durum diğer hizmetleri de etkileyebilir."
 ],
 "After system boot": [
  null,
  "Sistem önyüklemesinden sonra"
 ],
 "Alert and above": [
  null,
  "Uyarı ve üstü"
 ],
 "Alias": [
  null,
  "Kod adı"
 ],
 "All": [
  null,
  "Tümü"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Allow running (unmask)": [
  null,
  "Çalıştırmaya izin ver (maskelemeyi kaldır)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rolleri belgeleri"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Günlük iletilerindeki herhangi bir metin dizgisi süzülebilir. Dizgi ayrıca düzenli ifade biçiminde de olabilir. Ayrıca ileti günlük alanlarına göre süzmeyi de destekler. Bunlar, değerin olası değerlerin virgülle ayrılmış listesi olabilen, FIELD=VALUE biçimindeki boşlukla ayrılmış değerlerdir."
 ],
 "Appearance": [
  null,
  "Görünüm"
 ],
 "Apply and reboot": [
  null,
  "Uygula ve yeniden başlat"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Yeni ilke uygulanıyor... Bu işlem birkaç dakika sürebilir."
 ],
 "Asset tag": [
  null,
  "Demirbaş etiketi"
 ],
 "At minute": [
  null,
  "Dakikada"
 ],
 "At second": [
  null,
  "Saniyede"
 ],
 "At specific time": [
  null,
  "Belirli bir zamanda"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile yetkili görevleri gerçekleştirmek için kimlik doğrulaması gerekir"
 ],
 "Automatically starts": [
  null,
  "Otomatik olarak başlar"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Otomatik olarak ek NTP sunucularını kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "Automation script": [
  null,
  "Otomatikleştirme betiği"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS tarihi"
 ],
 "BIOS version": [
  null,
  "BIOS sürümü"
 ],
 "Bad": [
  null,
  "Hatalı"
 ],
 "Bad setting": [
  null,
  "Hatalı ayar"
 ],
 "Before": [
  null,
  "Önce"
 ],
 "Binds to": [
  null,
  "Bağlanır"
 ],
 "Black": [
  null,
  "Siyah"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Boot": [
  null,
  "Önyükleme"
 ],
 "Bound by": [
  null,
  "Bağlayan"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU güvenliği"
 ],
 "CPU security toggles": [
  null,
  "CPU güvenlik geçişleri"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Şu anki süzgeçlerin birleşimi kullanılarak herhangi bir günlük bulunamıyor."
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Cancel poweroff": [
  null,
  "Kapatmayı iptal et"
 ],
 "Cancel reboot": [
  null,
  "Yeniden başlatmayı iptal et"
 ],
 "Cannot be enabled": [
  null,
  "Etkinleştirilemez"
 ],
 "Cannot forward login credentials": [
  null,
  "Oturum açma kimlik bilgileri yönlendirilemiyor"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Bu sistemde realmd mevcut olmadığından bir etki alanına katılamıyor"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Change cryptographic policy": [
  null,
  "Şifreleme ilkesini değiştir"
 ],
 "Change host name": [
  null,
  "Anamakine adını değiştir"
 ],
 "Change performance profile": [
  null,
  "Performans profilini değiştir"
 ],
 "Change profile": [
  null,
  "Profili değiştir"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Checking installed software": [
  null,
  "Kurulu yazılımlar denetleniyor"
 ],
 "Class": [
  null,
  "Sınıf"
 ],
 "Clear 'Failed to start'": [
  null,
  "'Başlatılamadı' hatasını temizle"
 ],
 "Clear all filters": [
  null,
  "Tüm süzgeçleri temizle"
 ],
 "Client software": [
  null,
  "İstemci yazılımı"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager ve Firewalld'un Cockpit yapılandırması"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit, verilen anamakineyle iletişim kuramadı."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit, Linux sunucularınızı bir web tarayıcısı aracılığıyla yönetmenizi kolaylaştıran bir sunucu yöneticisidir. Terminal ve web aracı arasında geçiş yapmak sorun değildir. Cockpit aracılığıyla başlatılan bir hizmet terminal aracılığıyla durdurulabilir. Aynı şekilde, terminalde bir hata meydana gelirse, Cockpit günlüğü arayüzünde görülebilir."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit, sistemdeki yazılımla uyumlu değil."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit sistemde kurulu değil."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit yeni sistem yöneticileri için mükemmeldir; depolama yönetimi, günlükleri inceleme, hizmetleri başlatma ve durdurma gibi basit görevleri kolayca gerçekleştirmelerine olanak tanır. Aynı anda birkaç sunucuyu izleyebilir ve yönetebilirsiniz. Bunları tek bir tıklama ile ekleyin ve makineleriniz arkadaşlarıyla ilgilensin."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Tanılama ve destek verilerini topla ve paketle"
 ],
 "Collect kernel crash dumps": [
  null,
  "Çekirdek çökme dökümlerini topla"
 ],
 "Command": [
  null,
  "Komut"
 ],
 "Command not found": [
  null,
  "Komut bulunamadı"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned ile iletişim başarısız oldu"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "$0=$1 koşulu karşılanmadı"
 ],
 "Condition failed": [
  null,
  "Koşul başarısız oldu"
 ],
 "Configuration": [
  null,
  "Yapılandırma"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 aygıtının silinmesini onayla"
 ],
 "Conflicted by": [
  null,
  "Çakışan"
 ],
 "Conflicts": [
  null,
  "Çakışanlar"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Dbus'a bağlanma başarısız oldu: $0"
 ],
 "Connection has timed out.": [
  null,
  "Bağlantı zaman aşımına uğradı."
 ],
 "Consists of": [
  null,
  "İçerir"
 ],
 "Contacted domain": [
  null,
  "İletişim kurulan etki alanı"
 ],
 "Controller": [
  null,
  "Denetleyici"
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Crash reporting": [
  null,
  "Çökme bildirimi"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Create new task file with this content.": [
  null,
  "Bu içerikle yeni görev dosyası oluştur."
 ],
 "Create timer": [
  null,
  "Zamanlayıcı oluştur"
 ],
 "Critical and above": [
  null,
  "Kritik ve üstü"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Şifreleme İlkeleri TLS, IPSec, SSH, DNSSec ve Kerberos protokollerini kapsayan temel şifreleme alt sistemlerini yapılandıran bir sistem bileşenidir."
 ],
 "Cryptographic policy": [
  null,
  "Şifreleme ilkesi"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Şifreleme ilkesi tutarsız"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Şu anki önyükleme"
 ],
 "Custom cryptographic policy": [
  null,
  "Özel şifreleme ilkesi"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "SHA-1 imza doğrulamasına sahip VARSAYILAN'a izin verildi."
 ],
 "Daily": [
  null,
  "Günlük"
 ],
 "Dark": [
  null,
  "Koyu"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Tarih özellikleri, YYYY-MM-DD hh:mm:ss biçiminde olmalıdır. Alternatif olarak 'yesterday', 'today', 'tomorrow' dizgileri de anlaşılır. 'now' şu anki zamanı ifade eder. Son olarak, göreceli zamanlar '-' veya '+' önekleri ile belirtilebilir"
 ],
 "Debug and above": [
  null,
  "Hata ayıklama ve üstü"
 ],
 "Decrease by one": [
  null,
  "Bir azalt"
 ],
 "Default": [
  null,
  "Öntanımlı"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Delay must be a number": [
  null,
  "Gecikme bir sayı olmak zorundadır"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Deletion will remove the following files:": [
  null,
  "Silme işlemi aşağıdaki dosyaları kaldıracak:"
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Eşzamanlı çoklu kullanımı etkisizleştir"
 ],
 "Disable tuned": [
  null,
  "tuned'i etkisizleştir"
 ],
 "Disabled": [
  null,
  "Etkisizleştirildi"
 ],
 "Disallow running (mask)": [
  null,
  "Çalıştırmaya izin verme (maskele)"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "Does not automatically start": [
  null,
  "Otomatik olarak başlamaz"
 ],
 "Domain": [
  null,
  "Etki alanı"
 ],
 "Domain address": [
  null,
  "Etki alanı adresi"
 ],
 "Domain administrator name": [
  null,
  "Etki alanı yöneticisi adı"
 ],
 "Domain administrator password": [
  null,
  "Etki alanı yöneticisi parolası"
 ],
 "Domain could not be contacted": [
  null,
  "Etki alanıyla iletişim kurulamadı"
 ],
 "Domain is not supported": [
  null,
  "Etki alanı desteklenmiyor"
 ],
 "Don't repeat": [
  null,
  "Tekrarlama"
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd'yi düzenle"
 ],
 "Edit motd": [
  null,
  "motd'yi düzenle"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Enabled": [
  null,
  "Etkinleştirildi"
 ],
 "Entry at $0": [
  null,
  "$0 tarihindeki giriş"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "Error and above": [
  null,
  "Hata ve üstü"
 ],
 "Error message": [
  null,
  "Hata iletisi"
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Extended information": [
  null,
  "Genişletilmiş bilgiler"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS düzgün şekilde etkinleştirilmedi"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "Daha fazla Ortak Ölçüt kısıtlamasına sahip FIPS."
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "Failed to disable tuned": [
  null,
  "tuned etkisizleştirme başarısız oldu"
 ],
 "Failed to disable tuned profile": [
  null,
  "tuned profilini etkisizleştirmesi başarısız oldu"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld içinde $0 etkinleştirme başarısız oldu"
 ],
 "Failed to enable tuned": [
  null,
  "tuned etkinleştirme başarısız oldu"
 ],
 "Failed to fetch logs": [
  null,
  "Günlükleri getirme başarısız oldu"
 ],
 "Failed to load unit": [
  null,
  "Birim ekleme başarısız oldu"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "/etc/motd içinde değişiklikleri kaydetme başarısız oldu"
 ],
 "Failed to start": [
  null,
  "Başlatılamadı"
 ],
 "Failed to switch profile": [
  null,
  "Profil değiştirme başarısız oldu"
 ],
 "File state": [
  null,
  "Dosya durumu"
 ],
 "Filter by name or description": [
  null,
  "Ada veya açıklamaya göre süz"
 ],
 "Filters": [
  null,
  "Süzgeçler"
 ],
 "Font size": [
  null,
  "Yazı tipi boyutu"
 ],
 "Forbidden from running": [
  null,
  "Çalıştırılması yasak"
 ],
 "Frame number": [
  null,
  "Çerçeve numarası"
 ],
 "Free-form search": [
  null,
  "Serbest biçimli arama"
 ],
 "Fridays": [
  null,
  "Cuma günleri"
 ],
 "General": [
  null,
  "Genel"
 ],
 "Generated": [
  null,
  "Oluşturuldu"
 ],
 "Go to $0": [
  null,
  "$0 hizmetine git"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Hardware information": [
  null,
  "Donanım bilgileri"
 ],
 "Health": [
  null,
  "Sağlık"
 ],
 "Help": [
  null,
  "Yardım"
 ],
 "Hide confirmation password": [
  null,
  "Onay parolasını gizle"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "Hierarchy ID": [
  null,
  "Hiyerarşi Kimliği"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Artan saldırı yüzeyi pahasına daha yüksek birlikte çalışabilirlik."
 ],
 "Host key is incorrect": [
  null,
  "Anamakine anahtarı yanlış"
 ],
 "Hostname": [
  null,
  "Anamakine adı"
 ],
 "Hourly": [
  null,
  "Saatlik"
 ],
 "Hours": [
  null,
  "Saat"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "Identifier": [
  null,
  "Tanımlayıcı"
 ],
 "Increase by one": [
  null,
  "Bir artır"
 ],
 "Indirect": [
  null,
  "Dolaylı"
 ],
 "Info and above": [
  null,
  "Bilgi ve üstü"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Install realmd support": [
  null,
  "realmd desteğini kur"
 ],
 "Install software": [
  null,
  "Yazılım kur"
 ],
 "Installing $0": [
  null,
  "$0 kuruluyor"
 ],
 "Internal error": [
  null,
  "Dahili hata"
 ],
 "Invalid": [
  null,
  "Geçersiz"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid file permissions": [
  null,
  "Geçersiz dosya izinleri"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Join": [
  null,
  "Katıl"
 ],
 "Join domain": [
  null,
  "Etki alanına katıl"
 ],
 "Joining": [
  null,
  "Katılıyor"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Bir etki alanına katılmak, realmd kurulumu gerektirir"
 ],
 "Joining this domain is not supported": [
  null,
  "Bu etki alanına katılmak desteklenmiyor"
 ],
 "Joins namespace of": [
  null,
  "Katıldığı ait olduğu ad alanı"
 ],
 "Journal": [
  null,
  "Günlük"
 ],
 "Journal entry": [
  null,
  "Günlük girişi"
 ],
 "Journal entry not found": [
  null,
  "Günlük girişi bulunamadı"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "Active Directory birlikte çalışabilirliğine sahip ESKİ."
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Last 24 hours": [
  null,
  "Son 24 saat"
 ],
 "Last 7 days": [
  null,
  "Son 7 gün"
 ],
 "Last successful login:": [
  null,
  "Son başarılı oturum açma:"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "Leave $0": [
  null,
  "$0'dan ayrıl"
 ],
 "Leave domain": [
  null,
  "Etki alanından ayrıl"
 ],
 "Light": [
  null,
  "Açık"
 ],
 "Limits": [
  null,
  "Sınırlar"
 ],
 "Linked": [
  null,
  "Bağlantılı"
 ],
 "Listen": [
  null,
  "Dinle"
 ],
 "Listing units": [
  null,
  "Birimleri listeleme"
 ],
 "Listing units failed: $0": [
  null,
  "Birimleri listeleme başarısız oldu: $0"
 ],
 "Load earlier entries": [
  null,
  "Daha önceki girişleri yükle"
 ],
 "Loading earlier entries": [
  null,
  "Daha önceki girişler yükleniyor"
 ],
 "Loading keys...": [
  null,
  "Anahtarlar yükleniyor..."
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH anahtarlarını yükleme başarısız oldu"
 ],
 "Loading of units failed": [
  null,
  "Birimlerin yüklenmesi başarısız oldu"
 ],
 "Loading system modifications...": [
  null,
  "Sistem değişiklikleri yükleniyor..."
 ],
 "Loading unit failed": [
  null,
  "Birimin yüklenmesi başarısız oldu"
 ],
 "Loading...": [
  null,
  "Yükleniyor..."
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "Login failed": [
  null,
  "Oturum açma başarısız oldu"
 ],
 "Login format": [
  null,
  "Oturum açma biçimi"
 ],
 "Logs": [
  null,
  "Günlükler"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "Makine kimliği"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Makine SSH anahtarı parmak izleri"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Maintenance": [
  null,
  "Bakım"
 ],
 "Manage storage": [
  null,
  "Depolamayı yönet"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Mask service": [
  null,
  "Hizmeti maskele"
 ],
 "Masked": [
  null,
  "Maskelendi"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Hizmeti maskelemek, tüm bağımlı birimlerin çalışmasını engeller. Bunun beklenenden daha büyük etkisi olabilir. Lütfen bu birimi maskelemek istediğinizi onaylayın."
 ],
 "Memory": [
  null,
  "Bellek"
 ],
 "Memory technology": [
  null,
  "Bellek teknolojisi"
 ],
 "Merged": [
  null,
  "Birleştirildi"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Dakikanın 0 ile 59 arasında bir sayı olması gerekir"
 ],
 "Minutely": [
  null,
  "Dakikada"
 ],
 "Minutes": [
  null,
  "Dakika"
 ],
 "Mitigations": [
  null,
  "Risk azaltmaları"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Mondays": [
  null,
  "Pazartesi günleri"
 ],
 "Monthly": [
  null,
  "Aylık"
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "No": [
  null,
  "Hayır"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "No host keys found.": [
  null,
  "Bulunan anamakine anahtarları yok."
 ],
 "No log entries": [
  null,
  "Günlük girişleri yok"
 ],
 "No logs found": [
  null,
  "Bulunan günlükler yok"
 ],
 "No matching results": [
  null,
  "Eşleşen sonuçlar yok"
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Süzme ölçütüyle eşleşen sonuçlar yok. Sonuçları göstermek için tüm süzgeçleri temizleyin."
 ],
 "No rule hits": [
  null,
  "Kural sonuçları yok"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "No system modifications": [
  null,
  "Sistem değişiklikleri yok"
 ],
 "None": [
  null,
  "Yok"
 ],
 "Not a valid private key": [
  null,
  "Geçerli bir özel anahtar değil"
 ],
 "Not connected to Insights": [
  null,
  "Insights'a bağlı değil"
 ],
 "Not found": [
  null,
  "Bulunamadı"
 ],
 "Not permitted to configure realms": [
  null,
  "Bölgeleri yapılandırmaya izin verilmiyor"
 ],
 "Not permitted to perform this action.": [
  null,
  "Bu eylemi gerçekleştirmeye izinli değil."
 ],
 "Not running": [
  null,
  "Çalışmıyor"
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Note": [
  null,
  "Not"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Bildirim ve üstü"
 ],
 "Occurrences": [
  null,
  "Oluşumlar"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "On failure": [
  null,
  "Başarısızlık durumunda"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit kurulduktan sonra, \"systemctl enable --now cockpit.socket\" komutuyla etkinleştirin."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Sadece harfler, sayılar, : , _ , . , @ , - karakterlerine izin verilir"
 ],
 "Only emergency": [
  null,
  "Sadece acil durumlar"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS modunda önyükleme yaparken yalnızca onaylanmış ve izin verilen algoritmaları kullan."
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "Overview": [
  null,
  "Genel Bakış"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "Part of": [
  null,
  "Parçası olduğu"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Password not accepted": [
  null,
  "Parola kabul edilmedi"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Path": [
  null,
  "Yol"
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "Paths": [
  null,
  "Yollar"
 ],
 "Pause": [
  null,
  "Duraklat"
 ],
 "Performance profile": [
  null,
  "Performans profili"
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Pin unit": [
  null,
  "Birimi sabitle"
 ],
 "Pinned unit": [
  null,
  "Sabitlenmiş birim"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Pretty host name": [
  null,
  "Okunaklı anamakine adı"
 ],
 "Previous boot": [
  null,
  "Önceki önyükleme"
 ],
 "Priority": [
  null,
  "Öncelik"
 ],
 "Problem details": [
  null,
  "Sorun ayrıntıları"
 ],
 "Problem info": [
  null,
  "Sorun bilgileri"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Propagates reload to": [
  null,
  "Yeniden yüklemeyi şuna yayar"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Birlikte çalışabilirlik pahasına beklenen yakın vadeli gelecekteki saldırılara karşı korur."
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Rank": [
  null,
  "Sıra"
 ],
 "Read more...": [
  null,
  "Daha fazlasını okuyun..."
 ],
 "Read-only": [
  null,
  "Salt-okunur"
 ],
 "Real host name": [
  null,
  "Gerçek anamakine adı"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Gerçek anamakine adı sadece küçük harf, rakam, kısa çizgi ve nokta karakterlerini (doldurulmuş alt etki alanlarıyla) içerebilir"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Gerçek anamakine adı 64 karakter veya daha kısa olmak zorundadır"
 ],
 "Reapply and reboot": [
  null,
  "Yeniden uygula ve yeniden başlat"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Geçerli tehdit modelleri için tavsiye edilen, güvenli ayarlar."
 ],
 "Reload": [
  null,
  "Yeniden yükle"
 ],
 "Reload propagated from": [
  null,
  "Yeniden yükleme şuradan yayıldı"
 ],
 "Reloading": [
  null,
  "Yeniden yükleniyor"
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Repeat": [
  null,
  "Tekrarla"
 ],
 "Repeat monthly": [
  null,
  "Her ay tekrarla"
 ],
 "Repeat weekly": [
  null,
  "Her hafta tekrarla"
 ],
 "Report": [
  null,
  "Bildir"
 ],
 "Report to ABRT Analytics": [
  null,
  "ABRT Analytics'e bildir"
 ],
 "Reported; no links available": [
  null,
  "Bildirildi; mevcut bağlantılar yok"
 ],
 "Reporting failed": [
  null,
  "Bildirme başarısız oldu"
 ],
 "Reporting was canceled": [
  null,
  "Bildirme iptal edildi"
 ],
 "Reports:": [
  null,
  "Bildirmeler:"
 ],
 "Required by": [
  null,
  "Gerektiren"
 ],
 "Required by ": [
  null,
  "Gerektiren: "
 ],
 "Requires": [
  null,
  "Gerekliler"
 ],
 "Requires administration access to edit": [
  null,
  "Düzenlemek için yönetim erişimi gerektirir"
 ],
 "Requisite": [
  null,
  "Gereklilik"
 ],
 "Requisite of": [
  null,
  "Gerekliliği"
 ],
 "Reset": [
  null,
  "Sıfırla"
 ],
 "Restart": [
  null,
  "Yeniden başlat"
 ],
 "Resume": [
  null,
  "Devam"
 ],
 "Review cryptographic policy": [
  null,
  "Şifreleme ilkesini gözden geçir"
 ],
 "Row expansion": [
  null,
  "Satır genişletme"
 ],
 "Row select": [
  null,
  "Satır seçimi"
 ],
 "Run at": [
  null,
  "Çalıştırma saati"
 ],
 "Run on": [
  null,
  "Çalıştırma tarihi"
 ],
 "Running": [
  null,
  "Çalışıyor"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "Cumartesi günleri"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Save and reboot": [
  null,
  "Kaydet ve yeniden başlat"
 ],
 "Save changes": [
  null,
  "Değişiklikleri kaydet"
 ],
 "Scheduled poweroff at $0": [
  null,
  "$0 için kapatma zamanlandı"
 ],
 "Scheduled reboot at $0": [
  null,
  "$0 için yeniden başlatma zamanlandı"
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Search": [
  null,
  "Ara"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Saniyenin 0 ile 59 arasında bir sayı olması gerekir"
 ],
 "Seconds": [
  null,
  "Saniye"
 ],
 "Secure shell keys": [
  null,
  "Güvenli kabuk anahtarları"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Güvenlik Gelişmiş Linux yapılandırması ve sorun giderme"
 ],
 "Select a identifier": [
  null,
  "Bir tanımlayıcı seçin"
 ],
 "Send": [
  null,
  "Gönder"
 ],
 "Server has closed the connection.": [
  null,
  "Sunucu bağlantıyı kapattı."
 ],
 "Server software": [
  null,
  "Sunucu yazılımı"
 ],
 "Service logs": [
  null,
  "Hizmet günlükleri"
 ],
 "Services": [
  null,
  "Hizmetler"
 ],
 "Set hostname": [
  null,
  "Anamakine adını ayarla"
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Shell script": [
  null,
  "Kabuk betiği"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Tüm iş parçacıklarını göster"
 ],
 "Show confirmation password": [
  null,
  "Onay parolasını göster"
 ],
 "Show fingerprints": [
  null,
  "Parmak izlerini göster"
 ],
 "Show messages containing given string.": [
  null,
  "Verilen dizgiyi içeren iletileri gösterin."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Belirtilen systemd birimi için iletileri gösterin."
 ],
 "Show messages from a specific boot.": [
  null,
  "Belirli bir önyüklemeden gelen iletileri gösterin."
 ],
 "Show more relationships": [
  null,
  "Daha fazla ilişki göster"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Show relationships": [
  null,
  "İlişkileri göster"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Shutdown": [
  null,
  "Kapat"
 ],
 "Since": [
  null,
  "Başlangıç"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "Slot": [
  null,
  "Yuva"
 ],
 "Sockets": [
  null,
  "Soketler"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Yazılım tabanlı geçici çözümler, CPU güvenlik sorunlarını önlemeye yardımcı olur. Bu risk azaltmaları, performansı düşürme yan etkisine sahiptir. Bu ayarları değiştirmekte sorumluluk size aittir."
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Speed": [
  null,
  "Hız"
 ],
 "Start": [
  null,
  "Başlat"
 ],
 "Start and enable": [
  null,
  "Başlat ve etkinleştir"
 ],
 "Start service": [
  null,
  "Hizmeti başlat"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Belirtilen tarihten daha yeni veya o tarihteki girişleri göstermeyi başlatın."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Belirtilen tarihten daha eski veya o tarihteki girişleri göstermeyi başlatın."
 ],
 "State": [
  null,
  "Durum"
 ],
 "Static": [
  null,
  "Sabit"
 ],
 "Status": [
  null,
  "Durum"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "Stop": [
  null,
  "Durdur"
 ],
 "Stop and disable": [
  null,
  "Durdur ve etkisizleştir"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Strong password": [
  null,
  "Güçlü parola"
 ],
 "Stub": [
  null,
  "Kalıntı"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd sinyallerine abone olma başarısız oldu: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Başarılı olarak panoya kopyalandı"
 ],
 "Sundays": [
  null,
  "Pazar günleri"
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "System information": [
  null,
  "Sistem bilgileri"
 ],
 "System time": [
  null,
  "Sistem saati"
 ],
 "Systemd units": [
  null,
  "Systemd birimleri"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Hedefler"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Oturum açmış kullanıcının sistem değişikliklerini görüntülemesine izin verilmiyor"
 ],
 "The passwords do not match.": [
  null,
  "Parolalar eşleşmiyor."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Sunucu, desteklenen herhangi bir yöntemi kullanarak kimlik doğrulamayı reddetti."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "$0 kullanıcısının CPU güvenlik riski azaltmalarını değiştirmesine izin verilmiyor"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "$0 kullanıcısının şifreleme ilkelerini değiştirmesine izin verilmiyor"
 ],
 "This field cannot be empty": [
  null,
  "Bu alan boş olamaz"
 ],
 "This may take a while": [
  null,
  "Bu biraz zaman alabilir"
 ],
 "This system is using a custom profile": [
  null,
  "Bu sistem özel bir profil kullanıyor"
 ],
 "This system is using the recommended profile": [
  null,
  "Bu sistem önerilen profili kullanıyor"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Bu araç, SELinux ilkesini yapılandırır ve ilke ihlallerinin anlaşılmasına ve çözülmesine yardımcı olabilir."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Bu araç, sistemi çekirdek çökme dökümlerini diske yazacak şekilde yapılandırır."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Bu araç, çalışan sistemden bir yapılandırma ve tanılama bilgileri arşivi oluşturur. Arşiv, kayıt veya izleme amacıyla yerel veya merkezi olarak depolanabilir veya teknik hata bulma ve hata ayıklamaya yardımcı olması için teknik destek temsilcilerine, geliştiricilere veya sistem yöneticilerine gönderilebilir."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Bu araç, dosya sistemleri, LVM2 birim grupları ve NFS bağlamaları gibi yerel depolamayı yönetir."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Bu araç, NetworkManager ve Firewalld kullanarak birleştirmeler, köprüler, takımlar, VLAN'lar ve güvenlik duvarları gibi ağları yönetir. NetworkManager, Ubuntu'nun varsayılan systemd-networkd ve Debian'ın ifupdown betikleriyle uyumsuzdur."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Bu birim açıkça etkinleştirilecek şekilde tasarlanmadı."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Bu, '_BOOT_ID=' için bir eşleşme ekleyecektir. Eğer belirtilmemişse, şu anki önyükleme için günlükler gösterilecektir. Eğer önyükleme kimliği atlanırsa, pozitif bir denkleştirme, günlüğün başından itibaren başlayarak önyüklemeleri arayacak ve eşit ya da sıfırdan az denkleştirme, günlüğün sonundan başlayarak önyüklemeleri arayacaktır. Böylece, 1, günlükte bulunan ilk önyükleme, 2, ikincisi ve bunun gibi; -0 son önyükleme ise, -1 sondan önceki önyükleme ve bunun gibi."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Bu, belirli birim için olası tüm iletileri bulmak amacıyla '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' ve 'UNIT=' için eşleşme ekleyecek. Virgülle ayrılmış daha fazla birim içerebilir. "
 ],
 "Thursdays": [
  null,
  "Perşembe günleri"
 ],
 "Time": [
  null,
  "Zaman"
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "Timer creation failed": [
  null,
  "Zamanlayıcı oluşturma başarısız oldu"
 ],
 "Timer deletion failed": [
  null,
  "Zamanlayıcı silme başarısız oldu"
 ],
 "Timers": [
  null,
  "Zamanlayıcılar"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Toggle filters": [
  null,
  "Süzgeçleri aç/kapat"
 ],
 "Too much data": [
  null,
  "Çok fazla veri"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transient": [
  null,
  "Geçici"
 ],
 "Trigger": [
  null,
  "Tetikleyici"
 ],
 "Triggered by": [
  null,
  "Tetikleyen"
 ],
 "Triggers": [
  null,
  "Tetikleyiciler"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "Tuesdays": [
  null,
  "Salı günleri"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned başlatılamadı"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned , sisteminizi izleyen ve belirli iş yükleri altında performansı en iyi hale getiren bir hizmettir. Tuned'ın çekirdeği, sisteminizi farklı kullanım durumları için ayarlayan profillerdir."
 ],
 "Tuned is not available": [
  null,
  "Tuned kullanılabilir değil"
 ],
 "Tuned is not running": [
  null,
  "Tuned çalışmıyor"
 ],
 "Tuned is off": [
  null,
  "Tuned kapalı"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Type to filter": [
  null,
  "Süzmek için yazın"
 ],
 "Unit": [
  null,
  "Birim"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Unpin unit": [
  null,
  "Birimi sabitlemeyi kaldır"
 ],
 "Until": [
  null,
  "Bitiş"
 ],
 "Untrusted host": [
  null,
  "Güvenilmeyen anamakine"
 ],
 "Up since": [
  null,
  "Çalıştığı süre"
 ],
 "Updating status...": [
  null,
  "Durum güncelleniyor..."
 ],
 "Usage": [
  null,
  "Kullanım"
 ],
 "User": [
  null,
  "Kullanıcı"
 ],
 "Validating address": [
  null,
  "Adres doğrulanıyor"
 ],
 "Vendor": [
  null,
  "Satıcı"
 ],
 "Version": [
  null,
  "Sürüm"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "View all services": [
  null,
  "Tüm hizmetleri görüntüle"
 ],
 "View automation script": [
  null,
  "Otomatikleştirme betiğini görüntüle"
 ],
 "View hardware details": [
  null,
  "Donanım ayrıntılarını görüntüle"
 ],
 "View login history": [
  null,
  "Oturum açma geçmişini görüntüle"
 ],
 "View metrics and history": [
  null,
  "Ölçümleri ve geçmişi görüntüle"
 ],
 "View report": [
  null,
  "Raporu görüntüle"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Bellek bilgilerini görüntülemek için yönetimsel erişim gerekir."
 ],
 "Visit firewall": [
  null,
  "Güvenlik duvarını ziyaret et"
 ],
 "Waiting for input…": [
  null,
  "Girdi bekleniyor…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Waiting to start…": [
  null,
  "Başlatma bekleniyor…"
 ],
 "Wanted by": [
  null,
  "İsteyen"
 ],
 "Wants": [
  null,
  "İstenen"
 ],
 "Warning and above": [
  null,
  "Uyarı ve üstü"
 ],
 "Weak password": [
  null,
  "Zayıf parola"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux sunucuları için Web Konsolu"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web konsolu sınırlı erişim kipinde çalışıyor."
 ],
 "Wednesdays": [
  null,
  "Çarşamba günleri"
 ],
 "Weekly": [
  null,
  "Haftalık"
 ],
 "Weeks": [
  null,
  "Haftalar"
 ],
 "White": [
  null,
  "Beyaz"
 ],
 "Yearly": [
  null,
  "Yıllık"
 ],
 "Yes": [
  null,
  "Evet"
 ],
 "You may try to load older entries.": [
  null,
  "Daha eski girişleri yüklemeyi deneyebilirsiniz."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Your session has been terminated.": [
  null,
  "Oturumunuz sonlandırıldı."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Oturumunuzun süresi doldu. Lütfen tekrar oturum açın."
 ],
 "Zone": [
  null,
  "Bölge"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "active": [
  null,
  "etkin"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh anamakine anahtarlarını listeleme başarısız oldu: $0"
 ],
 "in less than a minute": [
  null,
  "bir dakikadan az süre"
 ],
 "inconsistent": [
  null,
  "tutarsız"
 ],
 "journalctl manpage": [
  null,
  "journalctl kılavuz sayfası"
 ],
 "less than a minute ago": [
  null,
  "bir dakikadan az bir süre önce"
 ],
 "none": [
  null,
  "yok"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU'nun",
  "$0 CPU'nun"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "recommended": [
  null,
  "önerilir"
 ],
 "running $0": [
  null,
  "$0 çalışıyor"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ],
 "unknown": [
  null,
  "bilinmeyen"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Etki alanı"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Bir etki alanına katıl"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0 anamakinesinden"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$1 üzerinde $0 anamakinesinden"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0 üzerinde"
 ]
});
