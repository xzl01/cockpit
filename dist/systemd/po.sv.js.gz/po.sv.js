cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritisk träff",
  "$0 träffar, inklusive kritiska"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avslutade med kod $1"
 ],
 "$0 failed": [
  null,
  "$0 misslyckades"
 ],
 "$0 failed login attempt": [
  null,
  "$0 misslyckat inloggningsförsök",
  "$0 misslyckade inloggningsförsök"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 important hit": [
  null,
  "$0 viktig träff",
  "$0 träffar, inklusive viktiga"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dödad med signal $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 träff med låg allvarlighet",
  "$0 träffar med låg allvarlighet"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "$0 moderate hit": [
  null,
  "$0 måttlig träff",
  "$0 träffar, inklusive måttliga"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 service has failed": [
  null,
  "$0 tjänsten har misslyckats",
  "$0 tjänsterna har misslyckats"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$0: crash at $1": [
  null,
  "$0: krasch vid $1"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "10th": [
  null,
  "10:e"
 ],
 "11th": [
  null,
  "11:e"
 ],
 "12th": [
  null,
  "12:e"
 ],
 "13th": [
  null,
  "13:e"
 ],
 "14th": [
  null,
  "14:e"
 ],
 "15th": [
  null,
  "15:e"
 ],
 "16th": [
  null,
  "16:e"
 ],
 "17th": [
  null,
  "17:e"
 ],
 "18th": [
  null,
  "18:e"
 ],
 "19th": [
  null,
  "19:e"
 ],
 "1st": [
  null,
  "1:a"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "20th": [
  null,
  "20:e"
 ],
 "21th": [
  null,
  "21:a"
 ],
 "22th": [
  null,
  "22:a"
 ],
 "23th": [
  null,
  "23:e"
 ],
 "24th": [
  null,
  "24:e"
 ],
 "25th": [
  null,
  "25:e"
 ],
 "26th": [
  null,
  "26:e"
 ],
 "27th": [
  null,
  "27:e"
 ],
 "28th": [
  null,
  "28:e"
 ],
 "29th": [
  null,
  "29:e"
 ],
 "2nd": [
  null,
  "2:a"
 ],
 "30th": [
  null,
  "30:e"
 ],
 "31st": [
  null,
  "31:a"
 ],
 "3rd": [
  null,
  "3:e"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "4th": [
  null,
  "4:e"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "5th": [
  null,
  "5:e"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "6th": [
  null,
  "6:e"
 ],
 "7th": [
  null,
  "7:e"
 ],
 "8th": [
  null,
  "8:e"
 ],
 "9th": [
  null,
  "9:e"
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Acceptable password": [
  null,
  "Acceptabelt lösenord"
 ],
 "Active since ": [
  null,
  "Aktiv sedan "
 ],
 "Active state": [
  null,
  "Aktivt tillstånd"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "Additional actions": [
  null,
  "Ytterligare åtgärder"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration med Cockpits webbkonsol"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "After": [
  null,
  "Efter"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Om du lämnar domänen kommer bara lokala användare kunna logga in på den här datorn. Det kan också påverka andra tjänster eftersom DNS och listan av betrodda CA kan ändras."
 ],
 "After system boot": [
  null,
  "Efter systemstart"
 ],
 "Alert and above": [
  null,
  "Larm och högre"
 ],
 "Alias": [
  null,
  "alias"
 ],
 "All": [
  null,
  "Alla"
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "Allow running (unmask)": [
  null,
  "Tillåt start (göm inte)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentation för Ansibleroller"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Alla textsträngar i loggmeddelandena kan filtreras. Strängen kan också vara i form av ett reguljärt uttryck. Stöder även filtrering efter meddelandeloggfält. Dessa är mellanslagsseparerade värden, i formen FÄLT=VÄRDE, där värde kan vara kommaseparerad lista över möjliga värden."
 ],
 "Appearance": [
  null,
  "Utseende"
 ],
 "Apply and reboot": [
  null,
  "Verkställ och starta om"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Tar ny policy i drift … Detta kan ta några minuter."
 ],
 "Asset tag": [
  null,
  "MaskinID"
 ],
 "At minute": [
  null,
  "På minut"
 ],
 "At second": [
  null,
  "På sekund"
 ],
 "At specific time": [
  null,
  "Vid en specifik tidpunkt"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering krävs för att utföra privilegierade uppgifter med Cockpits webbkonsol"
 ],
 "Automatically starts": [
  null,
  "Startar automatiskt"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Använder automatiskt ytterligare NTP-servrar"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS-datum"
 ],
 "BIOS version": [
  null,
  "BIOS-version"
 ],
 "Bad": [
  null,
  "Dålig"
 ],
 "Bad setting": [
  null,
  "Dålig inställning"
 ],
 "Before": [
  null,
  "Före"
 ],
 "Binds to": [
  null,
  "Binder till"
 ],
 "Black": [
  null,
  "Svart"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Boot": [
  null,
  "Start"
 ],
 "Bound by": [
  null,
  "Bundet av"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU-säkerhet"
 ],
 "CPU security toggles": [
  null,
  "CPU-säkerhetsinställningar"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Hittade inga loggar med dessa filter aktiva."
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cancel poweroff": [
  null,
  "Avbryt avstängning"
 ],
 "Cancel reboot": [
  null,
  "Avbryt omstart"
 ],
 "Cannot be enabled": [
  null,
  "Kan inte slås på"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inte vidarebefordra inloggningsuppgifterna"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Kan inte ansluta till en domän eftersom realmd inte finns på detta system"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change cryptographic policy": [
  null,
  "Ändra kryptografisk policy"
 ],
 "Change host name": [
  null,
  "Ändra värdnamn"
 ],
 "Change performance profile": [
  null,
  "Ändra prestandaprofil"
 ],
 "Change profile": [
  null,
  "Ändra profil"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "Class": [
  null,
  "Klass"
 ],
 "Clear 'Failed to start'": [
  null,
  "Nollställ \"Misslyckad start\""
 ],
 "Clear all filters": [
  null,
  "Nollställ alla filter"
 ],
 "Client software": [
  null,
  "Klientprogramvara"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit konfiguration av NetworkManager och Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunde inte kontakta den angivna värden."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit är en serverhanterare som gör det lätt att administrera dina Linuxservrar via en webbläsare. Att hoppa mellan terminalen och webbverktyget är inget problem. En tjänst som startas via Cockpit kan stoppas via terminalen. Likaledes, om ett fel uppstår i terminalen kan det ses i Cockpits journalgränssnitt."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit är inte kompatibelt med programvaran på systemet."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit är inte installerat på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit är perfekt för nya systemadministratörer, låter dem lätt utföra enkla uppgifter såsom lagringsadministration, inspektion av journaler och att starta och stoppa tjänster. Du kan övervaka och administrera flera servrar på samma gång. Lägg bara till dem med ett enda klick och dina maskiner kommer se efter sina kompisar."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Samla och paketera diagnostik och support data"
 ],
 "Collect kernel crash dumps": [
  null,
  "Samla kärnkraschdumpar"
 ],
 "Command": [
  null,
  "Kommando"
 ],
 "Command not found": [
  null,
  "Kommando hittades inte"
 ],
 "Communication with tuned has failed": [
  null,
  "Kommunikationen med tuned har misslyckats"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Villkoret $0=$1 uppfylldes inte"
 ],
 "Condition failed": [
  null,
  "Villkoret misslyckades"
 ],
 "Configuration": [
  null,
  "Konfiguration"
 ],
 "Confirm deletion of $0": [
  null,
  "Bekräfta raderingen av $0"
 ],
 "Conflicted by": [
  null,
  "Står i konflikt med"
 ],
 "Conflicts": [
  null,
  "Konflikter"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Anslutningen till dbus misslyckades: $0"
 ],
 "Connection has timed out.": [
  null,
  "Anslutningens tidsgräns överskreds."
 ],
 "Consists of": [
  null,
  "Består av"
 ],
 "Contacted domain": [
  null,
  "Kontaktade domänen"
 ],
 "Controller": [
  null,
  "Styrenhet"
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Crash reporting": [
  null,
  "Rapportera krascher"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Create new task file with this content.": [
  null,
  "Skapa en ny uppgiftsfil med detta innehåll."
 ],
 "Create timer": [
  null,
  "Skapa en timer"
 ],
 "Critical and above": [
  null,
  "Kritisk och högre"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografisk policy är en systemkomponent som konfigurerar de grundläggande kryptografiska undersystemen, innefattande protokollen TLS, IPSec, SSH, DNSSec och Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "Kryptografisk policy"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Kryptografipolicyn är inkonsekvent"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Nuvarande uppstart"
 ],
 "Custom cryptographic policy": [
  null,
  "Anpassad kryptografisk policy"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT med verifiering av SHA-1-signatur tillåten."
 ],
 "Daily": [
  null,
  "Dagligen"
 ],
 "Dark": [
  null,
  "Mörk"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Datumspecifikationen skall ha formatet ÅÅÅÅ-MM-DD hh:mm:ss. Alternativt förstås strängarna ”yesterday”, ”today”, ”tomorrow”. ”now” refererar till den aktuella tiden. Slutligen kan relativa tider anges, inledda med ”-” eller ”+”"
 ],
 "Debug and above": [
  null,
  "Felsökning och högre"
 ],
 "Decrease by one": [
  null,
  "Minska med en"
 ],
 "Default": [
  null,
  "Standard"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Delay must be a number": [
  null,
  "Fördröjning måste vara en siffra"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Deletion will remove the following files:": [
  null,
  "Radering kommer ta bort följande filer:"
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Stäng av hyperthreading"
 ],
 "Disable tuned": [
  null,
  "Avaktivera tuned"
 ],
 "Disabled": [
  null,
  "Avaktiverad"
 ],
 "Disallow running (mask)": [
  null,
  "Hindra körning (göm)"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "Does not automatically start": [
  null,
  "Startar inte automatiskt"
 ],
 "Domain": [
  null,
  "Domän"
 ],
 "Domain address": [
  null,
  "Domänadress"
 ],
 "Domain administrator name": [
  null,
  "Domänadministratörens namn"
 ],
 "Domain administrator password": [
  null,
  "Domänadministratörens lösenord"
 ],
 "Domain could not be contacted": [
  null,
  "Domän kunde inte kontaktas"
 ],
 "Domain is not supported": [
  null,
  "Domän stödjs inte"
 ],
 "Don't repeat": [
  null,
  "Upprepa inte"
 ],
 "Downloading $0": [
  null,
  "Hämtar $0"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "Edit /etc/motd": [
  null,
  "Redigera /etc/motd"
 ],
 "Edit motd": [
  null,
  "Redigera motd"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Enabled": [
  null,
  "Aktiverad"
 ],
 "Entry at $0": [
  null,
  "Ingång vid $0"
 ],
 "Error": [
  null,
  "Fel"
 ],
 "Error and above": [
  null,
  "Fel och högre"
 ],
 "Error message": [
  null,
  "Felmeddelande"
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Extended information": [
  null,
  "Utökad information"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS är inte korrekt aktiverat"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS med ytterligare begränsningar av allmänna kriterier."
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "Failed to disable tuned": [
  null,
  "Misslyckades att avaktivera tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Misslyckades med att avaktivera en tuned-profil"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Misslyckades att aktivera tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Misslyckades att hämta loggar"
 ],
 "Failed to load unit": [
  null,
  "Misslyckades att ladda enhet"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Misslyckades med att spara ändringar i /etc/motd"
 ],
 "Failed to start": [
  null,
  "Misslyckades att starta"
 ],
 "Failed to switch profile": [
  null,
  "Misslyckades att byta profil"
 ],
 "File state": [
  null,
  "Filstatus"
 ],
 "Filter by name or description": [
  null,
  "Filtrera efter namn eller beskrivning"
 ],
 "Filters": [
  null,
  "Filter"
 ],
 "Font size": [
  null,
  "Textstorlek"
 ],
 "Forbidden from running": [
  null,
  "Kan ej köras"
 ],
 "Frame number": [
  null,
  "Bildrutenummer"
 ],
 "Free-form search": [
  null,
  "Friformssökning"
 ],
 "Fridays": [
  null,
  "Fredagar"
 ],
 "General": [
  null,
  "Allmänt"
 ],
 "Generated": [
  null,
  "Genererad"
 ],
 "Go to $0": [
  null,
  "Gå till $0"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "Hardware information": [
  null,
  "Hårdvaruinformation"
 ],
 "Health": [
  null,
  "Hälsa"
 ],
 "Help": [
  null,
  "Hjälp"
 ],
 "Hide confirmation password": [
  null,
  "Dölj bekräftelselösenord"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "Hierarchy ID": [
  null,
  "Hierarki ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Högre interoperabilitet till priset av en ökad attackyta."
 ],
 "Host key is incorrect": [
  null,
  "Värdnyckeln är felaktig"
 ],
 "Hostname": [
  null,
  "Värdnamn"
 ],
 "Hourly": [
  null,
  "Varje timme"
 ],
 "Hours": [
  null,
  "Timmar"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identifierare"
 ],
 "Increase by one": [
  null,
  "Öka med en"
 ],
 "Indirect": [
  null,
  "Indirekt"
 ],
 "Info and above": [
  null,
  "Info och högre"
 ],
 "Insights: ": [
  null,
  "Detaljer: "
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Install realmd support": [
  null,
  "Installera realmd stöd"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Internal error": [
  null,
  "Internt fel"
 ],
 "Invalid": [
  null,
  "Felaktig"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Join": [
  null,
  "Gå med"
 ],
 "Join domain": [
  null,
  "Gå med i domän"
 ],
 "Joining": [
  null,
  "Går med"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Att gå med i en domän kräver installation av realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Att gå med i denna domän stödjs inte"
 ],
 "Joins namespace of": [
  null,
  "Går med i namnrymden för"
 ],
 "Journal": [
  null,
  "Journal"
 ],
 "Journal entry": [
  null,
  "Journalpost"
 ],
 "Journal entry not found": [
  null,
  "Journalposten hittades inte"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY med Active Directory-interoperabilitet."
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Last 24 hours": [
  null,
  "Senaste 24 timmarna"
 ],
 "Last 7 days": [
  null,
  "Senaste 7 dagarna"
 ],
 "Last successful login:": [
  null,
  "Senaste lyckade inloggning:"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Leave $0": [
  null,
  "Lämna $0"
 ],
 "Leave domain": [
  null,
  "Lämna domänen"
 ],
 "Light": [
  null,
  "Ljust"
 ],
 "Limits": [
  null,
  "Begränsningar"
 ],
 "Linked": [
  null,
  "Länkad"
 ],
 "Listen": [
  null,
  "Lyssna"
 ],
 "Listing units": [
  null,
  "Listar enheter"
 ],
 "Listing units failed: $0": [
  null,
  "Misslyckades att lista enheter: $0"
 ],
 "Load earlier entries": [
  null,
  "Läs in tidigare poster"
 ],
 "Loading earlier entries": [
  null,
  "Läser in tidigare poster"
 ],
 "Loading keys...": [
  null,
  "Läser in nycklar..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Inläsningen av SSH-nycklar misslyckades"
 ],
 "Loading of units failed": [
  null,
  "Inläsningen av enheter misslyckades"
 ],
 "Loading system modifications...": [
  null,
  "Läser in anpassningar till systemet..."
 ],
 "Loading unit failed": [
  null,
  "Läsa in enhet misslyckades"
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "Login failed": [
  null,
  "Inloggningen misslyckades"
 ],
 "Login format": [
  null,
  "Inloggningsformat"
 ],
 "Logs": [
  null,
  "Loggar"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "Machine ID": [
  null,
  "Maskin-ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Maskinens SSH-nyckels fingeravtryck"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Maintenance": [
  null,
  "Underhåll"
 ],
 "Manage storage": [
  null,
  "Hantera lagring"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Mask service": [
  null,
  "Göm tjänst"
 ],
 "Masked": [
  null,
  "Gömd"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Att gömma en tjänst hindrar alla tjänster som beror på den att starta. Det kan ha en större effekt än tänkt. Se till att du verkligen vill gömma denna tjänst."
 ],
 "Memory": [
  null,
  "Minne"
 ],
 "Memory technology": [
  null,
  "Minnesteknologi"
 ],
 "Merged": [
  null,
  "Sammanslagna"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minuterna måste vara ett tal mellan 0-59"
 ],
 "Minutely": [
  null,
  "Minutvis"
 ],
 "Minutes": [
  null,
  "Minuter"
 ],
 "Mitigations": [
  null,
  "Rättningar"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Mondays": [
  null,
  "Måndagar"
 ],
 "Monthly": [
  null,
  "Månadsvis"
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "No": [
  null,
  "Nej"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "No host keys found.": [
  null,
  "Inga värdnycklar hittade."
 ],
 "No log entries": [
  null,
  "Inga loggposter"
 ],
 "No logs found": [
  null,
  "Inga loggar hittades"
 ],
 "No matching results": [
  null,
  "Inga matchande resultat"
 ],
 "No results found": [
  null,
  "Inga resultat funna"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Inga resultat matchar filterkriterierna. Rensa alla filter för att visa resultat."
 ],
 "No rule hits": [
  null,
  "Inga regelträffar"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "No system modifications": [
  null,
  "Inga systemändringar"
 ],
 "None": [
  null,
  "Inga"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Not connected to Insights": [
  null,
  "Inte ansluten till Insights"
 ],
 "Not found": [
  null,
  "Finns inte"
 ],
 "Not permitted to configure realms": [
  null,
  "Inte tillåtet att konfigurera att ändra riken"
 ],
 "Not permitted to perform this action.": [
  null,
  "Inte tillåtet att utföra denna åtgärd."
 ],
 "Not running": [
  null,
  "Kör inte"
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Note": [
  null,
  "Observera"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Notice and above": [
  null,
  "Notering och högre"
 ],
 "Occurrences": [
  null,
  "Förekomster"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "On failure": [
  null,
  "Vid misslyckande"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "När Cockpit är installerat, aktivera det med ”systemctl enable --now cockpit.socket”."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Endast alfabetet, siffror, :, _, ., @, - är tillåtna"
 ],
 "Only emergency": [
  null,
  "Endast nödläge"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Använd endast godkända och tillåtna algoritmer vid uppstart i FIPS-läge."
 ],
 "Other": [
  null,
  "Annan"
 ],
 "Overview": [
  null,
  "Översikt"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "Part of": [
  null,
  "Del av"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Paste error": [
  null,
  "Klistra in fel"
 ],
 "Path": [
  null,
  "Sökväg"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "Paths": [
  null,
  "Sökvägar"
 ],
 "Pause": [
  null,
  "Pausa"
 ],
 "Performance profile": [
  null,
  "Prestandaprofil"
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Pin unit": [
  null,
  "Fäst enhet"
 ],
 "Pinned unit": [
  null,
  "Fästa enheter"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "Pretty host name": [
  null,
  "Snyggt värdnamn"
 ],
 "Previous boot": [
  null,
  "Tidigare uppstart"
 ],
 "Priority": [
  null,
  "Prioritet"
 ],
 "Problem details": [
  null,
  "Problemdetaljer"
 ],
 "Problem info": [
  null,
  "Probleminformation"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "Propagates reload to": [
  null,
  "Vidarebefordrar omladdning till"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Skyddar mot förutsedda attacker på kort sikt på bekostnad av interoperabilitet."
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Rank": [
  null,
  "Ordning"
 ],
 "Read more...": [
  null,
  "Läs mer..."
 ],
 "Read-only": [
  null,
  "Skrivskyddad"
 ],
 "Real host name": [
  null,
  "Verkligt värdnamn"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Det verkliga värdnamnet kan endast innehålla gemena bokstäver, siffror, bindestreck och punkter (med populerade underdomäner)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Det verkliga värdnamnet får bara vara 64 tecken eller mindre"
 ],
 "Reapply and reboot": [
  null,
  "Återverkställ och starta om"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Rekommenderade, säkra inställningar för aktuella hotmodeller."
 ],
 "Reload": [
  null,
  "Läs om"
 ],
 "Reload propagated from": [
  null,
  "Omläsning vidarebefordrad från"
 ],
 "Reloading": [
  null,
  "Laddar om"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Remove": [
  null,
  "Ta bort"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Repeat": [
  null,
  "Upprepa"
 ],
 "Repeat monthly": [
  null,
  "Upprepa månadsvis"
 ],
 "Repeat weekly": [
  null,
  "Upprepa varje vecka"
 ],
 "Report": [
  null,
  "Rapport"
 ],
 "Report to ABRT Analytics": [
  null,
  "Rapportera till ABRT Analys"
 ],
 "Reported; no links available": [
  null,
  "Rapporterad; inga länkar tillgängliga"
 ],
 "Reporting failed": [
  null,
  "Rapporteringen misslyckades"
 ],
 "Reporting was canceled": [
  null,
  "Rapporteringen avbröts"
 ],
 "Reports:": [
  null,
  "Rapporter:"
 ],
 "Required by": [
  null,
  "Begärd av"
 ],
 "Required by ": [
  null,
  "Krävs av "
 ],
 "Requires": [
  null,
  "Begär"
 ],
 "Requires administration access to edit": [
  null,
  "Kräver administrationsbehörighet för att redigera"
 ],
 "Requisite": [
  null,
  "Behov"
 ],
 "Requisite of": [
  null,
  "Behov av"
 ],
 "Reset": [
  null,
  "Återställ"
 ],
 "Restart": [
  null,
  "Starta om"
 ],
 "Resume": [
  null,
  "Återuppta"
 ],
 "Review cryptographic policy": [
  null,
  "Granska kryptografisk policy"
 ],
 "Row expansion": [
  null,
  "Radexpansion"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Run at": [
  null,
  "Kör vid"
 ],
 "Run on": [
  null,
  "Kör på"
 ],
 "Running": [
  null,
  "Kör"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "Lördagar"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Save and reboot": [
  null,
  "Spara och starta om"
 ],
 "Save changes": [
  null,
  "Spara ändringar"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Schemalagd avstängning vid $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Schemalagd omstart till $0"
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Search": [
  null,
  "Sök"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Sekunder måste vara ett tal mellan 0-59"
 ],
 "Seconds": [
  null,
  "Sekunder"
 ],
 "Secure shell keys": [
  null,
  "Säkra skalnycklar"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Säkerhetsförbättrad Linux-konfiguration och felsökning"
 ],
 "Select a identifier": [
  null,
  "Välj en identifierare"
 ],
 "Send": [
  null,
  "Skicka"
 ],
 "Server has closed the connection.": [
  null,
  "Servern har stängt förbindelsen."
 ],
 "Server software": [
  null,
  "Serverprogramvara"
 ],
 "Service logs": [
  null,
  "Tjänsteloggar"
 ],
 "Services": [
  null,
  "Tjänster"
 ],
 "Set hostname": [
  null,
  "Ange värdnamn"
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Shell script": [
  null,
  "Skalskript"
 ],
 "Shift+Insert": [
  null,
  "Skift+Insert"
 ],
 "Show all threads": [
  null,
  "Visa alla trådar"
 ],
 "Show confirmation password": [
  null,
  "Visa bekräftelselösenord"
 ],
 "Show fingerprints": [
  null,
  "Visa fingeravtryck"
 ],
 "Show messages containing given string.": [
  null,
  "Visa meddelanden som innehåller en given sträng."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Visa meddelande för den angivna systemd-enheten."
 ],
 "Show messages from a specific boot.": [
  null,
  "Visa meddelanden från en specifik start."
 ],
 "Show more relationships": [
  null,
  "Visa mer relationer"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Show relationships": [
  null,
  "Visa relationer"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Shutdown": [
  null,
  "Stäng av"
 ],
 "Since": [
  null,
  "Sedan"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "Slot": [
  null,
  "Plats"
 ],
 "Sockets": [
  null,
  "Uttag"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Programvarubaserade sätt att gå runt problem hjälper till att förhindra CPU-säkerhetsrisker. Dessa begränsningar har sidoeffekten att reducera prestanda. Ändra dessa inställningar på egen risk."
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Speed": [
  null,
  "Hastighet"
 ],
 "Start": [
  null,
  "Starta"
 ],
 "Start and enable": [
  null,
  "Starta och aktivera"
 ],
 "Start service": [
  null,
  "Starta tjänst"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Börja visa poster på eller nyare än det angivna datumet."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Börja visa poster på eller äldre än det angivna datumet."
 ],
 "State": [
  null,
  "Tillstånd"
 ],
 "Static": [
  null,
  "Statisk"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "Stop": [
  null,
  "Stoppa"
 ],
 "Stop and disable": [
  null,
  "Stoppa och avaktivera"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Strong password": [
  null,
  "Starkt lösenord"
 ],
 "Stub": [
  null,
  "Stubbe"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Att prenumerera på systemd-signaler misslyckades: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Kopierades till urklipp"
 ],
 "Sundays": [
  null,
  "Söndagar"
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "System": [
  null,
  "System"
 ],
 "System information": [
  null,
  "Systeminformation"
 ],
 "System time": [
  null,
  "Systemtid"
 ],
 "Systemd units": [
  null,
  "Systemenheter"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "Targets": [
  null,
  "Mål"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den inloggade användaren har inte tillåtelse att se systemändringar"
 ],
 "The passwords do not match.": [
  null,
  "Lösenorden stämmer inte överens."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Servern vägrade att autentisera med några stödda metoder."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Användaren $0 tillåts inte ändra CPU-säkerhetsbegränsningar"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Användaren $0 har inte rättighet att ändra kryptografisk policy"
 ],
 "This field cannot be empty": [
  null,
  "Detta fält får inte vara tomt"
 ],
 "This may take a while": [
  null,
  "Detta kan ta ett tag"
 ],
 "This system is using a custom profile": [
  null,
  "Detta system använder en anpassad profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Detta system använder den rekommenderade profilen"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Det här verktyget konfigurerar SELinux-policyn och kan hjälpa till med att förstå och lösa policy överträdelser."
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  "Det här verktyget konfigurerar systemet till att kunna skriva kärnkraschdumpar till disken."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Detta verktyg genererar ett arkiv med konfiguration och diagnostisk information från det körande systemet. Arkivet kan förvaras lokalt eller centralt för inspelning eller spårningsändamål eller kan skickas till tekniska supportrepresentanter, utvecklare eller systemadministratörer för att hjälpa till med teknisk felspårning och felsökning."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Detta verktyg hanterar lokal lagring, såsom filsystem, LVM2-volymgrupper och NFS-monteringar."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Detta verktyg hanterar nätverk som bindningar, broar, team, VLAN och brandväggar med NetworkManager och Firewalld. NetworkManager är inkompatibelt med Ubuntus standard systemd-networkd och Debians ifupdown skript."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Denna enhet är inte gjord för att aktiveras explicit."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Detta kommer lägga till en matchning av ”_BOOT_ID=”. Om det inte anges kommer den aktuella uppstarten visas. Om uppstarts-ID:t utelämnas kommer ett positivt avstånd leta efter uppstarter från början av journalen och ett lika-med-eller-mindre-än noll-avstånd leta efter uppstarter från slutet av journalen. Alltså betyder 1 den första uppstarten som finns i journalen i kronologisk ordning, 2 den andra och så vidare; medan -0 är sista uppstarten, -1 uppstarten före det, och så vidare."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Detta kommer lägga till en matchning av ”_SYSTEMD_UNIT=”, ”COREDUMP_UNIT=” och ”UNIT=” för att hitta alla möjliga meddelanden för den angivna enheten. Kan innehålla flera enheter separerade av komma. "
 ],
 "Thursdays": [
  null,
  "Torsdagar"
 ],
 "Time": [
  null,
  "Tid"
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "Timer creation failed": [
  null,
  "Att skapa en timer misslyckades"
 ],
 "Timer deletion failed": [
  null,
  "Att radera en timer misslyckades"
 ],
 "Timers": [
  null,
  "Timrar"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Toggle filters": [
  null,
  "Växla filter"
 ],
 "Too much data": [
  null,
  "För mycket data"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Transient": [
  null,
  "Transient"
 ],
 "Trigger": [
  null,
  "Utlösare"
 ],
 "Triggered by": [
  null,
  "Utlöst av"
 ],
 "Triggers": [
  null,
  "Utlösare"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "Tuesdays": [
  null,
  "Tisdagar"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned har misslyckats med att starta"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned är en tjänst som övervakar systemet och optimerar prestandan under vissa belastningar. Kärnan av Tuned är profiler, vilka trimmar systemet för olika användningsfall."
 ],
 "Tuned is not available": [
  null,
  "Tuned är inte tillgänglig"
 ],
 "Tuned is not running": [
  null,
  "Tuned kör inte"
 ],
 "Tuned is off": [
  null,
  "Tuned är avslagen"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type to filter": [
  null,
  "Skriv för att filtrera"
 ],
 "Unit": [
  null,
  "Enhet"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Unpin unit": [
  null,
  "Avfäst enhet"
 ],
 "Until": [
  null,
  "Tills"
 ],
 "Untrusted host": [
  null,
  "Ej betrodd värd"
 ],
 "Updating status...": [
  null,
  "Uppdaterar status..."
 ],
 "Usage": [
  null,
  "Användning"
 ],
 "User": [
  null,
  "Användare"
 ],
 "Validating address": [
  null,
  "Validerar adress"
 ],
 "Vendor": [
  null,
  "Leverantör"
 ],
 "Version": [
  null,
  "Version"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "View all services": [
  null,
  "Visa alla tjänster"
 ],
 "View automation script": [
  null,
  "Visa automatiseringsskript"
 ],
 "View hardware details": [
  null,
  "Visa hårdvarudetaljer"
 ],
 "View login history": [
  null,
  "Visa inloggningshistorik"
 ],
 "View metrics and history": [
  null,
  "Visa mätvärden och historik"
 ],
 "View report": [
  null,
  "Visa rapport"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Att visa minnesinformation kräver administrativ åtkomst."
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Waiting for input…": [
  null,
  "Väntar på inmatning…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder skall bli klara"
 ],
 "Waiting to start…": [
  null,
  "Väntar på att starta …"
 ],
 "Wanted by": [
  null,
  "Önskat av"
 ],
 "Wants": [
  null,
  "Önskar"
 ],
 "Warning and above": [
  null,
  "Varning och högre"
 ],
 "Weak password": [
  null,
  "Svagt lösenord"
 ],
 "Web Console for Linux servers": [
  null,
  "Webbkonsol för Linuxservrar"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Webbkonsolen körs i begränsad åtkomstläge."
 ],
 "Wednesdays": [
  null,
  "Onsdagar"
 ],
 "Weekly": [
  null,
  "Veckovis"
 ],
 "Weeks": [
  null,
  "Veckor"
 ],
 "White": [
  null,
  "Vit"
 ],
 "Yearly": [
  null,
  "Årligen"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You may try to load older entries.": [
  null,
  "Du kan försöka ladda äldre poster."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Din webbläsare tillåter inte att klistra in från sammanhangsmenyn. Du kan använda Skift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Din session har avslutats."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Din session har gått ut. Logga in igen."
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "misslyckades att lista ssh-värdnycklar: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "inconsistent": [
  null,
  "inkonsekvent"
 ],
 "journalctl manpage": [
  null,
  "journalctl mansida"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "ingen"
 ],
 "of $0 CPU": [
  null,
  "av $0 CPU-kärna",
  "av $0 CPU-kärnor"
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "recommended": [
  null,
  "rekommenderad"
 ],
 "running $0": [
  null,
  "kör $0"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "unknown": [
  null,
  "okänd"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domän"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Gå med i en domän"
 ],
 "from <host>\u0004from $0": [
  null,
  "från $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "från $0 på $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "på $0"
 ]
});
