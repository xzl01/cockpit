cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "調整系統設定"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Logs": [
  null,
  "系統日誌"
 ],
 "Managing services": [
  null,
  "管理服務"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "Overview": [
  null,
  "主機狀態"
 ],
 "Reviewing logs": [
  null,
  "正在檢視紀錄檔"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "服務"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Terminal": [
  null,
  "終端機"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "標籤"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "開機"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "指令"
 ],
 "console": [
  null,
  "主控臺"
 ],
 "coredump": [
  null,
  "核心傾印"
 ],
 "cpu": [
  null,
  "處理器"
 ],
 "crash": [
  null,
  "當機"
 ],
 "date": [
  null,
  "日期"
 ],
 "debug": [
  null,
  "除錯"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "已停用"
 ],
 "disks": [
  null,
  "磁碟"
 ],
 "domain": [
  null,
  "網域"
 ],
 "enable": [
  null,
  "啟用"
 ],
 "error": [
  null,
  "錯誤"
 ],
 "graphs": [
  null,
  "圖表"
 ],
 "hardware": [
  null,
  "硬體"
 ],
 "history": [
  null,
  "歷史記錄"
 ],
 "host": [
  null,
  "主機"
 ],
 "journal": [
  null,
  "日誌"
 ],
 "machine": [
  null,
  "機器"
 ],
 "mask": [
  null,
  "遮罩"
 ],
 "memory": [
  null,
  "記憶體"
 ],
 "metrics": [
  null,
  "指標度量"
 ],
 "mitigation": [
  null,
  "緩解"
 ],
 "network": [
  null,
  "網路"
 ],
 "operating system": [
  null,
  "作業系統"
 ],
 "os": [
  null,
  "作業系統"
 ],
 "path": [
  null,
  "路徑"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "效能"
 ],
 "power": [
  null,
  "電源"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "重新啟動"
 ],
 "serial": [
  null,
  "序號"
 ],
 "service": [
  null,
  "服務"
 ],
 "shell": [
  null,
  "shell"
 ],
 "shut": [
  null,
  "關"
 ],
 "socket": [
  null,
  "socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "目標"
 ],
 "time": [
  null,
  "時間"
 ],
 "timer": [
  null,
  "計時器"
 ],
 "unit": [
  null,
  "單元"
 ],
 "unmask": [
  null,
  "解除遮罩"
 ],
 "version": [
  null,
  "版本"
 ],
 "warning": [
  null,
  "警告"
 ]
});
