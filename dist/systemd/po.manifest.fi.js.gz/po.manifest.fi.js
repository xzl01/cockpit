cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Järjestelmäasetusten määrittäminen"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Logs": [
  null,
  "Lokit"
 ],
 "Managing services": [
  null,
  "Palvelujen hallinta"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "Overview": [
  null,
  "Esittely"
 ],
 "Reviewing logs": [
  null,
  "Tarkistetaan lokeja"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Palvelut"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Terminal": [
  null,
  "Pääte"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "sisältötunniste"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "käynnistys"
 ],
 "cgroups": [
  null,
  "c-ryhmät"
 ],
 "command": [
  null,
  "komento"
 ],
 "console": [
  null,
  "konsoli"
 ],
 "coredump": [
  null,
  "ytimen tyhjennys"
 ],
 "cpu": [
  null,
  "suoritin"
 ],
 "crash": [
  null,
  "kaatuminen"
 ],
 "date": [
  null,
  "päivämäärä"
 ],
 "debug": [
  null,
  "virheenjäljitys"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "poista käytöstä"
 ],
 "disks": [
  null,
  "levyt"
 ],
 "domain": [
  null,
  "toimialue"
 ],
 "enable": [
  null,
  "ota käyttöön"
 ],
 "error": [
  null,
  "virhe"
 ],
 "graphs": [
  null,
  "kaaviot"
 ],
 "hardware": [
  null,
  "laitteisto"
 ],
 "history": [
  null,
  "historia"
 ],
 "host": [
  null,
  "kone"
 ],
 "journal": [
  null,
  "päiväkirja"
 ],
 "machine": [
  null,
  "kone"
 ],
 "mask": [
  null,
  "peite"
 ],
 "memory": [
  null,
  "muisti"
 ],
 "metrics": [
  null,
  "mittarit"
 ],
 "mitigation": [
  null,
  "lievennys"
 ],
 "network": [
  null,
  "verkko"
 ],
 "operating system": [
  null,
  "käyttöjärjestelmä"
 ],
 "os": [
  null,
  "käyttöjärjestelmä"
 ],
 "path": [
  null,
  "polku"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "suorituskyky"
 ],
 "power": [
  null,
  "virta"
 ],
 "ram": [
  null,
  "ram-muisti"
 ],
 "restart": [
  null,
  "käynnistä uudelleen"
 ],
 "serial": [
  null,
  "sarja"
 ],
 "service": [
  null,
  "palvelu"
 ],
 "shell": [
  null,
  "komentotulkki"
 ],
 "shut": [
  null,
  "sulje"
 ],
 "socket": [
  null,
  "pistoke"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "kohde"
 ],
 "time": [
  null,
  "aika"
 ],
 "timer": [
  null,
  "ajastin"
 ],
 "unit": [
  null,
  "yksikkö"
 ],
 "unmask": [
  null,
  "poista peite"
 ],
 "version": [
  null,
  "versio"
 ],
 "warning": [
  null,
  "varoitus"
 ]
});
