cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Konfigurowanie ustawień systemu"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Logs": [
  null,
  "Dzienniki"
 ],
 "Managing services": [
  null,
  "Zarządzanie usługami"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "Overview": [
  null,
  "Przegląd"
 ],
 "Reviewing logs": [
  null,
  "Przeglądanie dzienników"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Usługi"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "abrt": [
  null,
  "ABRT"
 ],
 "asset tag": [
  null,
  "etykieta zasobu"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "BIOS"
 ],
 "boot": [
  null,
  "uruchom"
 ],
 "cgroups": [
  null,
  "CGroups"
 ],
 "command": [
  null,
  "polecenie"
 ],
 "console": [
  null,
  "konsola"
 ],
 "coredump": [
  null,
  "zrzut core"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "crash": [
  null,
  "awaria"
 ],
 "date": [
  null,
  "data"
 ],
 "debug": [
  null,
  "debuguj"
 ],
 "dimm": [
  null,
  "DIMM"
 ],
 "disable": [
  null,
  "wyłącz"
 ],
 "disks": [
  null,
  "dyski"
 ],
 "domain": [
  null,
  "domena"
 ],
 "enable": [
  null,
  "włącz"
 ],
 "error": [
  null,
  "błąd"
 ],
 "graphs": [
  null,
  "wykresy"
 ],
 "hardware": [
  null,
  "sprzęt"
 ],
 "history": [
  null,
  "historia"
 ],
 "host": [
  null,
  "gospodarz"
 ],
 "journal": [
  null,
  "dziennik"
 ],
 "machine": [
  null,
  "komputer"
 ],
 "mask": [
  null,
  "maska"
 ],
 "memory": [
  null,
  "pamięć"
 ],
 "metrics": [
  null,
  "statystyki"
 ],
 "mitigation": [
  null,
  "poprawka zmniejszająca ryzyko"
 ],
 "network": [
  null,
  "sieć"
 ],
 "operating system": [
  null,
  "system operacyjny"
 ],
 "os": [
  null,
  "system operacyjny"
 ],
 "path": [
  null,
  "ścieżka"
 ],
 "pci": [
  null,
  "PCI"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "wydajność"
 ],
 "power": [
  null,
  "zasilanie"
 ],
 "ram": [
  null,
  "RAM"
 ],
 "restart": [
  null,
  "uruchom ponownie"
 ],
 "serial": [
  null,
  "szeregowe"
 ],
 "service": [
  null,
  "usługa"
 ],
 "shell": [
  null,
  "powłoka"
 ],
 "shut": [
  null,
  "wyłącz"
 ],
 "socket": [
  null,
  "gniazdo"
 ],
 "ssh": [
  null,
  "SSH"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cel"
 ],
 "time": [
  null,
  "czas"
 ],
 "timer": [
  null,
  "licznik"
 ],
 "unit": [
  null,
  "jednostka"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "version": [
  null,
  "wersja"
 ],
 "warning": [
  null,
  "ostrzeżenie"
 ]
});
