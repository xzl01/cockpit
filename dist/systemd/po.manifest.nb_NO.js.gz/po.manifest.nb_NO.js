cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Konfigurere systeminnstillinger"
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Logs": [
  null,
  "Logger"
 ],
 "Managing services": [
  null,
  "Administrere tjenester"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "Overview": [
  null,
  "Oversikt"
 ],
 "Reviewing logs": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Tjenester"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "eiendomsmerke"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "oppstart"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "kommando"
 ],
 "console": [
  null,
  "konsoll"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "krasj"
 ],
 "date": [
  null,
  "dato"
 ],
 "debug": [
  null,
  "debug"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "deaktiver"
 ],
 "disks": [
  null,
  "disker"
 ],
 "domain": [
  null,
  "domene"
 ],
 "enable": [
  null,
  "aktiver"
 ],
 "error": [
  null,
  "feil"
 ],
 "graphs": [
  null,
  "grafer"
 ],
 "hardware": [
  null,
  "maskinvare"
 ],
 "history": [
  null,
  "historikk"
 ],
 "host": [
  null,
  "vert"
 ],
 "journal": [
  null,
  "journal"
 ],
 "machine": [
  null,
  "maskin"
 ],
 "mask": [
  null,
  "maske"
 ],
 "memory": [
  null,
  "minne"
 ],
 "metrics": [
  null,
  ""
 ],
 "mitigation": [
  null,
  ""
 ],
 "network": [
  null,
  "nettverk"
 ],
 "operating system": [
  null,
  "operativsystem"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "sti"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "power": [
  null,
  ""
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "omstart"
 ],
 "serial": [
  null,
  ""
 ],
 "service": [
  null,
  "tjeneste"
 ],
 "shell": [
  null,
  "skall"
 ],
 "shut": [
  null,
  ""
 ],
 "socket": [
  null,
  ""
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "mål"
 ],
 "time": [
  null,
  "tid"
 ],
 "timer": [
  null,
  "timer"
 ],
 "unit": [
  null,
  "enhet"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "version": [
  null,
  "versjon"
 ],
 "warning": [
  null,
  "advarsel"
 ]
});
