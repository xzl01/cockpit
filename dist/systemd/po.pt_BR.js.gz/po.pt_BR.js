cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 exited with code $1": [
  null,
  "$0 saiu com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "$0 failed login attempt": [
  null,
  "Tentativa de login falhou para o usuário $0",
  "Tentativas de login falharam para o usuário $0"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mortos com sinal $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 hit de baixa gravidade",
  "$0 hits de baixas gravidades"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 service has failed": [
  null,
  "$0 serviço falhou",
  "$0 serviços falharam"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "$0: crash at $1": [
  null,
  ""
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 Minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "10th": [
  null,
  "10º"
 ],
 "11th": [
  null,
  "11º"
 ],
 "12th": [
  null,
  "12º"
 ],
 "13th": [
  null,
  "13º"
 ],
 "14th": [
  null,
  "14º"
 ],
 "15th": [
  null,
  "15º"
 ],
 "16th": [
  null,
  "16º"
 ],
 "17th": [
  null,
  "17º"
 ],
 "18th": [
  null,
  "18º"
 ],
 "19th": [
  null,
  "19º"
 ],
 "1st": [
  null,
  "1º"
 ],
 "20 minutes": [
  null,
  "20 Minutos"
 ],
 "20th": [
  null,
  "20º"
 ],
 "21th": [
  null,
  "21º"
 ],
 "22th": [
  null,
  "22º"
 ],
 "23th": [
  null,
  "23º"
 ],
 "24th": [
  null,
  "24º"
 ],
 "25th": [
  null,
  "25º"
 ],
 "26th": [
  null,
  "26º"
 ],
 "27th": [
  null,
  "27º"
 ],
 "28th": [
  null,
  "28º"
 ],
 "29th": [
  null,
  "29º"
 ],
 "2nd": [
  null,
  "2º"
 ],
 "30th": [
  null,
  "30º"
 ],
 "31st": [
  null,
  "31º"
 ],
 "3rd": [
  null,
  "3º"
 ],
 "40 minutes": [
  null,
  "40 Minutos"
 ],
 "4th": [
  null,
  "4º"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "5th": [
  null,
  "5º"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 Minutos"
 ],
 "6th": [
  null,
  "6º"
 ],
 "7th": [
  null,
  "7º"
 ],
 "8th": [
  null,
  "8º"
 ],
 "9th": [
  null,
  "9º"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Active since ": [
  null,
  "Ativo desde "
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "Additional actions": [
  null,
  "Ações adicionais"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA Avançado"
 ],
 "After": [
  null,
  "Após"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Após sair do domínio, apenas os usuários com credenciais locais poderão fazer login nesta máquina. Isso também pode afetar outros serviços, como as configurações de resolução DNS e a lista de autoridades de certificação confiáveis."
 ],
 "After system boot": [
  null,
  "Após a inicialização do sistema"
 ],
 "Alert and above": [
  null,
  "Alerta e acima"
 ],
 "Alias": [
  null,
  "Apelido"
 ],
 "All": [
  null,
  "Todos"
 ],
 "Allow running (unmask)": [
  null,
  "Permitir a execução (desmascarar)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Qualquer sequência de texto nas mensagens de log pode ser filtrada. A sequência também pode estar na forma de uma expressão regular. Também suporta filtragem por campos de registro de mensagem. Esses valores são separados por espaços, no formato CAMPO=VALOR, onde o valor pode ser uma lista separada por vírgulas de valores possíveis."
 ],
 "Appearance": [
  null,
  "Aparência"
 ],
 "Apply and reboot": [
  null,
  "Aplicar e reiniciar"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Aplicando a nova política... Isso pode levar alguns minutos."
 ],
 "Asset tag": [
  null,
  "Etiqueta de ativo"
 ],
 "At minute": [
  null,
  "A cada minuto"
 ],
 "At specific time": [
  null,
  "Em tempo específico"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ],
 "Automatically starts": [
  null,
  "Inicia automaticamente"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS data"
 ],
 "BIOS version": [
  null,
  "BIOS versão"
 ],
 "Before": [
  null,
  "Antes"
 ],
 "Binds to": [
  null,
  "Vincula a"
 ],
 "Black": [
  null,
  "Preto"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Boot": [
  null,
  "Inicialização"
 ],
 "Bound by": [
  null,
  "Vinculado pela"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "Segurança da CPU"
 ],
 "CPU security toggles": [
  null,
  "Interruptores de segurança da CPU"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Não é possível encontrar nenhum registro usando a combinação atual de filtros."
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cancel poweroff": [
  null,
  ""
 ],
 "Cannot be enabled": [
  null,
  "Não pode ser habilitado"
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  ""
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change host name": [
  null,
  "Alterar o Nome do Host"
 ],
 "Change performance profile": [
  null,
  "Perfil alterar o desempenho"
 ],
 "Change profile": [
  null,
  "Alterar o perfil"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Checking installed software": [
  null,
  "Verificando o software instalado"
 ],
 "Class": [
  null,
  "Classe"
 ],
 "Clear 'Failed to start'": [
  null,
  ""
 ],
 "Clear all filters": [
  null,
  "Limpar todos os filtros"
 ],
 "Client software": [
  null,
  "Software do cliente"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  ""
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Collect and package diagnostic and support data": [
  null,
  ""
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Communication with tuned has failed": [
  null,
  "A comunicação com sintonizado falhou"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Condição $0=$1 não foi cumprida"
 ],
 "Condition failed": [
  null,
  "Condição falhou"
 ],
 "Configuration": [
  null,
  "Configuração"
 ],
 "Conflicted by": [
  null,
  "Conflito por"
 ],
 "Conflicts": [
  null,
  "Conflitos"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Consists of": [
  null,
  "Consiste em"
 ],
 "Contacted domain": [
  null,
  "Domínio contatado"
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Create new task file with this content.": [
  null,
  ""
 ],
 "Create timer": [
  null,
  "Criar Temporizador"
 ],
 "Critical and above": [
  null,
  "Crítico e acima"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  ""
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Inicialização atual"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  ""
 ],
 "Daily": [
  null,
  "Diariamente"
 ],
 "Dark": [
  null,
  "Escuro"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  ""
 ],
 "Debug and above": [
  null,
  "Depurar e acima"
 ],
 "Decrease by one": [
  null,
  ""
 ],
 "Default": [
  null,
  "Padrão"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Deletion will remove the following files:": [
  null,
  ""
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Disable simultaneous multithreading": [
  null,
  ""
 ],
 "Disable tuned": [
  null,
  "Desabilitar tuned"
 ],
 "Disabled": [
  null,
  "Desabilitado"
 ],
 "Disallow running (mask)": [
  null,
  ""
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "Domain": [
  null,
  "Domínio"
 ],
 "Domain address": [
  null,
  "Endereço do Domínio"
 ],
 "Domain administrator name": [
  null,
  "Nome do Administrador de Domínio"
 ],
 "Domain administrator password": [
  null,
  "Senha do Administrador de Domínio"
 ],
 "Domain could not be contacted": [
  null,
  "O Domínio não pôde ser contatado"
 ],
 "Domain is not supported": [
  null,
  "O Domínio não é suportado"
 ],
 "Don't repeat": [
  null,
  "Não Repita"
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Dual rank": [
  null,
  ""
 ],
 "Edit /etc/motd": [
  null,
  "Editar /etc/motd"
 ],
 "Edit motd": [
  null,
  "Editar motd"
 ],
 "Embedded PC": [
  null,
  ""
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Entry at $0": [
  null,
  ""
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Error and above": [
  null,
  "Erro e acima"
 ],
 "Error message": [
  null,
  "Mensagem de erro"
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Extended information": [
  null,
  "Informação estendida"
 ],
 "FIPS is not properly enabled": [
  null,
  ""
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  ""
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "Failed to disable tuned": [
  null,
  "Falha ao desabilitar tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Falha ao desativar o perfil do tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Falha ao habilitar tuned"
 ],
 "Failed to start": [
  null,
  "Falha ao iniciar"
 ],
 "Failed to switch profile": [
  null,
  "Falha ao mudar de perfil"
 ],
 "Filter by name or description": [
  null,
  "Filtrar por nome ou descrição"
 ],
 "Filters": [
  null,
  "Filtros"
 ],
 "Font size": [
  null,
  "Tamanho da fonte"
 ],
 "Forbidden from running": [
  null,
  ""
 ],
 "Frame number": [
  null,
  ""
 ],
 "Fridays": [
  null,
  "Sextas"
 ],
 "General": [
  null,
  "Geral"
 ],
 "Generated": [
  null,
  "Gerado"
 ],
 "Go to $0": [
  null,
  "Ir para $0"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "Hardware information": [
  null,
  "Informação de Hardware"
 ],
 "Health": [
  null,
  ""
 ],
 "Help": [
  null,
  "Ajuda"
 ],
 "Hierarchy ID": [
  null,
  ""
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  ""
 ],
 "Host key is incorrect": [
  null,
  "Chave de Host incorreta"
 ],
 "Hostname": [
  null,
  "Nome do host"
 ],
 "Hours": [
  null,
  "Horas"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identificador"
 ],
 "Increase by one": [
  null,
  ""
 ],
 "Info and above": [
  null,
  "Info e acima"
 ],
 "Insights: ": [
  null,
  "Ideias: "
 ],
 "Install": [
  null,
  "Instale"
 ],
 "Install software": [
  null,
  "Instale Software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Invalid": [
  null,
  "Inválido"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Join": [
  null,
  "Afiliar-se"
 ],
 "Join domain": [
  null,
  "Associar-se ao domínio"
 ],
 "Joining this domain is not supported": [
  null,
  "A adesão à este domínio não é suportada"
 ],
 "Joins namespace of": [
  null,
  "Junte os espaços nos nomes de"
 ],
 "Journal": [
  null,
  "Diário"
 ],
 "Journal entry": [
  null,
  "Entrada do diário"
 ],
 "Journal entry not found": [
  null,
  "Entrada do diário não encontrada"
 ],
 "Kernel dump": [
  null,
  "Dump do Kernel"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  ""
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last 24 hours": [
  null,
  "Últimas 24 horas"
 ],
 "Last 7 days": [
  null,
  "Últimos 7 dias"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "Leave domain": [
  null,
  "Abandonar Domínio"
 ],
 "Light": [
  null,
  ""
 ],
 "Load earlier entries": [
  null,
  "Carregar logs anteriores"
 ],
 "Loading earlier entries": [
  null,
  "Carregando logs anteriores"
 ],
 "Loading keys...": [
  null,
  "Carregando chaves..."
 ],
 "Loading of SSH keys failed": [
  null,
  "O carregamento das chaves SSH falhou"
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "Login format": [
  null,
  "Formato de Login"
 ],
 "Logs": [
  null,
  "Logs"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "ID de Máquina"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Máquina de Chaves SSH e Impressões digitais"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Mask service": [
  null,
  "Serviço de máscara"
 ],
 "Masked": [
  null,
  ""
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  ""
 ],
 "Memory": [
  null,
  "Memória"
 ],
 "Memory technology": [
  null,
  ""
 ],
 "Merged": [
  null,
  ""
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minutos precisam ser números entre 0-59"
 ],
 "Minutes": [
  null,
  "Minutos"
 ],
 "Mitigations": [
  null,
  ""
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Mondays": [
  null,
  "Segundas"
 ],
 "Monthly": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "No": [
  null,
  "Não"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "No host keys found.": [
  null,
  "Nenhuma chave de host encontrada."
 ],
 "No logs found": [
  null,
  "Nenhum log encontrado"
 ],
 "No matching results": [
  null,
  ""
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  ""
 ],
 "No rule hits": [
  null,
  ""
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "None": [
  null,
  "Nenhum"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Not connected to Insights": [
  null,
  ""
 ],
 "Not found": [
  null,
  "Não encontrado"
 ],
 "Not permitted to perform this action.": [
  null,
  "Não é permitido executar esta ação."
 ],
 "Not running": [
  null,
  "Não está rodando"
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Note": [
  null,
  "Nota"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Observe e acima"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "On failure": [
  null,
  "Em Falha"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Apenas alfabetos, números, : , _ , . , @ , - são permitidos"
 ],
 "Only emergency": [
  null,
  "Apenas emergência"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  ""
 ],
 "Other": [
  null,
  "De outros"
 ],
 "Overview": [
  null,
  "Visão geral"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "Part of": [
  null,
  "Parte de"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Path": [
  null,
  "Caminho"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "Paths": [
  null,
  "Caminhos"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Performance profile": [
  null,
  "Perfil de desempenho"
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "Pick date": [
  null,
  ""
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Pretty host name": [
  null,
  "Nome de Host Bonito"
 ],
 "Previous boot": [
  null,
  ""
 ],
 "Priority": [
  null,
  "Prioridade"
 ],
 "Problem details": [
  null,
  "Detalhes do problema"
 ],
 "Problem info": [
  null,
  "Informação do Problema"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Propagates reload to": [
  null,
  "Propaga Recarregar para"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  ""
 ],
 "Rank": [
  null,
  ""
 ],
 "Read more...": [
  null,
  ""
 ],
 "Read-only": [
  null,
  "Somente leitura"
 ],
 "Real host name": [
  null,
  "Nome Real de Host"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Nome de host real só pode conter caracteres minúsculos, dígitos, traços e períodos (com subdomínios preenchidos)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Nome de host real deve conter 64 caracteres ou menos"
 ],
 "Reapply and reboot": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  ""
 ],
 "Reload": [
  null,
  "Recarregar"
 ],
 "Reload propagated from": [
  null,
  "Recarregar propagado de"
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Repeat weekly": [
  null,
  "Repita Semanalmente"
 ],
 "Report": [
  null,
  "Relatório"
 ],
 "Report to ABRT Analytics": [
  null,
  ""
 ],
 "Reported; no links available": [
  null,
  ""
 ],
 "Reporting failed": [
  null,
  ""
 ],
 "Reporting was canceled": [
  null,
  ""
 ],
 "Reports:": [
  null,
  ""
 ],
 "Required by": [
  null,
  "Solicitado por"
 ],
 "Required by ": [
  null,
  ""
 ],
 "Requires": [
  null,
  "Requere"
 ],
 "Requires administration access to edit": [
  null,
  ""
 ],
 "Requisite": [
  null,
  "Requisita"
 ],
 "Requisite of": [
  null,
  "Requisitode"
 ],
 "Reset": [
  null,
  "Redefinir"
 ],
 "Restart": [
  null,
  "Reiniciar"
 ],
 "Resume": [
  null,
  ""
 ],
 "Run on": [
  null,
  ""
 ],
 "Running": [
  null,
  "Executando"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Saturdays": [
  null,
  "Sábados"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Save and reboot": [
  null,
  ""
 ],
 "Save changes": [
  null,
  "Salvar Mudanças"
 ],
 "Scheduled poweroff at $0": [
  null,
  ""
 ],
 "Scheduled reboot at $0": [
  null,
  ""
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Search": [
  null,
  ""
 ],
 "Seconds": [
  null,
  "Segundos"
 ],
 "Secure shell keys": [
  null,
  ""
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Send": [
  null,
  "Enviar"
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Server software": [
  null,
  "Software de servidor"
 ],
 "Service logs": [
  null,
  "Logs de Serviço"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Set hostname": [
  null,
  "Definir nome do host"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show fingerprints": [
  null,
  "Exibir digitais"
 ],
 "Show messages containing given string.": [
  null,
  ""
 ],
 "Show messages for the specified systemd unit.": [
  null,
  ""
 ],
 "Show messages from a specific boot.": [
  null,
  ""
 ],
 "Show more relationships": [
  null,
  ""
 ],
 "Show relationships": [
  null,
  ""
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Shutdown": [
  null,
  "Desligar"
 ],
 "Since": [
  null,
  "Desde"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Speed": [
  null,
  "Velocidade"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Start and enable": [
  null,
  "Iniciar e habilitar"
 ],
 "Start service": [
  null,
  "Começar serviço"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  ""
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  ""
 ],
 "State": [
  null,
  "Estado"
 ],
 "Static": [
  null,
  "Estático"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Pare"
 ],
 "Stop and disable": [
  null,
  "Parar e desabilitar"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Stub": [
  null,
  ""
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  ""
 ],
 "Successfully copied to clipboard": [
  null,
  "Copiado com sucesso para a área de transferência"
 ],
 "Sundays": [
  null,
  "Domingos"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System information": [
  null,
  "Informação do sistema"
 ],
 "System time": [
  null,
  "Hora do sistema"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Alvos"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  ""
 ],
 "The passwords do not match.": [
  null,
  "As senhas não batem."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  ""
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "O usuário $0 não tem permissão para alterar políticas criptográficas"
 ],
 "This field cannot be empty": [
  null,
  "Este campo não pode estar vazio"
 ],
 "This may take a while": [
  null,
  "Isso pode demorar um pouco"
 ],
 "This system is using a custom profile": [
  null,
  "Este sistema está usando um perfil personalizado"
 ],
 "This system is using the recommended profile": [
  null,
  "Este sistema está usando o perfil recomendado"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  ""
 ],
 "This tool configures the system to write kernel crash dumps to disk.": [
  null,
  ""
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  ""
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  ""
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Esta unidade não foi projetada para ser habilitada explicitamente."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  ""
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  ""
 ],
 "Thursdays": [
  null,
  "Quintas"
 ],
 "Time": [
  null,
  "Tempo"
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "Timers": [
  null,
  "Temporizadores"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Transient": [
  null,
  ""
 ],
 "Triggered by": [
  null,
  "Disparado por"
 ],
 "Triggers": [
  null,
  "Triggers"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Tuesdays": [
  null,
  "Terças"
 ],
 "Tuned has failed to start": [
  null,
  "Falhou ao iniciar Tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  ""
 ],
 "Tuned is not available": [
  null,
  "Tuned não está disponível"
 ],
 "Tuned is not running": [
  null,
  "Tuned não está em execução"
 ],
 "Tuned is off": [
  null,
  "Tuned está fora"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Type to filter": [
  null,
  "Tipo para filtrar"
 ],
 "Unit": [
  null,
  "Unidade"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Until": [
  null,
  ""
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Updating status...": [
  null,
  ""
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "User": [
  null,
  "Usuário"
 ],
 "Validating address": [
  null,
  "Validando endereço"
 ],
 "Vendor": [
  null,
  "Fabricante"
 ],
 "Version": [
  null,
  "Versão"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "View automation script": [
  null,
  ""
 ],
 "View hardware details": [
  null,
  ""
 ],
 "View login history": [
  null,
  ""
 ],
 "View metrics and history": [
  null,
  ""
 ],
 "View report": [
  null,
  ""
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Visualizar informações de memória requer acesso administrativo."
 ],
 "Waiting for input…": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando que outras operações de gerenciamento de software terminem"
 ],
 "Waiting to start…": [
  null,
  ""
 ],
 "Wanted by": [
  null,
  "Requerido por"
 ],
 "Wants": [
  null,
  "Requer"
 ],
 "Warning and above": [
  null,
  "Aviso e acima"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "Web console is running in limited access mode.": [
  null,
  ""
 ],
 "Wednesdays": [
  null,
  "Quartas"
 ],
 "Weeks": [
  null,
  "Semanas"
 ],
 "White": [
  null,
  "Branco"
 ],
 "Yearly": [
  null,
  ""
 ],
 "Yes": [
  null,
  "Sim"
 ],
 "You may try to load older entries.": [
  null,
  ""
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "active": [
  null,
  "ativo"
 ],
 "edit": [
  null,
  ""
 ],
 "failed to list ssh host keys: $0": [
  null,
  "falha ao listar chaves locais de ssh: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "inconsistent": [
  null,
  "inconsistente"
 ],
 "journalctl manpage": [
  null,
  "manpage do journalctl"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "nenhum"
 ],
 "password quality": [
  null,
  ""
 ],
 "recommended": [
  null,
  "recomendado"
 ],
 "running $0": [
  null,
  ""
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "unknown": [
  null,
  "desconhecido"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "em $0"
 ]
});
